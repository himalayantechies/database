-- MySQL dump 10.13  Distrib 5.5.48, for Linux (x86_64)
--
-- Host: localhost    Database: oopsnepa_ccard
-- ------------------------------------------------------
-- Server version	5.5.48-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblactivity`
--

DROP TABLE IF EXISTS `tblactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblactivity` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `desc` text,
  `organisation` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `cardnumber` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblactivity`
--

LOCK TABLES `tblactivity` WRITE;
/*!40000 ALTER TABLE `tblactivity` DISABLE KEYS */;
INSERT INTO `tblactivity` (`ID`, `model`, `action`, `desc`, `organisation`, `user_id`, `created`, `cardnumber`) VALUES (1,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #L100000001 issues with 0 points',14,100,'2014-08-06 09:42:50','L100000001'),(2,'tblloyaltycardholderhistories','addpoint_loyaltycard','0 points added to cardnumber #L100000002',14,100,'2014-08-06 09:47:05','L100000002'),(3,'tblloyaltycardholderhistories','addpoint_loyaltycard','170 points added to cardnumber #L100000002',14,100,'2014-08-06 09:47:57','L100000002'),(4,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #09 issues with 50 points',14,103,'2014-08-08 07:32:19','09'),(5,'tblloyaltycardholderhistories','redeempoint_loyaltycard','8 points redeemed from cardnumber #09',14,103,'2014-08-08 07:39:12','09'),(6,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #1324 issues with 22 points',14,100,'2014-08-15 09:11:24','1324'),(7,'tblloyaltycardholderhistories','redeempoint_loyaltycard','10 points redeemed from cardnumber #1324',14,100,'2014-08-15 09:27:50','1324'),(8,'tblloyaltycardholderhistories','redeempoint_loyaltycard','6 points redeemed from cardnumber #1324',14,100,'2014-08-15 09:45:55','1324'),(9,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #;1001? issues with 1000 points',24,105,'2014-10-10 11:17:23',';1001?'),(10,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #;1002? issues with 500 points',24,105,'2014-10-10 11:19:50',';1002?'),(11,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #;1003? issues with 0 points',24,105,'2014-10-10 11:22:02',';1003?'),(12,'tblloyaltycardholderhistories','addpoint_loyaltycard','2000 points added to cardnumber #;1003?',24,105,'2014-10-10 11:23:01',';1003?'),(13,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #;1004? issues with 2500 points',24,105,'2014-10-10 11:24:40',';1004?'),(14,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #;1005? issues with 0 points',24,105,'2014-10-10 11:28:00',';1005?'),(15,'tblloyaltycardholderhistories','addpoint_loyaltycard','3000 points added to cardnumber #;1001?',24,105,'2014-10-10 11:32:50',';1001?'),(16,'tblloyaltycardholderhistories','addpoint_loyaltycard','4500 points added to cardnumber #;1002?',24,105,'2014-10-10 11:33:29',';1002?'),(17,'tblloyaltycardholderhistories','addpoint_loyaltycard','1500 points added to cardnumber #;1003?',24,105,'2014-10-10 11:33:48',';1003?'),(18,'tblloyaltycardholderhistories','addpoint_loyaltycard','6200 points added to cardnumber #;1005?',24,105,'2014-10-10 11:34:31',';1005?'),(19,'tblloyaltycardholderhistories','addpoint_loyaltycard','2800 points added to cardnumber #;1004?',24,105,'2014-10-10 11:36:14',';1004?'),(20,'tblloyaltycardholderhistories','addpoint_loyaltycard','3400 points added to cardnumber #;1004?',24,105,'2014-10-10 11:36:48',';1004?'),(21,'tblloyaltycardholderhistories','addpoint_loyaltycard','16000 points added to cardnumber #;1003?',24,105,'2014-10-10 11:38:09',';1003?'),(22,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #50000 issues with 1000 points',24,105,'2014-10-10 11:39:24','50000'),(23,'tblloyaltycardholderhistories','addpoint_loyaltycard','5200 points added to cardnumber #1003',24,105,'2014-10-11 11:19:49','1003'),(24,'tblloyaltycardholderhistories','addpoint_loyaltycard','5200 points added to cardnumber #;1005?',24,105,'2014-10-15 09:36:32',';1005?'),(25,'tblloyaltycardholderhistories','addpoint_loyaltycard','7600 points added to cardnumber #1003',24,105,'2014-10-25 12:05:10','1003'),(26,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #6745rt issues with 100 points',14,103,'2014-10-29 08:32:18','6745rt'),(27,'tblloyaltycardholderhistories','addpoint_loyaltycard','5600 points added to cardnumber #1004',24,105,'2014-10-31 11:47:54','1004'),(28,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #;1008? issues with 0 points',24,105,'2014-10-31 12:00:26',';1008?'),(29,'tblloyaltycardholderhistories','addpoint_loyaltycard','6700 points added to cardnumber #;1008?',24,105,'2014-10-31 12:00:49',';1008?'),(30,'tblloyaltycardholderhistories','addpoint_loyaltycard','4500 points added to cardnumber #;1008?',24,105,'2014-10-31 12:01:34',';1008?'),(31,'tblgiftcards','add_giftcard','#66yy66666y giftcard issues with a value of &pound;7000',32,111,'2014-12-22 16:59:05','6666666'),(32,'tblgiftcardhistories','redeem_giftcard','&pound;70 redeemed from cardnumber #;6666666',32,111,'2014-12-22 17:00:09',';6666666'),(33,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #K123456789 issues with 20 points',32,111,'2014-12-22 17:01:14','K123456789'),(34,'tblgiftcards','add_giftcard','#1991 giftcard issues with a value of &pound;5',32,111,'2014-12-23 08:42:32','1991'),(35,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #12345 issues with 5 points',32,111,'2014-12-23 08:44:27','12345'),(36,'tblgiftcardhistories','redeem_giftcard','&pound;930 redeemed from cardnumber #6666666',32,111,'2014-12-23 10:53:31','6666666'),(37,'tblgiftcards','add_giftcard','#123456 giftcard issues with a value of &pound;120',32,111,'2014-12-23 10:53:49','123456'),(38,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #9808004816 issues with 500 points',32,111,'2015-09-22 11:54:53','9808004816'),(39,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #00010 issues with 0 points',6,113,'2015-10-20 10:16:46','00010'),(40,'tblgiftcards','add_giftcard','#000101 giftcard issues with a value of &pound;10',6,113,'2015-10-20 10:17:32','000101'),(41,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #00007 issues with 0 points',24,105,'2015-11-02 10:41:39','00007'),(42,'tblloyaltycardholderhistories','addpoint_loyaltycard','1000 points added to cardnumber #00007',24,105,'2015-11-02 11:12:47','00007'),(43,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #00007 issues with 10 points',24,105,'2015-11-02 11:35:22','00007'),(44,'tblloyaltycardholderhistories','addpoint_loyaltycard','1000 points added to cardnumber #00007',24,105,'2015-11-02 12:01:56','00007'),(45,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #00004 issues with 5 points',6,101,'2015-11-03 09:50:39','00004'),(46,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #00007 issues with 100 points',24,105,'2015-11-03 12:13:22','00007'),(47,'tblloyaltycardholderhistories','addpoint_loyaltycard','1047 points added to cardnumber #00007',24,105,'2015-11-03 12:19:49','00007'),(48,'tblloyaltycardholderhistories','redeempoint_loyaltycard','100 points redeemed from cardnumber #00007',24,105,'2015-11-03 12:35:41','00007'),(49,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #00008 issues with 100 points',24,105,'2015-11-04 09:16:22','00008'),(50,'tblloyaltycardholderhistories','addpoint_loyaltycard','10000 points added to cardnumber #00007',24,105,'2015-11-04 15:37:01','00007'),(51,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #00008 issues with 1000 points',24,105,'2015-11-04 15:40:11','00008'),(52,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #7149 issues with 50 points',32,115,'2015-12-14 07:09:12','7149'),(53,'tblloyaltycardholders','new_loyaltycard','Loyaltycard #00001 issues with 0 points',6,101,'2015-12-18 13:33:00','00001'),(54,'tblloyaltycardholderhistories','addpoint_loyaltycard','3000 points added to cardnumber #00001',6,101,'2015-12-18 13:34:14','00001');
/*!40000 ALTER TABLE `tblactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgiftcard`
--

DROP TABLE IF EXISTS `tblgiftcard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgiftcard` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique ID used by the system',
  `Organisation` int(11) DEFAULT NULL COMMENT 'Foreign Key to tblOrganisation. This would be the organisation which issued the card to this customer.',
  `CardNumber` varchar(50) DEFAULT NULL COMMENT 'Number on the gift card',
  `ValueRemaining` decimal(18,2) DEFAULT NULL COMMENT 'Amount of Value Remaining On Card',
  `OriginalValue` decimal(18,2) DEFAULT NULL COMMENT 'The value on the card when it was issued',
  `Record_Created` datetime DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_CreatedBy` varchar(50) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_Revno` int(11) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_User` varchar(50) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_Updated` datetime DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  PRIMARY KEY (`ID`),
  KEY `IDX_tblGiftCard` (`Organisation`),
  CONSTRAINT `FK_tblGiftCard_tblOrganisation` FOREIGN KEY (`Organisation`) REFERENCES `tblorganisation` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgiftcard`
--

LOCK TABLES `tblgiftcard` WRITE;
/*!40000 ALTER TABLE `tblgiftcard` DISABLE KEYS */;
INSERT INTO `tblgiftcard` (`ID`, `Organisation`, `CardNumber`, `ValueRemaining`, `OriginalValue`, `Record_Created`, `Record_CreatedBy`, `Record_Revno`, `Record_User`, `Record_Updated`) VALUES (15,6,'10000',50.00,50.00,'2013-10-21 04:47:19','76',1,'76','2013-10-21 04:53:53'),(18,6,'10001',75.00,75.00,'2013-10-21 09:40:11','76',1,'76','2013-10-21 09:40:11'),(25,6,'6000',50.00,50.00,'2013-10-31 16:12:14','76',1,'76','2013-10-31 16:13:03'),(34,32,'6666666',6930.00,7000.00,'2014-12-22 16:59:05','111',1,'111','2014-12-23 10:53:31'),(35,32,'123456',120.00,120.00,'2014-12-23 10:53:49','111',1,'111','2014-12-23 10:53:49'),(36,6,'000101',10.00,10.00,'2015-10-20 10:17:32','113',1,'113','2015-10-20 10:17:32'),(37,32,'23',250.00,250.00,'2015-12-16 11:08:19','115',1,'115','2015-12-16 11:08:19'),(38,6,'00002',0.00,100.00,'2016-03-10 15:40:05','101',1,'101','2016-03-10 15:40:50');
/*!40000 ALTER TABLE `tblgiftcard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblgiftcardhistory`
--

DROP TABLE IF EXISTS `tblgiftcardhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblgiftcardhistory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique ID used by the system',
  `Organisation` int(11) DEFAULT NULL COMMENT 'Foreign Key to tblOrganisation. This would be the organisation which issued the card to this customer.',
  `GiftCardID` int(11) DEFAULT NULL COMMENT 'Foreign Key Link to tblGiftCard',
  `ValueSpent` decimal(18,2) DEFAULT NULL COMMENT 'Amount of Value Remaining On Card',
  `DateUsed` datetime DEFAULT NULL COMMENT 'The date this amount was spent',
  `Notes` longtext COMMENT 'If we ever want to keep additional information about the transaction, it can go here',
  `Record_Created` datetime DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_CreatedBy` varchar(50) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_Revno` int(11) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_User` varchar(50) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_Updated` datetime DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  PRIMARY KEY (`ID`),
  KEY `IDX_tblGiftCardHistory` (`Organisation`,`GiftCardID`),
  KEY `FK_tblGiftCardHistory_tblGiftCard` (`GiftCardID`),
  CONSTRAINT `FK_tblGiftCardHistory_tblGiftCard` FOREIGN KEY (`GiftCardID`) REFERENCES `tblgiftcard` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tblGiftCardHistory_tblOrganisation` FOREIGN KEY (`Organisation`) REFERENCES `tblorganisation` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblgiftcardhistory`
--

LOCK TABLES `tblgiftcardhistory` WRITE;
/*!40000 ALTER TABLE `tblgiftcardhistory` DISABLE KEYS */;
INSERT INTO `tblgiftcardhistory` (`ID`, `Organisation`, `GiftCardID`, `ValueSpent`, `DateUsed`, `Notes`, `Record_Created`, `Record_CreatedBy`, `Record_Revno`, `Record_User`, `Record_Updated`) VALUES (3,32,34,70.00,'2014-12-22 17:00:09','','2014-12-22 17:00:09','111',1,'111','2014-12-22 17:00:09'),(4,6,38,100.00,'2016-03-10 15:40:50',NULL,'2016-03-10 15:40:50','101',1,'101','2016-03-10 15:40:50');
/*!40000 ALTER TABLE `tblgiftcardhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloyaltycardhistory`
--

DROP TABLE IF EXISTS `tblloyaltycardhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloyaltycardhistory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique ID used by the system',
  `Organisation` int(11) DEFAULT NULL COMMENT 'Foreign Key to tblOrganisation. This would be the organisation which issued the card to this customer.',
  `LoyaltyCardID` int(11) DEFAULT NULL COMMENT 'Foreign Key Link to tblLoyaltyCardHolder',
  `Points_Redeemed` int(11) DEFAULT NULL COMMENT 'Amount of points redeemed on this occasion (if any)',
  `ValueSpent` decimal(18,2) DEFAULT NULL COMMENT 'Amount spent in £, in order to earn points',
  `PointsAdded` int(11) DEFAULT NULL COMMENT 'Points added at this time',
  `DateUsed` datetime DEFAULT NULL COMMENT 'The date this amount was spent',
  `Notes` longtext COMMENT 'If we ever want to keep additional information about the transaction, it can go here',
  `Record_Created` datetime DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_CreatedBy` varchar(50) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_Revno` int(11) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_User` varchar(50) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_Updated` datetime DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  PRIMARY KEY (`ID`),
  KEY `IDX_tblLoyaltyCardHistory` (`Organisation`,`LoyaltyCardID`),
  KEY `FK_tblLoyaltyCardHistory_tblLoyaltyCardHolder` (`LoyaltyCardID`),
  CONSTRAINT `FK_tblLoyaltyCardHistory_tblLoyaltyCardHolder` FOREIGN KEY (`LoyaltyCardID`) REFERENCES `tblloyaltycardholder` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_tblLoyaltyCardHistory_tblOrganisation` FOREIGN KEY (`Organisation`) REFERENCES `tblorganisation` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloyaltycardhistory`
--

LOCK TABLES `tblloyaltycardhistory` WRITE;
/*!40000 ALTER TABLE `tblloyaltycardhistory` DISABLE KEYS */;
INSERT INTO `tblloyaltycardhistory` (`ID`, `Organisation`, `LoyaltyCardID`, `Points_Redeemed`, `ValueSpent`, `PointsAdded`, `DateUsed`, `Notes`, `Record_Created`, `Record_CreatedBy`, `Record_Revno`, `Record_User`, `Record_Updated`) VALUES (164,6,87,0,25.00,750,'2014-07-28 08:51:45','','2014-07-28 08:51:45','101',1,'101','2014-07-28 08:51:45'),(165,6,87,0,44.00,1320,'2014-07-28 08:52:35','','2014-07-28 08:52:35','101',1,'101','2014-07-28 08:52:35'),(166,6,87,0,78.00,2340,'2014-07-28 08:52:48','','2014-07-28 08:52:48','101',1,'101','2014-07-28 08:52:48'),(172,24,98,0,20.00,2000,'2014-10-10 11:23:01','','2014-10-10 11:23:01','105',1,'105','2014-10-10 11:23:01'),(173,24,96,0,30.00,3000,'2014-10-10 11:32:50','','2014-10-10 11:32:50','105',1,'105','2014-10-10 11:32:50'),(174,24,97,0,45.00,4500,'2014-10-10 11:33:29','','2014-10-10 11:33:29','105',1,'105','2014-10-10 11:33:29'),(175,24,98,0,15.00,1500,'2014-10-10 11:33:48','','2014-10-10 11:33:48','105',1,'105','2014-10-10 11:33:48'),(176,24,100,0,62.00,6200,'2014-10-10 11:34:31','','2014-10-10 11:34:31','105',1,'105','2014-10-10 11:34:31'),(177,24,99,0,28.00,2800,'2014-10-10 11:36:14','','2014-10-10 11:36:14','105',1,'105','2014-10-10 11:36:14'),(178,24,99,0,34.00,3400,'2014-10-10 11:36:48','','2014-10-10 11:36:48','105',1,'105','2014-10-10 11:36:48'),(179,24,98,0,160.00,16000,'2014-10-10 11:38:09','testing manual entry','2014-10-10 11:38:09','105',1,'105','2014-10-10 11:38:09'),(180,24,98,0,52.00,5200,'2014-10-11 11:19:49','','2014-10-11 11:19:49','105',1,'105','2014-10-11 11:19:49'),(181,24,100,0,52.00,5200,'2014-10-15 09:36:32','','2014-10-15 09:36:32','105',1,'105','2014-10-15 09:36:32'),(182,24,98,0,76.00,7600,'2014-10-25 12:05:10','','2014-10-25 12:05:10','105',1,'105','2014-10-25 12:05:10'),(183,24,99,0,56.00,5600,'2014-10-31 11:47:54','','2014-10-31 11:47:54','105',1,'105','2014-10-31 11:47:54'),(184,24,101,0,67.00,6700,'2014-10-31 12:00:49','','2014-10-31 12:00:49','105',1,'105','2014-10-31 12:00:49'),(185,24,101,0,45.00,4500,'2014-10-31 12:01:33','','2014-10-31 12:01:33','105',1,'105','2014-10-31 12:01:33'),(188,24,108,0,10.47,1047,'2015-11-03 12:19:49','','2015-11-03 12:19:49','105',1,'105','2015-11-03 12:19:49'),(189,24,108,100,1.00,0,'2015-11-03 12:35:41','used 100 points to get a bottle of pop','2015-11-03 12:35:41','105',1,'105','2015-11-03 12:35:41'),(190,24,108,0,100.00,10000,'2015-11-04 15:37:01','another add points test\r\n','2015-11-04 15:37:01','105',1,'105','2015-11-04 15:37:01'),(191,1,87,0,500.00,15000,'2015-11-23 08:30:41',NULL,'2015-11-23 08:30:41','55',1,'55','2015-11-23 08:30:41'),(192,1,87,800,26.67,0,'2015-11-23 08:35:42',NULL,'2015-11-23 08:35:42','55',1,'55','2015-11-23 08:35:42'),(193,32,102,0,850.00,10200,'2015-11-23 08:50:20',NULL,'2015-11-23 08:50:20','115',1,'115','2015-11-23 08:50:20'),(194,32,102,250,20.83,0,'2015-11-23 10:07:03',NULL,'2015-11-23 10:07:03','115',1,'115','2015-11-23 10:07:03'),(195,NULL,110,0,2.00,2,'2015-12-16 10:31:24',NULL,'2015-12-16 10:31:24',NULL,1,NULL,'2015-12-16 10:31:24'),(196,NULL,110,21,21.00,0,'2015-12-16 10:31:41',NULL,'2015-12-16 10:31:41',NULL,1,NULL,'2015-12-16 10:31:41'),(197,32,111,0,2.00,24,'2015-12-16 10:55:53',NULL,'2015-12-16 10:55:53','115',1,'115','2015-12-16 10:55:53'),(198,32,111,23,1.92,0,'2015-12-16 10:56:11',NULL,'2015-12-16 10:56:11','115',1,'115','2015-12-16 10:56:11'),(199,6,113,0,100.00,3000,'2015-12-18 13:34:14','','2015-12-18 13:34:14','101',1,'101','2015-12-18 13:34:14'),(200,6,113,0,100.00,3000,'2015-12-18 15:07:00',NULL,'2015-12-18 15:07:00','101',1,'101','2015-12-18 15:07:00'),(201,6,113,0,100.00,3000,'2015-12-18 15:21:44',NULL,'2015-12-18 15:21:44','101',1,'101','2015-12-18 15:21:44'),(202,6,113,5000,166.67,0,'2015-12-18 15:23:27',NULL,'2015-12-18 15:23:27','101',1,'101','2015-12-18 15:23:27'),(204,6,113,0,100.00,3000,'2016-03-10 15:30:52',NULL,'2016-03-10 15:30:52','101',1,'101','2016-03-10 15:30:52'),(205,6,113,0,100.00,3000,'2016-03-10 15:31:37',NULL,'2016-03-10 15:31:37','101',1,'101','2016-03-10 15:31:37'),(206,6,113,1000,33.33,0,'2016-03-10 15:36:51',NULL,'2016-03-10 15:36:51','101',1,'101','2016-03-10 15:36:51'),(207,6,113,0,10.00,300,'2016-03-21 11:13:20',NULL,'2016-03-21 11:13:20','101',1,'101','2016-03-21 11:13:20');
/*!40000 ALTER TABLE `tblloyaltycardhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloyaltycardholder`
--

DROP TABLE IF EXISTS `tblloyaltycardholder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloyaltycardholder` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique ID used by the system',
  `Organisation` int(11) DEFAULT NULL COMMENT 'Foreign Key to tblOrganisation. This would be the organisation which issued the card to this customer.',
  `FirstName` varchar(100) DEFAULT NULL COMMENT 'Name of user. These are optional.',
  `MiddleName` varchar(100) DEFAULT NULL,
  `Surname` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `age` varchar(100) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `Address1` varchar(100) DEFAULT NULL,
  `Address2` varchar(100) DEFAULT NULL,
  `Address3` varchar(100) DEFAULT NULL,
  `Town` varchar(50) DEFAULT NULL,
  `County` varchar(50) DEFAULT NULL,
  `Country` varchar(50) DEFAULT NULL,
  `Postcode` varchar(20) DEFAULT NULL,
  `Email1` varchar(200) DEFAULT NULL COMMENT 'This will serve as their login too',
  `Email2` varchar(200) DEFAULT NULL,
  `Telephone` varchar(50) DEFAULT NULL,
  `CardNumber` varchar(50) DEFAULT NULL,
  `ValueSpent` decimal(18,2) DEFAULT NULL COMMENT 'Amount the card holder has spent with the organisation',
  `Points` int(11) DEFAULT NULL COMMENT 'The number of points on the card',
  `Email_Marketing_Opt_In` tinyint(1) DEFAULT NULL COMMENT 'Default False. This is a flag to show if the client has agreed to receive email marketing information',
  `Activated` int(1) NOT NULL DEFAULT '0',
  `Record_Created` datetime DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_CreatedBy` varchar(50) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_Revno` int(11) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_User` varchar(50) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_Updated` datetime DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  PRIMARY KEY (`ID`),
  KEY `IDX_tblLoyaltyCardHolder` (`Organisation`,`Email1`),
  CONSTRAINT `FK_tblLoyaltyCardHolder_tblOrganisation` FOREIGN KEY (`Organisation`) REFERENCES `tblorganisation` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloyaltycardholder`
--

LOCK TABLES `tblloyaltycardholder` WRITE;
/*!40000 ALTER TABLE `tblloyaltycardholder` DISABLE KEYS */;
INSERT INTO `tblloyaltycardholder` (`ID`, `Organisation`, `FirstName`, `MiddleName`, `Surname`, `password`, `DateOfBirth`, `age`, `occupation`, `Address1`, `Address2`, `Address3`, `Town`, `County`, `Country`, `Postcode`, `Email1`, `Email2`, `Telephone`, `CardNumber`, `ValueSpent`, `Points`, `Email_Marketing_Opt_In`, `Activated`, `Record_Created`, `Record_CreatedBy`, `Record_Revno`, `Record_User`, `Record_Updated`) VALUES (25,6,'John','','Smith','',NULL,NULL,NULL,'1 Nowhere Road','','','Exeter','','UK','EX1 3QT','JSMITH@GMAIL.COM','','','10050',0.00,0,0,1,'2013-10-31 15:46:39','76',1,'76','2013-10-31 15:52:51'),(87,6,'Kandy','M.','Solutions','123456','2014-07-09','','','119 Crespi Drive','','21','San Francisco','CA','United States','94132','login@himalayantechies.com','','4155084503','123456789',673.67,18610,0,0,'2014-07-28 08:49:29','101',1,'55','2015-11-23 08:35:42'),(96,24,'Carol',NULL,'White',NULL,NULL,NULL,NULL,'The Cottage','High Street','n/a','Anytown',NULL,NULL,'GF4 5RT','Carol@gmail.com',NULL,'123698547','1001',30.00,4000,1,0,'2014-10-10 11:17:23','105',1,'105','2014-10-17 10:02:21'),(97,24,'Daniel',NULL,'Black',NULL,NULL,NULL,NULL,'Corner House','Back Street','n/a','Newtown',NULL,NULL,'jk87 67yt','Daniel@thingy.co.uk',NULL,'147896523','1002',45.00,5000,1,0,'2014-10-10 11:19:50','105',1,'105','2014-10-17 10:02:49'),(98,24,'Brian',NULL,'Pink',NULL,NULL,NULL,NULL,'Flat 1','Primrose house','Long Way','Nicetown',NULL,NULL,'hj87 SD54','Brian@hjgutrf.com',NULL,'54698712','1003',323.00,32300,1,0,'2014-10-10 11:22:00','105',1,'105','2014-10-25 12:05:10'),(99,24,'Terry',NULL,'Towel',NULL,NULL,NULL,NULL,'New House','Long Lane','n/a','Toytown',NULL,NULL,'DF54 6TY','Tery@jhgfds.com',NULL,'45698712','1004',118.00,14300,0,0,'2014-10-10 11:24:40','105',1,'105','2014-10-31 11:47:54'),(100,24,'Sheila',NULL,'Green',NULL,NULL,NULL,NULL,'The big place','Shrubbery Close','n/a','Newtown',NULL,NULL,'GH67 8DF','Sheila@kjhgfds.com',NULL,'456985214','1005',114.00,11400,1,0,'2014-10-10 11:28:00','105',1,'105','2014-10-17 10:03:47'),(101,24,'Richard',NULL,'Green',NULL,NULL,NULL,NULL,'The big house','New Street','Darl Lane','Toytown',NULL,NULL,'gh2 34m','lufd@iug.com',NULL,'123654789','1008',112.00,11200,0,0,'2014-10-31 12:00:26','105',1,'105','2014-10-31 12:01:34'),(102,32,'Kandy','M.','Solutions',NULL,'1970-01-01',NULL,NULL,'119 Crespi Drive','12','21','San Francisco','CA','United States','94132','bob123@himalayantechies.com','','4155084503','123456789',870.83,9970,1,0,'2014-12-22 17:01:14','111',1,'115','2015-11-23 10:07:03'),(103,32,'Shikha','N/A','Kedia',NULL,'1989-08-02',NULL,NULL,'119 Crespi Drive','Apartment B','N/A','San Francisco','N/A','Nepal','985124','shikha@himalayantechies.com','','9808004817','9808004816',0.00,500,0,0,'2015-09-22 11:54:53','111',1,'111','2015-09-22 11:54:53'),(104,6,'Edward','','Gwernan-Jones',NULL,'1970-01-01','22','','Test','',NULL,'','','','Ex14 test','edward@kandysolutions.co.uk','','','00010',0.00,0,0,0,'2015-10-20 10:16:46','113',1,'113','2015-10-20 10:16:46'),(107,6,'Edward','','Gwernan-Jones','1349dbcedf47a83cde7c279c770caed4acb777e9',NULL,'','','Greenbanks','',NULL,'','','','EX14 3BU','edwardgwer.jones@gmail.com','','','00004',0.00,5,0,0,'2015-11-03 09:50:39','101',1,'101','2015-11-03 09:50:39'),(108,24,'Julian',NULL,'Hicks','1cf7b975dd149e0193a2b975b7b4bae5ff1e7142',NULL,NULL,NULL,'Ffynnonston','Dwrbach','','Fishguard','Pembrokeshire',NULL,'SA65 9QT','JulianGHicks@hotmail.com',NULL,'01348873570','00007',111.47,11047,0,0,'2015-11-03 12:13:22','105',1,'105','2015-11-04 15:37:01'),(109,32,'pores','pores','paut','79334f9a7481731e732ed885728ac2a3007c2312','2015-01-12',NULL,NULL,'address1','address2','address3','town','county','cntry','4567','asingh@himalayantechies.com','arpita_92@hotmail.com','9878675432','7149',0.00,50,1,0,'2015-12-14 07:09:12','115',1,'115','2015-12-14 07:09:12'),(110,NULL,'arpi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'arpi@singh.com',NULL,NULL,'123',23.00,4,NULL,0,'2015-12-16 10:31:04',NULL,1,NULL,'2015-12-16 10:31:41'),(111,32,'ret',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ret@ret.com',NULL,NULL,'567',3.92,21,NULL,0,'2015-12-16 10:55:36','115',1,'115','2015-12-16 10:56:11'),(112,6,'andrew',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Aemogford@Gmail.Com',NULL,NULL,'898766',0.00,500,NULL,0,'2015-12-17 09:42:36','113',1,'113','2015-12-17 09:42:36'),(113,6,'Julian','Glyn','Hicks',NULL,'1970-01-01','53','Producer','Ffynnonston','Dwrbach',NULL,'Fishguard','Pembrokeshire','UK','SA659QT','JulianGHicks@hotmail.com','','01348873570','00001',710.00,9300,0,0,'2015-12-18 13:33:00','101',1,'101','2016-03-21 11:13:20'),(114,6,'Tested on Netbook',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'flip@flop',NULL,NULL,'00005',0.00,100,NULL,0,'2016-03-21 11:46:02','101',1,'101','2016-03-21 11:46:02');
/*!40000 ALTER TABLE `tblloyaltycardholder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloyaltycardholdersetting`
--

DROP TABLE IF EXISTS `tblloyaltycardholdersetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblloyaltycardholdersetting` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique ID used by the system',
  `Organisation` int(11) NOT NULL COMMENT 'Foreign Key to tblOrganisation. This would be the organisation which issued the card to this customer.',
  `Fieldname` varchar(255) NOT NULL,
  `Labelname` varchar(255) DEFAULT NULL,
  `IsVisible` tinyint(1) NOT NULL,
  `Ismandatory` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_tblLoyaltyCardHolder` (`Organisation`),
  CONSTRAINT `tblloyaltycardholdersetting_ibfk_1` FOREIGN KEY (`Organisation`) REFERENCES `tblorganisation` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=775 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloyaltycardholdersetting`
--

LOCK TABLES `tblloyaltycardholdersetting` WRITE;
/*!40000 ALTER TABLE `tblloyaltycardholdersetting` DISABLE KEYS */;
INSERT INTO `tblloyaltycardholdersetting` (`ID`, `Organisation`, `Fieldname`, `Labelname`, `IsVisible`, `Ismandatory`) VALUES (123,1,'FirstName','First Name',1,1),(124,1,'MiddleName','Middle Name',1,1),(125,1,'Surname','Surname',1,1),(126,1,'DateOfBirth','Date Of Birth',1,1),(127,1,'Address1','Address1',1,1),(128,1,'Address2','Address2',1,1),(129,1,'Address3','Address3',1,1),(130,1,'Town','Town',1,1),(131,1,'County','County',1,1),(132,1,'Country','Country',1,1),(133,1,'Postcode','Postcode',1,1),(134,1,'Email1','Email1',1,1),(135,1,'Email2','Email2',1,1),(136,1,'Telephone','Telephone',1,1),(137,1,'Points','Points',1,1),(138,1,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(427,21,'FirstName','First Name',1,1),(428,21,'MiddleName','Middle Name',1,1),(429,21,'Surname','Surname',1,1),(430,21,'DateOfBirth','Date Of Birth',1,1),(431,21,'Address1','Address1',1,1),(432,21,'Address2','Address2',1,1),(433,21,'Address3','Address3',1,1),(434,21,'Town','Town',1,1),(435,21,'County','County',1,1),(436,21,'Country','Country',1,1),(437,21,'Postcode','Postcode',1,1),(438,21,'Email1','Email1',1,1),(439,21,'Email2','Email2',1,1),(440,21,'Telephone','Telephone',1,1),(441,21,'Points','Points',1,1),(442,21,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(443,1,'age','Age',1,1),(444,1,'occupation','Occupation',1,1),(463,21,'age','Age',1,1),(464,21,'occupation','Occupation',1,1),(465,1,'FirstName','First Name',1,1),(466,1,'MiddleName','Middle Name',1,1),(467,1,'Surname','Surname',1,1),(468,1,'DateOfBirth','Date Of Birth',1,1),(469,1,'Address1','Address1',1,1),(470,1,'Address2','Address2',1,1),(471,1,'Address3','Address3',1,1),(472,1,'Town','Town',1,1),(473,1,'County','County',1,1),(474,1,'Country','Country',1,1),(475,1,'Postcode','Postcode',1,1),(476,1,'Email1','Email1',1,1),(477,1,'Email2','Email2',1,1),(478,1,'Telephone','Telephone',1,1),(479,1,'Points','Points',1,1),(480,1,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(481,22,'FirstName','First Name',1,1),(482,22,'MiddleName','Middle Name',1,1),(483,22,'Surname','Surname',1,1),(484,22,'DateOfBirth','Date Of Birth',1,1),(485,22,'age','Age',1,1),(486,22,'occupation','Occupation',1,1),(487,22,'Address1','Address1',1,1),(488,22,'Address2','Address2',1,1),(489,22,'Address3','Address3',1,1),(490,22,'Town','Town',1,1),(491,22,'County','County',1,1),(492,22,'Country','Country',1,1),(493,22,'Postcode','Postcode',1,1),(494,22,'Email1','Email1',1,1),(495,22,'Email2','Email2',1,1),(496,22,'Telephone','Telephone',1,1),(497,22,'Points','Points',1,1),(498,22,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(499,6,'FirstName','First Name',1,1),(500,6,'MiddleName','Middle Name',1,0),(501,6,'Surname','Surname',1,1),(502,6,'DateOfBirth','Date Of Birth',1,0),(503,6,'age','Age',1,0),(504,6,'occupation','Occupation',1,0),(505,6,'Address1','Address1',1,1),(506,6,'Address2','Address2',1,0),(507,6,'Address3','Address3',0,0),(508,6,'Town','Town',1,0),(509,6,'County','County',1,0),(510,6,'Country','Country',1,0),(511,6,'Postcode','Postcode',1,1),(512,6,'Email1','Email1',1,1),(513,6,'Email2','Email2',1,0),(514,6,'Telephone','Telephone',1,0),(515,6,'Points','Points',1,1),(516,6,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(517,1,'FirstName','First Name',1,1),(518,1,'MiddleName','Middle Name',1,1),(519,1,'Surname','Surname',1,1),(520,1,'DateOfBirth','Date Of Birth',1,1),(521,1,'Address1','Address1',1,1),(522,1,'Address2','Address2',1,1),(523,1,'Address3','Address3',1,1),(524,1,'Town','Town',1,1),(525,1,'County','County',1,1),(526,1,'Country','Country',1,1),(527,1,'Postcode','Postcode',1,1),(528,1,'Email1','Email1',1,1),(529,1,'Email2','Email2',1,1),(530,1,'Telephone','Telephone',1,1),(531,1,'Points','Points',1,1),(532,1,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(533,1,'FirstName','First Name',1,1),(534,1,'MiddleName','Middle Name',1,1),(535,1,'Surname','Surname',1,1),(536,1,'DateOfBirth','Date Of Birth',1,1),(537,1,'Address1','Address1',1,1),(538,1,'Address2','Address2',1,1),(539,1,'Address3','Address3',1,1),(540,1,'Town','Town',1,1),(541,1,'County','County',1,1),(542,1,'Country','Country',1,1),(543,1,'Postcode','Postcode',1,1),(544,1,'Email1','Email1',1,1),(545,1,'Email2','Email2',1,1),(546,1,'Telephone','Telephone',1,1),(547,1,'Points','Points',1,1),(548,1,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(549,1,'FirstName','First Name',1,1),(550,1,'MiddleName','Middle Name',1,1),(551,1,'Surname','Surname',1,1),(552,1,'DateOfBirth','Date Of Birth',1,1),(553,1,'Address1','Address1',1,1),(554,1,'Address2','Address2',1,1),(555,1,'Address3','Address3',1,1),(556,1,'Town','Town',1,1),(557,1,'County','County',1,1),(558,1,'Country','Country',1,1),(559,1,'Postcode','Postcode',1,1),(560,1,'Email1','Email1',1,1),(561,1,'Email2','Email2',1,1),(562,1,'Telephone','Telephone',1,1),(563,1,'Points','Points',1,1),(564,1,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(565,1,'FirstName','First Name',1,1),(566,1,'MiddleName','Middle Name',1,1),(567,1,'Surname','Surname',1,1),(568,1,'DateOfBirth','Date Of Birth',1,1),(569,1,'Address1','Address1',1,1),(570,1,'Address2','Address2',1,1),(571,1,'Address3','Address3',1,1),(572,1,'Town','Town',1,1),(573,1,'County','County',1,1),(574,1,'Country','Country',1,1),(575,1,'Postcode','Postcode',1,1),(576,1,'Email1','Email1',1,1),(577,1,'Email2','Email2',1,1),(578,1,'Telephone','Telephone',1,1),(579,1,'Points','Points',1,1),(580,1,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(581,24,'FirstName','First Name',1,1),(582,24,'MiddleName','Middle Name',0,0),(583,24,'Surname','Surname',1,1),(584,24,'DateOfBirth','Date Of Birth',0,0),(585,24,'age','Age',0,0),(586,24,'occupation','Occupation',0,0),(587,24,'Address1','Address1',1,1),(588,24,'Address2','Address2',1,1),(589,24,'Address3','Address3',1,0),(590,24,'Town','Town',1,1),(591,24,'County','County',1,0),(592,24,'Country','Country',0,0),(593,24,'Postcode','Postcode',1,1),(594,24,'Email1','Email1',1,1),(595,24,'Email2','Email2',0,0),(596,24,'Telephone','Telephone',1,1),(597,24,'Points','Points',1,1),(598,24,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(599,1,'FirstName','First Name',1,1),(600,1,'MiddleName','Middle Name',1,1),(601,1,'Surname','Surname',1,1),(602,1,'DateOfBirth','Date Of Birth',1,1),(603,1,'Address1','Address1',1,1),(604,1,'Address2','Address2',1,1),(605,1,'Address3','Address3',1,1),(606,1,'Town','Town',1,1),(607,1,'County','County',1,1),(608,1,'Country','Country',1,1),(609,1,'Postcode','Postcode',1,1),(610,1,'Email1','Email1',1,1),(611,1,'Email2','Email2',1,1),(612,1,'Telephone','Telephone',1,1),(613,1,'Points','Points',1,1),(614,1,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(615,1,'FirstName','First Name',1,1),(616,1,'MiddleName','Middle Name',1,1),(617,1,'Surname','Surname',1,1),(618,1,'DateOfBirth','Date Of Birth',1,1),(619,1,'Address1','Address1',1,1),(620,1,'Address2','Address2',1,1),(621,1,'Address3','Address3',1,1),(622,1,'Town','Town',1,1),(623,1,'County','County',1,1),(624,1,'Country','Country',1,1),(625,1,'Postcode','Postcode',1,1),(626,1,'Email1','Email1',1,1),(627,1,'Email2','Email2',1,1),(628,1,'Telephone','Telephone',1,1),(629,1,'Points','Points',1,1),(630,1,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(743,32,'FirstName','First Name',1,1),(744,32,'MiddleName','Middle Name',1,1),(745,32,'Surname','Surname',1,1),(746,32,'DateOfBirth','Date Of Birth',1,1),(747,32,'Address1','Address1',1,1),(748,32,'Address2','Address2',1,1),(749,32,'Address3','Address3',1,1),(750,32,'Town','Town',1,1),(751,32,'County','County',1,1),(752,32,'Country','Country',1,1),(753,32,'Postcode','Postcode',1,1),(754,32,'Email1','Email1',1,1),(755,32,'Email2','Email2',1,1),(756,32,'Telephone','Telephone',1,1),(757,32,'Points','Points',1,1),(758,32,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1),(759,33,'FirstName','First Name',1,1),(760,33,'MiddleName','Middle Name',1,1),(761,33,'Surname','Surname',1,1),(762,33,'DateOfBirth','Date Of Birth',1,1),(763,33,'Address1','Address1',1,1),(764,33,'Address2','Address2',1,1),(765,33,'Address3','Address3',1,1),(766,33,'Town','Town',1,1),(767,33,'County','County',1,1),(768,33,'Country','Country',1,1),(769,33,'Postcode','Postcode',1,1),(770,33,'Email1','Email1',1,1),(771,33,'Email2','Email2',1,1),(772,33,'Telephone','Telephone',1,1),(773,33,'Points','Points',1,1),(774,33,'Email_Marketing_Opt_In','Email_Marketing_Opt_In',1,1);
/*!40000 ALTER TABLE `tblloyaltycardholdersetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblorganisation`
--

DROP TABLE IF EXISTS `tblorganisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblorganisation` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique ID used by the system',
  `Name` varchar(200) NOT NULL COMMENT 'Name of Organisation',
  `PointsPerPoundSpent` int(11) DEFAULT NULL,
  `Address1` varchar(100) NOT NULL,
  `Address2` varchar(100) NOT NULL,
  `Address3` varchar(100) NOT NULL,
  `Town` varchar(50) NOT NULL,
  `County` varchar(50) NOT NULL,
  `Country` varchar(50) NOT NULL,
  `Postcode` varchar(20) NOT NULL,
  `Telephone1` varchar(50) NOT NULL,
  `Telephone2` varchar(50) NOT NULL,
  `Telephone3` varchar(50) NOT NULL,
  `Fax` varchar(200) NOT NULL,
  `Email1` varchar(200) NOT NULL,
  `Email2` varchar(200) NOT NULL,
  `Active` tinyint(1) NOT NULL COMMENT 'Indicates if this organisation is a current user of the loyalty card system',
  `Logo` longtext NOT NULL COMMENT 'The path for the logo of this customer. This would permit personalisation of web pages.',
  `OrgGUID` varchar(64) DEFAULT NULL COMMENT 'This is a very long random number, that will be unique. This can be used in the link to the organisations card holder pages, so that is not possible to look at other organisations pages simply by guessing their ID',
  `Record_Created` datetime DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_CreatedBy` varchar(50) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_Revno` int(11) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_User` varchar(50) DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  `Record_Updated` datetime DEFAULT NULL COMMENT 'System Columns to track when record was created and edited',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UN_tblOrganisation_OrgGUID` (`OrgGUID`),
  KEY `IDX_tblOrganisation` (`Name`,`Postcode`,`Email1`,`Email2`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblorganisation`
--

LOCK TABLES `tblorganisation` WRITE;
/*!40000 ALTER TABLE `tblorganisation` DISABLE KEYS */;
INSERT INTO `tblorganisation` (`ID`, `Name`, `PointsPerPoundSpent`, `Address1`, `Address2`, `Address3`, `Town`, `County`, `Country`, `Postcode`, `Telephone1`, `Telephone2`, `Telephone3`, `Fax`, `Email1`, `Email2`, `Active`, `Logo`, `OrgGUID`, `Record_Created`, `Record_CreatedBy`, `Record_Revno`, `Record_User`, `Record_Updated`) VALUES (1,'Concept Card',0,'33 Baxton Street','','','Bapton','Tivertron','United Kingdom','ET 3TT','','','','','info@conceptcard.com','admin@conceptcard.com',1,'','234555122354','2013-10-19 11:31:00','',NULL,'55','2015-09-22 11:31:44'),(6,'Kandy Solutions Limited',30,'Littlebrook Cottage','Frog Street','Bampton','Tiverton','Devon','UK','EX16 9NT','07715486701','','','','andrew@kandysolutions.co.uk','',1,'','eb222ecac913180babf6a5faa50f39498caf52d1','2013-10-21 04:29:06','55',1,'101','2014-07-28 08:50:38'),(21,'Jewellery Box',10,'174 Westgate','','','Bradford','West Yorkshire','United Kingdom','BD1 2RN','01274 392400','07867772999','','','sharazmughal@hotmail.com','',1,'','008e8551486dc7e7ec43d6d1b504f3baeccba7a9','2014-06-09 14:08:23','55',1,'55','2014-06-09 14:08:23'),(22,'Westcars',10,'11 Blundells Road','','','Tiverton','','','EX16 4DB','08431 785 224','','','','stuart@westcars-tiverton.com','',1,'','2e16f0b241141192d3eca28b49ff4c92a654cefe','2014-07-28 07:29:37','55',1,'55','2015-09-22 11:32:07'),(23,'Handyman\'s Hardware Ltd',1,'71 High Street','DIY District','','Handytown','Devon','United Kingdom','EX17 1DW','01363 773530','','','','blokie7@gmail.com','',0,'','53c242f1db0faacceb7cdc3f3ec5a871c5228a61','2014-07-28 11:45:09','98',1,'98','2014-07-28 11:45:09'),(24,'Customer Loyalty Plus',100,'4 Lake View','','','Crediton','Devon','United Kingdom','EX17 1DW','07974 834381','01363 773530','','','customerloyaltyplus@gmail.com','',1,'','fa13c989fbe41d7cc7bc11529720143917ac5187','2014-10-10 10:44:29','98',1,'98','2014-10-10 10:44:29'),(32,'HimalayanTechies',12,'Sanepa','','','Kathmandu','London','Nepal','3S3D3D','5551007','','','','bob@himalayantechies.com','',1,'','074aea09351e5c687de490da730e5d1f17456bd9','2014-12-22 16:55:19','55',1,'55','2015-09-22 11:50:12'),(33,'Tabletop Towns',100,'Ffynnonston','Dwrbach','','Fishguard','Pembrokeshire','UK','SA659QT','01348873570','07969953297','','','Julian@tabletoptowns.co.uk','',1,'','3b336031a93641ceecbab65c7481de129ee01e33','2016-03-30 10:45:20','55',1,'55','2016-03-30 10:45:20');
/*!40000 ALTER TABLE `tblorganisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblorganisationuser`
--

DROP TABLE IF EXISTS `tblorganisationuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblorganisationuser` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique ID used by the system',
  `Organisation` int(11) DEFAULT NULL COMMENT 'Foreign Key to tblOrganisation',
  `FirstName` varchar(100) DEFAULT NULL COMMENT 'Name of user',
  `MiddleName` varchar(100) DEFAULT NULL,
  `Surname` varchar(100) DEFAULT NULL,
  `Email1` varchar(200) DEFAULT NULL COMMENT 'This will serve as their login too',
  `Email2` varchar(200) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL COMMENT 'Encrypted column',
  `Record_Created` datetime DEFAULT NULL,
  `Record_CreatedBy` varchar(50) DEFAULT NULL,
  `Record_Revno` int(11) DEFAULT NULL,
  `Record_User` varchar(50) DEFAULT NULL,
  `Record_Updated` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_tblOrganisationUser` (`Organisation`,`Email1`),
  CONSTRAINT `FK_tblOrganisationUser_tblOrganisation` FOREIGN KEY (`Organisation`) REFERENCES `tblorganisation` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblorganisationuser`
--

LOCK TABLES `tblorganisationuser` WRITE;
/*!40000 ALTER TABLE `tblorganisationuser` DISABLE KEYS */;
INSERT INTO `tblorganisationuser` (`ID`, `Organisation`, `FirstName`, `MiddleName`, `Surname`, `Email1`, `Email2`, `Password`, `Record_Created`, `Record_CreatedBy`, `Record_Revno`, `Record_User`, `Record_Updated`) VALUES (55,1,'Vaibhaw','','Poddar','login@conceptcard.com','logout@conceptcard.com','47eda41da4512cbaf020a4b3ccdbdd910dc0e25e','2013-10-19 16:40:00','',NULL,'55','2013-11-21 06:14:57'),(95,21,'Sharaz','','Mughal','sharazmughal@hotmail.com','sm2ugl@googlemail.com','56935adeb5be21e9c34bfc8fccf404504c978a45','2014-06-09 14:11:03','55',1,'55','2014-06-09 14:11:03'),(97,22,'Stuart','','Ward','stuart@westcars-tiverton.com','','7cb034d4c3a5437f4415c3a2ec6cf49988f1a0a3','2014-07-28 07:46:45','55',1,'55','2014-07-28 07:46:45'),(98,1,'Paul','','Brown','paul@conceptcard.co.uk','','18e352917db34b1847552c5ab52fc988d3254405','2014-07-28 08:21:42','55',1,'55','2014-07-28 08:21:42'),(99,1,'Andrew','','Mogford','aemogford@gmail.com','aemogford@gmail.com','f828e34ff7e0857a93a97c2d28efa5348e8a09d8','2014-07-28 08:36:00','55',1,'55','2014-07-28 08:36:00'),(101,6,'Andrew','','Mogford','concept@kandysolutions.co.uk','','47eda41da4512cbaf020a4b3ccdbdd910dc0e25e','2014-07-28 08:46:31','98',1,'98','2014-07-28 08:46:31'),(102,23,'Paul','Geoffrey','Brown','blokie7@gmail.com','','7d524beda88aed30f2557decb4ed45cb9f3c7c5c','2014-07-28 11:50:42','98',1,'98','2014-07-28 11:50:42'),(105,24,'Paul','','Brown','customerloyaltyplus@gmail.com','','7d524beda88aed30f2557decb4ed45cb9f3c7c5c','2014-10-10 10:51:05','98',1,'98','2014-10-10 10:51:05'),(106,1,'Edward','Hugh','Gwernan-Jones','edwardgwer.jones@gmail.com','','72e1146df9062ae5967c53b5995478e4186c2eab','2014-10-17 08:21:33','99',1,'99','2014-10-17 08:21:33'),(111,32,'HimalayanTechies',NULL,NULL,'bob@himalayantechies.com',NULL,'af20187a3f142de429f2685c51d922abd82fbbda','2014-12-22 16:55:19','55',1,'55','2014-12-22 16:55:19'),(113,6,'Edward','','Gwernan-Jones','edward@kandysolutions.co.uk','','71ce626ee5396a23742edafb85e1f583c38447a8','2015-09-25 15:18:26','101',1,'101','2015-09-25 15:18:26'),(114,6,'Julian','','Hicks','julianghicks@hotmail.com','','80ac0cabdb2a805eec7b132147e9ba79fbf35942','2015-11-10 13:37:50','101',1,'101','2015-11-10 13:37:50'),(115,32,'Himalayan','','Tecies','info@himalayantechies.com','','47eda41da4512cbaf020a4b3ccdbdd910dc0e25e','2015-11-23 08:47:01','55',1,'55','2015-11-23 08:47:01'),(116,32,'Sakshi','','Agrawal','sagrawal@himalayantechies.com','sagrawal@khumbaya.com','7e8c54bf4110d6702ce75654b1fe5773d5182772','2015-12-21 05:42:56','55',1,'55','2015-12-21 05:42:56'),(117,6,'Test','','Test','marketing@conceptcard.co.uk','','47eda41da4512cbaf020a4b3ccdbdd910dc0e25e','2016-03-21 12:18:53','101',1,'101','2016-03-21 12:18:53'),(118,33,'Tabletop Towns',NULL,NULL,'Julian@tabletoptowns.co.uk',NULL,'ba4db132776074b626c43813f7f8a28b2d524d41','2016-03-30 10:45:21','55',1,'55','2016-03-30 10:45:21'),(119,33,'Jules','G','Hicks','JGHICKS@live.co.uk','','3d9eb3897f964c083ebda84898fd3e59fcd80e4d','2016-03-30 11:14:41','55',1,'55','2016-03-30 11:14:41');
/*!40000 ALTER TABLE `tblorganisationuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploads`
--

DROP TABLE IF EXISTS `uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `table_id` int(11) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `size` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `table_id` (`table_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploads`
--

LOCK TABLES `uploads` WRITE;
/*!40000 ALTER TABLE `uploads` DISABLE KEYS */;
INSERT INTO `uploads` (`id`, `table`, `field`, `table_id`, `name`, `type`, `size`) VALUES (11,'Organisation','Logo',12,'great-nepalese-restaurant.jpg','image/jpeg',13822),(15,'Organisation','Logo',14,'himalayan-enterprises.jpg','image/jpeg',7627),(16,'Organisation','Logo',33,'tabletop-towns.jpg','image/jpeg',7696);
/*!40000 ALTER TABLE `uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'oopsnepa_ccard'
--

--
-- Dumping routines for database 'oopsnepa_ccard'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-14 20:46:07
