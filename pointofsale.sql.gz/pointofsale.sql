-- phpMyAdmin SQL Dump
-- version 4.5.0-dev
-- http://www.phpmyadmin.net
--
-- Host: himalayantechies-db-server.cepyls6xdgwo.us-west-2.rds.amazonaws.com
-- Generation Time: Jun 22, 2015 at 03:35 AM
-- Server version: 5.6.19-log
-- PHP Version: 5.4.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pointofsale`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=253 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `acos`
--

INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, NULL, NULL, 'Controller', 1, 418),
(2, 1, 'ControlPanels', NULL, 'ControlPanels', 2, 15),
(3, 2, 'ControlPanels', NULL, 'admin_getControllerMethods', 3, 4),
(4, 1, 'UserRoles', NULL, 'UserRoles', 16, 27),
(5, 4, 'UserRoles', NULL, 'admin_add', 17, 18),
(6, 4, 'UserRoles', NULL, 'admin_delete', 19, 20),
(7, 4, 'UserRoles', NULL, 'admin_edit', 21, 22),
(8, 4, 'UserRoles', NULL, 'admin_index', 23, 24),
(9, 4, 'UserRoles', NULL, 'admin_save', 25, 26),
(10, 1, 'Tickets', NULL, 'Tickets', 28, 69),
(159, 154, 'Configurations', NULL, 'admin_save', 345, 346),
(12, 1, 'Categories', NULL, 'Categories', 70, 115),
(13, 1, 'Items', NULL, 'Items', 116, 135),
(14, 1, 'Orders', NULL, 'Orders', 136, 197),
(15, 1, 'Pages', NULL, 'Pages', 198, 211),
(16, 1, 'Payments', NULL, 'Payments', 212, 213),
(17, 1, 'Searches', NULL, 'Searches', 214, 217),
(18, 1, 'Shifts', NULL, 'Shifts', 218, 231),
(19, 1, 'ShiftsEmployees', NULL, 'ShiftsEmployees', 232, 243),
(20, 1, 'Statuses', NULL, 'Statuses', 244, 255),
(21, 1, 'Tables', NULL, 'Tables', 256, 277),
(22, 1, 'TablesTickets', NULL, 'TablesTickets', 278, 279),
(23, 1, 'Units', NULL, 'Units', 280, 291),
(24, 1, 'Uploads', NULL, 'Uploads', 292, 297),
(25, 1, 'Users', NULL, 'Users', 298, 335),
(26, 25, 'Users', NULL, 'admin_delete', 299, 300),
(27, 25, 'Users', NULL, 'admin_index', 301, 302),
(28, 25, 'Users', NULL, 'logout', 303, 304),
(29, 25, 'Users', NULL, 'profile', 305, 306),
(30, 25, 'Users', NULL, 'registration', 307, 308),
(31, 25, 'Users', NULL, 'update', 309, 310),
(32, 25, 'Users', NULL, 'upload', 311, 312),
(158, 154, 'Configurations', NULL, 'admin_index', 343, 344),
(157, 154, 'Configurations', NULL, 'admin_edit', 341, 342),
(156, 154, 'Configurations', NULL, 'admin_delete', 339, 340),
(40, 10, 'Tickets', NULL, 'all_tickets', 29, 30),
(41, 10, 'Tickets', NULL, 'beforeFilter', 31, 32),
(155, 154, 'Configurations', NULL, 'admin_add', 337, 338),
(201, 10, 'Tickets', NULL, 'backoffice_change_host', 61, 62),
(44, 10, 'Tickets', NULL, 'combine_tickets', 33, 34),
(45, 10, 'Tickets', NULL, 'last_order', 35, 36),
(46, 10, 'Tickets', NULL, 'my_tickets', 37, 38),
(47, 10, 'Tickets', NULL, 'passive_tables', 39, 40),
(48, 10, 'Tickets', NULL, 'split_tickets', 41, 42),
(49, 10, 'Tickets', NULL, 'orders_by_shift', 43, 44),
(51, 10, 'Tickets', NULL, 'tables', 45, 46),
(154, 1, 'Configurations', NULL, 'Configurations', 336, 357),
(53, 10, 'Tickets', NULL, 'ticket_to_split', 47, 48),
(54, 10, 'Tickets', NULL, 'void_tickets', 49, 50),
(55, 12, 'Categories', NULL, 'admin_add', 71, 72),
(56, 12, 'Categories', NULL, 'admin_delete', 73, 74),
(57, 12, 'Categories', NULL, 'admin_edit', 75, 76),
(58, 12, 'Categories', NULL, 'admin_index', 77, 78),
(59, 12, 'Categories', NULL, 'admin_locTree', 79, 80),
(60, 12, 'Categories', NULL, 'admin_move', 81, 82),
(61, 12, 'Categories', NULL, 'admin_save', 83, 84),
(62, 12, 'Categories', NULL, 'admin_treeUpdate', 85, 86),
(63, 12, 'Categories', NULL, 'beforeFilter', 87, 88),
(64, 12, 'Categories', NULL, 'categories_by_parent_id', 89, 90),
(66, 12, 'Categories', NULL, 'display_categories', 91, 92),
(67, 12, 'Categories', NULL, 'display_categories_items', 93, 94),
(68, 12, 'Categories', NULL, 'existing_tickets', 95, 96),
(161, 1, 'Inventories', NULL, 'Inventories', 358, 379),
(70, 12, 'Categories', NULL, 'is_parent', 97, 98),
(160, 15, 'Pages', NULL, 'home', 207, 208),
(72, 2, 'ControlPanels', NULL, 'admin_getControllerLists', 5, 6),
(73, 2, 'ControlPanels', NULL, 'admin_getControllerPermissions', 7, 8),
(74, 2, 'ControlPanels', NULL, 'admin_index', 9, 10),
(75, 2, 'ControlPanels', NULL, 'admin_security', 11, 12),
(76, 2, 'ControlPanels', NULL, 'beforeFilter', 13, 14),
(77, 13, 'Items', NULL, 'add_quantity', 117, 118),
(78, 13, 'Items', NULL, 'admin_add', 119, 120),
(79, 13, 'Items', NULL, 'admin_delete', 121, 122),
(80, 13, 'Items', NULL, 'admin_edit', 123, 124),
(81, 13, 'Items', NULL, 'admin_index', 125, 126),
(82, 13, 'Items', NULL, 'admin_save', 127, 128),
(83, 13, 'Items', NULL, 'beforeFilter', 129, 130),
(84, 13, 'Items', NULL, 'itemNameById', 131, 132),
(85, 13, 'Items', NULL, 'items_by_category', 133, 134),
(86, 14, 'Orders', NULL, 'add', 137, 138),
(87, 14, 'Orders', NULL, 'beforeFilter', 139, 140),
(205, 10, 'Tickets', NULL, 'user_by_ticket_id', 65, 66),
(206, 12, 'Categories', NULL, 'admin_file_upload', 105, 106),
(165, 161, 'Inventories', NULL, 'admin_index', 365, 366),
(92, 14, 'Orders', NULL, 'day_close_summery', 141, 142),
(93, 14, 'Orders', NULL, 'close_ticket', 143, 144),
(94, 14, 'Orders', NULL, 'decreaseQuantity', 145, 146),
(95, 14, 'Orders', NULL, 'delete_tables_ticket', 147, 148),
(96, 14, 'Orders', NULL, 'delete', 149, 150),
(207, 12, 'Categories', NULL, 'backoffice_all_categories', 107, 108),
(164, 161, 'Inventories', NULL, 'admin_edit', 363, 364),
(99, 14, 'Orders', NULL, 'increaseQuantity', 151, 152),
(101, 14, 'Orders', NULL, 'new_order', 153, 154),
(102, 14, 'Orders', NULL, 'new_ticket', 155, 156),
(103, 14, 'Orders', NULL, 'new_ticket_orders', 157, 158),
(163, 161, 'Inventories', NULL, 'admin_delete', 361, 362),
(106, 14, 'Orders', NULL, 'order_types', 159, 160),
(208, 24, 'Uploads', NULL, 'admin_file_upload', 293, 294),
(209, 12, 'Categories', NULL, 'get_child_categories', 109, 110),
(210, 12, 'Categories', NULL, 'get_parent_list', 111, 112),
(111, 14, 'Orders', NULL, 'ticket_orders', 161, 162),
(162, 161, 'Inventories', NULL, 'admin_add', 359, 360),
(114, 15, 'Pages', NULL, 'admin_home', 199, 200),
(115, 15, 'Pages', NULL, 'beforeFilter', 201, 202),
(151, 15, 'Pages', NULL, 'display', 205, 206),
(117, 15, 'Pages', NULL, 'imageUpdate', 203, 204),
(153, 12, 'Categories', NULL, 'parent_categories', 99, 100),
(152, 14, 'Orders', NULL, 'orders_by_types', 165, 166),
(120, 17, 'Searches', NULL, 'search', 215, 216),
(121, 18, 'Shifts', NULL, 'admin_add', 219, 220),
(122, 18, 'Shifts', NULL, 'admin_delete', 221, 222),
(123, 18, 'Shifts', NULL, 'admin_edit', 223, 224),
(124, 18, 'Shifts', NULL, 'admin_index', 225, 226),
(125, 18, 'Shifts', NULL, 'admin_save', 227, 228),
(126, 18, 'Shifts', NULL, 'start_new_shift', 229, 230),
(127, 19, 'ShiftsEmployees', NULL, 'admin_add', 233, 234),
(128, 19, 'ShiftsEmployees', NULL, 'admin_delete', 235, 236),
(129, 19, 'ShiftsEmployees', NULL, 'admin_edit', 237, 238),
(130, 19, 'ShiftsEmployees', NULL, 'admin_index', 239, 240),
(131, 19, 'ShiftsEmployees', NULL, 'admin_save', 241, 242),
(132, 20, 'Statuses', NULL, 'admin_add', 245, 246),
(133, 20, 'Statuses', NULL, 'admin_delete', 247, 248),
(134, 20, 'Statuses', NULL, 'admin_edit', 249, 250),
(135, 20, 'Statuses', NULL, 'admin_index', 251, 252),
(136, 20, 'Statuses', NULL, 'admin_save', 253, 254),
(137, 21, 'Tables', NULL, 'admin_delete', 257, 258),
(138, 21, 'Tables', NULL, 'admin_add', 259, 260),
(139, 21, 'Tables', NULL, 'admin_edit', 261, 262),
(140, 21, 'Tables', NULL, 'admin_index', 263, 264),
(141, 21, 'Tables', NULL, 'admin_save', 265, 266),
(143, 23, 'Units', NULL, 'admin_add', 281, 282),
(144, 23, 'Units', NULL, 'admin_delete', 283, 284),
(145, 23, 'Units', NULL, 'admin_index', 285, 286),
(146, 23, 'Units', NULL, 'admin_edit', 287, 288),
(147, 23, 'Units', NULL, 'admin_save', 289, 290),
(148, 25, 'Users', NULL, 'login', 313, 314),
(149, 14, 'Orders', NULL, 'order_form', 163, 164),
(150, 10, 'Tickets', NULL, 'my_tables', 51, 52),
(166, 161, 'Inventories', NULL, 'admin_save', 367, 368),
(203, 25, 'Users', NULL, 'user_by_ticket_id', 325, 326),
(204, 10, 'Tickets', NULL, 'credit_payment_form', 63, 64),
(171, 12, 'Categories', NULL, 'all_categories', 101, 102),
(172, 10, 'Tickets', NULL, 'all_tables', 53, 54),
(173, 25, 'Users', NULL, 'resetpassword', 315, 316),
(174, 25, 'Users', NULL, 'credit_members', 317, 318),
(175, 25, 'Users', NULL, 'close', 319, 320),
(176, 25, 'Users', NULL, 'changePass', 321, 322),
(177, 25, 'Users', NULL, 'all_members', 323, 324),
(211, 12, 'Categories', NULL, 'get_path', 113, 114),
(179, 10, 'Tickets', NULL, 'credit_payment', 55, 56),
(180, 10, 'Tickets', NULL, 'creditors_payment', 57, 58),
(181, 10, 'Tickets', NULL, 'creditors_tickets', 59, 60),
(182, 14, 'Orders', NULL, 'creditors_orders', 167, 168),
(183, 14, 'Orders', NULL, 'creditors_ticket_orders', 169, 170),
(184, 12, 'Categories', NULL, 'get_categories', 103, 104),
(185, 15, 'Pages', NULL, 'backoffice_home', 209, 210),
(186, 161, 'Inventories', NULL, 'backoffice_inventory_reports', 369, 370),
(187, 161, 'Inventories', NULL, 'backoffice_inventory_summary', 371, 372),
(188, 14, 'Orders', NULL, 'backoffice_canceled_orders_reports', 171, 172),
(189, 14, 'Orders', NULL, 'backoffice_categories_grouped_reports', 173, 174),
(190, 14, 'Orders', NULL, 'backoffice_credit_report', 175, 176),
(192, 14, 'Orders', NULL, 'backoffice_products_grouped_reports', 177, 178),
(193, 14, 'Orders', NULL, 'backoffice_detailed_reports', 179, 180),
(194, 14, 'Orders', NULL, 'backoffice_report_by_date', 181, 182),
(195, 14, 'Orders', NULL, 'backoffice_reports_per_item', 183, 184),
(196, 14, 'Orders', NULL, 'backoffice_tax_reports', 185, 186),
(197, 14, 'Orders', NULL, 'backoffice_transaction_reports', 187, 188),
(198, 21, 'Tables', NULL, 'backoffice_assign_host', 267, 268),
(199, 14, 'Orders', NULL, 'get_start_end_date', 189, 190),
(212, 25, 'Users', NULL, 'admin_change_role', 327, 328),
(213, 10, 'Tickets', NULL, 'change_host', 67, 68),
(214, 21, 'Tables', NULL, 'change_table', 269, 270),
(215, 21, 'Tables', NULL, 'assign_table', 271, 272),
(216, 154, 'Configurations', NULL, 'update_version', 347, 348),
(219, 21, 'Tables', NULL, 'remove_table', 273, 274),
(218, 154, 'Configurations', NULL, 'backoffice_check_updates', 349, 350),
(220, 21, 'Tables', NULL, 'update_tables', 275, 276),
(221, 154, 'Configurations', NULL, 'deleteDir', 351, 352),
(222, 154, 'Configurations', NULL, 'project_info', 353, 354),
(223, 154, 'Configurations', NULL, 'version_available', 355, 356),
(224, 25, 'Users', NULL, 'old_files', 329, 330),
(225, 25, 'Users', NULL, 'edit_profile', 331, 332),
(226, 25, 'Users', NULL, 'db_update', 333, 334),
(227, 1, 'Counters', NULL, 'Counters', 380, 395),
(228, 227, 'Counters', NULL, 'admin_add', 381, 382),
(229, 227, 'Counters', NULL, 'admin_delete', 383, 384),
(230, 227, 'Counters', NULL, 'admin_edit', 385, 386),
(231, 227, 'Counters', NULL, 'admin_index', 387, 388),
(232, 227, 'Counters', NULL, 'admin_save', 389, 390),
(233, 227, 'Counters', NULL, 'get_counters', 391, 392),
(234, 227, 'Counters', NULL, 'configure_counter', 393, 394),
(235, 14, 'Orders', NULL, 'table_is_used', 191, 192),
(236, 161, 'Inventories', NULL, 'item_summary', 373, 374),
(237, 161, 'Inventories', NULL, 'dateRange', 375, 376),
(238, 161, 'Inventories', NULL, 'category_summary', 377, 378),
(239, 24, 'Uploads', NULL, 'deleteUpload', 295, 296),
(240, 1, 'CompanyInfos', NULL, 'CompanyInfos', 396, 405),
(241, 240, 'CompanyInfos', NULL, 'admin_edit', 397, 398),
(242, 240, 'CompanyInfos', NULL, 'admin_index', 399, 400),
(243, 240, 'CompanyInfos', NULL, 'admin_save', 401, 402),
(244, 240, 'CompanyInfos', NULL, 'admin_change_logo', 403, 404),
(245, 14, 'Orders', NULL, 'return_creditors_ticket_orders', 193, 194),
(246, 14, 'Orders', NULL, 'creditors_all_tickets', 195, 196),
(247, 1, 'UnitRatios', NULL, 'UnitRatios', 406, 417),
(248, 247, 'UnitRatios', NULL, 'admin_add', 407, 408),
(249, 247, 'UnitRatios', NULL, 'admin_index', 409, 410),
(250, 247, 'UnitRatios', NULL, 'admin_delete', 411, 412),
(251, 247, 'UnitRatios', NULL, 'admin_edit', 413, 414),
(252, 247, 'UnitRatios', NULL, 'admin_save', 415, 416);

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
  `id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `table` varchar(15) NOT NULL,
  `street` varchar(80) DEFAULT NULL,
  `direction` varchar(225) DEFAULT NULL,
  `location_map_id` int(11) DEFAULT NULL,
  `phone_number` varchar(24) DEFAULT NULL,
  `email` varchar(99) DEFAULT NULL,
  `website` varchar(99) DEFAULT NULL,
  `geocode_lt` varchar(10) DEFAULT NULL,
  `geocode_lg` varchar(10) DEFAULT NULL,
  `status_id` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3133 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `table_id`, `table`, `street`, `direction`, `location_map_id`, `phone_number`, `email`, `website`, `geocode_lt`, `geocode_lg`, `status_id`) VALUES
(1412, 650, 'User', NULL, NULL, 482, '', NULL, NULL, '', '', 1),
(1428, 653, 'User', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(1430, 654, 'User', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(1431, 655, 'User', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(1432, 656, 'User', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(1434, 657, 'User', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(1439, 23, 'User', '', '', NULL, '', NULL, '', '', '', 1),
(1440, 23, 'User', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(1441, 23, 'User', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(1446, 658, 'User', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(1447, 659, 'User', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(1449, 660, 'User', NULL, NULL, NULL, '', NULL, NULL, '', '', 0),
(1476, 663, 'User', NULL, NULL, 504, '', NULL, NULL, '', '', 1),
(3119, 918, 'User', '', '', NULL, '', NULL, '', '', '', 1),
(3120, 919, 'User', '', '', NULL, '', NULL, '', NULL, NULL, 1),
(3113, 910, 'User', '', '', NULL, '', NULL, '', '27.670935', '85.404900', 1),
(3114, 911, 'User', '', '', NULL, '', NULL, '', '', '', 1),
(3115, 912, 'User', '', '', NULL, '', NULL, '', '', '', 1),
(3116, 913, 'User', '', '', NULL, '', NULL, '', '', '', 1),
(3117, 914, 'User', '', '', NULL, '', NULL, '', '', '', 1),
(3118, 915, 'User', '', '', NULL, '', NULL, '', '', '', 1),
(3121, 920, 'User', '', '', NULL, '', NULL, '', NULL, NULL, 1),
(3122, 921, 'User', '', '', NULL, '', NULL, '', NULL, NULL, 1),
(3123, 922, 'User', '', '', NULL, '', NULL, '', NULL, NULL, 1),
(3124, 923, 'User', '', '', NULL, '', NULL, '', NULL, NULL, 1),
(3125, 924, 'User', '', '', NULL, '', NULL, '', NULL, NULL, 1),
(3127, 926, 'User', '', '', NULL, '', NULL, '', NULL, NULL, 1),
(3128, 4, 'User', '', '', NULL, '', NULL, '', NULL, NULL, 1),
(3130, 6, 'User', '', '', NULL, '', NULL, '', NULL, NULL, 1),
(3132, 1, 'User', '', NULL, NULL, '', NULL, '', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aros`
--

INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, 'UserRole', 1, 'R_administrator', 1, 4),
(2, NULL, 'UserRole', 2, 'R_cashier', 5, 8),
(3, NULL, 'UserRole', 3, 'R_host', 9, 12),
(4, NULL, 'UserRole', 4, 'R_member', 13, 20),
(5, 1, 'User', 1, 'administrator', 2, 3),
(6, 2, 'User', 2, 'cashier', 6, 7),
(7, 3, 'User', 3, 'host', 10, 11),
(8, 4, 'User', 4, 'sagar', 16, 17),
(10, 4, 'User', 6, 'bob', 18, 19);

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) NOT NULL,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) NOT NULL DEFAULT '0',
  `_read` varchar(2) NOT NULL DEFAULT '0',
  `_update` varchar(2) NOT NULL DEFAULT '0',
  `_delete` varchar(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aros_acos`
--

INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES
(1, 1, 1, '1', '1', '1', '1'),
(2, 2, 64, '1', '1', '1', '1'),
(3, 2, 66, '1', '1', '1', '1'),
(4, 2, 67, '1', '1', '1', '1'),
(5, 2, 68, '1', '1', '1', '1'),
(6, 2, 184, '1', '1', '1', '1'),
(7, 2, 209, '1', '1', '1', '1'),
(8, 2, 210, '1', '1', '1', '1'),
(9, 2, 211, '1', '1', '1', '1'),
(10, 2, 153, '1', '1', '1', '1'),
(11, 2, 70, '1', '1', '1', '1'),
(12, 2, 85, '1', '1', '1', '1'),
(13, 2, 84, '1', '1', '1', '1'),
(14, 2, 77, '1', '1', '1', '1'),
(15, 2, 234, '1', '1', '1', '1'),
(16, 2, 233, '1', '1', '1', '1'),
(17, 2, 86, '1', '1', '1', '1'),
(18, 2, 93, '1', '1', '1', '1'),
(19, 2, 94, '1', '1', '1', '1'),
(20, 2, 96, '1', '1', '1', '1'),
(21, 2, 99, '1', '1', '1', '1'),
(22, 2, 101, '1', '1', '1', '1'),
(23, 2, 102, '1', '1', '1', '1'),
(24, 2, 106, '1', '1', '1', '1'),
(25, 2, 152, '1', '1', '1', '1'),
(26, 2, 111, '1', '1', '1', '1'),
(27, 2, 235, '1', '1', '1', '1'),
(28, 2, 172, '1', '1', '1', '1'),
(29, 2, 40, '1', '1', '1', '1'),
(30, 2, 44, '1', '1', '1', '1'),
(31, 2, 45, '1', '1', '1', '1'),
(32, 2, 150, '1', '1', '1', '1'),
(33, 2, 46, '1', '1', '1', '1'),
(34, 2, 49, '1', '1', '1', '1'),
(35, 2, 47, '1', '1', '1', '1'),
(36, 2, 48, '1', '1', '1', '1'),
(37, 2, 51, '1', '1', '1', '1'),
(38, 2, 53, '1', '1', '1', '1'),
(39, 2, 54, '1', '1', '1', '1'),
(40, 2, 28, '1', '1', '1', '1'),
(41, 2, 148, '1', '1', '1', '1'),
(42, 2, 174, '1', '1', '1', '1'),
(43, 2, 176, '1', '1', '1', '1'),
(44, 3, 64, '1', '1', '1', '1'),
(45, 3, 66, '1', '1', '1', '1'),
(46, 3, 67, '1', '1', '1', '1'),
(47, 3, 68, '1', '1', '1', '1'),
(48, 3, 184, '1', '1', '1', '1'),
(49, 3, 209, '1', '1', '1', '1'),
(50, 3, 210, '1', '1', '1', '1'),
(51, 3, 211, '1', '1', '1', '1'),
(52, 3, 70, '1', '1', '1', '1'),
(53, 3, 153, '1', '1', '1', '1'),
(54, 3, 77, '1', '1', '1', '1'),
(55, 3, 84, '1', '1', '1', '1'),
(56, 3, 85, '1', '1', '1', '1'),
(57, 3, 86, '1', '1', '1', '1'),
(58, 3, 94, '1', '1', '1', '1'),
(59, 3, 96, '1', '1', '1', '1'),
(60, 3, 95, '1', '1', '1', '1'),
(61, 3, 99, '1', '1', '1', '1'),
(62, 3, 101, '1', '1', '1', '1'),
(63, 3, 102, '1', '1', '1', '1'),
(64, 3, 103, '1', '1', '1', '1'),
(65, 3, 149, '1', '1', '1', '1'),
(66, 3, 106, '1', '1', '1', '1'),
(67, 3, 152, '1', '1', '1', '1'),
(68, 3, 235, '1', '1', '1', '1'),
(69, 3, 111, '1', '1', '1', '1'),
(70, 3, 172, '1', '1', '1', '1'),
(71, 3, 40, '1', '1', '1', '1'),
(72, 3, 44, '1', '1', '1', '1'),
(73, 3, 45, '1', '1', '1', '1'),
(74, 3, 150, '1', '1', '1', '1'),
(75, 3, 46, '1', '1', '1', '1'),
(76, 3, 47, '1', '1', '1', '1'),
(77, 3, 48, '1', '1', '1', '1'),
(78, 3, 51, '1', '1', '1', '1'),
(79, 3, 53, '1', '1', '1', '1'),
(80, 3, 54, '1', '1', '1', '1'),
(81, 3, 148, '1', '1', '1', '1'),
(82, 3, 28, '1', '1', '1', '1'),
(83, 3, 176, '1', '1', '1', '1'),
(84, 3, 173, '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `abbr` varchar(5) DEFAULT NULL,
  `description` text,
  `url` varchar(50) NOT NULL,
  `image` varchar(150) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) NOT NULL,
  `rght` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `abbr`, `description`, `url`, `image`, `parent_id`, `lft`, `rght`, `user_id`, `created_date`) VALUES
(1, 'Starters', '', NULL, 'starters', 'Cheddar_Rosemary_and_Red_Onion_Tart', NULL, 1, 2, 1, '2013-01-08 08:55:42'),
(2, 'Momo', '', NULL, 'momo', 'momo', NULL, 3, 4, 1, '2013-01-08 08:55:54'),
(3, 'Soup', '', NULL, 'soup', 'soup', NULL, 5, 6, 1, '2013-01-08 08:56:37'),
(4, 'Chatamari', '', NULL, 'chatamari', '2009072300720Chatamari201', NULL, 7, 8, 1, '2013-01-08 08:56:53'),
(5, 'Peri Peri Specials', '', NULL, 'peri-peri-specials', 'special-chicken-tikka', NULL, 9, 10, 1, '2013-01-08 08:58:27'),
(6, 'Noodles/Fried Rice', '', NULL, 'noodles-fried-rice', 'Flat-noodles-stir-fried-sausage-sauce-spicy-recipe-Spicy-Pasta', NULL, 11, 12, 1, '2013-01-08 11:21:41'),
(7, 'Pasta/Spaghetti', '', NULL, 'pasta-spaghetti', 'browned+butter+lemon+pasta3', NULL, 13, 14, 1, '2013-01-08 11:21:54'),
(8, 'Sizzler', '', NULL, 'sizzler', 'Sizzlers-Signature', NULL, 15, 16, 1, '2013-01-08 11:22:00'),
(9, 'Chopsuey', '', NULL, 'chopsuey', 'chop-suey-1', NULL, 17, 18, 1, '2013-01-08 11:22:07'),
(10, 'Other Mains', '', NULL, 'other-mains', 'main-dish-meal', NULL, 19, 20, 1, '2013-01-08 11:22:22'),
(11, 'Beverages', '', NULL, 'beverages', 'beverages', NULL, 21, 22, 1, '2013-01-08 11:22:42'),
(12, 'Imports', '', NULL, 'imports', 'LARGE PHOTOS_ALCOHOL', NULL, 23, 28, 1, '2013-01-08 11:22:53'),
(13, 'Beer', '', NULL, 'beer', 'beerbuzz600', NULL, 29, 30, 1, '2013-01-08 11:22:59'),
(14, 'Cocktail', '', NULL, 'cocktail', 'Shaken_Not_Stirred_V2_0', NULL, 31, 32, 1, '2013-01-08 11:25:24'),
(15, 'Mocktail', '', NULL, 'mocktail', 'LT-cheerful_cherry_mocktail_4', NULL, 33, 34, 1, '2013-01-08 11:25:30'),
(16, 'Wine', '', NULL, 'wine', 'bottles2005', NULL, 35, 40, 1, '2013-01-08 11:25:43'),
(17, '30ml', '', NULL, '30ml', NULL, 12, 24, 25, 1, '2013-01-08 11:48:07'),
(18, '60ml', '', NULL, '60ml', NULL, 12, 26, 27, 1, '2013-01-08 11:49:06'),
(19, 'Glass', '', NULL, 'glass', NULL, 16, 36, 37, 1, '2013-01-10 05:44:51'),
(20, 'Bottle', '', NULL, 'bottle', NULL, 16, 38, 39, 1, '2013-01-10 05:45:03'),
(23, 'Locals', '', NULL, 'locals', 'booze', NULL, 41, 46, 1, '2013-01-10 07:06:25'),
(24, 'Shots', '', NULL, 'shots', '2345543856_6d0fbafb66', NULL, 47, 48, 1, '2013-01-10 07:06:32'),
(25, '30ml', '', NULL, '30ml-1', NULL, 23, 42, 43, 1, '2013-01-10 07:09:20'),
(26, '60ml', '', NULL, '60ml-1', NULL, 23, 44, 45, 1, '2013-01-10 07:09:27'),
(27, 'Bottle (Vodka/Rum/Gin)', '', NULL, 'bottle-vodka-rum-gin', 'belvedere-silver-vodka-bottle-1', NULL, 49, 50, 1, '2013-01-10 07:22:52');

-- --------------------------------------------------------

--
-- Table structure for table `company_infos`
--

CREATE TABLE IF NOT EXISTS `company_infos` (
  `id` int(11) NOT NULL,
  `key` varchar(150) NOT NULL,
  `value` varchar(150) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `company_infos`
--

INSERT INTO `company_infos` (`id`, `key`, `value`) VALUES
(1, 'name', 'Peri Peri The Restaurant '),
(2, 'address', 'Pulchowk'),
(3, 'contact', '4546566'),
(4, 'logo', '45791_130712836974825_1802034_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `configurations`
--

CREATE TABLE IF NOT EXISTS `configurations` (
  `id` int(11) NOT NULL,
  `key` varchar(50) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `configurations`
--

INSERT INTO `configurations` (`id`, `key`, `status_id`, `value`, `created`, `modified`) VALUES
(1, 'Discount', 46, '', '2012-08-27 05:15:11', '2012-12-06 16:19:45'),
(2, 'Service Charge', 46, '10', '2012-08-27 05:15:21', '2013-01-10 11:22:35'),
(3, 'Tax', 45, '13', '2012-08-27 05:15:32', '2013-01-22 14:31:39'),
(4, 'Javascript', 45, '', '2012-08-27 05:15:49', '2013-01-08 15:00:06'),
(5, 'Assign Employee', 45, '', '2012-08-27 05:16:00', '2012-08-28 16:59:11'),
(7, 'Price Tag', 46, '', '2012-12-12 02:00:17', '2013-01-08 14:59:54');

-- --------------------------------------------------------

--
-- Table structure for table `counters`
--

CREATE TABLE IF NOT EXISTS `counters` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `credits`
--

CREATE TABLE IF NOT EXISTS `credits` (
  `id` int(11) NOT NULL,
  `member_id` int(11) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL,
  `payment_type` varchar(30) DEFAULT NULL,
  `previous_remaining` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `remaining` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `inventories`
--

CREATE TABLE IF NOT EXISTS `inventories` (
  `id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `unit_price` int(11) DEFAULT NULL,
  `total_cost` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `counted` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `description` text,
  `image` varchar(150) DEFAULT NULL,
  `purchase_unit_price` int(11) DEFAULT NULL,
  `purchase_unit_id` int(11) DEFAULT NULL,
  `unit_difference` int(11) DEFAULT NULL,
  `unit_price` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `stock_unit_number` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `discountable` tinyint(1) DEFAULT NULL,
  `stockable` tinyint(1) NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `url` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `category_id`, `name`, `description`, `image`, `purchase_unit_price`, `purchase_unit_id`, `unit_difference`, `unit_price`, `quantity`, `stock_unit_number`, `user_id`, `status_id`, `unit_id`, `discountable`, `stockable`, `created_date`, `url`) VALUES
(1, 1, 'Sukuti Sadeko', '', NULL, NULL, NULL, NULL, 200, 0, NULL, 1, 42, 1, 1, 0, '2013-01-08 09:07:18', NULL),
(2, 1, 'Choela', '', NULL, NULL, NULL, NULL, 150, NULL, NULL, 1, 42, NULL, 1, 1, '2013-01-08 09:18:54', NULL),
(4, 1, 'Buff Chilli', '', NULL, NULL, NULL, NULL, 180, 0, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:19:43', NULL),
(5, 1, 'Chicken Chilli', '', NULL, NULL, NULL, NULL, 200, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:20:23', NULL),
(7, 1, 'Chicken Nuggets', '', NULL, NULL, NULL, NULL, 150, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:21:47', NULL),
(8, 1, 'Chicken Sekuwa', '', NULL, NULL, NULL, NULL, 200, 0, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:22:43', NULL),
(9, 1, 'Chicken Stirfry', '', NULL, NULL, NULL, NULL, 200, 0, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:23:11', NULL),
(10, 1, 'Chicken Sadeko', '', NULL, NULL, NULL, NULL, 200, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:23:45', NULL),
(11, 1, 'Cheese Ball', '', NULL, NULL, NULL, NULL, 180, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:24:07', NULL),
(12, 1, 'Chips Chilli', '', NULL, NULL, NULL, NULL, 150, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:24:32', NULL),
(13, 1, 'Peanuts Sadeko', '', NULL, NULL, NULL, NULL, 80, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:24:57', NULL),
(15, 1, 'Veg Tempura', '', NULL, NULL, NULL, NULL, 120, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:25:44', NULL),
(16, 1, 'Garlic Potato', '', NULL, NULL, NULL, NULL, 150, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:26:13', NULL),
(17, 1, 'Cheese Pakora', '', NULL, NULL, NULL, NULL, 180, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:26:35', NULL),
(18, 1, 'Veg Stirfry', '', NULL, NULL, NULL, NULL, 150, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:26:55', NULL),
(19, 1, 'Chips Small', '', NULL, NULL, NULL, NULL, 100, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:27:13', NULL),
(20, 1, 'Chips Large', '', NULL, NULL, NULL, NULL, 180, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 09:27:30', NULL),
(21, 2, 'Momocha', '', NULL, NULL, NULL, NULL, 120, 0, NULL, 1, 42, 1, 1, 0, '2013-01-08 10:46:38', NULL),
(22, 2, 'Chicken', '', NULL, NULL, NULL, NULL, 140, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-08 10:46:48', NULL),
(23, 2, 'Buff', '', NULL, NULL, NULL, NULL, 120, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-08 10:47:00', NULL),
(24, 2, 'Veg', '', NULL, NULL, NULL, NULL, 100, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 10:47:36', NULL),
(25, 1, 'Chicken Mushroom', '', NULL, NULL, NULL, NULL, 150, 0, NULL, 1, 42, NULL, 0, 0, '2013-01-08 10:52:46', NULL),
(26, 3, 'Mushroom', '', NULL, NULL, NULL, NULL, 120, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 10:53:07', NULL),
(27, 3, 'Hot N Sour Chi', '', NULL, NULL, NULL, NULL, 150, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 10:53:29', NULL),
(28, 3, 'Hot N Sour Veg', '', NULL, NULL, NULL, NULL, 120, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 10:53:50', NULL),
(29, 4, 'Egg Chatamari', '', NULL, NULL, NULL, NULL, 120, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 11:03:11', NULL),
(30, 4, 'Chicken Chatamari', '', NULL, NULL, NULL, NULL, 150, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 11:03:30', NULL),
(31, 4, 'Mixed Chatamari', '', NULL, NULL, NULL, NULL, 180, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 11:04:29', NULL),
(32, 5, 'Quarter Chicken', '', NULL, NULL, NULL, NULL, 225, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 11:05:21', NULL),
(33, 5, 'Half Chicken', '', NULL, NULL, NULL, NULL, 400, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:06:11', NULL),
(34, 5, 'Whole Chicken', '', NULL, NULL, NULL, NULL, 750, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:06:32', NULL),
(35, 5, '3 Wings', '', NULL, NULL, NULL, NULL, 225, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:06:49', NULL),
(36, 5, '5 Wings', '', NULL, NULL, NULL, NULL, 400, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:07:22', NULL),
(37, 5, '10 Wings', '', NULL, NULL, NULL, NULL, 750, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:08:07', NULL),
(38, 5, 'Chicken Burger/ pita with Chips', '', NULL, NULL, NULL, NULL, 250, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:08:52', NULL),
(39, 5, 'Veg Burger/pita with Chips', '', NULL, NULL, NULL, NULL, 200, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-08 11:09:54', NULL),
(40, 5, 'Grilled Chicken Wrap', '', NULL, NULL, NULL, NULL, 180, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:14:07', NULL),
(41, 5, 'Mediterranean Chi Roll', '', NULL, NULL, NULL, NULL, 230, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:16:02', NULL),
(42, 5, 'Veg Wrap', '', NULL, NULL, NULL, NULL, 150, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:16:28', NULL),
(43, 5, 'Mediterranean Salad', '', NULL, NULL, NULL, NULL, 180, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 11:17:09', NULL),
(44, 5, 'Mediterranean Salad with Chicken', '', NULL, NULL, NULL, NULL, 180, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:17:57', NULL),
(45, 5, 'Green Salad', '', NULL, NULL, NULL, NULL, 125, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:18:20', NULL),
(46, 5, 'Whole Chicken with Chips and Rice', '', NULL, NULL, NULL, NULL, 1000, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:20:03', NULL),
(47, 5, 'Wings with Chips and Beer', '', NULL, NULL, NULL, NULL, 500, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:20:23', NULL),
(48, 5, 'Burger/Pita with Chips and Coke', '', NULL, NULL, NULL, NULL, 275, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:21:04', NULL),
(49, 6, 'Chi Noodle ', '', NULL, NULL, NULL, NULL, 160, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:27:21', NULL),
(50, 6, 'Buff Noodles', '', NULL, NULL, NULL, NULL, 140, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 11:27:42', NULL),
(51, 6, 'Veg Noodles', '', NULL, NULL, NULL, NULL, 125, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:28:12', NULL),
(52, 6, 'Mix Noodles', '', NULL, NULL, NULL, NULL, 160, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:28:32', NULL),
(53, 6, 'Chicken Fried Rice', '', NULL, NULL, NULL, NULL, 160, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:28:57', NULL),
(54, 6, 'Buff Fried Rice', '', NULL, NULL, NULL, NULL, 140, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:29:19', NULL),
(55, 6, 'Veg Fried Rice', '', NULL, NULL, NULL, NULL, 125, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:29:39', NULL),
(56, 6, 'Mix Fried Rice', '', NULL, NULL, NULL, NULL, 160, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:30:13', NULL),
(57, 7, 'Bolognaise', '', NULL, NULL, NULL, NULL, 230, 0, NULL, 1, 42, NULL, 0, 0, '2013-01-08 11:30:38', NULL),
(58, 7, 'Pomodoro', '', NULL, NULL, NULL, NULL, 200, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:31:10', NULL),
(59, 7, 'Carbonara', '', NULL, NULL, NULL, NULL, 250, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:31:37', NULL),
(60, 8, 'Chicken', '', NULL, NULL, NULL, NULL, 300, NULL, NULL, 1, 42, NULL, 0, 0, '2013-01-08 11:31:55', NULL),
(61, 8, 'Veg', '', NULL, NULL, NULL, NULL, 210, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-08 11:32:07', NULL),
(62, 8, 'Pangra', '', NULL, NULL, NULL, NULL, 250, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:32:27', NULL),
(63, 9, 'American', '', NULL, NULL, NULL, NULL, 220, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:32:58', NULL),
(64, 9, 'Chinese', '', NULL, NULL, NULL, NULL, 200, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:33:18', NULL),
(65, 10, 'Chicken Curry with Rice', '', NULL, NULL, NULL, NULL, 220, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:34:39', NULL),
(66, 10, 'Thai Red Curry', '', NULL, NULL, NULL, NULL, 220, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:35:25', NULL),
(67, 10, 'Dal Makhani', '', NULL, NULL, NULL, NULL, 120, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:35:53', NULL),
(68, 10, 'Veg Curry', '', NULL, NULL, NULL, NULL, 150, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:36:16', NULL),
(69, 10, 'Chicken Biryani', '', NULL, NULL, NULL, NULL, 280, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:36:41', NULL),
(70, 10, 'Veg Biryani', '', NULL, NULL, NULL, NULL, 250, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:37:03', NULL),
(71, 10, 'Plain Rice', '', NULL, NULL, NULL, NULL, 60, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:37:23', NULL),
(72, 11, 'Coke/Fanta/Sprite', '', NULL, NULL, NULL, NULL, 50, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:39:11', NULL),
(73, 11, 'Red Bull', '', NULL, NULL, NULL, NULL, 100, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:39:30', NULL),
(74, 11, 'Juice', '', NULL, NULL, NULL, NULL, 100, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:39:52', NULL),
(75, 11, 'Fresh Lime Soda', '', NULL, NULL, NULL, NULL, 50, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:40:27', NULL),
(76, 11, 'Bottled Water', '', NULL, NULL, NULL, NULL, 50, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:40:55', NULL),
(77, 11, 'Iced Tea', '', NULL, NULL, NULL, NULL, 100, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:41:16', NULL),
(78, 11, 'Milk Tea', '', NULL, NULL, NULL, NULL, 50, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:41:36', NULL),
(79, 11, 'Black Tea', '', NULL, NULL, NULL, NULL, 30, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:41:59', NULL),
(80, 11, 'Black Coffee', '', NULL, NULL, NULL, NULL, 40, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:45:42', NULL),
(81, 11, 'Milk Coffee', '', NULL, NULL, NULL, NULL, 60, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:46:14', NULL),
(82, 11, 'Hot Lemon with Honey', '', NULL, NULL, NULL, NULL, 60, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-08 11:46:30', NULL),
(83, 19, 'Red', '', NULL, NULL, NULL, NULL, 400, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-10 06:04:11', NULL),
(84, 20, 'Red', '', NULL, NULL, NULL, NULL, 1600, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-10 06:04:27', NULL),
(85, 19, 'White', '', NULL, NULL, NULL, NULL, 400, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-10 06:05:13', NULL),
(86, 20, 'White', '', NULL, NULL, NULL, NULL, 1600, NULL, NULL, 1, 42, NULL, 1, 0, '2013-01-10 06:31:14', NULL),
(87, 17, 'Absolut Vodka Flavored ', '', NULL, NULL, NULL, NULL, 200, 0, NULL, 1, 42, 1, 1, 0, '2013-01-10 06:54:40', NULL),
(88, 17, 'Absolut Vodka Regular', '', NULL, NULL, NULL, NULL, 180, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 06:55:04', NULL),
(89, 17, 'Jameson Irish Whisky', '', NULL, NULL, NULL, NULL, 200, NULL, NULL, 1, 42, 1, 0, 0, '2013-01-10 06:55:40', NULL),
(90, 17, 'Ballantines', '', NULL, NULL, NULL, NULL, 200, NULL, NULL, 1, 42, 1, 0, 0, '2013-01-10 06:56:31', NULL),
(91, 17, 'Beefeater Gin', '', NULL, NULL, NULL, NULL, 180, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 06:57:52', NULL),
(92, 17, 'Jack Daniels ', '', NULL, NULL, NULL, NULL, 200, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 06:58:12', NULL),
(93, 17, 'Red Label', '', NULL, NULL, NULL, NULL, 180, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 06:58:28', NULL),
(94, 17, 'Black Label', '', NULL, NULL, NULL, NULL, 260, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 06:58:46', NULL),
(95, 17, 'Chivas Regal', '', NULL, NULL, NULL, NULL, 260, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:03:04', NULL),
(96, 17, 'Glenlivet Single Malt', '', NULL, NULL, NULL, NULL, 220, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:05:04', NULL),
(97, 17, 'Tia Maria', '', NULL, NULL, NULL, NULL, 200, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:05:28', NULL),
(98, 17, 'Baileys', '', NULL, NULL, NULL, NULL, 200, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:05:50', NULL),
(99, 24, 'Sauza Gold', '', NULL, NULL, NULL, NULL, 250, NULL, NULL, 1, 42, 4, 1, 0, '2013-01-10 07:08:41', NULL),
(100, 25, 'Royal Stag', '', NULL, NULL, NULL, NULL, 80, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:09:56', NULL),
(101, 25, 'Spey Livet/Signature', '', NULL, NULL, NULL, NULL, 100, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:10:25', NULL),
(102, 25, 'Ruslan Vodka', '', NULL, NULL, NULL, NULL, 80, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:12:40', NULL),
(103, 25, 'Khukuri Rum', '', NULL, NULL, NULL, NULL, 80, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:13:22', NULL),
(104, 25, 'Gin', '', NULL, NULL, NULL, NULL, 80, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:13:38', NULL),
(105, 13, 'Calsberg', '', NULL, NULL, NULL, NULL, 350, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:15:39', NULL),
(106, 13, 'Tuborg', '', NULL, NULL, NULL, NULL, 300, 0, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:15:55', NULL),
(107, 13, 'Gurkha', '', NULL, NULL, NULL, NULL, 300, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:16:16', NULL),
(108, 14, 'Long Island Iced Tea', '', NULL, NULL, NULL, NULL, 300, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:16:36', NULL),
(109, 14, 'Long Beach Iced Tea', '', NULL, NULL, NULL, NULL, 300, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:17:45', NULL),
(110, 14, 'Margarita', '', NULL, NULL, NULL, NULL, 300, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:18:05', NULL),
(111, 14, 'Screw Driver', '', NULL, NULL, NULL, NULL, 300, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:18:32', NULL),
(112, 14, 'Mojito', '', NULL, NULL, NULL, NULL, 250, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:18:55', NULL),
(113, 14, 'Dorado', '', NULL, NULL, NULL, NULL, 250, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:19:18', NULL),
(114, 14, 'Hot Rum Punch', '', NULL, NULL, NULL, NULL, 250, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:19:45', NULL),
(115, 15, 'Fruit Rum Punch', '', NULL, NULL, NULL, NULL, 300, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:20:05', NULL),
(116, 15, 'Capiriska', '', NULL, NULL, NULL, NULL, 250, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:20:30', NULL),
(117, 15, 'Black Current', '', NULL, NULL, NULL, NULL, 250, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 07:20:52', NULL),
(118, 18, 'Absolut Vodka Flavored', '', NULL, NULL, NULL, NULL, 380, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:09:32', NULL),
(119, 18, 'Absolut Vodka Regular', '', NULL, NULL, NULL, NULL, 350, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:12:08', NULL),
(120, 18, 'Jameson Irish Whisky', '', NULL, NULL, NULL, NULL, 380, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:13:25', NULL),
(121, 18, 'Ballantines', '', NULL, NULL, NULL, NULL, 380, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:14:00', NULL),
(122, 18, 'Beefeater Gin', '', NULL, NULL, NULL, NULL, 330, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:15:18', NULL),
(123, 18, 'Jack Daniels', '', NULL, NULL, NULL, NULL, 380, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:15:54', NULL),
(124, 18, 'Red Label', '', NULL, NULL, NULL, NULL, 350, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:16:55', NULL),
(125, 18, 'Black Label', '', NULL, NULL, NULL, NULL, 500, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:17:44', NULL),
(126, 18, 'Chivas Regal', '', NULL, NULL, NULL, NULL, 500, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:18:06', NULL),
(127, 18, 'Glenlivet Single Malt', '', NULL, NULL, NULL, NULL, 220, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:18:31', NULL),
(128, 18, 'Tia Maria', '', NULL, NULL, NULL, NULL, 380, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:18:52', NULL),
(129, 18, 'Baileys', '', NULL, NULL, NULL, NULL, 380, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:19:14', NULL),
(130, 26, 'Royal Stag', '', NULL, NULL, NULL, NULL, 135, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:20:04', NULL),
(131, 26, 'Spey Livet/Signature', '', NULL, NULL, NULL, NULL, 175, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:21:06', NULL),
(132, 26, 'Ruslan Vodka', '', NULL, NULL, NULL, NULL, 135, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:21:48', NULL),
(133, 26, 'Khukuri Rum', '', NULL, NULL, NULL, NULL, 135, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:22:32', NULL),
(134, 26, 'Gin', '', NULL, NULL, NULL, NULL, 135, NULL, NULL, 1, 42, 1, 1, 0, '2013-01-10 08:22:53', NULL),
(135, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, '2013-01-22 14:46:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `location_maps`
--

CREATE TABLE IF NOT EXISTS `location_maps` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `url` varchar(150) DEFAULT NULL,
  `geocode_lt` varchar(10) DEFAULT NULL,
  `geocode_lg` varchar(10) DEFAULT NULL,
  `location_type_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=657 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `location_maps`
--

INSERT INTO `location_maps` (`id`, `name`, `description`, `url`, `geocode_lt`, `geocode_lg`, `location_type_id`, `parent_id`, `lft`, `rght`) VALUES
(573, 'Bakhundole', NULL, 'bakhundole', '27.683528', '85.314202', 4, 482, 899, 900),
(574, 'Ramshah Path', NULL, 'ramshah-path', NULL, NULL, 4, 3, 818, 819),
(575, 'Nakkhu', NULL, 'nakkhu', NULL, NULL, 4, 70, 948, 949),
(14, 'Ward No 10', NULL, 'ward-no-10', NULL, NULL, 6, 3, 116, 135),
(448, 'Hanuman Than', NULL, 'hanuman-sthan', NULL, NULL, 4, 37, 613, 614),
(518, 'Chabahil', NULL, 'chabahil', NULL, NULL, 4, 3, 744, 745),
(15, 'Ward No 11', NULL, 'ward-no-11', NULL, NULL, 6, 3, 136, 179),
(16, 'Ward No 12', NULL, 'ward-no-12', NULL, NULL, 6, 3, 180, 213),
(396, 'Araniko Highway', NULL, 'araniko-highway', NULL, NULL, 4, 39, 655, 656),
(388, 'Bhimsengola ', NULL, 'bhimsengola', '27.700134', '85.343964', 4, 3, 864, 865),
(382, 'Jama Masjid', NULL, 'jama-masjid', NULL, NULL, 5, 36, 583, 584),
(358, 'Bhotahiti', NULL, 'bhotahiti', NULL, NULL, 4, 35, 539, 540),
(356, 'Rastriya Nachgar', NULL, 'rastriya-nachgar', NULL, NULL, 5, 35, 535, 536),
(352, 'Election Commission', NULL, 'election-commission', NULL, NULL, 5, 35, 531, 532),
(351, 'SAARC Secretariat', NULL, 'saarc-secretariat', NULL, NULL, 5, 35, 529, 530),
(350, 'Karmachari Sanchya Kosh (Employee Provident fund))', NULL, 'karmachari-sanchya-kosh-employee-provident-fund', NULL, NULL, 5, 35, 527, 528),
(342, 'GreenLand Children Academy', NULL, 'greenland-children-academy', NULL, NULL, 5, 34, 509, 510),
(331, 'Thamel Chowk', NULL, 'thamel-chowk', NULL, NULL, 5, 34, 487, 488),
(324, 'Penga Than', NULL, 'penga-than', NULL, NULL, 4, 32, 473, 474),
(300, 'Subal Bahal', NULL, 'subal-bahal', NULL, NULL, 4, 29, 423, 424),
(285, 'Desa', NULL, 'desa', NULL, NULL, 4, 28, 391, 392),
(279, 'R.B Complex ', NULL, 'r-b-complex', NULL, NULL, 5, 27, 381, 382),
(278, 'Gautam High School', NULL, 'gautam-high-school', NULL, NULL, 5, 27, 379, 380),
(277, 'EPS school', NULL, 'eps-school', NULL, NULL, 5, 27, 377, 378),
(597, 'Lekhnath Marg', 'Lekhnath Marg', 'lekhnath-marg', '27.717687', '85.313516', 4, 3, 842, 843),
(263, 'Kwakcha', NULL, 'kwakcha', NULL, NULL, 5, 24, 353, 354),
(260, 'Yetkha Bahal', NULL, 'yetkha-bahal', NULL, NULL, 5, 24, 347, 348),
(244, 'Neta Pacho', NULL, 'neta-pacho', NULL, NULL, 4, 23, 313, 314),
(237, 'Indrayeni Temple', NULL, 'indrayeni-temple', NULL, NULL, 5, 22, 297, 298),
(233, 'Pode tole', NULL, 'pode-tole', NULL, NULL, 4, 22, 289, 290),
(232, 'Shanti Sikchya Mandir', NULL, 'shanti-sikchya-mandir', NULL, NULL, 5, 22, 287, 288),
(213, 'Galko Palkho', NULL, 'galko-palkho', NULL, NULL, 4, 21, 247, 248),
(207, 'Bhaucha Khusi Khola', NULL, 'bhaucha-khusi-khola', NULL, NULL, 4, 20, 235, 236),
(154, 'Jambudip Cemetry', NULL, 'jambudip-cemetry', NULL, NULL, 5, 16, 199, 200),
(153, 'Nepal Transportation Corporation', NULL, 'nepal-transportation-corporation', NULL, NULL, 5, 16, 197, 198),
(152, 'Mayal Bari', NULL, 'mayal-bari', NULL, NULL, 5, 16, 195, 196),
(148, 'Buddha Temple', NULL, 'buddha-temple', NULL, NULL, 5, 16, 187, 188),
(143, 'Royal drugs Limited', NULL, 'royal-drugs-limited', NULL, NULL, 5, 15, 175, 176),
(133, 'Army Head quarter', NULL, 'army-head-quarter', NULL, NULL, 5, 15, 165, 166),
(131, 'Bhadrakali Road', NULL, 'bhadrakali-road', NULL, NULL, 4, 15, 161, 162),
(123, 'Drinking Water Corporation', NULL, 'drinking-water-corporation', NULL, NULL, 5, 15, 147, 148),
(118, 'Lakhe Chaur', NULL, 'lakhe-chaur', NULL, NULL, 4, 14, 133, 134),
(100, 'Dhobighat', NULL, 'dhobighat', NULL, NULL, 4, 70, 926, 927),
(76, 'Bhrikuti Tole', NULL, 'bhrikuti-tole', NULL, NULL, 4, 5, 65, 66),
(64, 'Ward Office', NULL, 'ward-office', NULL, NULL, 5, 4, 47, 48),
(61, 'Children Welfare Centre', NULL, 'children-welfare-centre', NULL, NULL, 5, 47, 24, 25),
(60, 'Narayan Temple', NULL, 'narayan-temple', NULL, NULL, 5, 4, 41, 42),
(47, 'Naxal', NULL, 'naksal', NULL, NULL, 4, 4, 19, 26),
(21, 'Ward No 16', NULL, 'ward-no-16', NULL, NULL, 6, 3, 242, 281),
(579, 'Mahendrachowk', NULL, 'mahendrachowk', NULL, NULL, 4, 578, 1008, 1009),
(578, 'Biratnagar', NULL, 'biratnagar', NULL, NULL, 3, 464, 1007, 1010),
(2, 'Bagmati', NULL, 'bagmati', NULL, NULL, 7, 1, 2, 979),
(3, 'Kathmandu', 'Katmandu, Kastamandap', 'kathmandu', NULL, NULL, 3, 2, 3, 874),
(4, 'Ward No 1', NULL, 'ward-no-1', NULL, NULL, 6, 3, 4, 51),
(5, 'Ward No 2', NULL, 'ward-no-2', NULL, NULL, 6, 3, 52, 115),
(576, 'Dharan', NULL, 'dharan', NULL, NULL, 3, 464, 1003, 1006),
(577, 'Bhanuchowk', NULL, 'bhanuchowk', NULL, NULL, 4, 576, 1004, 1005),
(449, 'Maitighar Chowk', NULL, 'maiti-ghar-chowk', '27.69451', '85.320382', 4, 3, 866, 867),
(447, 'Archeology Department', NULL, 'archeology-department', NULL, NULL, 5, 37, 611, 612),
(446, 'High Court', NULL, 'high-court', NULL, NULL, 5, 37, 609, 610),
(445, 'Singha Durbar', NULL, 'singha-durbar', NULL, NULL, 5, 37, 607, 608),
(444, 'Terathume Tole', NULL, 'terathume-tole', NULL, NULL, 4, 37, 605, 606),
(443, 'Anam Nagar', '', 'anam-nagar', '', '', 4, 3, 848, 849),
(509, 'Satungal', NULL, 'satungal', NULL, NULL, 4, 559, 785, 786),
(441, 'Ghattekulo', NULL, 'ghattekulo', NULL, NULL, 4, 37, 603, 604),
(440, 'Nepal Tole', NULL, 'nepal-tole', NULL, NULL, 4, 37, 601, 602),
(439, 'Padmakanya School', NULL, 'padmakanya-school', NULL, NULL, 5, 37, 599, 600),
(438, 'Bijaya Memorial School', NULL, 'bijaya-memorial-school', NULL, NULL, 5, 37, 597, 598),
(437, 'Kalikasthan', NULL, 'kalikasthan', NULL, NULL, 4, 37, 595, 596),
(436, 'Bansghari', NULL, 'bansghari', NULL, NULL, 4, 37, 593, 594),
(434, 'Germany Embassy', NULL, 'germany-embassy', NULL, NULL, 5, 38, 639, 640),
(433, 'Bhairab Sthan', NULL, 'bhairab-sthan', NULL, NULL, 5, 38, 637, 638),
(432, 'Gyaneshwor Ward Office', NULL, 'gyaneshwor-ward-office', NULL, NULL, 5, 38, 635, 636),
(431, 'Narayan Chaur', NULL, 'narayan-chaur', NULL, NULL, 4, 38, 633, 634),
(429, 'Udaland School', NULL, 'udaland-school', NULL, NULL, 5, 38, 631, 632),
(428, 'Kumari Hall', NULL, 'kumari-hall', NULL, NULL, 5, 38, 629, 630),
(427, 'Dhobidhara', NULL, 'dhobidhara', NULL, NULL, 4, 38, 627, 628),
(426, 'Dillibazar', NULL, 'dillibazar', NULL, NULL, 4, 38, 625, 626),
(425, 'Charkhal', NULL, 'charkhal', NULL, NULL, 2, 38, 623, 624),
(424, 'Pancha Kumari Marg', NULL, 'pancha-kumari-marg', NULL, NULL, 4, 38, 621, 622),
(423, 'Maiti Devi Temple', NULL, 'maiti-devi-temple', NULL, NULL, 5, 422, 618, 619),
(422, 'Maitidevi Chowk ', NULL, 'maiti-devi-chowk', NULL, NULL, 4, 38, 617, 620),
(565, 'Uttar Dhoka', NULL, 'uttar-dhoka', NULL, NULL, 4, 3, 792, 793),
(420, 'Subidha Nagar', NULL, 'subidha-nagar', NULL, NULL, 4, 40, 701, 702),
(572, 'Narsing Gate Chowk', NULL, 'narsing-gate-chowk', NULL, NULL, 4, 330, 811, 812),
(418, 'Gairi Gaun', NULL, 'gairi-gaun', NULL, NULL, 4, 40, 699, 700),
(417, 'Basuki Nagar', NULL, 'basuki-nagar', NULL, NULL, 4, 40, 697, 698),
(416, 'Mahadevsthan Height', NULL, 'mahadevsthan-height', NULL, NULL, 4, 40, 695, 696),
(415, 'Koteshwor', NULL, 'koteshwor-mahadev', NULL, NULL, 4, 3, 802, 803),
(414, 'Sahayog Nagar ', NULL, 'sahayog-nagar', NULL, NULL, 4, 40, 693, 694),
(413, 'Setiopi', NULL, 'setiopi', NULL, NULL, 4, 40, 691, 692),
(412, 'Phulbari', NULL, 'phulbari', NULL, NULL, 4, 40, 689, 690),
(411, 'Suryakot', NULL, 'suryakot', NULL, NULL, 4, 40, 687, 688),
(410, 'Tridevi Nagar', NULL, 'tridevi-nagar', NULL, NULL, 4, 40, 685, 686),
(409, 'Kot Devi', NULL, 'kot-devi', NULL, NULL, 4, 40, 683, 684),
(408, 'Jadibuti chowk', NULL, 'jadibuti-chowk', NULL, NULL, 4, 40, 681, 682),
(407, 'Palpakot', NULL, 'palpakot', NULL, NULL, 4, 40, 679, 680),
(406, 'Saraswati Nagar', NULL, 'saraswati-nagar', NULL, NULL, 4, 40, 677, 678),
(405, 'Manahara Tole', NULL, 'manahara-tole', NULL, NULL, 4, 40, 675, 676),
(404, 'Sinamangal', NULL, 'sinamangal', NULL, NULL, 4, 40, 673, 674),
(403, 'Nhakati Tole', NULL, 'nhakati-tole', NULL, NULL, 4, 40, 671, 672),
(402, 'Suruchi Tole', NULL, 'suruchi-tole', NULL, NULL, 4, 39, 667, 668),
(401, 'Chhitiz Nagar', NULL, 'chhitiz-nagar', NULL, NULL, 4, 39, 665, 666),
(400, 'Shree Nagar', NULL, 'shree-nagar', NULL, NULL, 3, 39, 663, 664),
(399, 'Alok Nagar', NULL, 'alok-nagar', NULL, NULL, 4, 39, 661, 662),
(398, 'Min Bhawan', NULL, 'min-bhawan', NULL, NULL, 4, 39, 659, 660),
(397, 'Teenkune', NULL, 'teenkune', NULL, NULL, 4, 39, 657, 658),
(395, 'Birendra International Convention Hall (BICC)', NULL, 'birendra-international-convention-hall-bicc', NULL, NULL, 5, 39, 653, 654),
(394, 'Shiva Darshan Hall', NULL, 'shiva-darshan-hall', NULL, NULL, 5, 39, 651, 652),
(393, 'Jagriti Nagar', NULL, 'jagriti-nagar', NULL, NULL, 4, 39, 649, 650),
(392, 'New (Naya) Baneshwor', NULL, 'new-naya-baneshwor', '27.688335', '85.335574', 4, 3, 858, 859),
(390, 'Milan Chowk', NULL, 'milan-chowk', '27.695137', '85.340445', 4, 387, 861, 862),
(389, 'Gurans tole', NULL, 'gurans-tole', NULL, NULL, 4, 39, 647, 648),
(387, 'Old (Purano) Baneshwor', NULL, 'old-purano-baneshwor', '27.695593', '85.33757', 4, 3, 860, 863),
(386, 'Sinamangal Road', NULL, 'sinamangal-road', NULL, NULL, 4, 39, 645, 646),
(385, 'Maitidevi Street', NULL, 'maitidevi-street', NULL, NULL, 4, 39, 643, 644),
(384, 'Bag Bazaar', NULL, 'bagbazaar-road', NULL, NULL, 4, 36, 587, 590),
(383, 'Model Hospital', NULL, 'model-hospital', NULL, NULL, 5, 36, 585, 586),
(381, 'Tri-chandra College', NULL, 'tri-chandra-college', NULL, NULL, 5, 36, 581, 582),
(593, 'Pyukha', NULL, 'pyukha', NULL, NULL, 4, 264, 829, 830),
(379, 'Shahi Sainik Manch (Army Stage)', NULL, 'shahi-sainik-manch-army-stage', NULL, NULL, 5, 36, 579, 580),
(378, 'Mahankalsthan', NULL, 'mahankalsthan', NULL, NULL, 5, 36, 577, 578),
(377, 'Shanker Dev Campus', NULL, 'shanker-dev-campus', NULL, NULL, 5, 36, 575, 576),
(376, 'Khasibazzar', NULL, 'khasibazzar', NULL, NULL, 5, 36, 573, 574),
(375, 'Putali Sadak', NULL, 'putali-sadak', NULL, NULL, 4, 36, 569, 572),
(374, 'Mahendra Police Club', NULL, 'mahendra-police-club', NULL, NULL, 5, 36, 567, 568),
(373, 'Old Bus Park', NULL, 'old-bus-park', NULL, NULL, 5, 36, 565, 566),
(372, 'Nepal Electricity Authority', NULL, 'nepal-electricity-authority', NULL, NULL, 5, 36, 563, 564),
(371, 'Bhadrakali Chowk', NULL, 'bhadrakali-chowk', NULL, NULL, 5, 36, 559, 562),
(370, 'Kantipath', NULL, 'kantipath', NULL, NULL, 4, 36, 557, 558),
(369, 'Shora Hate Ganesh', NULL, 'shora-hate-ganesh', NULL, NULL, 5, 36, 555, 556),
(368, 'Sahid Gate Road', NULL, 'sahid-gate-road', NULL, NULL, 5, 36, 553, 554),
(367, 'Tundikhel', NULL, 'tundikhel', NULL, NULL, 5, 36, 551, 552),
(366, 'Ratna Park', NULL, 'ratna-park', NULL, NULL, 4, 36, 549, 550),
(365, 'Ranipokhari', NULL, 'ranipokhari', NULL, NULL, 5, 36, 547, 548),
(364, 'Durbar High School', NULL, 'durbar-high-school', NULL, NULL, 5, 35, 543, 544),
(363, 'Mahaboudha', '', 'mahabauddha-street', '27.705335', '85.312168', 4, 3, 872, 873),
(656, 'Kandevsthan', 'Kandevsthan', 'kandevsthan', NULL, NULL, 4, 483, 905, 906),
(361, 'Nepal Dairy', NULL, 'nepal-dairy', NULL, NULL, 5, 35, 541, 542),
(596, 'Kalanki', 'Kalanki', 'kalanki', NULL, NULL, 4, 3, 840, 841),
(357, 'Ason', NULL, 'ason', NULL, NULL, 4, 35, 537, 538),
(566, 'Gokarna', NULL, 'gokarna', NULL, NULL, 4, 3, 794, 797),
(354, 'Kamalachhi', NULL, 'kamalachhi', NULL, NULL, 4, 35, 533, 534),
(349, 'Pabitra Nagar', NULL, 'pabitra-nagar', NULL, NULL, 4, 34, 523, 524),
(348, 'Miteri Pool', NULL, 'miteri-pool', NULL, NULL, 5, 34, 521, 522),
(347, 'Gongabu Planning Area', NULL, 'gongabu-planning-area', NULL, NULL, 5, 34, 519, 520),
(346, 'Morning Star School', NULL, 'morning-star-school', NULL, NULL, 5, 34, 517, 518),
(345, 'Pabitra Nagar', NULL, 'pabitra-nagar', NULL, NULL, 4, 34, 515, 516),
(344, 'New Himal School', NULL, 'new-himal-school', NULL, NULL, 5, 34, 513, 514),
(343, 'Samakhusi Road', NULL, 'samakhusi-road', NULL, NULL, 4, 34, 511, 512),
(341, 'Ranibari', NULL, 'ranibari', NULL, NULL, 4, 34, 507, 508),
(340, 'Indian Embassy', NULL, 'indian-embassy', NULL, NULL, 5, 34, 505, 506),
(339, 'British Embassy', NULL, 'british-embassy', NULL, NULL, 5, 34, 503, 504),
(338, 'Marty''s Memorial School', NULL, 'marty-s-memorial-school', NULL, NULL, 5, 34, 501, 502),
(337, 'Department of Mins and Geology', NULL, 'department-of-mins-and-geology', NULL, NULL, 5, 34, 499, 500),
(335, 'Gairidhara', NULL, 'gairidhara', NULL, NULL, 4, 34, 495, 496),
(334, 'Lokhit High School', NULL, 'lokhit-high-school', NULL, NULL, 5, 34, 493, 494),
(333, 'Bhagwan Bahal', NULL, 'bhagwan-bahal', NULL, NULL, 4, 34, 491, 492),
(332, 'Kesar Mahal', NULL, 'kesar-mahal', NULL, NULL, 5, 34, 489, 490),
(330, 'Thamel', NULL, 'thamel', NULL, NULL, 4, 3, 810, 817),
(329, 'Mhepi', NULL, 'mhepi', NULL, NULL, 4, 34, 485, 486),
(328, 'Mitra Nagar', NULL, 'mitra-nagar', NULL, NULL, 4, 34, 483, 484),
(327, 'Gongabu Bus Park', NULL, 'gongabu-bus-park', NULL, NULL, 4, 34, 481, 482),
(326, 'kusumbiyalachhi', NULL, 'kusumbiyalachhi', NULL, NULL, 4, 32, 477, 478),
(325, 'Bheda Singh', NULL, 'bheda-singh', NULL, NULL, 4, 32, 475, 476),
(323, 'Thanhiti ', NULL, 'thanhiti', NULL, NULL, 4, 32, 471, 472),
(322, 'Indra Chowk', NULL, 'indra-chowk', NULL, NULL, 4, 32, 469, 470),
(321, 'Balkumari', NULL, 'balkumari', NULL, NULL, 4, 32, 467, 468),
(497, 'Samakhusi', NULL, 'samakhusi-1', NULL, NULL, 4, 3, 716, 719),
(319, 'Jyatha Street', NULL, 'jyatha-street', NULL, NULL, 4, 330, 813, 814),
(318, 'Sweta Kali Temple', NULL, 'sweta-kali-temple', NULL, NULL, 5, 31, 463, 464),
(317, 'Bhulukha Dewal', NULL, 'bhulukha-dewal', NULL, NULL, 4, 31, 461, 462),
(316, 'Nar Devi Chowk', NULL, 'nar-devi-chowk', NULL, NULL, 4, 31, 459, 460),
(315, 'Itumbaha', NULL, 'itumbaha', NULL, NULL, 4, 31, 457, 458),
(314, 'Tamsi Pakha Street', NULL, 'tamsi-pakha-street', NULL, NULL, 4, 31, 455, 456),
(313, 'Bangemudha street', NULL, 'bangemudha-street', NULL, NULL, 4, 31, 453, 454),
(312, 'Mahalaxmi Chowk', NULL, 'mahalaxmi-chowk', NULL, NULL, 5, 30, 449, 450),
(311, 'Kumari Chowk', NULL, 'kumari-chowk', NULL, NULL, 5, 30, 447, 448),
(310, 'Hanuman Chowk', NULL, 'hanuman-chowk', NULL, NULL, 5, 30, 445, 446),
(309, 'Indra Chowk', NULL, 'indra-chowk', NULL, NULL, 5, 30, 443, 444),
(308, 'Hanuman Dhoka Durbar Square', NULL, 'hanuman-dhoka-durbar-square', NULL, NULL, 5, 30, 441, 442),
(307, 'District Police Office', NULL, 'district-police-office', NULL, NULL, 5, 30, 439, 440),
(306, 'Hanuman Dhoka ', NULL, 'hanuman-dhoka', NULL, NULL, 4, 30, 437, 438),
(305, 'Marwadi Sewa Samiti', NULL, 'marwadi-sewa-samiti', NULL, NULL, 5, 29, 433, 434),
(304, 'Himalaya Uchcha Madyamik Bidyalaya', NULL, 'himalaya-uchcha-madyamik-bidyalaya', NULL, NULL, 5, 29, 431, 432),
(303, 'Krishna Chowk', NULL, 'krishna-chowk', NULL, NULL, 5, 29, 429, 430),
(302, 'Guheshwori Temple', NULL, 'guheshwori-temple', NULL, NULL, 5, 29, 427, 428),
(301, 'Bhuji Bahal', NULL, 'bhuji-bahal', NULL, NULL, 4, 29, 425, 426),
(299, 'Smul Bahal', NULL, 'smul-bahal', NULL, NULL, 4, 29, 421, 422),
(298, 'Duru Bahal', NULL, 'duru-bahal', NULL, NULL, 4, 29, 419, 420),
(297, 'Ehiva Chowk', NULL, 'ehiva-chowk', NULL, NULL, 4, 29, 417, 418),
(296, 'Dau Bahal', NULL, 'dau-bahal', NULL, NULL, 4, 29, 415, 416),
(295, 'Phasikeba', NULL, 'phasikeba', NULL, NULL, 4, 29, 413, 414),
(294, 'Ranjana Galli', NULL, 'ranjana-galli', NULL, NULL, 4, 29, 411, 412),
(293, 'Guchcha Tole', NULL, 'guchcha-tole', NULL, NULL, 4, 29, 409, 410),
(292, 'Watu Tole', NULL, 'watu-tole', NULL, NULL, 4, 29, 407, 408),
(291, 'layakusa', NULL, 'layakusa', NULL, NULL, 5, 28, 403, 404),
(290, 'Om Bahal', NULL, 'om-bahal', NULL, NULL, 5, 28, 401, 402),
(289, 'Mathema Chowk', NULL, 'mathema-chowk', NULL, NULL, 5, 28, 399, 400),
(288, 'Chikamugal', NULL, 'chikamugal', NULL, NULL, 5, 28, 397, 398),
(287, 'Narayan Temple', NULL, 'narayan-temple', NULL, NULL, 5, 28, 395, 396),
(286, 'Mahadev Temple', NULL, 'mahadev-temple', NULL, NULL, 5, 28, 393, 394),
(606, 'Kundhar', '', 'kundhar', '28.262621', '83.972626', 4, 580, 994, 995),
(283, 'Kumari house (gar)', NULL, 'kumari-house-gar', NULL, NULL, 5, 28, 389, 390),
(282, 'Nasapha', NULL, 'nasapha', NULL, NULL, 5, 28, 387, 388),
(281, 'kumari Chowk', NULL, 'kumari-chowk', NULL, NULL, 5, 28, 385, 386),
(602, 'Hariharbhawan', '', 'hariharbhawan', NULL, NULL, 4, 3, 856, 857),
(276, 'Bhadrakali Temple', NULL, 'bhadrakali-temple', NULL, NULL, 5, 371, 560, 561),
(275, 'Shankata Temple', NULL, 'shankata-temple', NULL, NULL, 5, 27, 375, 376),
(274, 'Shankata Primary School', NULL, 'shankata-primary-school', NULL, NULL, 5, 27, 373, 374),
(273, 'Depart of Ministry', NULL, 'depart-of-ministry', NULL, NULL, 5, 27, 371, 372),
(272, 'Nepal Bank', NULL, 'nepal-bank', NULL, NULL, 5, 27, 369, 370),
(270, 'Post Office Nepal', NULL, 'post-office-nepal', NULL, NULL, 5, 27, 367, 368),
(269, 'RNAC Building', NULL, 'rnac-building', NULL, NULL, 5, 27, 365, 366),
(268, 'Pako', NULL, 'pako', NULL, NULL, 4, 264, 825, 826),
(267, 'Sundhara ', NULL, 'sundhara', NULL, NULL, 4, 27, 363, 364),
(266, 'Tebahal', NULL, 'tebahal', NULL, NULL, 4, 27, 361, 362),
(508, 'Kamaladi', NULL, 'kamaladi', NULL, NULL, 4, 3, 736, 737),
(264, 'New Road', NULL, 'new-road', '27.703421', '85.311499', 4, 3, 822, 831),
(262, 'Santeshwor Mahadev ', NULL, 'santeshwor-mahadev', NULL, NULL, 5, 24, 351, 352),
(261, 'Arunodaya lower secondary School (Bidyalaya)', NULL, 'arunodaya-lower-secondary-school-bidyalaya', NULL, NULL, 5, 24, 349, 350),
(259, 'Kankeshwori Temple', NULL, 'kankeshwori-temple', NULL, NULL, 5, 24, 345, 346),
(258, 'Damai Tole', NULL, 'damai-tole', NULL, NULL, 4, 24, 343, 344),
(257, 'Chasan Tole', NULL, 'chasan-tole', NULL, NULL, 4, 24, 341, 342),
(256, 'Kasthamandup ', NULL, 'kasthamandup', NULL, NULL, 4, 24, 339, 340),
(255, 'Maru Dhoka Tole', NULL, 'maru-dhoka-tole', NULL, NULL, 4, 24, 337, 338),
(254, 'Bhurungkhel Park', NULL, 'bhurungkhel-park', NULL, NULL, 5, 23, 333, 334),
(253, 'Deko Park', NULL, 'deko-park', NULL, NULL, 5, 23, 331, 332),
(252, 'Jaljala School', NULL, 'jaljala-school', NULL, NULL, 5, 23, 329, 330),
(251, 'Hotel Harati', NULL, 'hotel-harati', NULL, NULL, 5, 23, 327, 328),
(250, 'Small Heaven''s School', NULL, 'small-heaven-s-school', NULL, NULL, 5, 23, 325, 326),
(249, 'Jenith School', NULL, 'jenith-school', NULL, NULL, 5, 23, 323, 324),
(248, 'Swetkal', NULL, 'swetkal', NULL, NULL, 4, 23, 321, 322),
(247, 'Baidya Chowk', NULL, 'baidya-chowk', NULL, NULL, 4, 23, 319, 320),
(246, 'Ikha Pokhari', NULL, 'ikha-pokhari', NULL, NULL, 4, 23, 317, 318),
(245, 'Pachhai Galli', NULL, 'pachhai-galli', NULL, NULL, 4, 23, 315, 316),
(243, 'Deko Tole', NULL, 'deko-tole', NULL, NULL, 4, 23, 311, 312),
(242, 'Saraswati School', NULL, 'saraswati-school', NULL, NULL, 5, 22, 307, 308),
(241, 'Public Youth Campus', NULL, 'public-youth-campus', NULL, NULL, 5, 22, 305, 306),
(240, 'Chhetrapati Street', NULL, 'chhetrapati-street', NULL, NULL, 4, 22, 303, 304),
(239, 'Kusale Chaur', NULL, 'kusale-chaur', NULL, NULL, 4, 22, 301, 302),
(238, 'Khusiboo', NULL, 'khusiboo', NULL, NULL, 4, 22, 299, 300),
(236, 'Raktakali School ', NULL, 'raktakali-school', NULL, NULL, 5, 22, 295, 296),
(235, 'NRB School', NULL, 'nrb-school', NULL, NULL, 5, 22, 293, 294),
(234, 'Dhobichaur ', NULL, 'dhobichaur', NULL, NULL, 4, 22, 291, 292),
(231, 'Kathmandu Medical College', NULL, 'kathmandu-medical-college', NULL, NULL, 5, 22, 285, 286),
(230, 'Thaiti ', NULL, 'thaiti', NULL, NULL, 4, 22, 283, 284),
(229, 'Ghoda Tabela', NULL, 'ghoda-tabela', NULL, NULL, 5, 21, 279, 280),
(228, 'Vanasthali School', NULL, 'vanasthali-school', NULL, NULL, 5, 21, 277, 278),
(227, 'Saraswati Campus', NULL, 'saraswati-campus', NULL, NULL, 5, 21, 275, 276),
(226, 'Banasthali ', NULL, 'banasthali', NULL, NULL, 4, 21, 273, 274),
(225, 'Mhaipi Street', NULL, 'mhaipi-street', NULL, NULL, 4, 21, 271, 272),
(224, 'Balaju Industrial Area', NULL, 'balaju-industrial-area', NULL, NULL, 4, 21, 269, 270),
(223, 'Baisa Dhara', NULL, 'baisa-dhara', NULL, NULL, 4, 21, 267, 268),
(222, 'Balaju chowk', NULL, 'balaju-chowk', NULL, NULL, 5, 21, 265, 266),
(221, 'Nagarjun Forest road', NULL, 'nagarjun-forest-road', NULL, NULL, 4, 21, 263, 264),
(220, 'Ekaltar', NULL, 'ekaltar', NULL, NULL, 4, 21, 261, 262),
(219, 'Balajutar', NULL, 'balajutar', NULL, NULL, 4, 21, 259, 260),
(218, 'Swayambhu ', NULL, 'swayambhu', NULL, NULL, 4, 21, 257, 258),
(217, 'Vanasthali ', NULL, 'vanasthali', NULL, NULL, 4, 21, 255, 256),
(216, 'Balaju ', NULL, 'balaju', NULL, NULL, 4, 21, 253, 254),
(215, 'Mhaipi Street', NULL, 'mhaipi-street', NULL, NULL, 4, 21, 251, 252),
(214, 'Naya Bazar ', NULL, 'naya-bazar', NULL, NULL, 4, 21, 249, 250),
(212, 'Kaldhara', NULL, 'kaldhara', NULL, NULL, 4, 21, 245, 246),
(211, 'Paknajol', NULL, 'paknajol', NULL, NULL, 4, 21, 243, 244),
(210, 'Chaksibari Road', NULL, 'chaksibari', NULL, NULL, 4, 330, 815, 816),
(209, 'Dallu Planning Area', NULL, 'dallu-planning-area', NULL, NULL, 4, 20, 239, 240),
(208, 'Bhuikhel', NULL, 'bhuikhel', NULL, NULL, 4, 20, 237, 238),
(206, 'Shova Bhagbati ', NULL, 'shova-bhagbati', NULL, NULL, 4, 20, 233, 234),
(205, 'Bijayswari', NULL, 'bijayswari', NULL, NULL, 4, 20, 231, 232),
(204, 'Chagal', NULL, 'chagal', NULL, NULL, 4, 20, 229, 230),
(203, 'Gathaghar', NULL, 'gathaghar', NULL, NULL, 4, 20, 227, 228),
(202, 'Dallu Chhauni', NULL, 'dallu-chhauni', NULL, NULL, 4, 3, 804, 805),
(599, 'Tahachal', 'Tahachal', 'tahachal', NULL, NULL, 4, 3, 850, 851),
(200, 'Chhauni', 'Chhauni', 'chhauni-byarek', NULL, NULL, 4, 20, 225, 226),
(199, 'Kimdol Chhauni', NULL, 'kimdol-chhauni', NULL, NULL, 4, 20, 223, 224),
(198, 'Kimdol', NULL, 'kimdol', NULL, NULL, 4, 20, 221, 222),
(197, 'Wahiti', NULL, 'wahiti', NULL, NULL, 4, 20, 219, 220),
(196, 'Manju Shree Bazar', NULL, 'manju-shree-bazar', NULL, NULL, 4, 20, 217, 218),
(195, 'Shanti Nagar', NULL, 'shanti-nagar', NULL, NULL, 4, 20, 215, 216),
(192, 'Balkhu', NULL, 'balkhu-tekusi', NULL, NULL, 4, 3, 832, 833),
(163, 'Sitapaila Road', NULL, 'sita-paila-road', NULL, NULL, 4, 523, 749, 750),
(162, 'Banijya Bank', NULL, 'banijya-bank', NULL, NULL, 5, 16, 211, 212),
(499, 'Gongabu Chowk', NULL, 'gongabu-chowk', NULL, NULL, 4, 497, 717, 718),
(159, 'FNCCI ', NULL, 'fncci', NULL, NULL, 5, 16, 209, 210),
(158, 'Bikasheshwor Mahadev', NULL, 'bikasheshwor-mahadev', NULL, NULL, 5, 16, 207, 208),
(157, 'Pachali Bhairab', NULL, 'pachali-bhairab', NULL, NULL, 5, 16, 205, 206),
(156, 'Pachali Park', NULL, 'pachali-park', NULL, NULL, 5, 16, 203, 204),
(155, 'Laxmeshwor Mahadev', NULL, 'laxmeshwor-mahadev', NULL, NULL, 5, 16, 201, 202),
(151, 'National Trading Limited', NULL, 'national-trading-limited', NULL, NULL, 5, 16, 193, 194),
(150, 'Teku Road', NULL, 'teku-road', NULL, NULL, 4, 16, 191, 192),
(149, 'Brahma Tole', NULL, 'brahma-tole', NULL, NULL, 5, 16, 189, 190),
(147, 'Saraswati Niketan High Scholl', NULL, 'saraswati-niketan-high-scholl', NULL, NULL, 5, 16, 185, 186),
(146, 'Tuke Bahal', NULL, 'tuke-bahal', NULL, NULL, 4, 16, 183, 184),
(145, 'Jaisi Dewal ', NULL, 'jaisi-dewal', NULL, NULL, 4, 16, 181, 182),
(500, 'Ombahal', NULL, 'ombahal', NULL, NULL, 4, 501, 723, 724),
(485, 'Babar Mahal', NULL, 'babar-mahal', '27.696372', '85.322571', 4, 3, 838, 839),
(141, 'Ministry of Health', NULL, 'ministry-of-health', NULL, NULL, 5, 15, 173, 174),
(498, 'Maharajgunj', NULL, 'maharajgunj', NULL, NULL, 4, 3, 720, 721),
(496, 'Kuleshwor', NULL, 'kuleshwor', NULL, NULL, 4, 3, 714, 715),
(136, 'Nepal Food Corporation', NULL, 'nepal-food-corporation', NULL, NULL, 5, 15, 171, 172),
(135, 'National Insurance Corporation', NULL, 'national-insurance-corporation', NULL, NULL, 5, 15, 169, 170),
(134, 'Rastriya Banijya Bank', NULL, 'rastriya-banijya-bank', NULL, NULL, 5, 15, 167, 168),
(132, 'National News Council', NULL, 'national-news-council', NULL, NULL, 5, 15, 163, 164),
(130, 'Nepal Tele Communication Corporation (NTC)', NULL, 'nepal-tele-communication-corporation-ntc', NULL, NULL, 5, 15, 159, 160),
(129, 'Bag Durbar', NULL, 'bag-durbar', NULL, NULL, 5, 15, 157, 158),
(128, 'Ministry of finance', NULL, 'ministry-of-finance', NULL, NULL, 5, 15, 155, 156),
(127, 'Kymp Office', NULL, 'kymp-office', NULL, NULL, 5, 15, 153, 154),
(126, 'Vetenary Hospital', NULL, 'vetenary-hospital', NULL, NULL, 5, 119, 138, 139),
(125, 'Department of Industry', NULL, 'department-of-industry', NULL, NULL, 5, 15, 151, 152),
(124, 'Jan Prashasan Campus', NULL, 'jan-prashasan-campus', NULL, NULL, 5, 15, 149, 150),
(122, 'Central Jail', NULL, 'central-jail', NULL, NULL, 5, 15, 145, 146),
(121, 'Bhote Bahal', NULL, 'bhote-bahal', NULL, NULL, 4, 15, 143, 144),
(120, 'Milan Marg', NULL, 'milan-marg', NULL, NULL, 4, 15, 141, 142),
(119, 'Tripureshwor', NULL, 'tripureshwor-street', NULL, NULL, 4, 15, 137, 140),
(117, 'Shanti Binayak', NULL, 'shanti-binayak', NULL, NULL, 5, 14, 131, 132),
(116, 'Pushpa Nagar', NULL, 'pushpa-nagar', NULL, NULL, 5, 14, 129, 130),
(115, 'Mahadevsthan', NULL, 'mahadevsthan', NULL, NULL, 5, 14, 127, 128),
(600, 'Bhimsenthan', '', 'bhimsenthan', NULL, NULL, 4, 3, 852, 853),
(601, 'Tinkune', 'Tinkune, Koteswor', 'tinkune', NULL, NULL, 1, 3, 854, 855),
(111, 'CDO Tole', NULL, 'cdo-tole', NULL, NULL, 5, 14, 125, 126),
(604, 'Bhani Mandal', 'Bhani Mandal', 'bhani-mandal-1', '', '', 4, 513, 921, 922),
(605, 'Nhugu Pokhari', 'Nhugu Pokhari', 'nhugu-pokhari', NULL, NULL, 4, 70, 958, 959),
(108, 'Bagati Tole', NULL, 'bagati-tole', NULL, NULL, 5, 14, 123, 124),
(107, 'Bijuli Bazar', NULL, 'bijuli-bazar', NULL, NULL, 5, 14, 121, 122),
(105, 'Shankamul Tol', '', 'shankamul-tol', NULL, NULL, 4, 14, 119, 120),
(511, 'Chakupat', NULL, 'chakupat', NULL, NULL, 4, 70, 916, 917),
(103, 'Baneshwor Height Road', NULL, 'baneshwor-height-road', NULL, NULL, 4, 14, 117, 118),
(102, 'French Embassy', NULL, 'french-embassy', NULL, NULL, 5, 5, 113, 114),
(101, 'Lazimpat', NULL, 'lazimpat', NULL, NULL, 4, 5, 111, 112),
(99, 'Kharel Tole', NULL, 'kharel-tole', NULL, NULL, 5, 5, 109, 110),
(98, 'Hotel Ambassador', NULL, 'hotel-ambassador', NULL, NULL, 5, 5, 107, 108),
(97, 'Universal Academy', NULL, 'universal-academy', NULL, NULL, 5, 5, 105, 106),
(96, 'Sisan School', NULL, 'sisan-school', NULL, NULL, 5, 5, 103, 104),
(95, 'Rapurdhara', NULL, 'rapurdhara', NULL, NULL, 5, 5, 101, 102),
(94, 'Kailash Chowk', NULL, 'kailash-chowk', NULL, NULL, 4, 5, 99, 100),
(93, 'Hotel Radission', NULL, 'hotel-radission', NULL, NULL, 5, 5, 97, 98),
(92, 'Phuspalal Academy', NULL, 'phuspalal-academy', NULL, NULL, 5, 5, 95, 96),
(91, 'Dayashor Mahadev', NULL, 'dayashor-mahadev', NULL, NULL, 5, 5, 93, 94),
(90, 'Princewood Academy', NULL, 'princewood-academy', NULL, NULL, 5, 5, 91, 92),
(89, 'Finland Embassy', NULL, 'finland-embassy', NULL, NULL, 5, 5, 89, 90),
(88, 'Sunrise School', NULL, 'sunrise-school', NULL, NULL, 5, 5, 87, 88),
(87, 'France School', NULL, 'france-school', NULL, NULL, 5, 5, 85, 86),
(86, 'Chandratara School', NULL, 'chandratara-school', NULL, NULL, 5, 5, 83, 84),
(85, 'Khursani Tar', NULL, 'khursani-tar', NULL, NULL, 4, 5, 81, 82),
(84, 'Blue Horizon School ', NULL, 'blue-horizon-school', NULL, NULL, 5, 5, 79, 80),
(83, 'Sakuna Phant', NULL, 'sakuna-phant', NULL, NULL, 5, 5, 77, 78),
(82, 'Anupam School', NULL, 'anupam-school', NULL, NULL, 5, 5, 75, 76),
(81, 'Neel Saraswati', NULL, 'neel-saraswati', NULL, NULL, 5, 5, 73, 74),
(80, 'Fairland School', NULL, 'fairland-school', NULL, NULL, 5, 5, 71, 72),
(510, 'Jhamsikhel', NULL, 'jhamsikhel', NULL, NULL, 4, 70, 912, 915),
(78, 'Jor Peepal', NULL, 'jor-peepal', NULL, NULL, 5, 5, 69, 70),
(77, 'Tangal', NULL, 'tangal', NULL, NULL, 4, 5, 67, 68),
(75, 'Gairi Dhara', NULL, 'gairi-dhara', NULL, NULL, 5, 5, 63, 64),
(74, 'Nakshal', NULL, 'nakshal', NULL, NULL, 4, 5, 59, 62),
(73, 'Nag Pokhari', NULL, 'nag-pokhari', NULL, NULL, 5, 5, 57, 58),
(72, 'Shiva temple', NULL, 'shiva-temple', NULL, NULL, 5, 5, 55, 56),
(71, 'Kailashchowk', NULL, 'kailashchowk', NULL, NULL, 5, 5, 53, 54),
(70, 'Lalitpur (Patan)', NULL, 'lalitpur', NULL, NULL, 3, 2, 897, 966),
(69, 'Bhaktapur', NULL, 'bhaktapur', NULL, NULL, 3, 2, 875, 896),
(477, 'Narayani', NULL, 'narayani', NULL, NULL, 7, 1, 1020, 1031),
(67, 'Lumbini', NULL, 'lumbini', NULL, NULL, 7, 1, 980, 985),
(514, 'Narayanhiti Marg (Path)', NULL, 'narayanhiti-marg-path', NULL, NULL, 4, 4, 49, 50),
(65, 'Naksal Bhagwati', NULL, 'naksal-bhagwati', NULL, NULL, 5, 47, 20, 21),
(63, 'Public Service Commission', NULL, 'public-service-commission', NULL, NULL, 5, 4, 45, 46),
(62, 'Goma Ganesh Temple', NULL, 'goma-ganesh-temple', NULL, NULL, 5, 4, 43, 44),
(59, 'Himal Nursing Home', NULL, 'himal-nursing-home', NULL, NULL, 5, 4, 39, 40),
(58, 'Om Nursing Home', NULL, 'om-nursing-home', NULL, NULL, 5, 4, 37, 38),
(57, 'Jain Mandhir', NULL, 'jain-mandhir', NULL, NULL, 5, 45, 16, 17),
(56, 'Kumari Temple', NULL, 'kumari-temple', NULL, NULL, 5, 4, 35, 36),
(55, 'Bagmati Boarding School', NULL, 'bagmati-boarding-school', NULL, NULL, 5, 74, 60, 61),
(54, 'Fohara Durbar', NULL, 'fohara-durbar', NULL, NULL, 5, 4, 33, 34),
(53, 'Hotel Annapurna', NULL, 'hotel-annapurna', NULL, NULL, 5, 4, 31, 32),
(52, 'Seto Durbar', NULL, 'seto-durbar', NULL, NULL, 5, 4, 29, 30),
(51, 'Bishowo Jyoti Hall', NULL, 'bishowo-jyoti-hall', NULL, NULL, 5, 43, 12, 13),
(50, 'Jay Nepal Hall', NULL, 'jay-nepal-hall', NULL, NULL, 5, 42, 6, 7),
(49, 'Police Headquarter', NULL, 'police-headquarter', NULL, NULL, 5, 47, 22, 23),
(48, 'Nag Pokhari', NULL, 'nag-pokhari', NULL, NULL, 4, 4, 27, 28),
(46, 'Royal Palace Museum', NULL, 'royal-palace-museum', NULL, NULL, 5, 41, 807, 808),
(45, 'Kamal Pokhari', NULL, 'kamal-pokhari', NULL, NULL, 4, 4, 15, 18),
(44, 'Krishna Bakery Chowk (Krishna Pauroti Chowk)', NULL, 'krishna-bakery-chowk-krishna-pauroti-chowk', NULL, NULL, 5, 42, 8, 9),
(43, 'Jamal', NULL, 'jamal', NULL, NULL, 4, 4, 11, 14),
(42, 'Hattisar', NULL, 'hattisar', NULL, NULL, 4, 4, 5, 10),
(41, 'Durbarmarg (Kings Way)', 'Durbarmarg, Kings Way', 'kings-way-durbarmarg', NULL, NULL, 4, 3, 806, 809),
(40, 'Ward No 35', NULL, 'ward-no-35', NULL, NULL, 6, 3, 670, 703),
(39, 'Ward No 34', NULL, 'ward-no-34', NULL, NULL, 6, 3, 642, 669),
(38, 'Ward No 33', NULL, 'ward-no-33', NULL, NULL, 6, 3, 616, 641),
(37, 'Ward No 32', NULL, 'ward-no-32', NULL, NULL, 6, 3, 592, 615),
(35, 'Ward No 30', NULL, 'ward-no-30', NULL, NULL, 6, 3, 526, 545),
(34, 'Ward No 29', NULL, 'ward-no-29', NULL, NULL, 6, 3, 480, 525),
(32, 'Ward No 27', NULL, 'ward-no-27', NULL, NULL, 6, 3, 466, 479),
(31, 'Ward No 26', NULL, 'ward-no-26', NULL, NULL, 6, 3, 452, 465),
(30, 'Ward No 25', NULL, 'ward-no-25', NULL, NULL, 6, 3, 436, 451),
(29, 'Ward No 24', NULL, 'ward-no-24', NULL, NULL, 6, 3, 406, 435),
(27, 'Ward No 22', NULL, 'ward-no-22', NULL, NULL, 6, 3, 360, 383),
(26, 'Ward No 21', NULL, 'ward-no-21', NULL, NULL, 6, 3, 356, 359),
(24, 'Ward No 19', NULL, 'ward-no-19', NULL, NULL, 6, 3, 336, 355),
(23, 'Ward No 18', NULL, 'ward-no-18', NULL, NULL, 6, 3, 310, 335),
(22, 'Ward No 17', NULL, 'ward-no-17', NULL, NULL, 6, 3, 282, 309),
(20, 'Ward No 15', NULL, 'ward-no-15', NULL, NULL, 6, 3, 214, 241),
(36, 'Ward No 31', NULL, 'ward-no-31', NULL, NULL, 6, 3, 546, 591),
(336, 'Dairy Development Corporation', NULL, 'dairy-development-corporation', NULL, NULL, 5, 34, 497, 498),
(28, 'Ward No 23', NULL, 'ward-no-23', NULL, NULL, 6, 3, 384, 405),
(1, 'Nepal', '', 'nepal', NULL, NULL, 1, NULL, 1, 1040),
(459, 'Bheri', NULL, 'bheri', NULL, NULL, 7, 1, 986, 987),
(460, 'Dhawalagiri', NULL, 'dhawalagiri', NULL, NULL, 7, 1, 988, 989),
(461, 'Gandaki', NULL, 'gandaki', NULL, NULL, 7, 1, 990, 997),
(462, 'Janakpur', NULL, 'janakpur', NULL, NULL, 7, 1, 998, 999),
(463, 'Karnali', NULL, 'karnali', NULL, NULL, 7, 1, 1000, 1001),
(464, 'Koshi', NULL, 'koshi', NULL, NULL, 7, 1, 1002, 1011),
(465, 'Mahakali', NULL, 'mahakali', NULL, NULL, 7, 1, 1012, 1013),
(466, 'Mechi', NULL, 'mechi', NULL, NULL, 7, 1, 1014, 1019),
(478, 'Rapti', NULL, 'rapti', NULL, NULL, 7, 1, 1032, 1033),
(479, 'Sagarmatha', NULL, 'sagarmatha', NULL, NULL, 7, 1, 1034, 1035),
(480, 'Seti', NULL, 'seti-1', NULL, NULL, 7, 1, 1036, 1037),
(481, 'Tilganga', NULL, 'tilganga', NULL, NULL, 4, 26, 357, 358),
(482, 'Sanepa', NULL, 'sanepa', NULL, NULL, 4, 70, 898, 901),
(483, 'Kupondole', NULL, 'kupondole', NULL, NULL, 4, 70, 902, 907),
(484, 'Pulchowk', NULL, 'pulchowk', NULL, NULL, 4, 70, 908, 909),
(486, 'Thapathali', NULL, 'thapathali', NULL, NULL, 4, 15, 177, 178),
(488, 'Boudha', NULL, 'boudha', NULL, NULL, 4, 3, 704, 705),
(489, 'Makhan Tole', NULL, 'makhan-tole', NULL, NULL, 4, 3, 706, 707),
(490, 'Jhochhen Tole (Freak Street)', NULL, 'jhochhen-tole-freak-street', NULL, NULL, 4, 3, 708, 709),
(491, 'Khichapokhari', NULL, 'khichapokhari', NULL, NULL, 4, 264, 823, 824),
(492, 'Ichchhumati Tole', NULL, 'ichchhumati-tole', NULL, NULL, 4, 384, 588, 589),
(493, 'Kumaripati', NULL, 'kumaripati', '27.670644', '85.320425', 4, 70, 950, 951),
(494, 'Janbahal', NULL, 'janbahal', NULL, NULL, 4, 3, 710, 713),
(495, 'Keltole', NULL, 'keltole', NULL, NULL, 4, 494, 711, 712),
(501, 'Siddicharan Marg', NULL, 'siddicharan-marg', NULL, NULL, 4, 3, 722, 725),
(502, 'Gyaneshwor', NULL, 'gyaneshwor-1', NULL, NULL, 4, 3, 726, 727),
(503, 'Shukra Path', NULL, 'shukra-path', NULL, NULL, 4, 3, 728, 729),
(504, 'Baluwatar', NULL, 'baluwatar', NULL, NULL, 4, 3, 730, 731),
(505, 'Pashupati Sadak', NULL, 'pashupati-sadak', NULL, NULL, 4, 3, 732, 733),
(506, 'Naghal Tole', NULL, 'naghal-tole', NULL, NULL, 4, 3, 734, 735),
(507, 'Lagankhel', NULL, 'lagankhel', NULL, NULL, 4, 70, 910, 911),
(512, 'Lukshi', NULL, 'lukshi', NULL, NULL, 4, 70, 918, 919),
(513, 'Jawalakhel', NULL, 'jawalakhel', NULL, NULL, 4, 70, 920, 923),
(515, 'Gauchar', NULL, 'gauchar', NULL, NULL, 4, 3, 738, 739),
(516, 'Gaushala', NULL, 'gaushala', NULL, NULL, 4, 3, 740, 741),
(517, 'Singha Durbar', NULL, 'singh-durbar', NULL, NULL, 4, 3, 742, 743),
(519, 'Ekantakuna', NULL, 'ekantakuna', NULL, NULL, 4, 70, 924, 925),
(520, 'Gwarko', NULL, 'gwarko', NULL, NULL, 4, 70, 928, 931),
(521, 'Basundhara', NULL, 'basundhara', NULL, NULL, 4, 3, 746, 747),
(522, 'New Plaza', NULL, 'new-plaza', NULL, NULL, 4, 375, 570, 571),
(523, 'Ring Road', NULL, 'ring-road', NULL, NULL, 4, 3, 748, 753),
(524, 'Lainchaur', NULL, 'lainchaur', NULL, NULL, 4, 3, 754, 755),
(525, 'Chobhar', NULL, 'chobhar', NULL, NULL, 4, 526, 968, 969),
(526, 'Kirtipur', NULL, 'kirtipur', NULL, NULL, 3, 2, 967, 972),
(527, 'Panipokhari', NULL, 'panipokhari', NULL, NULL, 4, 3, 756, 757),
(528, 'Battisputali', 'Battisputali Marg, Battisputali Road', 'battisputali', '27.704979', '85.342033', 4, 3, 758, 759),
(529, 'Jorpati', NULL, 'jorpati', NULL, NULL, 4, 3, 760, 761),
(530, 'Budhanilkantha', NULL, 'budhanilkantha', NULL, NULL, 4, 3, 762, 763),
(531, 'Bansbari', NULL, 'bansbari', NULL, NULL, 4, 3, 764, 765),
(532, 'Dharma Path', NULL, 'dharma-path', NULL, NULL, 4, 264, 827, 828),
(533, 'Khumaltar', NULL, 'khumaltar', NULL, NULL, 4, 70, 932, 933),
(534, 'Chithu', NULL, 'chithu', NULL, NULL, 4, 526, 970, 971),
(535, 'Golphutar', NULL, 'golphutar', NULL, NULL, 4, 3, 766, 767),
(536, 'Godawari', NULL, 'godawari', NULL, NULL, 3, 2, 973, 976),
(537, 'Taukhel', NULL, 'taukhel', NULL, NULL, 4, 536, 974, 975),
(538, 'Bhat Bhateni', NULL, 'bhat-bhateni', NULL, NULL, 4, 3, 768, 769),
(539, 'Bishalnagar', NULL, 'bishalnagar', NULL, NULL, 4, 3, 770, 771),
(540, 'Baghdol', NULL, 'baghdol', NULL, NULL, 4, 70, 934, 935),
(541, 'Pradarshani Marg', NULL, 'pradarshani-marg', NULL, NULL, 4, 3, 772, 773),
(542, 'Patan Dhoka', NULL, 'patan-dhoka', NULL, NULL, 4, 70, 936, 937),
(543, 'Mangal Bazaar', NULL, 'mangal-bazaar', NULL, NULL, 4, 70, 938, 939),
(544, 'Patan Durbar Square', NULL, 'patan-durbar-square', NULL, NULL, 4, 70, 940, 941),
(545, 'Man Bhawan', NULL, 'man-bhawan', '27.672165', '85.316048', 4, 70, 942, 943),
(546, 'Basantapur', NULL, 'basantapur-1', NULL, NULL, 4, 3, 774, 775),
(571, 'Sanothimi', NULL, 'sanothimi', NULL, NULL, 4, 69, 888, 889),
(549, 'Kaushaltar', NULL, 'kaushaltar', NULL, NULL, 4, 3, 778, 779),
(550, 'Balkot 4', NULL, 'balkot-4', NULL, NULL, 4, 69, 876, 877),
(551, 'Bhaktapur 14', NULL, 'bhaktapur-14', NULL, NULL, 4, 69, 878, 879),
(552, 'Kapan-3', NULL, 'kapan-3', NULL, NULL, 4, 3, 780, 781),
(553, 'Bhaktapur 15', NULL, 'bhaktapur-15', NULL, NULL, 4, 69, 880, 881),
(554, 'Manmiju 16', NULL, 'manmiju-16', NULL, NULL, 4, 3, 782, 783),
(555, 'Mathinapa 16', NULL, 'mathinapa-16', NULL, NULL, 4, 69, 882, 883),
(557, 'Mathinapa 12', NULL, 'mathinapa-12', NULL, NULL, 4, 69, 884, 885),
(558, 'Katunje 8', NULL, 'katunje-8', NULL, NULL, 4, 69, 886, 887),
(559, 'Thankot', NULL, 'thankot', NULL, NULL, 4, 3, 784, 787),
(560, 'Dhumbarahi', NULL, 'dhumbarahi', NULL, NULL, 4, 3, 788, 789),
(561, 'Bafal', NULL, 'bafal', NULL, NULL, 4, 523, 751, 752),
(562, 'Satdobato', NULL, 'satdobato', NULL, NULL, 4, 70, 944, 945),
(563, 'Tudikhel', NULL, 'tudikhel', NULL, NULL, 4, 3, 790, 791),
(564, 'Kavre', NULL, 'kavre', NULL, NULL, 3, 1, 1038, 1039),
(567, 'Rajnikung', NULL, 'rajnikung', NULL, NULL, 4, 566, 795, 796),
(568, 'Krishna Galli', NULL, 'krishna-galli', NULL, NULL, 4, 70, 946, 947),
(569, 'Buddha Nagar', NULL, 'buddha-nagar', NULL, NULL, 4, 3, 798, 799),
(570, 'Bijuli Bazaar', NULL, 'bijuli-bazaar', NULL, NULL, 4, 3, 800, 801),
(580, 'Pokhara', NULL, 'pokhara', NULL, NULL, 3, 461, 991, 996),
(581, 'Chipledhunga', NULL, 'chipledhunga', NULL, NULL, 4, 580, 992, 993),
(582, 'Narayangadh', NULL, 'chitwan', NULL, NULL, 3, 583, 1022, 1025),
(583, 'Chitwan', NULL, 'chitwan-1', NULL, NULL, 8, 477, 1021, 1030),
(584, 'Lions Chowk', NULL, 'lions-chowk', NULL, NULL, 4, 582, 1023, 1024),
(585, 'Rabibhawan', NULL, 'rabibhawan', '', '', 4, 598, 845, 846),
(586, 'Kapurdhara', NULL, 'kapurdhara', NULL, NULL, 4, 3, 820, 821),
(587, 'Imadol', NULL, 'imadol', NULL, NULL, 4, 520, 929, 930),
(589, 'Hattiban', NULL, 'hattiban', NULL, NULL, 4, 70, 952, 953),
(590, 'Mahalaxmisthan Chowk', NULL, 'mahalaxmisthan-chowk', NULL, NULL, 4, 70, 954, 955),
(591, 'Naya Bato', NULL, 'naya-bato', NULL, NULL, 4, 70, 956, 957),
(592, 'Thado Dhunga', NULL, 'thado-dhunga', NULL, NULL, 4, 510, 913, 914),
(594, 'Dhapasi', 'Dhapasi Marga', 'dhapasi', '27.745531', '85.335832', 4, 3, 834, 835),
(595, 'Solteemode', 'Solteemode, Redcross Marg', 'solteemode', NULL, NULL, 4, 3, 836, 837),
(598, 'Kalimati', 'Kalimati', 'kalimati', NULL, NULL, 4, 3, 844, 847),
(607, 'Bhairahawa', 'Siddharthanagar', 'bhairahawa', '27.509383', '83.451948', 3, 67, 981, 982),
(608, 'Butwal', 'Butwal', 'butwal', NULL, NULL, 3, 67, 983, 984),
(609, 'Bharatpur', 'Bharatpur', 'bharatpur', NULL, NULL, 3, 583, 1026, 1027),
(610, 'Jhapa', 'Jhapa', 'jhapa', NULL, NULL, 8, 466, 1015, 1018),
(611, 'Damak', 'Damak', 'damak', NULL, NULL, 3, 610, 1016, 1017),
(612, 'Naikap', 'Naikap', 'naikap', '27.688924', '85.272703', 4, 3, 868, 869),
(613, 'Gaurighat', 'Gaurighat', 'gaurighat', NULL, NULL, 4, 3, 870, 871),
(614, 'Sauraha', 'Sauraha', 'sauraha', NULL, NULL, 3, 583, 1028, 1029),
(615, 'Dhapakhel', 'Dhapakhel', 'dhapakhel', NULL, NULL, 4, 70, 960, 961),
(616, 'Bhola Ganesh', '', 'bhola-ganesh', NULL, NULL, 4, 70, 962, 963),
(617, 'Salla Ghari', '', 'salla-ghari', NULL, NULL, 4, 69, 890, 891),
(618, 'Byasi', '', 'byasi', NULL, NULL, 4, 69, 892, 893),
(619, 'Khauma Tole', '', 'khauma-tole', NULL, NULL, 4, 69, 894, 895),
(621, 'Nhyakhachuka', '', 'nhyakhachuka', NULL, NULL, 4, 70, 964, 965),
(622, 'Banepa', '', 'banepa', NULL, NULL, 3, 2, 977, 978),
(623, 'India', 'India', 'india-1', NULL, NULL, 1, NULL, 1041, 1104),
(624, 'Jwagol', 'Jwagol', 'jwagol', NULL, NULL, 4, 483, 903, 904),
(625, 'Andhra Pradesh', 'Andhra Pradesh', 'andhra-pradesh', NULL, NULL, 2, 623, 1042, 1043),
(626, 'Arunachal Pradesh', 'Arunachal Pradesh', 'arunachal-pradesh', NULL, NULL, 2, 623, 1044, 1045),
(627, 'Assam', 'Assam', 'assam', NULL, NULL, 2, 623, 1046, 1047),
(628, 'Bihar', 'Bihar', 'bihar', NULL, NULL, 2, 623, 1048, 1049),
(629, 'Chhattisgarh', 'Chhattisgarh', 'chhattisgarh', NULL, NULL, 2, 623, 1050, 1051),
(630, 'Goa', 'Goa', 'goa', NULL, NULL, 2, 623, 1052, 1053),
(631, 'Gujarat', 'Gujarat', 'gujarat', NULL, NULL, 2, 623, 1054, 1055),
(632, 'Haryana', 'Haryana', 'haryana', NULL, NULL, 2, 623, 1056, 1057),
(633, 'Himachal Pradesh', 'Himachal Pradesh', 'himachal-pradesh', NULL, NULL, 2, 623, 1058, 1059),
(634, 'Jammu and Kashmir', 'Jammu and Kashmir', 'jammu-and-kashmir', NULL, NULL, 2, 623, 1060, 1061),
(635, 'Jharkhand', 'Jharkhand', 'jharkhand', NULL, NULL, 2, 623, 1062, 1063),
(636, 'Karnataka', 'Karnataka', 'karnataka', NULL, NULL, 2, 623, 1064, 1065),
(637, 'Kerala', 'Kerala', 'kerala', NULL, NULL, 2, 623, 1066, 1067),
(638, 'Madhya Pradesh', 'Madhya Pradesh', 'madhya-pradesh', NULL, NULL, 2, 623, 1068, 1069),
(639, 'Maharashtra', 'Maharashtra', 'maharashtra', NULL, NULL, 2, 623, 1070, 1071),
(640, 'Manipur', 'Manipur', 'manipur', NULL, NULL, 2, 623, 1072, 1073),
(641, 'Meghalaya', 'Meghalaya', 'meghalaya', NULL, NULL, 2, 623, 1074, 1075),
(642, 'Orissa', 'Orissa', 'orissa', NULL, NULL, 2, 623, 1076, 1077),
(643, 'Punjab', 'Punjab', 'punjab', NULL, NULL, 2, 623, 1078, 1079),
(644, 'Nagaland', 'Nagaland', 'nagaland', NULL, NULL, 2, 623, 1080, 1081),
(645, 'Mizoram', 'Mizoram', 'mizoram', NULL, NULL, 2, 623, 1082, 1083),
(646, 'Rajasthan', 'Rajasthan', 'rajasthan', NULL, NULL, 2, 623, 1084, 1085),
(647, 'Sikkim', 'Sikkim', 'sikkim', NULL, NULL, 2, 623, 1086, 1087),
(648, 'Tamil Nadu', 'Tamil Nadu', 'tamil-nadu', NULL, NULL, 2, 623, 1088, 1089),
(649, 'Tripura', 'Tripura', 'tripura', NULL, NULL, 2, 623, 1090, 1091),
(650, 'Uttar Pradesh', 'Uttar Pradesh', 'uttar-pradesh', NULL, NULL, 2, 623, 1092, 1093),
(651, 'Uttarakhand', 'Uttarakhand', 'uttarakhand', NULL, NULL, 2, 623, 1094, 1095),
(652, 'West Bengal', 'West Bengal', 'west-bengal', NULL, NULL, 2, 623, 1096, 1097),
(653, 'Delhi', 'Delhi', 'delhi', NULL, NULL, 2, 623, 1098, 1099),
(654, 'Puducherry', 'Puducherry', 'puducherry', NULL, NULL, 2, 623, 1100, 1101),
(655, 'Chandigarh', 'Chandigarh', 'chandigarh', NULL, NULL, 2, 623, 1102, 1103);

-- --------------------------------------------------------

--
-- Table structure for table `location_types`
--

CREATE TABLE IF NOT EXISTS `location_types` (
  `id` int(11) NOT NULL,
  `name` varchar(24) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `location_types`
--

INSERT INTO `location_types` (`id`, `name`) VALUES
(1, 'Country'),
(2, 'State'),
(3, 'City'),
(4, 'Street'),
(5, 'Landmark'),
(6, 'Ward'),
(7, 'Zone'),
(8, 'District');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) DEFAULT NULL,
  `model` varchar(30) DEFAULT NULL,
  `table_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `printed` int(11) NOT NULL DEFAULT '0',
  `amount` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `ticket_id`, `model`, `table_id`, `item_id`, `user_id`, `quantity`, `printed`, `amount`, `created_date`, `status_id`) VALUES
(1, 1, 'Dine In', 1, 87, 1, 2, 0, 400, '2013-01-22 08:27:12', 41),
(2, 2, 'Dine In', 1, 1, 1, 2, 0, 400, '2013-01-22 08:36:23', 41),
(3, 2, 'Dine In', 1, 106, 1, 2, 0, 600, '2013-01-22 08:37:13', 41),
(4, 3, 'Dine In', 2, 8, 1, 2, 0, 400, '2013-01-22 08:39:40', 41),
(5, 4, 'Dine In', 1, 21, 1, 2, 0, 240, '2013-01-22 08:52:05', 41),
(6, 5, 'Dine In', 2, 9, 1, 2, 0, 400, '2013-01-22 08:52:45', 41),
(7, 6, 'Take Out', NULL, 8, 1, 3, 0, 600, '2013-01-22 09:09:03', 40),
(9, 8, 'Dine In', 2, 1, 1, 1, 0, 200, '2013-01-22 14:29:07', 41),
(10, 8, 'Dine In', 2, 9, 1, 2, 0, 400, '2013-01-22 14:29:26', 41),
(11, 9, 'Dine In', 14, 57, 1, 12, 0, 2760, '2013-09-10 09:57:08', 41),
(12, 10, 'Dine In', 4, 4, 1, 5, 0, 900, '2013-09-10 09:59:52', 40),
(13, 11, 'Dine In', 13, 25, 1, 5, 0, 750, '2013-09-10 10:00:29', 40);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) DEFAULT NULL,
  `counter_id` int(11) DEFAULT NULL,
  `cashier_id` int(11) DEFAULT NULL,
  `type` varchar(40) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `tax_amount` int(3) DEFAULT NULL,
  `dis_amount` int(11) DEFAULT NULL,
  `st_amount` int(11) DEFAULT NULL,
  `disOptoins` varchar(30) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `total_remaining` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `ticket_id`, `counter_id`, `cashier_id`, `type`, `amount`, `tax_amount`, `dis_amount`, `st_amount`, `disOptoins`, `total`, `member_id`, `total_remaining`, `date`) VALUES
(1, 2, NULL, 1, 'cash', 1000, NULL, 0, 100, 'Amount', 1100, NULL, NULL, '2013-01-22 02:37:35'),
(2, 3, NULL, 1, 'cash', 400, NULL, 0, 40, 'Amount', 440, NULL, NULL, '2013-01-22 02:41:26'),
(3, 4, NULL, 1, 'cash', 240, NULL, 0, 24, 'Percent', 264, NULL, NULL, '2013-01-22 02:54:03'),
(4, 5, NULL, 1, 'cash', 400, NULL, 0, 40, 'Amount', 440, NULL, NULL, '2013-01-22 03:02:25'),
(5, 8, NULL, 1, 'cash', 600, NULL, 60, 54, 'Percent', 594, NULL, NULL, '2013-01-22 08:31:31'),
(6, 9, NULL, 1, 'credit', 2760, NULL, 0, 276, 'Percent', 3036, 6, 3036, '2013-09-10 04:58:37');

-- --------------------------------------------------------

--
-- Table structure for table `shifts`
--

CREATE TABLE IF NOT EXISTS `shifts` (
  `id` int(11) NOT NULL,
  `shift` varchar(30) DEFAULT NULL,
  `starts` time DEFAULT NULL,
  `ends` time DEFAULT NULL,
  `status_id` tinyint(11) DEFAULT NULL,
  `number` int(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `shifts_employees`
--

CREATE TABLE IF NOT EXISTS `shifts_employees` (
  `id` int(11) NOT NULL,
  `position` int(3) DEFAULT NULL,
  `shift_id` int(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE IF NOT EXISTS `statuses` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `model` varchar(45) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `name`, `model`) VALUES
(6, 'Active', 'User'),
(7, 'Deleted', 'User'),
(9, 'In Active', 'User'),
(17, 'Password Reset', 'User'),
(30, 'Dine In', 'Order'),
(31, 'Take Out', 'Order'),
(32, 'Bar', 'Order'),
(33, 'Counter', 'Order'),
(34, 'With Order', 'Table'),
(35, 'With out Order', 'Table'),
(36, 'Active', 'Shift'),
(37, 'In Active', 'Shift'),
(38, 'Active', 'Ticket'),
(39, 'In Active', 'Ticket'),
(40, 'Active', 'OrderStatus'),
(41, 'In Active', 'OrderStatus'),
(42, 'In Stock', 'Item'),
(43, 'Not Available', 'Item'),
(44, 'In Active', 'Table'),
(45, 'Disabled', 'Configuration'),
(46, 'Enabled', 'Configuration'),
(47, 'Almost Finished', 'Item');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` int(11) NOT NULL,
  `supplier_name` varchar(200) DEFAULT NULL,
  `contact_person` varchar(40) DEFAULT NULL,
  `contact_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tables`
--

CREATE TABLE IF NOT EXISTS `tables` (
  `id` int(11) NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status_id` int(11) DEFAULT NULL,
  `host_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tables`
--

INSERT INTO `tables` (`id`, `name`, `user_id`, `created_date`, `status_id`, `host_id`) VALUES
(1, 'Table 1', 1, '2013-01-10 05:36:04', 35, NULL),
(2, 'Table 2', 1, '2013-01-10 05:36:05', 35, NULL),
(3, 'Table 3', 1, '2013-01-10 05:36:06', 35, NULL),
(4, 'Table 4', 1, '2013-01-10 05:36:07', 34, NULL),
(5, 'Table 5', 1, '2013-01-10 05:36:08', 35, NULL),
(6, 'Table 6', 1, '2013-01-10 05:36:09', 35, NULL),
(7, 'Table 7', 1, '2013-01-22 08:39:19', 35, NULL),
(8, 'Table 8', 1, '2013-01-22 09:18:02', 35, NULL),
(9, 'Table 9', 1, '2013-01-22 09:18:17', 35, NULL),
(10, 'Table 10', 1, '2013-01-22 09:18:33', 35, NULL),
(11, 'Table  11', 1, '2013-01-22 09:18:44', 35, NULL),
(12, 'Table 12', 1, '2013-01-22 09:18:54', 35, NULL),
(13, 'Table 13', 1, '2013-01-22 09:19:04', 34, NULL),
(14, 'Table 14', 1, '2013-01-22 09:19:12', 35, NULL),
(15, 'Table 15', 1, '2013-01-22 09:19:24', 35, NULL),
(16, 'Table 16', 1, '2013-01-22 09:19:35', 35, NULL),
(17, 'Table U1', 1, '2013-01-22 09:19:54', 35, NULL),
(18, 'Table U2', 1, '2013-01-22 09:20:09', 35, NULL),
(19, 'Table U3', 1, '2013-01-22 09:20:21', 35, NULL),
(20, 'Table U4', 1, '2013-01-22 09:20:31', 35, NULL),
(21, 'Table U5', 1, '2013-01-22 09:20:43', 35, NULL),
(22, 'Table U6', 1, '2013-01-22 09:20:56', 35, NULL),
(23, 'Table U7', 1, '2013-01-22 09:21:06', 35, NULL),
(24, 'Table U8', 1, '2013-01-22 09:21:17', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tables_tickets`
--

CREATE TABLE IF NOT EXISTS `tables_tickets` (
  `id` int(11) NOT NULL,
  `table_id` int(11) DEFAULT NULL,
  `ticket_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tables_tickets`
--

INSERT INTO `tables_tickets` (`id`, `table_id`, `ticket_id`) VALUES
(3, 2, 3),
(4, 1, 4),
(5, 2, 5),
(7, 2, 8),
(8, 14, 9),
(9, 4, 10),
(10, 13, 11);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL,
  `number` varchar(30) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `paid` tinyint(1) DEFAULT NULL,
  `cash_credit` varchar(20) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `number`, `amount`, `user_id`, `paid`, `cash_credit`, `status_id`, `created_date`, `customer_id`) VALUES
(1, '1', 400, 1, 0, NULL, 39, '2013-01-22 02:27:12', NULL),
(2, '2', 1000, 1, 1, NULL, 39, '2013-01-22 02:36:23', NULL),
(3, '3', 400, 1, 1, NULL, 39, '2013-01-22 02:39:12', NULL),
(4, '4', 240, 1, 1, NULL, 39, '2013-01-22 02:52:05', NULL),
(5, '5', 400, 1, 1, NULL, 39, '2013-01-22 02:52:45', NULL),
(6, '6', 600, 1, 0, NULL, 38, '2013-01-22 03:08:29', NULL),
(8, '8', 600, 1, 1, NULL, 39, '2013-01-22 08:29:07', NULL),
(9, '9', 2760, 1, 1, NULL, 39, '2013-09-10 04:57:08', NULL),
(10, '10', 900, 1, 0, NULL, 38, '2013-09-10 04:59:52', NULL),
(11, '11', 750, 1, 0, NULL, 38, '2013-09-10 05:00:29', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE IF NOT EXISTS `units` (
  `id` int(11) NOT NULL,
  `unit` varchar(25) DEFAULT NULL,
  `abbrevaition` varchar(5) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `unit`, `abbrevaition`, `user_id`, `created_date`) VALUES
(1, 'Glass', 'Gl', NULL, '2013-01-10 06:38:46'),
(2, 'Bottle', 'Btl', NULL, '2013-01-10 06:43:40'),
(3, 'Cup', 'Cup', NULL, '2013-01-10 06:44:23'),
(4, 'Shot', 'St', NULL, '2013-01-10 07:07:38');

-- --------------------------------------------------------

--
-- Table structure for table `unit_ratios`
--

CREATE TABLE IF NOT EXISTS `unit_ratios` (
  `id` int(11) NOT NULL,
  `sales_unit_id` int(11) DEFAULT NULL,
  `purchase_unit_id` int(11) DEFAULT NULL,
  `ratio` int(11) DEFAULT NULL,
  `user_id` varchar(30) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(11) NOT NULL,
  `model` varchar(50) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `file_name` varchar(200) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  `size` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`id`, `model`, `model_id`, `path`, `file_name`, `type`, `size`) VALUES
(99, 'Category', 16, 'cat-images', 'bottles2005.jpg', 'image/jpeg', 184881),
(98, 'Category', 12, 'cat-images', 'LARGE PHOTOS_ALCOHOL.jpg', 'image/jpeg', 56924),
(97, 'Category', 11, 'cat-images', 'beverages.jpg', 'image/jpeg', 117408),
(96, 'Category', 15, 'cat-images', 'LT-cheerful_cherry_mocktail_4.jpg', 'image/jpeg', 8909),
(95, 'Category', 14, 'cat-images', 'Shaken_Not_Stirred_V2_0.jpg', 'image/jpeg', 273108),
(94, 'Category', 13, 'cat-images', 'beerbuzz600.jpeg', 'image/jpeg', 229583),
(85, 'Category', 9, 'cat-images', 'chop-suey-1.jpg', 'image/jpeg', 108583),
(81, 'Category', 8, 'cat-images', 'Sizzlers-Signature.jpg', 'image/jpeg', 35310),
(82, 'Category', 7, 'cat-images', 'browned+butter+lemon+pasta3.jpg', 'image/jpeg', 159401),
(83, 'Category', 10, 'cat-images', 'main-dish-meal.jpg', 'image/jpeg', 87758),
(84, 'Category', 6, 'cat-images', 'Flat-noodles-stir-fried-sausage-sauce-spicy-recipe-Spicy-Pasta.jpg', 'image/jpeg', 592887),
(112, 'Category', 22, 'cat-images', 'Jura_White__51652_zoom.jpg', 'image/jpeg', 103432),
(111, 'Category', 21, 'cat-images', 'red-wine-glass1.jpg', 'image/jpeg', 9216),
(80, 'Category', 5, 'cat-images', 'special-chicken-tikka.jpg', 'image/jpeg', 34769),
(53, 'Category', 3, 'cat-images', 'soup.jpg', 'image/jpeg', 40026),
(75, 'Category', 2, 'cat-images', 'momo.jpg', 'image/jpeg', 21971),
(76, 'Category', 4, 'cat-images', '2009072300720Chatamari201.jpg', 'image/jpeg', 132376),
(79, 'Category', 1, 'cat-images', 'Cheddar_Rosemary_and_Red_Onion_Tart.jpg', 'image/jpeg', 750690),
(119, 'Category', 24, 'cat-images', '2345543856_6d0fbafb66.jpg', 'image/jpeg', 47909),
(117, 'Category', 27, 'cat-images', 'belvedere-silver-vodka-bottle-1.jpg', 'image/jpeg', 24713),
(118, 'Category', 23, 'cat-images', 'booze.jpg', 'image/jpeg', 125308);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `name` varchar(139) DEFAULT NULL,
  `username` varchar(59) NOT NULL,
  `password` varchar(40) NOT NULL,
  `alias` varchar(139) DEFAULT NULL,
  `url` varchar(139) DEFAULT NULL,
  `gender` smallint(1) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `login_ip` varchar(25) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `date_added` datetime DEFAULT NULL,
  `signup_ip` varchar(25) DEFAULT NULL,
  `pass_session` varchar(40) DEFAULT NULL,
  `facebook_id` varchar(100) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `alias`, `url`, `gender`, `date_of_birth`, `last_login`, `login_ip`, `role_id`, `status_id`, `date_added`, `signup_ip`, `pass_session`, `facebook_id`) VALUES
(1, 'Administrator', 'admin@pos.khumbaya.com', 'aa340c05d22e75340b5fa46397c10747dba88214', 'administrator', 'administrator', NULL, NULL, '2015-01-15 08:02:20', '202.51.76.238', 1, 6, '2012-10-04 11:06:43', '127.0.0.1', NULL, NULL),
(2, 'Cashier', 'cashier@pos.khumbaya.com', 'dacb62c3dd792f68bee76f7f00e494f84c07104f', 'cashier', 'cashier', NULL, NULL, '2013-01-01 13:45:29', '110.34.4.243', 2, 6, '2012-10-04 11:22:48', '127.0.0.1', NULL, NULL),
(3, 'Host', 'host@pos.khumbaya.com', '8331d5516fa6b77e7c544bdbb9419bf02b5ebab5', 'host', 'host', NULL, NULL, '2013-01-01 14:05:35', '49.244.106.173', 3, 6, '2012-10-04 11:29:34', '127.0.0.1', NULL, NULL),
(4, 'Sagar', 'sapkotasagar@something.com', 'd78077a1fceceb129faf26e94866fb8e995df3f2', 'sagar', 'sagar', 1, NULL, '2012-10-04 14:59:08', '127.0.0.1', 4, 6, '2012-10-04 13:39:18', '127.0.0.1', NULL, NULL),
(6, 'Vaibhaw Poddar', 'bob@himalayantechies.com', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'bob', 'bob', 1, NULL, NULL, NULL, 4, 6, '2012-10-25 13:36:36', '110.44.115.86', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `url` varchar(25) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `name`, `url`) VALUES
(1, 'Administrator', 'R_administrator'),
(2, 'Cashier', 'R_cashier'),
(3, 'Host', 'R_host'),
(4, 'Member', 'R_member');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acos`
--
ALTER TABLE `acos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros`
--
ALTER TABLE `aros`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros_acos`
--
ALTER TABLE `aros_acos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ARO_ACO_KEY` (`aro_id`,`aco_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company_infos`
--
ALTER TABLE `company_infos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `configurations`
--
ALTER TABLE `configurations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `counters`
--
ALTER TABLE `counters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `credits`
--
ALTER TABLE `credits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventories`
--
ALTER TABLE `inventories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location_maps`
--
ALTER TABLE `location_maps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location_types`
--
ALTER TABLE `location_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shifts`
--
ALTER TABLE `shifts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shifts_employees`
--
ALTER TABLE `shifts_employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tables`
--
ALTER TABLE `tables`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tables_tickets`
--
ALTER TABLE `tables_tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit_ratios`
--
ALTER TABLE `unit_ratios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acos`
--
ALTER TABLE `acos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=253;
--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3133;
--
-- AUTO_INCREMENT for table `aros`
--
ALTER TABLE `aros`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `aros_acos`
--
ALTER TABLE `aros_acos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=85;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `company_infos`
--
ALTER TABLE `company_infos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `configurations`
--
ALTER TABLE `configurations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `counters`
--
ALTER TABLE `counters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `credits`
--
ALTER TABLE `credits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inventories`
--
ALTER TABLE `inventories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=136;
--
-- AUTO_INCREMENT for table `location_maps`
--
ALTER TABLE `location_maps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=657;
--
-- AUTO_INCREMENT for table `location_types`
--
ALTER TABLE `location_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `shifts`
--
ALTER TABLE `shifts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `shifts_employees`
--
ALTER TABLE `shifts_employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tables`
--
ALTER TABLE `tables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `tables_tickets`
--
ALTER TABLE `tables_tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `unit_ratios`
--
ALTER TABLE `unit_ratios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=126;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
