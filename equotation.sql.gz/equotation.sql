-- phpMyAdmin SQL Dump
-- version 4.5.0-dev
-- http://www.phpmyadmin.net
--
-- Host: himalayantechies-db-server.cepyls6xdgwo.us-west-2.rds.amazonaws.com
-- Generation Time: Jun 21, 2015 at 04:51 AM
-- Server version: 5.6.19-log
-- PHP Version: 5.4.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `equotation`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=934 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `acos`
--

INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, 'APP', NULL, 'Controller', 1, 1866),
(39, 1, 'Plugin', NULL, 'FileUpload', 76, 85),
(41, 1, 'Plugin', NULL, 'PhpExcel', 86, 87),
(42, 1, 'Plugin', NULL, 'SuperAdmin', 88, 145),
(495, 494, 'Action', NULL, 'admin_add', 1013, 1014),
(494, 1, 'Controller', NULL, 'ApproveLevels', 1012, 1025),
(493, 469, 'Action', NULL, 'routeCache', 1009, 1010),
(492, 469, 'Action', NULL, 'return_navigations', 1007, 1008),
(491, 469, 'Action', NULL, 'return_main_nav', 1005, 1006),
(490, 469, 'Action', NULL, 'get_plugin_sub_nav', 1003, 1004),
(489, 469, 'Action', NULL, 'get_plugin_main_nav', 1001, 1002),
(488, 469, 'Action', NULL, 'getAddress', 999, 1000),
(487, 469, 'Action', NULL, 'daysOfWeek', 997, 998),
(486, 469, 'Action', NULL, 'createZip', 995, 996),
(485, 469, 'Action', NULL, 'beforeRender', 993, 994),
(484, 469, 'Action', NULL, 'beforeFilter', 991, 992),
(483, 469, 'Action', NULL, 'beforeFacebookSave', 989, 990),
(482, 469, 'Action', NULL, 'beforeFacebookLogin', 987, 988),
(481, 469, 'Action', NULL, 'appendTags', 985, 986),
(480, 469, 'Action', NULL, 'afterFacebookLogin', 983, 984),
(479, 469, 'Action', NULL, '_uploadBehavior', 981, 982),
(478, 469, 'Action', NULL, '_relatedUpload', 979, 980),
(477, 469, 'Action', NULL, '_pictureCrop', 977, 978),
(476, 469, 'Action', NULL, '_get_facebook_cookie', 975, 976),
(475, 469, 'Action', NULL, '_getDifference', 973, 974),
(474, 469, 'Action', NULL, '_getAddress', 971, 972),
(473, 469, 'Action', NULL, '_deleteUpload', 969, 970),
(472, 469, 'Action', NULL, '_array_sort', 967, 968),
(471, 469, 'Action', NULL, '__loadPlugin', 965, 966),
(470, 469, 'Action', NULL, '__loadConfig', 963, 964),
(469, 1, 'Controller', NULL, 'App', 962, 1011),
(862, 578, 'Action', NULL, 'delete', 1205, 1206),
(876, 1, 'Controller', NULL, 'Currencies', 1826, 1839),
(868, 756, 'Action', NULL, 'delete', 1599, 1600),
(867, 727, 'Action', NULL, 'delete', 1509, 1510),
(866, 692, 'Action', NULL, 'delete', 1447, 1448),
(865, 647, 'Action', NULL, 'delete', 1349, 1350),
(864, 619, 'Action', NULL, 'delete', 1307, 1308),
(863, 601, 'Action', NULL, 'delete', 1273, 1274),
(496, 494, 'Action', NULL, 'admin_delete', 1015, 1016),
(497, 494, 'Action', NULL, 'admin_edit', 1017, 1018),
(498, 494, 'Action', NULL, 'admin_index', 1019, 1020),
(499, 494, 'Action', NULL, 'admin_save', 1021, 1022),
(500, 494, 'Action', NULL, 'beforeFilter', 1023, 1024),
(501, 1, 'Controller', NULL, 'Articles', 1026, 1035),
(502, 501, 'Action', NULL, 'add', 1027, 1028),
(503, 501, 'Action', NULL, 'article', 1029, 1030),
(504, 501, 'Action', NULL, 'beforeFilter', 1031, 1032),
(505, 501, 'Action', NULL, 'index', 1033, 1034),
(506, 1, 'Controller', NULL, 'Attributes', 1036, 1049),
(507, 506, 'Action', NULL, 'admin_add', 1037, 1038),
(508, 506, 'Action', NULL, 'admin_delete', 1039, 1040),
(509, 506, 'Action', NULL, 'admin_edit', 1041, 1042),
(510, 506, 'Action', NULL, 'admin_index', 1043, 1044),
(511, 506, 'Action', NULL, 'admin_save', 1045, 1046),
(512, 506, 'Action', NULL, 'beforeFilter', 1047, 1048),
(513, 1, 'Controller', NULL, 'Bids', 1050, 1073),
(514, 513, 'Action', NULL, 'admin_bid_compare', 1051, 1052),
(515, 513, 'Action', NULL, 'admin_compare', 1053, 1054),
(516, 513, 'Action', NULL, 'admin_view', 1055, 1056),
(517, 513, 'Action', NULL, 'beforeFilter', 1057, 1058),
(518, 513, 'Action', NULL, 'edit', 1059, 1060),
(519, 513, 'Action', NULL, 'tender_bids', 1061, 1062),
(520, 513, 'Action', NULL, 'view', 1063, 1064),
(521, 1, 'Controller', NULL, 'Businesses', 1074, 1157),
(522, 521, 'Action', NULL, '_businessInfo', 1075, 1076),
(523, 521, 'Action', NULL, '_clicked', 1077, 1078),
(524, 521, 'Action', NULL, '_email_confirm', 1079, 1080),
(525, 521, 'Action', NULL, '_selectBoxes', 1081, 1082),
(526, 521, 'Action', NULL, 'admin_delete', 1083, 1084),
(527, 521, 'Action', NULL, 'admin_export', 1085, 1086),
(528, 521, 'Action', NULL, 'admin_getList', 1087, 1088),
(529, 521, 'Action', NULL, 'admin_index', 1089, 1090),
(530, 521, 'Action', NULL, 'autoComplete', 1091, 1092),
(531, 521, 'Action', NULL, 'autoCompleteFill', 1093, 1094),
(532, 521, 'Action', NULL, 'beforeFilter', 1095, 1096),
(533, 521, 'Action', NULL, 'business', 1097, 1098),
(534, 521, 'Action', NULL, 'business_related', 1099, 1100),
(535, 521, 'Action', NULL, 'claim', 1101, 1102),
(536, 521, 'Action', NULL, 'claimStatus', 1103, 1104),
(537, 521, 'Action', NULL, 'compare', 1105, 1106),
(538, 521, 'Action', NULL, 'confirm', 1107, 1108),
(539, 521, 'Action', NULL, 'email2fren', 1109, 1110),
(540, 521, 'Action', NULL, 'featuredBusiness', 1111, 1112),
(541, 521, 'Action', NULL, 'fillAddress', 1113, 1114),
(542, 521, 'Action', NULL, 'getAddress', 1115, 1116),
(543, 521, 'Action', NULL, 'getAddressList', 1117, 1118),
(544, 521, 'Action', NULL, 'getBusinessList', 1119, 1120),
(545, 521, 'Action', NULL, 'getChildTags', 1121, 1122),
(546, 521, 'Action', NULL, 'getGeocode', 1123, 1124),
(547, 521, 'Action', NULL, 'gpos_edit', 1125, 1126),
(548, 521, 'Action', NULL, 'gpos_view', 1127, 1128),
(549, 521, 'Action', NULL, 'guidelines', 1129, 1130),
(550, 521, 'Action', NULL, 'homeCategoryBusinessMap', 1131, 1132),
(551, 521, 'Action', NULL, 'homeCategoryBusinesses', 1133, 1134),
(552, 521, 'Action', NULL, 'imageCaption', 1135, 1136),
(553, 521, 'Action', NULL, 'imageDelete', 1137, 1138),
(554, 521, 'Action', NULL, 'index', 1139, 1140),
(555, 521, 'Action', NULL, 'jasonEncode', 1141, 1142),
(556, 521, 'Action', NULL, 'listUpdate', 1143, 1144),
(557, 521, 'Action', NULL, 'membership', 1145, 1146),
(558, 521, 'Action', NULL, 'removeDegree', 1147, 1148),
(559, 521, 'Action', NULL, 'save', 1149, 1150),
(560, 521, 'Action', NULL, 'statusUpdate', 1151, 1152),
(561, 521, 'Action', NULL, 'upload', 1153, 1154),
(562, 1, 'Controller', NULL, 'Categories', 1158, 1189),
(563, 562, 'Action', NULL, '_clicked', 1159, 1160),
(564, 562, 'Action', NULL, 'admin_add', 1161, 1162),
(565, 562, 'Action', NULL, 'admin_delete', 1163, 1164),
(566, 562, 'Action', NULL, 'admin_edit', 1165, 1166),
(567, 562, 'Action', NULL, 'admin_index', 1167, 1168),
(568, 562, 'Action', NULL, 'admin_locTree', 1169, 1170),
(569, 562, 'Action', NULL, 'admin_move', 1171, 1172),
(570, 562, 'Action', NULL, 'admin_save', 1173, 1174),
(571, 562, 'Action', NULL, 'admin_treeUpdate', 1175, 1176),
(572, 562, 'Action', NULL, 'beforeFilter', 1177, 1178),
(573, 562, 'Action', NULL, 'category_select', 1179, 1180),
(574, 562, 'Action', NULL, 'display_categories', 1181, 1182),
(575, 562, 'Action', NULL, 'index', 1183, 1184),
(576, 562, 'Action', NULL, 'jasonEncode', 1185, 1186),
(577, 562, 'Action', NULL, 'test', 1187, 1188),
(578, 1, 'Controller', NULL, 'Classifieds', 1190, 1207),
(579, 578, 'Action', NULL, 'add', 1191, 1192),
(580, 578, 'Action', NULL, 'beforeFilter', 1193, 1194),
(581, 578, 'Action', NULL, 'contactperson', 1195, 1196),
(582, 578, 'Action', NULL, 'edit', 1197, 1198),
(583, 578, 'Action', NULL, 'email', 1199, 1200),
(584, 578, 'Action', NULL, 'index', 1201, 1202),
(585, 578, 'Action', NULL, 'view', 1203, 1204),
(586, 1, 'Controller', NULL, 'Emails', 1208, 1231),
(587, 586, 'Action', NULL, '__previewEmail', 1209, 1210),
(588, 586, 'Action', NULL, 'admin_add', 1211, 1212),
(589, 586, 'Action', NULL, 'admin_attach', 1213, 1214),
(590, 586, 'Action', NULL, 'admin_delete', 1215, 1216),
(591, 586, 'Action', NULL, 'admin_edit', 1217, 1218),
(592, 586, 'Action', NULL, 'admin_email', 1219, 1220),
(593, 586, 'Action', NULL, 'admin_index', 1221, 1222),
(594, 586, 'Action', NULL, 'admin_preview', 1223, 1224),
(595, 586, 'Action', NULL, 'admin_save', 1225, 1226),
(596, 586, 'Action', NULL, 'beforeFilter', 1227, 1228),
(597, 586, 'Action', NULL, 'emailAttach', 1229, 1230),
(598, 1, 'Controller', NULL, 'Emergencies', 1232, 1237),
(599, 598, 'Action', NULL, 'beforeFilter', 1233, 1234),
(600, 598, 'Action', NULL, 'index', 1235, 1236),
(601, 1, 'Controller', NULL, 'Events', 1238, 1275),
(602, 601, 'Action', NULL, '_clicked', 1239, 1240),
(603, 601, 'Action', NULL, 'add', 1241, 1242),
(604, 601, 'Action', NULL, 'admin_delete', 1243, 1244),
(605, 601, 'Action', NULL, 'admin_index', 1245, 1246),
(606, 601, 'Action', NULL, 'admin_view', 1247, 1248),
(607, 601, 'Action', NULL, 'beforeFilter', 1249, 1250),
(608, 601, 'Action', NULL, 'display_events', 1251, 1252),
(609, 601, 'Action', NULL, 'edit', 1253, 1254),
(610, 601, 'Action', NULL, 'email2fren', 1255, 1256),
(611, 601, 'Action', NULL, 'event', 1257, 1258),
(612, 601, 'Action', NULL, 'getBusinessAddress', 1259, 1260),
(613, 601, 'Action', NULL, 'imageCaption', 1261, 1262),
(614, 601, 'Action', NULL, 'imageDelete', 1263, 1264),
(615, 601, 'Action', NULL, 'index', 1265, 1266),
(616, 601, 'Action', NULL, 'jasonEncode', 1267, 1268),
(617, 601, 'Action', NULL, 'upload', 1269, 1270),
(618, 601, 'Action', NULL, 'view', 1271, 1272),
(619, 1, 'Controller', NULL, 'Expressions', 1276, 1309),
(620, 619, 'Action', NULL, '_email_comments', 1277, 1278),
(621, 619, 'Action', NULL, '_email_confirm', 1279, 1280),
(622, 619, 'Action', NULL, 'addComments', 1281, 1282),
(623, 619, 'Action', NULL, 'beforeFilter', 1283, 1284),
(624, 619, 'Action', NULL, 'deleteImage', 1285, 1286),
(625, 619, 'Action', NULL, 'deleteTag', 1287, 1288),
(626, 619, 'Action', NULL, 'express', 1289, 1290),
(627, 619, 'Action', NULL, 'expressedby', 1291, 1292),
(628, 619, 'Action', NULL, 'expression', 1293, 1294),
(629, 619, 'Action', NULL, 'getTags', 1295, 1296),
(630, 619, 'Action', NULL, 'homePageExpression', 1297, 1298),
(631, 619, 'Action', NULL, 'index', 1299, 1300),
(632, 619, 'Action', NULL, 'index1', 1301, 1302),
(633, 619, 'Action', NULL, 'likeDislike', 1303, 1304),
(634, 619, 'Action', NULL, 'tag', 1305, 1306),
(635, 1, 'Controller', NULL, 'Faqs', 1310, 1327),
(636, 635, 'Action', NULL, 'admin_add', 1311, 1312),
(637, 635, 'Action', NULL, 'admin_delete', 1313, 1314),
(638, 635, 'Action', NULL, 'admin_edit', 1315, 1316),
(639, 635, 'Action', NULL, 'admin_index', 1317, 1318),
(640, 635, 'Action', NULL, 'admin_save', 1319, 1320),
(641, 635, 'Action', NULL, 'beforeFilter', 1321, 1322),
(642, 635, 'Action', NULL, 'faq', 1323, 1324),
(643, 635, 'Action', NULL, 'faqCategory', 1325, 1326),
(644, 1, 'Controller', NULL, 'Fb', 1328, 1333),
(645, 644, 'Action', NULL, 'beforeFilter', 1329, 1330),
(646, 644, 'Action', NULL, 'index', 1331, 1332),
(647, 1, 'Controller', NULL, 'Ideas', 1334, 1351),
(648, 647, 'Action', NULL, 'add', 1335, 1336),
(649, 647, 'Action', NULL, 'addComments', 1337, 1338),
(650, 647, 'Action', NULL, 'beforeFilter', 1339, 1340),
(651, 647, 'Action', NULL, 'edit', 1341, 1342),
(652, 647, 'Action', NULL, 'index', 1343, 1344),
(653, 647, 'Action', NULL, 'likeDislike', 1345, 1346),
(654, 647, 'Action', NULL, 'postlist', 1347, 1348),
(655, 1, 'Controller', NULL, 'Invitations', 1352, 1361),
(656, 655, 'Action', NULL, 'admin_add', 1353, 1354),
(657, 655, 'Action', NULL, 'admin_cancel', 1355, 1356),
(658, 655, 'Action', NULL, 'admin_index', 1357, 1358),
(659, 655, 'Action', NULL, 'beforeFilter', 1359, 1360),
(660, 1, 'Controller', NULL, 'Keywords', 1362, 1375),
(661, 660, 'Action', NULL, 'admin_add', 1363, 1364),
(662, 660, 'Action', NULL, 'admin_delete', 1365, 1366),
(663, 660, 'Action', NULL, 'admin_edit', 1367, 1368),
(664, 660, 'Action', NULL, 'admin_index', 1369, 1370),
(665, 660, 'Action', NULL, 'admin_save', 1371, 1372),
(666, 660, 'Action', NULL, 'beforeFilter', 1373, 1374),
(667, 1, 'Controller', NULL, 'LocationMaps', 1376, 1403),
(668, 667, 'Action', NULL, 'addComments', 1377, 1378),
(669, 667, 'Action', NULL, 'admin_add', 1379, 1380),
(670, 667, 'Action', NULL, 'admin_delete', 1381, 1382),
(671, 667, 'Action', NULL, 'admin_edit', 1383, 1384),
(672, 667, 'Action', NULL, 'admin_index', 1385, 1386),
(673, 667, 'Action', NULL, 'admin_locTree', 1387, 1388),
(674, 667, 'Action', NULL, 'admin_move', 1389, 1390),
(675, 667, 'Action', NULL, 'admin_save', 1391, 1392),
(676, 667, 'Action', NULL, 'admin_treeUpdate', 1393, 1394),
(677, 667, 'Action', NULL, 'beforeFilter', 1395, 1396),
(678, 667, 'Action', NULL, 'edit', 1397, 1398),
(679, 667, 'Action', NULL, 'index', 1399, 1400),
(680, 667, 'Action', NULL, 'likeDislike', 1401, 1402),
(681, 1, 'Controller', NULL, 'Manufactures', 1404, 1409),
(682, 681, 'Action', NULL, 'beforeFilter', 1405, 1406),
(683, 681, 'Action', NULL, 'upload_excel_sheet', 1407, 1408),
(684, 1, 'Controller', NULL, 'Maps', 1410, 1417),
(685, 684, 'Action', NULL, 'beforeFilter', 1411, 1412),
(686, 684, 'Action', NULL, 'getRecord', 1413, 1414),
(687, 684, 'Action', NULL, 'index', 1415, 1416),
(688, 1, 'Controller', NULL, 'Markers', 1418, 1425),
(689, 688, 'Action', NULL, 'beforeFilter', 1419, 1420),
(690, 688, 'Action', NULL, 'index', 1421, 1422),
(691, 688, 'Action', NULL, 'parseToXML', 1423, 1424),
(692, 1, 'Controller', NULL, 'Nolights', 1426, 1449),
(693, 692, 'Action', NULL, 'add', 1427, 1428),
(694, 692, 'Action', NULL, 'beforeFilter', 1429, 1430),
(695, 692, 'Action', NULL, 'edit', 1431, 1432),
(696, 692, 'Action', NULL, 'effectiveDate', 1433, 1434),
(697, 692, 'Action', NULL, 'getGroupSchedules', 1435, 1436),
(698, 692, 'Action', NULL, 'index', 1437, 1438),
(699, 692, 'Action', NULL, 'jsonEncode', 1439, 1440),
(700, 692, 'Action', NULL, 'nolightCache', 1441, 1442),
(701, 692, 'Action', NULL, 'publish', 1443, 1444),
(702, 692, 'Action', NULL, 'save', 1445, 1446),
(703, 1, 'Controller', NULL, 'Pages', 1450, 1483),
(704, 703, 'Action', NULL, 'beforeFilter', 1451, 1452),
(705, 703, 'Action', NULL, 'createAddresses', 1453, 1454),
(706, 703, 'Action', NULL, 'createBusinesses', 1455, 1456),
(707, 703, 'Action', NULL, 'createMapaddress', 1457, 1458),
(708, 703, 'Action', NULL, 'createRouteCache', 1459, 1460),
(709, 703, 'Action', NULL, 'createTags', 1461, 1462),
(710, 703, 'Action', NULL, 'cron_database', 1463, 1464),
(711, 703, 'Action', NULL, 'display', 1465, 1466),
(712, 703, 'Action', NULL, 'facebook', 1467, 1468),
(713, 703, 'Action', NULL, 'flight_monitor', 1469, 1470),
(714, 703, 'Action', NULL, 'getNews', 1471, 1472),
(715, 703, 'Action', NULL, 'imageUpdate', 1473, 1474),
(716, 703, 'Action', NULL, 'manual_cronJob', 1475, 1476),
(717, 703, 'Action', NULL, 'map', 1477, 1478),
(718, 703, 'Action', NULL, 'sql', 1479, 1480),
(719, 703, 'Action', NULL, 'survey', 1481, 1482),
(720, 1, 'Controller', NULL, 'PluginViews', 1484, 1497),
(721, 720, 'Action', NULL, 'admin_add', 1485, 1486),
(722, 720, 'Action', NULL, 'admin_delete', 1487, 1488),
(723, 720, 'Action', NULL, 'admin_edit', 1489, 1490),
(724, 720, 'Action', NULL, 'admin_index', 1491, 1492),
(725, 720, 'Action', NULL, 'admin_save', 1493, 1494),
(726, 720, 'Action', NULL, 'beforeFilter', 1495, 1496),
(727, 1, 'Controller', NULL, 'Posts', 1498, 1511),
(728, 727, 'Action', NULL, 'add', 1499, 1500),
(729, 727, 'Action', NULL, 'addComments', 1501, 1502),
(730, 727, 'Action', NULL, 'beforeFilter', 1503, 1504),
(731, 727, 'Action', NULL, 'edit', 1505, 1506),
(732, 727, 'Action', NULL, 'index', 1507, 1508),
(733, 1, 'Controller', NULL, 'PublicTransports', 1512, 1527),
(734, 733, 'Action', NULL, 'beforeFilter', 1513, 1514),
(735, 733, 'Action', NULL, 'gen', 1515, 1516),
(736, 733, 'Action', NULL, 'generateUniqueHexColors', 1517, 1518),
(737, 733, 'Action', NULL, 'getLocation', 1519, 1520),
(738, 733, 'Action', NULL, 'index', 1521, 1522),
(739, 733, 'Action', NULL, 'test_recursive', 1523, 1524),
(740, 733, 'Action', NULL, 'view', 1525, 1526),
(741, 1, 'Controller', NULL, 'ReqDocs', 1528, 1543),
(742, 741, 'Action', NULL, 'admin_add', 1529, 1530),
(743, 741, 'Action', NULL, 'admin_delete', 1531, 1532),
(744, 741, 'Action', NULL, 'admin_edit', 1533, 1534),
(745, 741, 'Action', NULL, 'admin_index', 1535, 1536),
(746, 741, 'Action', NULL, 'admin_save', 1537, 1538),
(747, 741, 'Action', NULL, 'admin_view', 1539, 1540),
(748, 741, 'Action', NULL, 'beforeFilter', 1541, 1542),
(749, 1, 'Controller', NULL, 'Requests', 1544, 1583),
(750, 749, 'Action', NULL, 'admin_view', 1545, 1546),
(751, 749, 'Action', NULL, 'approve', 1547, 1548),
(752, 749, 'Action', NULL, 'beforeFilter', 1549, 1550),
(753, 749, 'Action', NULL, 'bid_request', 1551, 1552),
(754, 749, 'Action', NULL, 'save_document', 1553, 1554),
(755, 749, 'Action', NULL, 'view', 1555, 1556),
(756, 1, 'Controller', NULL, 'Reviews', 1584, 1601),
(757, 756, 'Action', NULL, 'admin_delete', 1585, 1586),
(758, 756, 'Action', NULL, 'admin_index', 1587, 1588),
(759, 756, 'Action', NULL, 'beforeFilter', 1589, 1590),
(760, 756, 'Action', NULL, 'index', 1591, 1592),
(761, 756, 'Action', NULL, 'prevComment', 1593, 1594),
(762, 756, 'Action', NULL, 'review', 1595, 1596),
(763, 756, 'Action', NULL, 'usefulCount', 1597, 1598),
(764, 1, 'Controller', NULL, 'SearchHistories', 1602, 1609),
(765, 764, 'Action', NULL, 'admin_delete', 1603, 1604),
(766, 764, 'Action', NULL, 'admin_index', 1605, 1606),
(767, 764, 'Action', NULL, 'beforeFilter', 1607, 1608),
(768, 1, 'Controller', NULL, 'Searches', 1610, 1643),
(769, 768, 'Action', NULL, '_address', 1611, 1612),
(770, 768, 'Action', NULL, '_addressValue', 1613, 1614),
(771, 768, 'Action', NULL, '_category', 1615, 1616),
(772, 768, 'Action', NULL, '_getAddressList', 1617, 1618),
(773, 768, 'Action', NULL, '_getCategory', 1619, 1620),
(774, 768, 'Action', NULL, '_getCategoryList', 1621, 1622),
(775, 768, 'Action', NULL, '_getTag', 1623, 1624),
(776, 768, 'Action', NULL, '_initializeSearchHistory', 1625, 1626),
(777, 768, 'Action', NULL, '_page', 1627, 1628),
(778, 768, 'Action', NULL, '_partial', 1629, 1630),
(779, 768, 'Action', NULL, '_searchByBusiness', 1631, 1632),
(780, 768, 'Action', NULL, '_searchByEvent', 1633, 1634),
(781, 768, 'Action', NULL, '_searchByExpression', 1635, 1636),
(782, 768, 'Action', NULL, '_searchTerms', 1637, 1638),
(783, 768, 'Action', NULL, 'beforeFilter', 1639, 1640),
(784, 768, 'Action', NULL, 'search', 1641, 1642),
(785, 1, 'Controller', NULL, 'Selections', 1644, 1661),
(786, 785, 'Action', NULL, 'admin_add', 1645, 1646),
(787, 785, 'Action', NULL, 'admin_approve', 1647, 1648),
(788, 785, 'Action', NULL, 'admin_edit', 1649, 1650),
(789, 785, 'Action', NULL, 'admin_index', 1651, 1652),
(790, 785, 'Action', NULL, 'admin_select_bid', 1653, 1654),
(791, 785, 'Action', NULL, 'beforeFilter', 1655, 1656),
(792, 1, 'Controller', NULL, 'SiteConfigurations', 1662, 1677),
(793, 792, 'Action', NULL, 'admin_add', 1663, 1664),
(794, 792, 'Action', NULL, 'admin_delete', 1665, 1666),
(795, 792, 'Action', NULL, 'admin_edit', 1667, 1668),
(796, 792, 'Action', NULL, 'admin_index', 1669, 1670),
(797, 792, 'Action', NULL, 'admin_save', 1671, 1672),
(798, 792, 'Action', NULL, 'admin_setting', 1673, 1674),
(799, 792, 'Action', NULL, 'beforeFilter', 1675, 1676),
(800, 1, 'Controller', NULL, 'Statuses', 1678, 1691),
(801, 800, 'Action', NULL, 'admin_add', 1679, 1680),
(802, 800, 'Action', NULL, 'admin_delete', 1681, 1682),
(803, 800, 'Action', NULL, 'admin_edit', 1683, 1684),
(804, 800, 'Action', NULL, 'admin_index', 1685, 1686),
(805, 800, 'Action', NULL, 'admin_save', 1687, 1688),
(806, 800, 'Action', NULL, 'beforeFilter', 1689, 1690),
(807, 1, 'Controller', NULL, 'Tenders', 1692, 1759),
(808, 807, 'Action', NULL, 'admin_add', 1693, 1694),
(809, 807, 'Action', NULL, 'admin_edit', 1695, 1696),
(810, 807, 'Action', NULL, 'admin_index', 1697, 1698),
(811, 807, 'Action', NULL, 'admin_view', 1699, 1700),
(812, 807, 'Action', NULL, 'beforeFilter', 1701, 1702),
(813, 807, 'Action', NULL, 'bid', 1703, 1704),
(814, 807, 'Action', NULL, 'deleteUpload', 1705, 1706),
(815, 807, 'Action', NULL, 'download', 1707, 1708),
(816, 807, 'Action', NULL, 'index', 1709, 1710),
(817, 807, 'Action', NULL, 'save_TenderDoc', 1711, 1712),
(818, 807, 'Action', NULL, 'upload_excel_sheet', 1713, 1714),
(819, 807, 'Action', NULL, 'view', 1715, 1716),
(820, 1, 'Controller', NULL, 'Uploads', 1760, 1765),
(821, 820, 'Action', NULL, 'beforeFilter', 1761, 1762),
(822, 820, 'Action', NULL, 'deleteUpload', 1763, 1764),
(823, 1, 'Controller', NULL, 'UserRoles', 1766, 1779),
(824, 823, 'Action', NULL, 'admin_add', 1767, 1768),
(825, 823, 'Action', NULL, 'admin_delete', 1769, 1770),
(826, 823, 'Action', NULL, 'admin_edit', 1771, 1772),
(827, 823, 'Action', NULL, 'admin_index', 1773, 1774),
(828, 823, 'Action', NULL, 'admin_save', 1775, 1776),
(829, 823, 'Action', NULL, 'beforeFilter', 1777, 1778),
(830, 1, 'Controller', NULL, 'Users', 1780, 1825),
(831, 830, 'Action', NULL, '_email', 1781, 1782),
(832, 830, 'Action', NULL, '_profileEvent', 1783, 1784),
(833, 830, 'Action', NULL, 'admin_delete', 1785, 1786),
(834, 830, 'Action', NULL, 'admin_edit', 1787, 1788),
(835, 830, 'Action', NULL, 'admin_index', 1789, 1790),
(836, 830, 'Action', NULL, 'beforeFilter', 1791, 1792),
(837, 830, 'Action', NULL, 'changePass', 1793, 1794),
(838, 830, 'Action', NULL, 'close', 1795, 1796),
(839, 830, 'Action', NULL, 'deleteUpload', 1797, 1798),
(840, 830, 'Action', NULL, 'login', 1799, 1800),
(841, 830, 'Action', NULL, 'logout', 1801, 1802),
(842, 830, 'Action', NULL, 'members', 1803, 1804),
(843, 830, 'Action', NULL, 'profile', 1805, 1806),
(844, 830, 'Action', NULL, 'registration', 1807, 1808),
(845, 830, 'Action', NULL, 'resetpassword', 1809, 1810),
(846, 830, 'Action', NULL, 'update', 1811, 1812),
(847, 830, 'Action', NULL, 'upload', 1813, 1814),
(848, 830, 'Action', NULL, 'weather', 1815, 1816),
(849, 39, 'Controller', NULL, 'FileUploadApp', 83, 84),
(850, 42, 'Controller', NULL, 'ControlPanels', 121, 138),
(851, 850, 'Action', NULL, 'acoSync', 122, 123),
(852, 850, 'Action', NULL, 'beforeFilter', 124, 125),
(853, 850, 'Action', NULL, 'cleanPermission', 126, 127),
(854, 850, 'Action', NULL, 'getControllerLists', 128, 129),
(855, 850, 'Action', NULL, 'getPermissions', 130, 131),
(856, 850, 'Action', NULL, 'getUserLists', 132, 133),
(857, 850, 'Action', NULL, 'index', 134, 135),
(858, 850, 'Action', NULL, 'security', 136, 137),
(859, 42, 'Controller', NULL, 'SuperAdminApp', 139, 144),
(860, 859, 'Action', NULL, 'beforeFilter', 140, 141),
(861, 859, 'Action', NULL, 'beforeRender', 142, 143),
(870, 749, 'Action', NULL, 'download', 1557, 1558),
(871, 513, 'Action', NULL, 'admin_min_bid_report', 1065, 1066),
(872, 749, 'Action', NULL, 'admin_invite_to_bid', 1559, 1560),
(873, 749, 'Action', NULL, 'missing_files', 1561, 1562),
(874, 749, 'Action', NULL, 'view_control', 1563, 1564),
(875, 807, 'Action', NULL, 'admin_delete', 1719, 1720),
(877, 876, 'Action', NULL, 'admin_add', 1827, 1828),
(878, 876, 'Action', NULL, 'admin_delete', 1829, 1830),
(879, 876, 'Action', NULL, 'admin_edit', 1831, 1832),
(880, 876, 'Action', NULL, 'admin_index', 1833, 1834),
(881, 876, 'Action', NULL, 'admin_save', 1835, 1836),
(882, 876, 'Action', NULL, 'beforeFilter', 1837, 1838),
(883, 807, 'Action', NULL, 'admin_add_currency', 1721, 1722),
(884, 807, 'Action', NULL, 'admin_currency_index', 1723, 1724),
(885, 807, 'Action', NULL, 'admin_edit_currency', 1725, 1726),
(886, 807, 'Action', NULL, 'admin_save_currency', 1727, 1728),
(887, 807, 'Action', NULL, 'download_guideline', 1729, 1730),
(888, 807, 'Action', NULL, 'get_rate', 1731, 1732),
(889, 749, 'Action', NULL, 'staff_approve', 1565, 1566),
(890, 749, 'Action', NULL, 'bid_view_password', 1567, 1568),
(891, 749, 'Action', NULL, 'deleteUpload', 1569, 1570),
(892, 749, 'Action', NULL, 'verify_password', 1571, 1572),
(893, 749, 'Action', NULL, 'verify_password_element', 1573, 1574),
(894, 830, 'Action', NULL, 'verify_password', 1817, 1818),
(895, 830, 'Action', NULL, 'verify_password_element', 1819, 1820),
(896, 1, 'Controller', NULL, 'PluginUploads', 1840, 1847),
(897, 896, 'Action', NULL, 'admin_index', 1841, 1842),
(898, 896, 'Action', NULL, 'admin_plugin_upload', 1843, 1844),
(899, 896, 'Action', NULL, 'beforeFilter', 1845, 1846),
(900, 807, 'Action', NULL, 'admin_delete_currency', 1733, 1734),
(901, 807, 'Action', NULL, 'default_quotation_download', 1735, 1736),
(902, 830, 'Action', NULL, 'add_member', 1821, 1822),
(903, 830, 'Action', NULL, 'changePass1', 1823, 1824),
(904, 807, 'Action', NULL, 'manufactureList', 1737, 1738),
(905, 807, 'Action', NULL, 'movedown', 1739, 1740),
(906, 807, 'Action', NULL, 'moveup', 1741, 1742),
(907, 807, 'Action', NULL, 'setting', 1743, 1744),
(908, 807, 'Action', NULL, 'update_status', 1745, 1746),
(909, 807, 'Action', NULL, 'admin_save_attr', 1747, 1748),
(910, 807, 'Action', NULL, 'admin_publish', 1749, 1750),
(911, 807, 'Action', NULL, 'admin_edit_attr', 1751, 1752),
(912, 807, 'Action', NULL, 'admin_delete_attr', 1753, 1754),
(913, 807, 'Action', NULL, 'admin_bid_open_approval', 1755, 1756),
(914, 807, 'Action', NULL, 'admin_add_attr', 1757, 1758),
(915, 749, 'Action', NULL, 'admin_invite', 1575, 1576),
(916, 749, 'Action', NULL, 'approveLevel', 1577, 1578),
(917, 749, 'Action', NULL, 'reject', 1579, 1580),
(918, 749, 'Action', NULL, 'simple_upload_bid_doc', 1581, 1582),
(919, 513, 'Action', NULL, 'admin_bid_document', 1067, 1068),
(920, 513, 'Action', NULL, 'bid_document', 1069, 1070),
(921, 513, 'Action', NULL, 'product', 1071, 1072),
(922, 1, 'Controller', NULL, 'Settings', 1848, 1865),
(923, 922, 'Action', NULL, 'admin_add', 1849, 1850),
(924, 922, 'Action', NULL, 'admin_companysetting', 1851, 1852),
(925, 922, 'Action', NULL, 'admin_delete', 1853, 1854),
(926, 922, 'Action', NULL, 'admin_edit', 1855, 1856),
(927, 922, 'Action', NULL, 'admin_index', 1857, 1858),
(928, 922, 'Action', NULL, 'admin_save', 1859, 1860),
(929, 922, 'Action', NULL, 'admin_view', 1861, 1862),
(930, 922, 'Action', NULL, 'beforeFilter', 1863, 1864),
(931, 785, 'Action', NULL, 'admin_selected', 1657, 1658),
(932, 785, 'Action', NULL, 'download_selection', 1659, 1660),
(933, 521, 'Action', NULL, 'member_approve', 1155, 1156);

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
  `id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `table` varchar(15) NOT NULL,
  `street` varchar(80) DEFAULT NULL,
  `direction` varchar(225) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `phone_number` varchar(24) DEFAULT NULL,
  `email` varchar(99) DEFAULT NULL,
  `website` varchar(99) DEFAULT NULL,
  `geocode_lt` varchar(10) DEFAULT NULL,
  `geocode_lg` varchar(10) DEFAULT NULL,
  `status_id` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=164 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `table_id`, `table`, `street`, `direction`, `city`, `district`, `country`, `phone_number`, `email`, `website`, `geocode_lt`, `geocode_lg`, `status_id`) VALUES
(12, 1, 'User', 'Anam Nagar', '', 'Kathamdu', 'Bagmati', 'Nepal', '', 'support@himalayantechies.com', 'http://www.himalayantechies.com', '', '', 1),
(26, 3, 'Business', '', '', 'Kathmandu', '', 'Nepal', '', '', '', '', '', 1),
(100, 58, 'User', 'Anam Nagar', '', 'Kathmandu', '', 'Nepal', '014248109', 'sagrawal@himalayantechies.com', 'http://www.himalayantechies.com', '', '', 1),
(24, 2, 'Business', 'Baneshwor', '', '482', 'Bagmati', 'Nepal', '9843108751', 'sdahal@himalayantechies.com', '', '', '', 1),
(22, 1, 'Business', '', '', '482', '', '', '75657567', 'supplier@gmail.com', '', '', '', 1),
(33, 12, 'User', '355', 'Near to Laxmibank, Hattisar Road, Kamalpokhari, Kathmandu', '50', NULL, NULL, '+977-1-4435167', NULL, 'www.deuralijanta.com', '', '', 1),
(157, 100, 'User', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(42, 21, 'User', '', '', '594', NULL, NULL, '', NULL, '', '', '', 1),
(30, 9, 'User', 'Tokha', 'Grande Tower', '770', NULL, NULL, '9803278100', NULL, '', '', '', 1),
(31, 10, 'User', '', '', '211', NULL, NULL, '9843367691', NULL, '', '', '', 1),
(34, 13, 'User', '', '', '211', NULL, NULL, '9843367691', NULL, '', '', '', 1),
(35, 14, 'User', '', '', '594', NULL, NULL, '9851078392', 'sagrawal@himalayantechies.com', '', '', '', 1),
(36, 15, 'User', '', '', '594', NULL, NULL, '9801138717', 'sdahal@himalayantechies.com', '', '', '', 1),
(44, 23, 'User', '', '', '590', '', '', '', '', '', '', '', 1),
(45, 24, 'User', '', '', '770', NULL, NULL, '9803278100', NULL, '', '', '', 1),
(150, 95, 'User', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(47, 26, 'User', '', '', '460', '', '', '64846494165', 'arpita_92@hotmail.com', '', '', '', 1),
(48, 4, 'Business', '', '', 'Lalitpur', '', '', '', 'support@himalayantechies.com', '', '', '', 1),
(49, 27, 'User', 'kathamandu', '', '770', NULL, NULL, '9841589962,9801202509', NULL, '', '', '', 1),
(50, 28, 'User', 'banepa', 'banepa', '622', '', '', '0444444', '', '', '', '', 1),
(65, 8, 'Business', '', '', '482', NULL, NULL, '', '', '', '', '', 1),
(53, 6, 'Business', '', '', 'Kathmandu', '', '', '9803047068', 'support@himalayantechies.com', '', '', '', 1),
(63, 7, 'Business', '', '', 'Kathmandu', 'Bagmati', 'Nepal', '', 'support@himalayantechies.com', '', '', '', 1),
(66, 9, 'Business', '', '', '482', NULL, NULL, '', '', '', '', '', 1),
(67, 10, 'Business', '', '', '482', NULL, NULL, '', '', '', '', '', 1),
(68, 11, 'Business', '', '', '482', NULL, NULL, '', '', '', '', '', 1),
(69, 12, 'Business', '', '', '482', NULL, NULL, '', '', '', '', '', 1),
(77, 15, 'Business', '', '', '482', NULL, NULL, '', '', '', '', '', 1),
(110, 60, 'User', '', NULL, '', '', '', '', 'pisces_sakshi@hotmail.com', '', NULL, NULL, 1),
(147, 31, 'Business', '', NULL, '', '', '', '', 'sagrawal@himalayntechies.com', '', NULL, NULL, 1),
(92, 21, 'Business', '', '', '482', NULL, NULL, '', '', '', '', '', 1),
(75, 14, 'Business', '', '', '267', NULL, NULL, '', '', '', '', '', 1),
(83, 17, 'Business', '', '', '482', NULL, NULL, '', '', '', '', '', 1),
(81, 48, 'User', '', '', '482', NULL, NULL, '', NULL, '', '', '', 1),
(82, 16, 'Business', '', '', '482', NULL, NULL, '', '', '', '', '', 1),
(125, 74, 'User', '', NULL, '', '', '', '', 'support@himalayantechies.com', '', NULL, NULL, 1),
(88, 19, 'Business', '', '', '482', NULL, NULL, '', '', '', '', '', 1),
(89, 52, 'User', '', '', '121', '', '', '9841502630', '', '', '', '', 1),
(124, 28, 'Business', '', NULL, '', '', '', '', '', '', NULL, NULL, 1),
(95, 22, 'Business', '', '', '443', NULL, NULL, '', '', '', '', '', 1),
(97, 23, 'Business', '', '', '502', NULL, NULL, '', '', '', '', '', 1),
(98, 57, 'User', '', '', 'Lalitpur', 'Bagmati', 'Nepal', '', 'blimbu@himalayantechies.com', '', '', '', 1),
(123, 73, 'User', '', NULL, '', '', '', '555', 'bob@himalayantechies.com', '', NULL, NULL, 1),
(102, 59, 'User', '', '', '392', NULL, NULL, '', NULL, '', '', '', 1),
(103, 26, 'Business', '', '', '192', NULL, NULL, '', '', '', '', '', 1),
(104, 27, 'Business', '', NULL, 'Kathmandu', '', 'Nepal', '5551007', 'excel-traders@himalayantechies.com', 'http://www.himalayantechies.com', NULL, NULL, 1),
(129, 77, 'User', 'Sanepa', NULL, 'Kathmandu', 'Bagmati', 'Nepal', '9843108751', 'sdahal@himalayantechies.com', 'himalayantechies.com', NULL, NULL, 1),
(127, 76, 'User', 'lalitpur', NULL, 'Kathmandu', 'Bagmati', 'Nepal', '9801045391', 'arpita_92@hotmail.com', '', NULL, NULL, 1),
(130, 78, 'User', 'Sanepa', NULL, 'Kathmandu', 'Bagmati', 'Nepal', '9843108751', 'sdahal@gmail.com', 'http://www.khumbaya.com', NULL, NULL, 1),
(126, 75, 'User', '', NULL, '', '', '', '+9775551007', 'bijay@himalayantechies.com', '', NULL, NULL, 1),
(109, 60, 'User', 'Tahachal', NULL, 'Kathmandu', 'Bagmati', 'Nepal', '9801045390', 'arpita_92@hotmail.com', 'http://oopscareer.com', NULL, NULL, 1),
(111, 61, 'User', '', NULL, '', '', '', '', '', '', NULL, NULL, 1),
(112, 62, 'User', '', NULL, '', '', '', '', '', '', NULL, NULL, 1),
(113, 63, 'User', '', NULL, '', '', '', '', '', '', NULL, NULL, 1),
(114, 64, 'User', '', NULL, '', '', '', '', NULL, '', NULL, NULL, 1),
(115, 65, 'User', '', NULL, '', '', '', '', NULL, '', NULL, NULL, 1),
(116, 66, 'User', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(118, 68, 'User', '', NULL, '', '', '', '', 'sagrawal@himalayantehies.com', '', NULL, NULL, 1),
(146, 93, 'User', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(120, 70, 'User', 'patan', NULL, '', '', '', '', 'ran@hotmail.com', '', NULL, NULL, 1),
(132, 80, 'User', '', NULL, '', '', '', '', 'bob@himalayantechies.com', '', NULL, NULL, 1),
(133, 81, 'User', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(134, 30, 'Business', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(141, 88, 'User', 'Sanepa', NULL, 'Kathmandu', 'Bagmati', 'Nepal', '9843108751', 'support@himalayantechies.com', '', NULL, NULL, 1),
(148, 94, 'User', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(137, 84, 'User', '', NULL, '', '', '', '', 'arpita_92@hotmail.com', '', NULL, NULL, 1),
(142, 89, 'User', 'Sankhamul', NULL, 'Kathmandu', 'Bagmati', 'Nepal', '', 'support@himalayantechies.com', '', NULL, NULL, 1),
(143, 90, 'User', '', NULL, '', '', 'Nepal', '', 'sagrawal@himalayantehies.com', '', NULL, NULL, 1),
(149, 32, 'Business', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(151, 96, 'User', '', NULL, '', '', '', '', 'pisces_sakshi@hotmail.com', '', NULL, NULL, 1),
(152, 33, 'Business', '', NULL, '', '', '', '', 'pisces_sakshi@hotmail.com', '', NULL, NULL, 1),
(153, 97, 'User', 'sanepa', NULL, 'kathmandu', 'Bagmati', 'Nepal', '6549612695', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(154, 98, 'User', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(155, 34, 'Business', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(156, 99, 'User', '', NULL, '', '', '', '', 'pisces_sakshi@hotmail.com', '', NULL, NULL, 1),
(158, 101, 'User', '', NULL, '', '', '', '', 'sagrawal@himalayantechies.com', '', NULL, NULL, 1),
(159, 102, 'User', 'BANESHWOR', NULL, 'Ktm', 'Bagmati', 'Nepal', '9843108751', 'sahil_dahal@hotmail.com', '', NULL, NULL, 1),
(160, 103, 'User', 'kamal pokhari', NULL, '', '', '', '756756', 'piscesss.sakshi@gmail.com', '', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aros`
--

INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, 'UserRole', 1, 'admin', 1, 8),
(2, NULL, 'UserRole', 2, 'staff', 9, 20),
(3, NULL, 'UserRole', 3, 'client', 21, 108),
(4, 1, 'User', 1, 'htadmin', 2, 3),
(116, 25, 'User', 100, 'staff-testing', 114, 115),
(13, 2, 'User', 3, 'staff', 10, 11),
(14, 3, 'User', 4, 'supplier2', 22, 23),
(15, 3, 'User', 5, 'supplier3', 24, 25),
(16, 2, 'User', 2, 'staff-1', 12, 13),
(27, 3, 'User', 12, 'prava-dhungana', 26, 27),
(74, 3, 'User', 58, 'saakshi-1', 46, 47),
(37, 3, 'User', 21, 'abcsupplier', 30, 31),
(23, 2, 'User', 9, 'binu', 14, 15),
(24, 2, 'User', 10, 'sushil', 16, 17),
(25, NULL, 'UserRole', 4, 'staff-1', 109, 116),
(28, 3, 'User', 13, 'sushil1', 28, 29),
(29, 1, 'User', 14, 'baburam', 4, 5),
(30, 1, 'User', 15, 'tuldhar-manik', 6, 7),
(39, 3, 'User', 23, 'resha', 32, 33),
(40, 3, 'User', 24, 'supp-1', 34, 35),
(111, 3, 'User', 95, 'te-1', 94, 95),
(42, 3, 'User', 26, 'abc-1', 36, 37),
(43, 25, 'User', 27, 'dipak-khatri', 110, 111),
(44, 3, 'User', 28, 'a-gautam', 38, 39),
(89, 3, 'User', 73, 'bob', 66, 67),
(110, 3, 'User', 94, 'testing-1', 92, 93),
(64, 3, 'User', 48, 'newtestemail', 40, 41),
(75, 3, 'User', 59, 'test-client', 48, 49),
(68, 3, 'User', 52, 'sajwal-1', 42, 43),
(73, 3, 'User', 57, 'upload-user', 44, 45),
(76, 3, 'User', 60, 'test-1', 50, 51),
(77, 3, 'User', 61, 'testt', 52, 53),
(78, 25, 'User', 62, 'grande-test', 112, 113),
(79, 3, 'User', 63, 'grande', 54, 55),
(80, 3, 'User', 64, 'fred', 56, 57),
(81, 3, 'User', 65, 'mohit', 58, 59),
(82, 3, 'User', 66, 'shilpa', 60, 61),
(90, 3, 'User', 74, 'mmalla', 68, 69),
(84, 3, 'User', 68, 'sakshi', 62, 63),
(92, 3, 'User', 76, 'rosh', 72, 73),
(86, 3, 'User', 70, 'ran12', 64, 65),
(93, 3, 'User', 77, 'sahil', 74, 75),
(91, 3, 'User', 75, 'bijay', 70, 71),
(94, 3, 'User', 78, 'tester', 76, 77),
(96, 3, 'User', 80, 'andrew', 78, 79),
(97, 3, 'User', 81, 'sandhya', 80, 81),
(104, 3, 'User', 88, 'binod', 84, 85),
(113, 3, 'User', 97, '01tester', 98, 99),
(100, 3, 'User', 84, 'ankita123', 82, 83),
(112, 3, 'User', 96, 'tes-1', 96, 97),
(105, 3, 'User', 89, 'binod1', 86, 87),
(106, 3, 'User', 90, 'ching', 88, 89),
(109, 3, 'User', 93, 'test-1', 90, 91),
(114, 3, 'User', 98, 'china', 100, 101),
(115, 3, 'User', 99, 'sa-1', 102, 103),
(117, 2, 'User', 101, 'admin-testing', 18, 19),
(118, 3, 'User', 102, 'dahal', 104, 105),
(119, 3, 'User', 103, 'business-2', 106, 107);

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) NOT NULL,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) NOT NULL DEFAULT '0',
  `_read` varchar(2) NOT NULL DEFAULT '0',
  `_update` varchar(2) NOT NULL DEFAULT '0',
  `_delete` varchar(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=143 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aros_acos`
--

INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES
(1, 1, 1, '1', '1', '1', '1'),
(50, 3, 545, '1', '1', '1', '1'),
(49, 3, 544, '1', '1', '1', '1'),
(45, 3, 561, '1', '1', '1', '1'),
(35, 1, 554, '1', '1', '1', '1'),
(36, 1, 842, '1', '1', '1', '1'),
(37, 3, 520, '1', '1', '1', '1'),
(46, 3, 541, '1', '1', '1', '1'),
(48, 3, 543, '1', '1', '1', '1'),
(47, 3, 542, '1', '1', '1', '1'),
(34, 1, 533, '1', '1', '1', '1'),
(38, 3, 519, '1', '1', '1', '1'),
(39, 3, 518, '1', '1', '1', '1'),
(40, 3, 533, '1', '1', '1', '1'),
(41, 3, 531, '1', '1', '1', '1'),
(42, 3, 530, '1', '1', '1', '1'),
(43, 3, 534, '1', '1', '1', '1'),
(44, 3, 559, '1', '1', '1', '1'),
(51, 3, 546, '1', '1', '1', '1'),
(52, 3, 557, '1', '1', '1', '1'),
(53, 3, 554, '1', '1', '1', '1'),
(54, 3, 555, '1', '1', '1', '1'),
(55, 3, 754, '1', '1', '1', '1'),
(56, 3, 753, '1', '1', '1', '1'),
(57, 3, 755, '1', '1', '1', '1'),
(58, 3, 813, '1', '1', '1', '1'),
(59, 3, 819, '1', '1', '1', '1'),
(60, 3, 847, '1', '1', '1', '1'),
(61, 3, 846, '1', '1', '1', '1'),
(62, 3, 845, '1', '1', '1', '1'),
(63, 3, 844, '1', '1', '1', '1'),
(64, 3, 843, '1', '1', '1', '1'),
(65, 3, 842, '1', '1', '1', '1'),
(66, 3, 841, '1', '1', '1', '1'),
(67, 3, 840, '1', '1', '1', '1'),
(68, 3, 848, '1', '1', '1', '1'),
(69, 3, 839, '1', '1', '1', '1'),
(70, 3, 838, '1', '1', '1', '1'),
(71, 3, 837, '1', '1', '1', '1'),
(72, 1, 755, '1', '1', '1', '1'),
(73, 3, 815, '1', '1', '1', '1'),
(74, 2, 1, '1', '1', '1', '1'),
(75, 2, 533, '-1', '-1', '-1', '-1'),
(76, 2, 554, '-1', '-1', '-1', '-1'),
(77, 2, 557, '-1', '-1', '-1', '-1'),
(78, 2, 753, '-1', '-1', '-1', '-1'),
(79, 2, 755, '-1', '-1', '-1', '-1'),
(80, 2, 754, '-1', '-1', '-1', '-1'),
(81, 2, 813, '-1', '-1', '-1', '-1'),
(82, 2, 42, '-1', '-1', '-1', '-1'),
(83, 2, 842, '-1', '-1', '-1', '-1'),
(84, 3, 1, '1', '1', '1', '1'),
(85, 1, 823, '1', '1', '1', '1'),
(86, 2, 823, '-1', '-1', '-1', '-1'),
(87, 2, 833, '-1', '-1', '-1', '-1'),
(88, 2, 834, '-1', '-1', '-1', '-1'),
(89, 2, 835, '-1', '-1', '-1', '-1'),
(90, 2, 529, '-1', '-1', '-1', '-1'),
(92, 25, 1, '-1', '-1', '-1', '-1'),
(93, 25, 42, '-1', '-1', '-1', '-1'),
(94, 25, 554, '-1', '-1', '-1', '-1'),
(95, 25, 533, '-1', '-1', '-1', '-1'),
(96, 25, 567, '-1', '-1', '-1', '-1'),
(97, 25, 557, '-1', '-1', '-1', '-1'),
(98, 25, 529, '-1', '-1', '-1', '-1'),
(99, 25, 811, '1', '1', '1', '1'),
(100, 25, 810, '1', '1', '1', '1'),
(101, 25, 816, '1', '1', '1', '1'),
(102, 25, 840, '1', '1', '1', '1'),
(103, 25, 841, '1', '1', '1', '1'),
(104, 25, 843, '1', '1', '1', '1'),
(105, 25, 846, '1', '1', '1', '1'),
(106, 25, 847, '1', '1', '1', '1'),
(107, 25, 837, '1', '1', '1', '1'),
(108, 25, 831, '1', '1', '1', '1'),
(109, 25, 750, '1', '1', '1', '1'),
(110, 25, 889, '1', '1', '1', '1'),
(111, 3, 891, '1', '1', '1', '1'),
(112, 3, 888, '1', '1', '1', '1'),
(113, 3, 874, '1', '1', '1', '1'),
(114, 25, 516, '1', '1', '1', '1'),
(115, 25, 870, '1', '1', '1', '1'),
(116, 2, 711, '1', '1', '1', '1'),
(117, 3, 711, '1', '1', '1', '1'),
(118, 25, 711, '1', '1', '1', '1'),
(119, 3, 513, '-1', '-1', '-1', '-1'),
(120, 3, 921, '1', '1', '1', '1'),
(121, 3, 920, '1', '1', '1', '1'),
(122, 3, 521, '-1', '-1', '-1', '-1'),
(123, 3, 537, '1', '1', '1', '1'),
(124, 3, 556, '1', '1', '1', '1'),
(125, 3, 933, '1', '1', '1', '1'),
(126, 3, 749, '-1', '-1', '-1', '-1'),
(127, 3, 870, '1', '1', '1', '1'),
(128, 3, 873, '1', '1', '1', '1'),
(129, 3, 918, '1', '1', '1', '1'),
(130, 3, 785, '-1', '-1', '-1', '-1'),
(131, 3, 807, '-1', '-1', '-1', '-1'),
(132, 3, 811, '1', '1', '1', '1'),
(133, 3, 901, '1', '1', '1', '1'),
(134, 3, 814, '1', '1', '1', '1'),
(135, 3, 816, '1', '1', '1', '1'),
(136, 3, 904, '1', '1', '1', '1'),
(137, 3, 817, '1', '1', '1', '1'),
(138, 3, 907, '1', '1', '1', '1'),
(139, 3, 908, '1', '1', '1', '1'),
(140, 3, 818, '1', '1', '1', '1'),
(141, 3, 830, '-1', '-1', '-1', '-1'),
(142, 3, 903, '-1', '-1', '-1', '-1');

-- --------------------------------------------------------

--
-- Table structure for table `businesses`
--

CREATE TABLE IF NOT EXISTS `businesses` (
  `id` int(11) NOT NULL,
  `pan_no` varchar(11) DEFAULT NULL,
  `name` varchar(199) DEFAULT NULL,
  `description` text,
  `url` varchar(199) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `date_added` date DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `businesses`
--

INSERT INTO `businesses` (`id`, `pan_no`, `name`, `description`, `url`, `user_id`, `owner_id`, `status_id`, `date_added`, `category_id`) VALUES
(1, '98415026300', 'Sajwal Medical Center', 'description', 'suppliers-business', 3, 52, 1, '2013-09-20', 709),
(2, '9843108751', 'Sahil Medical Supplier', '', 'supplier2-s-business', 4, 77, 1, '2013-09-20', 708),
(3, '9801045391', 'Arpita Medical Supplier', '', 'supplier3-s-business', 5, 76, 1, '2013-09-23', 709),
(4, '9841959441', 'Bismeeta Medical Supplier', '', 'abc-enterprises', 26, 57, 1, '2013-10-31', 709),
(6, '9841893451', 'Saakshi Medical Supplier', '', 'sun', 23, 58, 1, '2013-11-01', 709),
(7, '9851061345', 'HT Medical Supplier', '', 'business-name', 38, 74, 1, '2013-11-14', 708),
(13, '6789', 'business', '', 'business-1', 40, 40, 1, '2013-11-17', 4),
(14, '10203040', 'Sajwal Enterprises', 'This is a test business.', 'sajwal-enterprises', 43, 43, 1, '2013-11-28', 3),
(15, '5432', 'Himalayan Enterprises', '', 'himalayan-enterprises', 44, 44, 1, '2013-11-28', 2),
(16, '543', 'Himalayan Enterprises', '', 'himalayan-enterprises', 47, 47, 1, '2013-11-28', 0),
(17, '5465756', 'Email Test Business', '', 'email-test-business', 48, 48, 1, '2013-11-28', 1),
(19, '789', 'HT', '', 'ht-1', 51, 51, 1, '2013-11-28', 1),
(21, '456', 'Himalayan Techies', '', 'himalayan-techies', 53, 53, 1, '2013-11-28', 2),
(22, '2048', 'Himalayan', '', 'fancy-clothings', 55, 55, 1, '2013-11-29', 3),
(23, '2043', 'Traders', '', 'traders', 56, 56, 1, '2013-11-29', 1),
(28, '33265984125', 'Kapilvastu Medical Suppliers', '', 'kapilvastu-medical-suppliers', 73, 73, 1, '2014-01-30', 709),
(30, '123456', '', '', 'sandhya-traders', 81, 81, 1, '2014-02-05', 708),
(31, '45645645', 'ABC traders', '', 'abc-traders', 93, 93, 1, '2014-02-18', 709),
(32, '12345', 'ABC traders', '', 'abc-traders-1', 94, 94, 1, '2014-02-18', 709),
(33, '45987', 'TES Traders', '', 'tes-traders', 96, 96, 1, '2014-02-18', 709),
(34, '87645', 'Business Traders', '', 'business-traders', 98, 98, 1, '2014-02-18', 709);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL,
  `model` varchar(20) DEFAULT NULL,
  `name` varchar(124) NOT NULL,
  `url` varchar(124) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=712 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `model`, `name`, `url`, `description`, `parent_id`, `lft`, `rght`) VALUES
(711, NULL, 'Travel Service', 'travel-service', NULL, NULL, 5, 6),
(708, NULL, 'Medical Suppliers', 'medical-suppliers', NULL, NULL, 1, 2),
(709, NULL, 'Medical Services', 'medical-services', NULL, NULL, 3, 4);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`) VALUES
(2, 'Currency', '1'),
(3, 'Document', '1'),
(4, 'Invitation', '1'),
(5, 'Manufacturer', '1'),
(6, 'Approve Levels', '1'),
(7, 'company_name', 'E-Bidding System'),
(8, 'administrator_email', 'ebidding@ebidding.com');

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE IF NOT EXISTS `statuses` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `model` varchar(45) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `name`, `model`) VALUES
(1, 'Active', 'Business'),
(2, 'Closed', 'Business'),
(53, 'Open for bidding', 'Tender'),
(5, 'Deleted', 'Business'),
(6, 'Active', 'User'),
(7, 'Deleted', 'User'),
(8, 'Pending Validation', 'Business'),
(9, 'Inactive', 'User'),
(55, 'Comparative Analysis', 'Tender'),
(12, 'Active', 'Review'),
(13, 'Active', 'Event'),
(14, 'Active', 'Address'),
(15, 'Pending Validation', 'Address'),
(17, 'Password Reset', 'User'),
(40, 'Canceled', 'Invitation'),
(39, 'Bid', 'Invitation'),
(38, 'Visited', 'Invitation'),
(37, 'Not Visited', 'Invitation'),
(36, 'Rejected', 'Bid'),
(35, 'Pending', 'Bid'),
(34, 'Selected', 'Bid'),
(33, 'Active', 'Tender'),
(32, 'Closed', 'Tender'),
(31, 'Open', 'Tender'),
(54, 'Closed for bidding', 'Tender'),
(41, 'Canceled', 'Bid'),
(42, 'Selected', 'Selection'),
(43, 'Waiting', 'Selection'),
(44, 'Rejected', 'Selection'),
(45, 'Open', 'TenderType'),
(46, 'Close', 'TenderType'),
(47, 'Not Approved', 'Request'),
(48, 'Approved', 'Request'),
(49, 'Rejected', 'Request'),
(50, 'Enabled', 'PluginView'),
(51, 'Disabled', 'PluginView'),
(52, 'Inactive', 'Tender'),
(56, 'Simple Upload', 'Tender'),
(57, 'Bid Analysis', 'Tender');

-- --------------------------------------------------------

--
-- Table structure for table `t_approves`
--

CREATE TABLE IF NOT EXISTS `t_approves` (
  `id` int(11) NOT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `approve_level_id` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `manufacture_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_approves`
--

INSERT INTO `t_approves` (`id`, `foreign_key`, `model`, `approve_level_id`, `approved_by`, `manufacture_id`) VALUES
(1, 1, 'Request', 188, 101, 35),
(2, 1, 'Request', 188, 101, 37),
(3, 1, 'Request', 189, 15, 35),
(4, 1, 'Request', 189, 15, 36),
(5, 1, 'Request', 189, 15, 37),
(6, 1, 'Request', 189, 15, 38),
(7, 2, 'Request', 188, 101, 44),
(8, 2, 'Request', 188, 101, 60),
(9, 2, 'Request', 189, 15, 44),
(10, 2, 'Request', 189, 15, 60),
(11, 2, 'Request', 189, 15, 64),
(12, 2, 'Request', 189, 15, 66),
(13, 7, 'Request', 200, 1, 27),
(14, 7, 'Request', 200, 1, 30),
(15, 7, 'Request', 200, 1, 32),
(16, 8, 'Request', 200, 1, 35),
(17, 8, 'Request', 200, 1, 37),
(18, 8, 'Request', 200, 1, 40),
(19, 8, 'Request', 200, 1, 44),
(20, 9, 'Request', 204, 1, 46),
(21, 9, 'Request', 204, 1, 48),
(22, 9, 'Request', 204, 1, 52),
(23, 10, 'Request', 204, 1, 27),
(24, 10, 'Request', 204, 1, 30),
(25, 10, 'Request', 204, 1, 32),
(26, 11, 'Request', 207, 1, 27),
(27, 11, 'Request', 207, 1, 29),
(28, 11, 'Request', 207, 1, 30),
(29, 12, 'Request', 207, 1, 27),
(30, 12, 'Request', 207, 1, 35),
(31, 12, 'Request', 207, 1, 37),
(32, 12, 'Request', 207, 1, 40),
(33, 21, 'Request', 223, 1, 27),
(34, 21, 'Request', 223, 1, 35),
(35, 21, 'Request', 223, 1, 47),
(36, 22, 'Request', 223, 1, 27),
(37, 22, 'Request', 223, 1, 30),
(38, 22, 'Request', 223, 1, 59),
(39, 23, 'Request', 227, 1, 29),
(40, 23, 'Request', 227, 1, 31),
(41, 23, 'Request', 227, 1, 44),
(42, 23, 'Request', 227, 1, 46),
(43, 24, 'Request', 227, 1, 27),
(44, 24, 'Request', 227, 1, 31),
(45, 24, 'Request', 227, 1, 33),
(46, 24, 'Request', 227, 1, 36),
(47, 24, 'Request', 228, 1, 27),
(48, 24, 'Request', 228, 1, 30),
(49, 24, 'Request', 228, 1, 31),
(50, 24, 'Request', 228, 1, 33),
(51, 24, 'Request', 228, 1, 36),
(52, 23, 'Request', 228, 1, 29),
(53, 23, 'Request', 228, 1, 31),
(54, 23, 'Request', 228, 1, 44),
(55, 23, 'Request', 228, 1, 46),
(56, 25, 'Request', 232, 1, 35),
(57, 26, 'Request', 235, 1, 33),
(58, 26, 'Request', 235, 1, 37),
(59, 26, 'Request', 235, 1, 40),
(60, 26, 'Request', 235, 1, 44),
(61, 27, 'Request', 235, 1, 37),
(62, 27, 'Request', 235, 1, 40),
(63, 27, 'Request', 235, 1, 44),
(64, 27, 'Request', 235, 1, 48),
(65, 28, 'Request', 241, 1, 35),
(66, 28, 'Request', 241, 1, 37),
(67, 28, 'Request', 241, 1, 40);

-- --------------------------------------------------------

--
-- Table structure for table `t_approve_levels_requests`
--

CREATE TABLE IF NOT EXISTS `t_approve_levels_requests` (
  `id` int(11) NOT NULL,
  `approve_level_id` int(2) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `request_id` int(10) DEFAULT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reject` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_approve_levels_requests`
--

INSERT INTO `t_approve_levels_requests` (`id`, `approve_level_id`, `user_id`, `request_id`, `time`, `reject`) VALUES
(1, 188, 101, 1, '2014-05-05 05:00:00', 0),
(2, 189, 15, 1, '2014-05-05 05:00:00', 0),
(3, 188, 101, 2, '2014-05-05 05:00:00', 0),
(4, 189, 15, 2, '2014-05-05 05:00:00', 0),
(5, 193, 1, 3, '2014-05-05 05:00:00', 0),
(6, 193, 1, 4, '2014-05-05 05:00:00', 0),
(7, 196, 1, 5, '2014-05-06 05:00:00', 0),
(8, 196, 1, 6, '2014-05-06 05:00:00', 0),
(9, 197, 15, 5, '2014-05-06 05:00:00', 0),
(10, 197, 15, 6, '2014-05-06 05:00:00', 0),
(11, 200, 1, 7, '2014-05-06 05:00:00', 0),
(12, 200, 1, 8, '2014-05-06 05:00:00', 0),
(13, 204, 1, 9, '2014-05-07 05:00:00', 0),
(14, 204, 1, 10, '2014-05-07 05:00:00', 0),
(15, 207, 1, 11, '2014-05-08 05:00:00', 0),
(16, 207, 1, 12, '2014-05-08 05:00:00', 0),
(17, 223, 1, 21, '2014-05-14 05:00:00', 0),
(18, 223, 1, 22, '2014-05-14 05:00:00', 0),
(19, 227, 1, 23, '2014-05-15 05:00:00', 0),
(20, 227, 1, 24, '2014-05-15 05:00:00', 0),
(21, 228, 1, 24, '2014-05-15 05:00:00', 0),
(22, 228, 1, 23, '2014-05-15 05:00:00', 0),
(23, 232, 1, 25, '2014-05-16 05:00:00', 0),
(24, 235, 1, 26, '2014-05-20 05:00:00', 0),
(25, 235, 1, 27, '2014-05-20 05:00:00', 0),
(26, 241, 1, 28, '2014-05-22 05:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `t_approve_level_tenders`
--

CREATE TABLE IF NOT EXISTS `t_approve_level_tenders` (
  `id` int(11) NOT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `tender_id` int(10) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_approve_level_tenders`
--

INSERT INTO `t_approve_level_tenders` (`id`, `foreign_key`, `model`, `type`, `tender_id`, `parent_id`, `lft`, `rght`) VALUES
(181, NULL, 'Parent', 'Request', 81, NULL, 1, 6),
(182, NULL, 'Parent', 'Selection', 81, NULL, 7, 10),
(183, 1, 'User', 'Request', 81, 181, 2, 3),
(184, 15, 'User', 'Request', 81, 181, 4, 5),
(185, 15, 'User', 'Selection', 81, 182, 8, 9),
(186, NULL, 'Parent', 'Request', 82, NULL, 11, 16),
(187, NULL, 'Parent', 'Selection', 82, NULL, 17, 20),
(188, 2, 'UserRole', 'Request', 82, 186, 12, 13),
(189, 15, 'User', 'Request', 82, 186, 14, 15),
(190, 1, 'User', 'Selection', 82, 187, 18, 19),
(191, NULL, 'Parent', 'Request', 83, NULL, 21, 24),
(192, NULL, 'Parent', 'Selection', 83, NULL, 25, 26),
(193, 1, 'User', 'Request', 83, 191, 22, 23),
(194, NULL, 'Parent', 'Request', 84, NULL, 27, 32),
(195, NULL, 'Parent', 'Selection', 84, NULL, 33, 34),
(196, 1, 'User', 'Request', 84, 194, 28, 29),
(197, 1, 'UserRole', 'Request', 84, 194, 30, 31),
(198, NULL, 'Parent', 'Request', 85, NULL, 35, 38),
(199, NULL, 'Parent', 'Selection', 85, NULL, 39, 42),
(200, 1, 'User', 'Request', 85, 198, 36, 37),
(201, 15, 'User', 'Selection', 85, 199, 40, 41),
(202, NULL, 'Parent', 'Request', 86, NULL, 43, 46),
(203, NULL, 'Parent', 'Selection', 86, NULL, 47, 48),
(204, 1, 'User', 'Request', 86, 202, 44, 45),
(205, NULL, 'Parent', 'Request', 87, NULL, 49, 52),
(206, NULL, 'Parent', 'Selection', 87, NULL, 53, 56),
(207, 1, 'User', 'Request', 87, 205, 50, 51),
(208, 15, 'User', 'Selection', 87, 206, 54, 55),
(209, NULL, 'Parent', 'Request', 88, NULL, 57, 58),
(210, NULL, 'Parent', 'Selection', 88, NULL, 59, 60),
(211, NULL, 'Parent', 'Request', 89, NULL, 61, 62),
(212, NULL, 'Parent', 'Selection', 89, NULL, 63, 64),
(213, NULL, 'Parent', 'Request', 90, NULL, 65, 66),
(214, NULL, 'Parent', 'Selection', 90, NULL, 67, 68),
(215, NULL, 'Parent', 'Request', 91, NULL, 69, 70),
(216, NULL, 'Parent', 'Selection', 91, NULL, 71, 72),
(217, NULL, 'Parent', 'Request', 92, NULL, 73, 74),
(218, NULL, 'Parent', 'Selection', 92, NULL, 75, 76),
(219, NULL, 'Parent', 'Request', 93, NULL, 77, 78),
(220, NULL, 'Parent', 'Selection', 93, NULL, 79, 80),
(221, NULL, 'Parent', 'Request', 94, NULL, 81, 84),
(222, NULL, 'Parent', 'Selection', 94, NULL, 85, 88),
(223, 1, 'User', 'Request', 94, 221, 82, 83),
(224, 15, 'User', 'Selection', 94, 222, 86, 87),
(225, NULL, 'Parent', 'Request', 95, NULL, 89, 94),
(226, NULL, 'Parent', 'Selection', 95, NULL, 95, 98),
(227, 1, 'User', 'Request', 95, 225, 90, 91),
(228, 1, 'User', 'Request', 95, 225, 92, 93),
(229, 1, 'User', 'Selection', 95, 226, 96, 97),
(230, NULL, 'Parent', 'Request', 96, NULL, 99, 102),
(231, NULL, 'Parent', 'Selection', 96, NULL, 103, 104),
(232, 1, 'User', 'Request', 96, 230, 100, 101),
(233, NULL, 'Parent', 'Request', 97, NULL, 105, 108),
(234, NULL, 'Parent', 'Selection', 97, NULL, 109, 112),
(235, 1, 'User', 'Request', 97, 233, 106, 107),
(236, 15, 'User', 'Selection', 97, 234, 110, 111),
(237, NULL, 'Parent', 'Request', 98, NULL, 113, 114),
(238, NULL, 'Parent', 'Selection', 98, NULL, 115, 116),
(239, NULL, 'Parent', 'Request', 99, NULL, 117, 120),
(240, NULL, 'Parent', 'Selection', 99, NULL, 121, 124),
(241, 1, 'User', 'Request', 99, 239, 118, 119),
(242, 15, 'User', 'Selection', 99, 240, 122, 123),
(243, NULL, 'Parent', 'Request', 100, NULL, 125, 126),
(244, NULL, 'Parent', 'Selection', 100, NULL, 127, 128),
(245, NULL, 'Parent', 'Request', 101, NULL, 129, 130),
(246, NULL, 'Parent', 'Selection', 101, NULL, 131, 132),
(247, NULL, 'Parent', 'Request', 102, NULL, 133, 136),
(248, NULL, 'Parent', 'Selection', 102, NULL, 137, 140),
(249, 1, 'User', 'Request', 102, 247, 134, 135),
(250, 15, 'User', 'Selection', 102, 248, 138, 139);

-- --------------------------------------------------------

--
-- Table structure for table `t_bids`
--

CREATE TABLE IF NOT EXISTS `t_bids` (
  `id` int(11) NOT NULL,
  `tender_manufacture_products_id` int(11) DEFAULT NULL,
  `request_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `rate_num` double DEFAULT NULL,
  `pack_size_box` varchar(255) DEFAULT NULL,
  `rate_word` varchar(255) DEFAULT NULL,
  `bonus` varchar(100) DEFAULT NULL,
  `max_ret_price` double DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `discount_type` varchar(20) DEFAULT NULL,
  `pcn_margin` float DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `remarks` text
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_bids`
--

INSERT INTO `t_bids` (`id`, `tender_manufacture_products_id`, `request_id`, `supplier_id`, `rate_num`, `pack_size_box`, `rate_word`, `bonus`, `max_ret_price`, `discount`, `discount_type`, `pcn_margin`, `status_id`, `created_date`, `updated_date`, `remarks`) VALUES
(1, 2545, 2, 6, 250, '20', NULL, '', 300, NULL, 'Amount', NULL, 35, '2014-05-05 11:58:36', '2014-05-05 11:58:36', ''),
(2, 2511, 2, 6, 200, '10', NULL, '', 250, NULL, 'Amount', NULL, 35, '2014-05-05 11:58:36', '2014-05-05 11:58:36', ''),
(3, 2536, 1, 2, 962.6999999999999, '5', NULL, '1', 1444.05, 962.7, 'Amount', NULL, 35, '2014-05-05 12:02:35', '2014-05-05 12:02:35', 'fgdf'),
(4, 2537, 1, 2, 962.6999999999999, '5', NULL, '1', 1444.05, 962.7, 'Amount', NULL, 35, '2014-05-05 12:02:35', '2014-05-05 12:02:35', 'This is a test'),
(5, 2538, 1, 2, 962.6999999999999, '5', NULL, '1', 1444.05, 962.7, 'Amount', NULL, 35, '2014-05-05 12:02:35', '2014-05-05 12:02:35', ''),
(6, 2539, 1, 2, 9627, '10', NULL, '1', 11071.05, 962.7, 'Amount', NULL, 35, '2014-05-05 12:02:35', '2014-05-05 12:02:35', 'ohhh'),
(7, 2586, 8, 2, 25000, '20', NULL, '', 30000, 2300, 'Amount', NULL, 35, '2014-05-06 12:21:57', '2014-05-06 12:21:57', ''),
(8, 2588, 8, 2, 30000, '10', NULL, '25', 40000, 200, 'Amount', NULL, 35, '2014-05-06 12:21:57', '2014-05-06 12:21:57', ''),
(9, 2578, 7, 6, 200, '10', NULL, '', 300, NULL, 'Amount', NULL, 35, '2014-05-06 12:23:06', '2014-05-06 12:23:06', ''),
(10, 2628, 10, 2, 240, '20', NULL, '', 300, NULL, 'Amount', NULL, 35, '2014-05-07 15:57:23', '2014-05-07 15:57:23', ''),
(11, 2631, 10, 2, 400, '10', NULL, '', 500, 25, 'Amount', NULL, 35, '2014-05-07 15:57:23', '2014-05-07 15:57:23', ''),
(12, 2647, 9, 6, 300, '10', NULL, '', 350, NULL, 'Amount', NULL, 35, '2014-05-07 15:59:13', '2014-05-07 15:59:13', ''),
(13, 2649, 9, 6, 200, '5', NULL, '30', 200, NULL, 'Amount', NULL, 35, '2014-05-07 15:59:13', '2014-05-07 15:59:13', ''),
(14, 2678, 12, 2, 250, '10', NULL, '', 300, NULL, 'Amount', NULL, 35, '2014-05-08 13:59:23', '2014-05-08 13:59:23', ''),
(15, 2686, 12, 2, 100, '4', NULL, '', 500, NULL, 'Amount', NULL, 35, '2014-05-08 13:59:23', '2014-05-08 13:59:23', ''),
(16, 2711, 15, 6, 250, '10', NULL, '', 300, NULL, 'Amount', NULL, 35, '2014-05-09 14:17:44', '2014-05-09 14:17:44', ''),
(17, 2712, 15, 6, 400, '5', NULL, '', 500, NULL, 'Amount', NULL, 35, '2014-05-09 14:17:44', '2014-05-09 14:17:44', ''),
(18, 2711, 16, 2, 500, '10', NULL, '', 600, NULL, 'Amount', NULL, 35, '2014-05-09 14:23:00', '2014-05-09 14:23:00', ''),
(19, 2713, 16, 2, 200, '50', NULL, '', 300, NULL, 'Amount', NULL, 35, '2014-05-09 14:23:00', '2014-05-09 14:23:00', ''),
(20, 2714, 16, 2, 350, '15', NULL, '', 400, NULL, 'Amount', NULL, 35, '2014-05-09 14:23:00', '2014-05-09 14:23:00', ''),
(21, 2761, 17, 6, 260, '10', NULL, '', 400, NULL, 'Amount', NULL, 35, '2014-05-12 13:41:58', '2014-05-12 13:41:58', ''),
(22, 2762, 17, 6, 350, '35', NULL, '', 500, NULL, 'Amount', NULL, 35, '2014-05-12 13:41:58', '2014-05-12 13:41:58', ''),
(23, 2761, 18, 2, 200, '10', NULL, '', 300, NULL, 'Amount', NULL, 35, '2014-05-12 13:49:15', '2014-05-12 13:49:15', ''),
(24, 2861, 19, 6, 300, '10', NULL, '', 400, NULL, 'Amount', NULL, 35, '2014-05-13 13:11:12', '2014-05-13 13:11:12', ''),
(25, 2864, 19, 6, 500, '40', NULL, '', 550, NULL, 'Amount', NULL, 35, '2014-05-13 13:11:12', '2014-05-13 13:11:12', ''),
(26, 2911, 20, 6, 300, '10', NULL, '', 360, NULL, 'Amount', NULL, 35, '2014-05-13 13:56:43', '2014-05-13 13:56:43', ''),
(27, 2913, 20, 6, 500, '4', NULL, '', 600, NULL, 'Amount', NULL, 35, '2014-05-13 13:56:43', '2014-05-13 13:56:43', ''),
(28, 2978, 22, 2, 300, '10', NULL, '', 360, NULL, 'Amount', NULL, 35, '2014-05-14 11:11:06', '2014-05-14 11:11:06', ''),
(29, 2981, 22, 2, 600, '50', NULL, '', 700, NULL, 'Amount', NULL, 35, '2014-05-14 11:11:06', '2014-05-14 11:11:06', ''),
(30, 2986, 21, 6, 300, '40', NULL, '', 500, NULL, 'Amount', NULL, 35, '2014-05-14 11:16:21', '2014-05-14 11:16:21', ''),
(31, 2998, 21, 6, 500, '30', NULL, '', 700, NULL, 'Amount', NULL, 35, '2014-05-14 11:16:21', '2014-05-14 11:16:21', ''),
(32, 3028, 24, 2, 200, '110', NULL, '', 400, NULL, 'Amount', NULL, 35, '2014-05-15 12:48:48', '2014-05-15 12:48:48', ''),
(33, 3031, 24, 2, 500, '20', NULL, '', 700, NULL, 'Amount', NULL, 35, '2014-05-15 12:48:48', '2014-05-15 12:48:48', ''),
(34, 3032, 23, 6, 500, '30', NULL, '', 600, NULL, 'Amount', NULL, 35, '2014-05-15 12:50:35', '2014-05-15 12:50:35', ''),
(35, 3045, 23, 6, 100, '50', NULL, '', 400, NULL, 'Amount', NULL, 35, '2014-05-15 12:50:35', '2014-05-15 12:50:35', ''),
(36, 3138, 27, 2, 250, '10', NULL, '', 300, NULL, 'Amount', NULL, 35, '2014-05-20 12:49:19', '2014-05-20 12:50:55', ''),
(37, 3141, 27, 2, 400, '20', NULL, '', 500, NULL, 'Amount', NULL, 35, '2014-05-20 12:49:19', '2014-05-20 12:50:55', ''),
(38, 3145, 27, 2, 300, '20', NULL, '', 500, NULL, 'Amount', NULL, NULL, NULL, '2014-05-20 12:50:55', ''),
(39, 3134, 26, 6, 400, '30', NULL, '3', 400, NULL, 'Amount', NULL, 35, '2014-05-20 12:52:54', '2014-05-20 12:52:54', ''),
(40, 3211, 31, 6, 34, '10', NULL, '56', 70, NULL, 'Amount', NULL, 35, '2014-05-26 12:57:17', '2014-05-26 12:57:17', '');

-- --------------------------------------------------------

--
-- Table structure for table `t_currency_tenders`
--

CREATE TABLE IF NOT EXISTS `t_currency_tenders` (
  `id` int(11) NOT NULL,
  `tender_id` int(11) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `ex_rate` float DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_currency_tenders`
--

INSERT INTO `t_currency_tenders` (`id`, `tender_id`, `currency`, `ex_rate`) VALUES
(42, 81, 'IC', 1.6),
(43, 82, '$', 96.27),
(44, 84, 'Dollar', 100),
(45, 85, 'IC', 1.6),
(46, 85, 'Dollar', 100),
(47, 87, 'IC', 1.6),
(48, 99, 'IC', 1.6),
(49, 102, 'IC', 1.6);

-- --------------------------------------------------------

--
-- Table structure for table `t_manufactures`
--

CREATE TABLE IF NOT EXISTS `t_manufactures` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_manufactures`
--

INSERT INTO `t_manufactures` (`id`, `name`) VALUES
(1, 'DENISCHEM LAB'),
(2, 'BAXTER HEALTHCARE'),
(3, 'CADILA HEALTHCARE'),
(4, 'OZONE PHARMACEUTICALS'),
(5, 'DR REDDY''S'),
(6, 'IPCA LABORATORIES'),
(7, 'SUN PHARMA'),
(8, 'ASIAN PHARMACEUTICALS'),
(9, 'RAPTAKOS'),
(10, 'Manufacturer 1'),
(11, 'Manufacturer 2'),
(12, 'Manufacturer 3'),
(13, 'Manufacturer 4'),
(14, 'Manufacturer 5'),
(15, 'Manufacturer 6'),
(16, 'Manufacturer 7'),
(17, 'Manufacturer 8'),
(18, 'Manufacturer 9'),
(19, 'Manufacturer 10'),
(20, 'Manufacturer 11'),
(21, 'Manufacturer 12'),
(22, 'Manufacturer 13'),
(23, 'Manufacturer 14'),
(24, 'Manufacturer 15'),
(25, 'Manufacturer 16'),
(26, 'Manufacturer 17'),
(27, 'Manufacturer 18'),
(28, 'Manufacturer 19'),
(29, 'Manufacturer 20'),
(30, 'Manufacturer 21'),
(31, 'Manufacturer 22'),
(32, 'Manufacturer 23'),
(33, 'Manufacturer 24'),
(34, 'Manufacturer 25'),
(35, 'Company 1'),
(36, 'Company 2'),
(37, 'Company 3'),
(38, 'Company 4'),
(39, 'Company 5'),
(40, 'Company 6'),
(41, 'Company 7'),
(42, 'Company 8'),
(43, 'Company 9'),
(44, 'Company 10'),
(45, 'Company 11'),
(46, 'Company 12'),
(47, 'Company 13'),
(48, 'Company 14'),
(49, 'Company 15'),
(50, 'Company 16'),
(51, 'Company 17'),
(52, 'Company 18'),
(53, 'Company 19'),
(54, 'Company 20'),
(55, 'Company 21'),
(56, 'Company 22'),
(57, 'Company 23'),
(58, 'Company 24'),
(59, 'Company 25'),
(60, 'Ranbaxy'),
(61, 'Sinovac Biotech Co Ltd'),
(62, 'Lanzhou Institute of Biological Products'),
(63, 'Akums Drugs and Pharmaceuticals Ltd'),
(64, 'Alive Pharmaceuticals Pvt. Ltd.'),
(65, 'Amie Pharmaceuticals Pvt. Ltd.'),
(66, 'Apex Pharmaceuticals Pvt. Ltd.'),
(67, 'Chemidrug Industries Pvt. Ltd.'),
(68, 'Concept Pharmaceuticals (Nepal) Pvt. Ltd.'),
(69, 'CTL Pharmceuticals Pvt. Ltd. '),
(70, 'Elder Universal Pharmaceutical (Nepal) Pvt. Ltd.'),
(71, 'Magnus Pharma Pvt. Ltd.'),
(72, 'Manoj Pharmaceutical Works'),
(73, 'Nepal Aushadhi Limited'),
(74, 'Panas Pharmaceuticals Pvt. Ltd.'),
(75, 'Ohm Pharma Lab Pvt. Ltd.'),
(76, 'Siddhartha Pharmaceuticals Pvt. Ltd.'),
(77, 'Vijayadeep Laboratories Ltd.'),
(78, 'Unique Pharmaceuticals Pvt. Ltd.'),
(79, 'GlaxoSmithKline'),
(80, 'Johnson & Johnson'),
(81, 'Roche'),
(82, 'Merk & Co.'),
(83, 'Novartis'),
(84, 'Bayer Healthcare'),
(85, 'Abbott Laboratories'),
(86, 'HT');

-- --------------------------------------------------------

--
-- Table structure for table `t_products`
--

CREATE TABLE IF NOT EXISTS `t_products` (
  `id` int(11) NOT NULL,
  `b_name` varchar(200) DEFAULT NULL,
  `g_name` varchar(200) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_products`
--

INSERT INTO `t_products` (`id`, `b_name`, `g_name`) VALUES
(1, '1/2 NORMAL SALINE 0.45% (500 ML, GLASS)', 'SODIUM CHORIDE'),
(2, 'NORMAL SALINE - VIAFLEX (500 ML, PLASTIC BAG)', 'SODIUM CHLORIDE'),
(3, 'OCID 20 CAPSULE', 'OMEPRAZOLE'),
(4, 'OLIC 5 ', 'FOLIC ACID'),
(5, 'OMEZ INJ 40', 'OMEPRAZOLE'),
(6, 'PACIMOL SYRUP 125 (60 ML)', 'PARACETAMOL'),
(7, 'PANTOCID 40', 'PANTOPRAZOLE'),
(8, 'PANTOCID INJ 40', 'PANTOPRAZOLE'),
(9, 'PANTOP 40', 'PANTOPRAZOLE'),
(10, 'ZYTEE RB GEL (10 ML)', 'BENZALKONIUM CHLORIDE + CHOLINE SALICYLATE'),
(11, 'Brand Name 1', 'Generic Name 1'),
(12, 'Brand Name 2', 'Generic Name 2'),
(13, 'Brand Name 3', 'Generic Name 3'),
(14, 'Brand Name 4', 'Generic Name 4'),
(15, 'Brand Name 5', 'Generic Name 5'),
(16, 'Brand Name 6', 'Generic Name 6'),
(17, 'Brand Name 7', 'Generic Name 7'),
(18, 'Brand Name 8', 'Generic Name 8'),
(19, 'Brand Name 9', 'Generic Name 9'),
(20, 'Brand Name 10', 'Generic Name 10'),
(21, 'Brand Name 11', 'Generic Name 11'),
(22, 'Brand Name 12', 'Generic Name 12'),
(23, 'Brand Name 13', 'Generic Name 13'),
(24, 'Brand Name 14', 'Generic Name 14'),
(25, 'Brand Name 15', 'Generic Name 15'),
(26, 'Brand Name 16', 'Generic Name 16'),
(27, 'Brand Name 17', 'Generic Name 17'),
(28, 'Brand Name 18', 'Generic Name 18'),
(29, 'Brand Name 19', 'Generic Name 19'),
(30, 'Brand Name 20', 'Generic Name 20'),
(31, 'Brand Name 21', 'Generic Name 21'),
(32, 'Brand Name 22', 'Generic Name 22'),
(33, 'Brand Name 23', 'Generic Name 23'),
(34, 'Brand Name 24', 'Generic Name 24'),
(35, 'Brand Name 25', 'Generic Name 25'),
(36, 'Brand Name 26', 'Generic Name 26'),
(37, 'Brand Name 27', 'Generic Name 27'),
(38, 'Brand Name 28', 'Generic Name 28'),
(39, 'Brand Name 29', 'Generic Name 29'),
(40, 'Brand Name 30', 'Generic Name 30'),
(41, 'Brand Name 31', 'Generic Name 31'),
(42, 'Brand Name 32', 'Generic Name 32'),
(43, 'Brand Name 33', 'Generic Name 33'),
(44, 'Brand Name 34', 'Generic Name 34'),
(45, 'Brand Name 35', 'Generic Name 35'),
(46, 'Brand Name 36', 'Generic Name 36'),
(47, 'Brand Name 37', 'Generic Name 37'),
(48, 'Brand Name 38', 'Generic Name 38'),
(49, 'Brand Name 39', 'Generic Name 39'),
(50, 'Brand Name 40', 'Generic Name 40'),
(51, 'Brand Name 41', 'Generic Name 41'),
(52, 'Brand Name 42', 'Generic Name 42'),
(53, 'Brand Name 43', 'Generic Name 43'),
(54, 'Brand Name 44', 'Generic Name 44'),
(55, 'Brand Name 45', 'Generic Name 45'),
(56, 'Brand Name 46', 'Generic Name 46'),
(57, 'Brand Name 47', 'Generic Name 47'),
(58, 'Brand Name 48', 'Generic Name 48'),
(59, 'Brand Name 49', 'Generic Name 49'),
(60, 'Brand Name 50', 'Generic Name 50'),
(61, 'Fiber', 'Metal'),
(62, 'tin', 'Metal'),
(63, 'Lead', 'Metal'),
(64, 'fFiber', ''),
(65, 'Coldin', 'sad'),
(66, 'Citamol', 'fgf'),
(67, 'Boots', 'Sports'),
(68, 'Ball', 'Sports'),
(69, 'Arm band', 'Sports'),
(70, '5.44154515462E+16', ''),
(71, 'Pad/ Gloves/ helmet', 'sad'),
(72, 'Bat', 'fgf'),
(73, 'Boots', '2145641651'),
(74, 'Stump', '58484');

-- --------------------------------------------------------

--
-- Table structure for table `t_requests`
--

CREATE TABLE IF NOT EXISTS `t_requests` (
  `id` int(11) NOT NULL,
  `tender_id` int(11) DEFAULT NULL,
  `business_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `bid_view` int(1) NOT NULL DEFAULT '0' COMMENT '0 =No, 1 = Yes',
  `overall_discount` float DEFAULT NULL,
  `discount_type` varchar(20) DEFAULT NULL,
  `document_status` int(1) NOT NULL DEFAULT '0' COMMENT '0 => unsufficent, 1 => sufficient',
  `currency` varchar(10) DEFAULT NULL,
  `supplier_status` varchar(255) DEFAULT NULL,
  `bid_view_password` varchar(10) DEFAULT NULL,
  `bid_view_password2` varchar(10) DEFAULT NULL,
  `bid_view_status` int(1) NOT NULL DEFAULT '0',
  `staff_approve` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_requests`
--

INSERT INTO `t_requests` (`id`, `tender_id`, `business_id`, `created_date`, `updated_date`, `user_id`, `type`, `status_id`, `bid_view`, `overall_discount`, `discount_type`, `document_status`, `currency`, `supplier_status`, `bid_view_password`, `bid_view_password2`, `bid_view_status`, `staff_approve`) VALUES
(1, 82, 2, '2014-05-05 11:03:12', '2014-05-05 11:03:12', 77, 'Invitation', 47, 1, NULL, 'Amount', 0, '$', 'Bid Placed', '000000', '000000', 1, 0),
(2, 82, 6, '2014-05-05 11:39:24', '2014-05-05 11:39:24', 58, 'Request', 47, 0, NULL, 'Amount', 1, 'NC', 'Bid Placed', '', '', 1, 0),
(3, 83, 6, '2014-05-05 12:59:30', '2014-05-05 13:01:49', 58, 'Request', 47, 0, NULL, NULL, 0, NULL, 'Bid Placed', '123456', '123456', 0, 0),
(4, 83, 2, '2014-05-05 13:00:17', '2014-05-05 13:07:17', 77, 'Request', 47, 0, NULL, NULL, 1, NULL, 'Bid Placed', '', '', 0, 0),
(5, 84, 2, '2014-05-06 10:47:14', '2014-05-06 11:02:01', 77, 'Invitation', 47, 0, NULL, NULL, 1, NULL, 'Bid Placed', '123456', '123456', 0, 0),
(6, 84, 6, '2014-05-06 10:56:25', '2014-05-06 11:03:18', 58, 'Request', 47, 0, NULL, NULL, 1, NULL, 'Bid Placed', '', '', 0, 0),
(7, 85, 6, '2014-05-06 12:15:40', '2014-05-06 12:15:40', 58, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 1, 0),
(8, 85, 2, '2014-05-06 12:18:16', '2014-05-06 12:18:16', 77, 'Request', 47, 0, 250, 'Amount', 0, 'Dollar', 'Bid Placed', '123456', '123456', 1, 0),
(9, 86, 6, '2014-05-07 15:31:00', '2014-05-07 15:31:00', 58, 'Request', 47, 0, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 1, 0),
(10, 86, 2, '2014-05-07 15:31:47', '2014-05-07 15:31:47', 77, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '123456', '123456', 1, 0),
(11, 87, 6, '2014-05-08 13:30:03', '2014-05-08 13:30:03', 58, 'Request', 47, 0, NULL, NULL, 0, NULL, 'Approved', NULL, NULL, 0, 0),
(12, 87, 2, '2014-05-08 13:34:53', '2014-05-08 13:34:53', 77, 'Request', 47, 0, 250, 'Amount', 0, 'NC', 'Bid Placed', '123456', '123456', 1, 0),
(13, 88, 6, '2014-05-08 15:26:03', '2014-05-08 15:27:09', 58, 'Request', 47, 0, NULL, NULL, 0, NULL, 'Bid Placed', NULL, NULL, 0, 0),
(14, 88, 2, '2014-05-08 15:32:03', '2014-05-08 15:32:21', 77, 'Request', 47, 0, NULL, NULL, 0, NULL, 'Bid Placed', NULL, NULL, 0, 0),
(15, 89, 6, '2014-05-09 14:16:47', '2014-05-09 14:16:48', 58, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 1, 0),
(16, 89, 2, '2014-05-09 14:19:59', '2014-05-09 14:19:59', 77, 'Request', 47, 0, NULL, 'Amount', 0, 'NC', 'Bid Placed', '123456', '123456', 1, 0),
(17, 90, 6, '2014-05-12 13:40:59', '2014-05-12 13:40:59', 58, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 1, 0),
(18, 90, 2, '2014-05-12 13:48:38', '2014-05-12 13:48:38', 77, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 1, 0),
(19, 92, 6, '2014-05-13 13:10:35', '2014-05-13 13:10:35', 58, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 0, 0),
(20, 93, 6, '2014-05-13 13:56:10', '2014-05-13 13:56:10', 58, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 1, 0),
(21, 94, 6, '2014-05-14 11:06:40', '2014-05-14 11:06:40', 58, 'Request', 47, 0, NULL, 'Amount', 0, 'NC', 'Bid Placed', '123456', '123456', 1, 0),
(22, 94, 2, '2014-05-14 11:07:24', '2014-05-14 11:07:24', 77, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 1, 0),
(23, 95, 6, '2014-05-15 12:34:46', '2014-05-15 12:34:46', 58, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 0, 0),
(24, 95, 2, '2014-05-15 12:35:43', '2014-05-15 12:35:43', 77, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 0, 0),
(25, 96, 2, '2014-05-16 11:57:40', '2014-05-16 11:57:40', 77, 'Invitation', 47, 0, NULL, NULL, 0, NULL, 'Pending', NULL, NULL, 0, 0),
(26, 97, 6, '2014-05-20 12:45:55', '2014-05-20 12:45:55', 58, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 0, 0),
(27, 97, 2, '2014-05-20 12:46:49', '2014-05-20 12:46:49', 77, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 0, 0),
(28, 99, 6, '2014-05-22 11:20:29', '2014-05-22 11:20:29', 58, 'Invitation', 47, 0, NULL, NULL, 0, NULL, 'Approved', NULL, NULL, 0, 0),
(29, 99, 2, '2014-05-22 11:37:40', '2014-05-22 11:37:40', 77, 'Request', 47, 0, NULL, NULL, 0, NULL, 'Requested', NULL, NULL, 0, 0),
(30, 100, 6, '2014-05-22 14:36:13', '2014-05-22 14:36:48', 58, 'Request', 47, 0, NULL, NULL, 0, NULL, 'Bid Placed', NULL, NULL, 1, 0),
(31, 101, 6, '2014-05-26 12:50:08', '2014-05-26 12:50:08', 58, 'Request', 47, 1, NULL, 'Amount', 0, 'NC', 'Bid Placed', '', '', 0, 0),
(32, 102, 6, '2014-05-27 12:52:47', '2014-05-27 12:52:47', 58, 'Invitation', 47, 0, NULL, NULL, 0, NULL, 'Invited', NULL, NULL, 0, 0),
(33, 102, 30, '2014-05-27 12:53:19', '2014-05-27 12:53:19', 81, 'Invitation', 47, 0, NULL, NULL, 0, NULL, 'Invited', NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `t_req_docs`
--

CREATE TABLE IF NOT EXISTS `t_req_docs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_req_docs`
--

INSERT INTO `t_req_docs` (`id`, `name`, `type`, `description`) VALUES
(1, 'License of the Firm', 'License', ''),
(2, 'Income Tax Registration Certificate', 'Tax Registration', ''),
(3, 'Renewed VAT or PAN Certificate', 'VAT / PAN', ''),
(5, 'Company Authorisation Letter', 'Authorisation ', ''),
(6, 'Tax Clearance Certificate', 'Tax Clearance', 'Please upload this document.'),
(8, 'DDA label certificate', 'DDA', 'This is mandatory document.');

-- --------------------------------------------------------

--
-- Table structure for table `t_req_doc_tenders`
--

CREATE TABLE IF NOT EXISTS `t_req_doc_tenders` (
  `id` int(11) NOT NULL,
  `req_doc_id` int(11) DEFAULT NULL,
  `tender_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_req_doc_tenders`
--

INSERT INTO `t_req_doc_tenders` (`id`, `req_doc_id`, `tender_id`) VALUES
(69, 1, 81),
(70, 5, 81),
(71, 3, 82),
(72, 1, 83),
(73, 2, 83),
(74, 6, 84),
(75, 3, 84),
(76, 2, 99),
(77, 5, 99),
(78, 1, 102),
(79, 8, 102);

-- --------------------------------------------------------

--
-- Table structure for table `t_selections`
--

CREATE TABLE IF NOT EXISTS `t_selections` (
  `id` int(11) NOT NULL,
  `tender_id` int(11) DEFAULT NULL,
  `bid_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_selections`
--

INSERT INTO `t_selections` (`id`, `tender_id`, `bid_id`, `status_id`, `created_date`, `updated_date`) VALUES
(1, 82, 2, 34, '2014-05-05 13:04:08', '2014-05-05 13:04:08'),
(2, 82, 4, 34, '2014-05-05 13:04:08', '2014-05-05 13:04:08'),
(3, 82, 5, 34, '2014-05-05 13:04:08', '2014-05-05 13:04:08'),
(4, 85, 9, 34, '2014-05-06 13:04:59', '2014-05-06 13:04:59'),
(5, 85, 7, 34, '2014-05-06 13:04:59', '2014-05-06 13:04:59'),
(6, 86, 10, 34, '2014-05-07 16:03:41', '2014-05-07 16:03:41'),
(7, 87, 14, 34, '2014-05-08 14:02:37', '2014-05-08 14:02:37'),
(8, 89, 16, 34, '2014-05-09 14:32:57', '2014-05-09 14:32:57'),
(9, 90, 23, 34, '2014-05-12 14:03:05', '2014-05-12 14:03:05'),
(10, 90, 22, 34, '2014-05-12 14:03:05', '2014-05-12 14:03:05'),
(11, 94, 28, 34, '2014-05-14 11:50:15', '2014-05-14 11:50:15'),
(12, 94, 30, 34, '2014-05-14 11:50:15', '2014-05-14 11:50:15'),
(13, 94, 31, 34, '2014-05-14 11:50:15', '2014-05-14 11:50:15');

-- --------------------------------------------------------

--
-- Table structure for table `t_tenders`
--

CREATE TABLE IF NOT EXISTS `t_tenders` (
  `id` int(11) NOT NULL,
  `code` varchar(60) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `opening_date` datetime DEFAULT NULL,
  `bid_opening_date` datetime DEFAULT NULL,
  `bid_closing_date` datetime DEFAULT NULL,
  `closing_date` datetime DEFAULT NULL,
  `description` text,
  `department_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `tender_publish` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_tenders`
--

INSERT INTO `t_tenders` (`id`, `code`, `type`, `subject`, `opening_date`, `bid_opening_date`, `bid_closing_date`, `closing_date`, `description`, `department_id`, `user_id`, `created_date`, `updated_date`, `status_id`, `tender_publish`) VALUES
(81, '2014-05-02_100001', 'Comparative Analysis', 'Quotation for bidding', '2014-05-02 15:35:46', '2014-05-02 15:20:46', '2014-05-02 15:40:46', '2014-05-02 15:55:46', '', NULL, 1, '2014-05-02 15:11:43', '2014-05-02 15:11:43', 52, 0),
(82, '2014-05-05_100002', 'Comparative Analysis', 'Quotation test', '2014-05-05 12:00:15', '2014-05-05 11:30:15', '2014-05-05 13:00:15', '2014-05-05 13:30:15', 'This is a test', NULL, 1, '2014-05-05 11:02:17', '2014-05-05 11:02:17', 32, 1),
(83, '2014-05-05_100003', 'Simple Upload', 'Quotation for Simple Upload', '2014-05-13 13:00:59', '2014-05-05 12:50:58', '2014-05-05 13:30:59', '2014-05-05 14:00:59', '', NULL, 1, '2014-05-05 12:46:49', '2014-05-05 12:46:49', 32, 1),
(84, '2014-05-06_100004', 'Simple Upload', 'Quotation for Electricity', '2014-05-06 11:30:05', '2014-05-06 10:55:05', '2014-05-06 11:20:05', '2014-05-06 11:40:06', '', NULL, 1, '2014-05-06 10:46:44', '2014-05-06 10:46:44', 32, 1),
(85, '2014-05-06_100005', 'Comparative Analysis', 'Comparative Analysis Quotation', '2014-05-06 12:30:49', '2014-05-06 12:10:49', '2014-05-06 13:00:49', '2014-05-06 13:10:49', '', NULL, 15, '2014-05-06 12:00:10', '2014-05-06 12:00:10', 32, 1),
(86, '2014-05-07_100006', 'Comparative Analysis', 'Hydro power Quotation', '2014-05-07 15:40:44', '2014-05-07 15:25:44', '2014-05-07 16:00:44', '2014-05-07 16:10:44', '', NULL, 1, '2014-05-07 15:18:21', '2014-05-07 15:19:04', 32, 1),
(87, '2014-05-08_100007', 'Comparative Analysis', 'Today''s Quotation Test', '2014-05-08 13:45:01', '2014-05-08 13:25:01', '2014-05-08 14:00:01', '2014-05-08 14:15:01', '', NULL, 1, '2014-05-08 13:18:58', '2014-05-08 13:18:58', 32, 1),
(88, '2014-05-08_100008', 'Simple Upload', 'Today''s Quotation for Simple upload', '2014-05-08 15:45:33', '2014-05-08 15:25:32', '2014-05-08 16:00:33', '2014-05-08 16:15:33', '', NULL, 1, '2014-05-08 15:17:44', '2014-05-08 15:17:44', 32, 1),
(89, '2014-05-09_100009', 'Comparative Analysis', 'Quotation for Today', '2014-05-09 14:25:56', '2014-05-09 13:55:56', '2014-05-09 14:30:56', '2014-05-09 14:55:56', '', NULL, 1, '2014-05-09 13:49:45', '2014-05-09 13:49:45', 32, 1),
(90, '2014-05-12_100010', 'Comparative Analysis', 'Testing Quotation ', '2014-05-12 13:55:11', '2014-05-12 13:40:10', '2014-05-12 14:00:11', '2014-05-12 14:10:11', '', NULL, 1, '2014-05-12 13:38:05', '2014-05-12 13:38:17', 32, 1),
(91, '2014-05-13_100011', 'Comparative Analysis', 'Quotation for Suppliers', '2014-05-13 12:50:15', '2014-05-13 12:30:15', '2014-05-13 13:00:15', '2014-05-13 13:10:15', '', NULL, 1, '2014-05-13 12:24:42', '2014-05-13 12:24:42', 32, 1),
(92, '2014-05-13_100012', 'Comparative Analysis', 'Test Quotation', '2014-05-13 13:25:11', '2014-05-13 13:10:11', '2014-05-13 13:30:11', '2014-05-13 13:40:11', '', NULL, 1, '2014-05-13 13:05:58', '2014-05-13 13:05:58', 32, 1),
(93, '2014-05-13_100013', 'Comparative Analysis', 'Test Quotation 1', '2014-05-13 14:10:37', '2014-05-13 13:55:37', '2014-05-13 14:25:37', '2014-05-13 14:30:37', '', NULL, 1, '2014-05-13 13:49:28', '2014-05-13 13:49:28', 32, 1),
(94, '2014-05-14_100014', 'Comparative Analysis', 'Water Quotation', '2014-05-14 11:40:52', '2014-05-14 11:05:52', '2014-05-14 11:35:52', '2014-05-14 12:00:52', '', NULL, 1, '2014-05-14 10:59:22', '2014-05-14 10:59:22', 32, 1),
(95, '2014-05-15_100015', 'Comparative Analysis', 'Quotation for today''s bidding', '2014-05-15 13:05:23', '2014-05-15 12:30:23', '2014-05-15 13:00:23', '2014-05-15 13:15:23', '', NULL, 1, '2014-05-15 12:25:29', '2014-05-15 12:25:29', 32, 1),
(96, '2014-05-16_100016', 'Comparative Analysis', 'Quotation test_1', '2014-05-16 12:00:19', '2014-05-15 01:45:19', '2014-05-16 14:00:19', '2014-05-16 12:30:19', 'Hi!!! This is just a test....', NULL, 1, '2014-05-16 11:57:14', '2014-05-16 11:57:14', 32, 0),
(97, '2014-05-20_100017', 'Comparative Analysis', 'Quotation for Electricity Generation', '2014-05-20 13:15:54', '2014-05-20 12:40:54', '2014-05-20 13:10:54', '2014-05-20 13:20:54', '', NULL, 1, '2014-05-20 12:35:33', '2014-05-20 12:35:33', 32, 1),
(98, '2014-05-21_100018', 'Comparative Analysis', 'Quotation for test bidding', '2014-05-21 16:25:12', '2014-05-21 15:45:12', '2014-05-21 16:20:12', '2014-05-21 16:30:13', '', NULL, 1, '2014-05-21 15:43:42', '2014-05-21 15:43:42', 32, 1),
(99, '2014-05-22_100019', 'Comparative Analysis', 'Supplier''s Quotation', '2014-05-22 12:15:48', '2014-05-22 11:25:48', '2014-05-22 12:00:48', '2014-05-22 12:30:48', '', NULL, 1, '2014-05-22 11:19:00', '2014-05-22 11:19:00', 32, 1),
(100, '2014-05-22_100020', 'Simple Upload', 'Simple Upload Quotation', '2014-05-22 15:05:45', '2014-05-22 14:35:45', '2014-05-22 15:00:45', '2014-05-22 15:10:45', '', NULL, 1, '2014-05-22 14:33:32', '2014-05-22 14:33:32', 32, 1),
(101, '2014-05-26_100021', 'Comparative Analysis', 'Quotation for Comparative Analysis', '2014-05-26 13:40:24', '2014-05-26 12:35:23', '2014-05-26 13:30:24', '2014-05-26 13:50:24', '', NULL, 1, '2014-05-26 12:32:04', '2014-05-26 12:32:21', 32, 1),
(102, '2014-05-27_100022', 'Comparative Analysis', 'Quotation for May', '2014-05-27 13:40:31', '2014-05-27 12:50:31', '2014-05-27 13:30:31', '2014-05-27 13:45:31', '', NULL, 1, '2014-05-27 12:47:00', '2014-05-27 12:47:00', 32, 1);

-- --------------------------------------------------------

--
-- Table structure for table `t_tender_manufacture_products`
--

CREATE TABLE IF NOT EXISTS `t_tender_manufacture_products` (
  `id` int(11) NOT NULL,
  `tender_id` int(11) DEFAULT NULL,
  `manufacture_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `dosage_form_id` int(11) DEFAULT NULL,
  `quantity` float(20,2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3311 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_tender_manufacture_products`
--

INSERT INTO `t_tender_manufacture_products` (`id`, `tender_id`, `manufacture_id`, `product_id`, `dosage_form_id`, `quantity`) VALUES
(2461, 81, 60, 11, NULL, 1000.00),
(2462, 81, 60, 12, NULL, 2000.00),
(2463, 81, 61, 13, NULL, 3000.00),
(2464, 81, 62, 14, NULL, 4000.00),
(2465, 81, 63, 15, NULL, 5000.00),
(2466, 81, 64, 16, NULL, 10000.00),
(2467, 81, 65, 17, NULL, 20000.00),
(2468, 81, 66, 18, NULL, 30000.00),
(2469, 81, 67, 19, NULL, 40000.00),
(2470, 81, 68, 20, NULL, 50000.00),
(2471, 81, 68, 21, NULL, 11111.00),
(2472, 81, 68, 22, NULL, 22222.00),
(2473, 81, 69, 23, NULL, 33333.00),
(2474, 81, 70, 24, NULL, 44444.00),
(2475, 81, 71, 25, NULL, 55555.00),
(2476, 81, 72, 26, NULL, 66666.00),
(2477, 81, 73, 27, NULL, 77777.00),
(2478, 81, 27, 28, NULL, 88888.00),
(2479, 81, 74, 29, NULL, 1200000.00),
(2480, 81, 29, 30, NULL, 123456792.00),
(2481, 81, 30, 31, NULL, 111.00),
(2482, 81, 31, 32, NULL, 22.00),
(2483, 81, 32, 33, NULL, 3.00),
(2484, 81, 33, 34, NULL, 4.00),
(2485, 81, 34, 35, NULL, 5.00),
(2486, 81, 35, 36, NULL, 6.00),
(2487, 81, 36, 37, NULL, 7.00),
(2488, 81, 37, 38, NULL, 8.00),
(2489, 81, 38, 39, NULL, 9.00),
(2490, 81, 75, 40, NULL, 9.00),
(2491, 81, 40, 41, NULL, 132.00),
(2492, 81, 76, 42, NULL, 500.00),
(2493, 81, 76, 43, NULL, 600.00),
(2494, 81, 43, 44, NULL, 6700.00),
(2495, 81, 44, 45, NULL, 87000.00),
(2496, 81, 76, 46, NULL, 7800.00),
(2497, 81, 46, 47, NULL, 56000000.00),
(2498, 81, 47, 48, NULL, 56000.00),
(2499, 81, 48, 49, NULL, 6700.00),
(2500, 81, 49, 50, NULL, 9800.00),
(2501, 81, 77, 51, NULL, 3000.00),
(2502, 81, 77, 52, NULL, 5605600.00),
(2503, 81, 52, 53, NULL, 45000.00),
(2504, 81, 53, 54, NULL, 8000.00),
(2505, 81, 54, 55, NULL, 6000.00),
(2506, 81, 55, 56, NULL, 8000.00),
(2507, 81, 78, 57, NULL, 13000.00),
(2508, 81, 57, 58, NULL, 9000.00),
(2509, 81, 78, 59, NULL, 70000.00),
(2510, 81, 59, 60, NULL, 8888000.00),
(2511, 82, 60, 11, NULL, 1000.00),
(2512, 82, 60, 12, NULL, 2000.00),
(2513, 82, 61, 13, NULL, 3000.00),
(2514, 82, 62, 14, NULL, 4000.00),
(2515, 82, 63, 15, NULL, 5000.00),
(2516, 82, 64, 16, NULL, 10000.00),
(2517, 82, 65, 17, NULL, 20000.00),
(2518, 82, 66, 18, NULL, 30000.00),
(2519, 82, 67, 19, NULL, 40000.00),
(2520, 82, 68, 20, NULL, 50000.00),
(2521, 82, 68, 21, NULL, 11111.00),
(2522, 82, 68, 22, NULL, 22222.00),
(2523, 82, 69, 23, NULL, 33333.00),
(2524, 82, 70, 24, NULL, 44444.00),
(2525, 82, 71, 25, NULL, 55555.00),
(2526, 82, 72, 26, NULL, 66666.00),
(2527, 82, 73, 27, NULL, 77777.00),
(2528, 82, 27, 28, NULL, 88888.00),
(2529, 82, 74, 29, NULL, 1200000.00),
(2530, 82, 29, 30, NULL, 123456792.00),
(2531, 82, 30, 31, NULL, 111.00),
(2532, 82, 31, 32, NULL, 22.00),
(2533, 82, 32, 33, NULL, 3.00),
(2534, 82, 33, 34, NULL, 4.00),
(2535, 82, 34, 35, NULL, 5.00),
(2536, 82, 35, 36, NULL, 6.00),
(2537, 82, 36, 37, NULL, 7.00),
(2538, 82, 37, 38, NULL, 8.00),
(2539, 82, 38, 39, NULL, 9.00),
(2540, 82, 75, 40, NULL, 9.00),
(2541, 82, 40, 41, NULL, 132.00),
(2542, 82, 76, 42, NULL, 500.00),
(2543, 82, 76, 43, NULL, 600.00),
(2544, 82, 43, 44, NULL, 6700.00),
(2545, 82, 44, 45, NULL, 87000.00),
(2546, 82, 76, 46, NULL, 7800.00),
(2547, 82, 46, 47, NULL, 56000000.00),
(2548, 82, 47, 48, NULL, 56000.00),
(2549, 82, 48, 49, NULL, 6700.00),
(2550, 82, 49, 50, NULL, 9800.00),
(2551, 82, 77, 51, NULL, 3000.00),
(2552, 82, 77, 52, NULL, 5605600.00),
(2553, 82, 52, 53, NULL, 45000.00),
(2554, 82, 53, 54, NULL, 8000.00),
(2555, 82, 54, 55, NULL, 6000.00),
(2556, 82, 55, 56, NULL, 8000.00),
(2557, 82, 78, 57, NULL, 13000.00),
(2558, 82, 57, 58, NULL, 9000.00),
(2559, 82, 78, 59, NULL, 70000.00),
(2560, 82, 59, 60, NULL, 8888000.00),
(2561, 85, 60, 11, NULL, 1000.00),
(2562, 85, 60, 12, NULL, 2000.00),
(2563, 85, 61, 13, NULL, 3000.00),
(2564, 85, 62, 14, NULL, 4000.00),
(2565, 85, 63, 15, NULL, 5000.00),
(2566, 85, 64, 16, NULL, 10000.00),
(2567, 85, 65, 17, NULL, 20000.00),
(2568, 85, 66, 18, NULL, 30000.00),
(2569, 85, 67, 19, NULL, 40000.00),
(2570, 85, 68, 20, NULL, 50000.00),
(2571, 85, 68, 21, NULL, 11111.00),
(2572, 85, 68, 22, NULL, 22222.00),
(2573, 85, 69, 23, NULL, 33333.00),
(2574, 85, 70, 24, NULL, 44444.00),
(2575, 85, 71, 25, NULL, 55555.00),
(2576, 85, 72, 26, NULL, 66666.00),
(2577, 85, 73, 27, NULL, 77777.00),
(2578, 85, 27, 28, NULL, 88888.00),
(2579, 85, 74, 29, NULL, 1200000.00),
(2580, 85, 29, 30, NULL, 123456792.00),
(2581, 85, 30, 31, NULL, 111.00),
(2582, 85, 31, 32, NULL, 22.00),
(2583, 85, 32, 33, NULL, 3.00),
(2584, 85, 33, 34, NULL, 4.00),
(2585, 85, 34, 35, NULL, 5.00),
(2586, 85, 35, 36, NULL, 6.00),
(2587, 85, 36, 37, NULL, 7.00),
(2588, 85, 37, 38, NULL, 8.00),
(2589, 85, 38, 39, NULL, 9.00),
(2590, 85, 75, 40, NULL, 9.00),
(2591, 85, 40, 41, NULL, 132.00),
(2592, 85, 76, 42, NULL, 500.00),
(2593, 85, 76, 43, NULL, 600.00),
(2594, 85, 43, 44, NULL, 6700.00),
(2595, 85, 44, 45, NULL, 87000.00),
(2596, 85, 76, 46, NULL, 7800.00),
(2597, 85, 46, 47, NULL, 56000000.00),
(2598, 85, 47, 48, NULL, 56000.00),
(2599, 85, 48, 49, NULL, 6700.00),
(2600, 85, 49, 50, NULL, 9800.00),
(2601, 85, 77, 51, NULL, 3000.00),
(2602, 85, 77, 52, NULL, 5605600.00),
(2603, 85, 52, 53, NULL, 45000.00),
(2604, 85, 53, 54, NULL, 8000.00),
(2605, 85, 54, 55, NULL, 6000.00),
(2606, 85, 55, 56, NULL, 8000.00),
(2607, 85, 78, 57, NULL, 13000.00),
(2608, 85, 57, 58, NULL, 9000.00),
(2609, 85, 78, 59, NULL, 70000.00),
(2610, 85, 59, 60, NULL, 8888000.00),
(2611, 86, 60, 11, NULL, 1000.00),
(2612, 86, 60, 12, NULL, 2000.00),
(2613, 86, 61, 13, NULL, 3000.00),
(2614, 86, 62, 14, NULL, 4000.00),
(2615, 86, 63, 15, NULL, 5000.00),
(2616, 86, 64, 16, NULL, 10000.00),
(2617, 86, 65, 17, NULL, 20000.00),
(2618, 86, 66, 18, NULL, 30000.00),
(2619, 86, 67, 19, NULL, 40000.00),
(2620, 86, 68, 20, NULL, 50000.00),
(2621, 86, 68, 21, NULL, 11111.00),
(2622, 86, 68, 22, NULL, 22222.00),
(2623, 86, 69, 23, NULL, 33333.00),
(2624, 86, 70, 24, NULL, 44444.00),
(2625, 86, 71, 25, NULL, 55555.00),
(2626, 86, 72, 26, NULL, 66666.00),
(2627, 86, 73, 27, NULL, 77777.00),
(2628, 86, 27, 28, NULL, 88888.00),
(2629, 86, 74, 29, NULL, 1200000.00),
(2630, 86, 29, 30, NULL, 123456792.00),
(2631, 86, 30, 31, NULL, 111.00),
(2632, 86, 31, 32, NULL, 22.00),
(2633, 86, 32, 33, NULL, 3.00),
(2634, 86, 33, 34, NULL, 4.00),
(2635, 86, 34, 35, NULL, 5.00),
(2636, 86, 35, 36, NULL, 6.00),
(2637, 86, 36, 37, NULL, 7.00),
(2638, 86, 37, 38, NULL, 8.00),
(2639, 86, 38, 39, NULL, 9.00),
(2640, 86, 75, 40, NULL, 9.00),
(2641, 86, 40, 41, NULL, 132.00),
(2642, 86, 76, 42, NULL, 500.00),
(2643, 86, 76, 43, NULL, 600.00),
(2644, 86, 43, 44, NULL, 6700.00),
(2645, 86, 44, 45, NULL, 87000.00),
(2646, 86, 76, 46, NULL, 7800.00),
(2647, 86, 46, 47, NULL, 56000000.00),
(2648, 86, 47, 48, NULL, 56000.00),
(2649, 86, 48, 49, NULL, 6700.00),
(2650, 86, 49, 50, NULL, 9800.00),
(2651, 86, 77, 51, NULL, 3000.00),
(2652, 86, 77, 52, NULL, 5605600.00),
(2653, 86, 52, 53, NULL, 45000.00),
(2654, 86, 53, 54, NULL, 8000.00),
(2655, 86, 54, 55, NULL, 6000.00),
(2656, 86, 55, 56, NULL, 8000.00),
(2657, 86, 78, 57, NULL, 13000.00),
(2658, 86, 57, 58, NULL, 9000.00),
(2659, 86, 78, 59, NULL, 70000.00),
(2660, 86, 59, 60, NULL, 8888000.00),
(2661, 87, 60, 11, NULL, 1000.00),
(2662, 87, 60, 12, NULL, 2000.00),
(2663, 87, 61, 13, NULL, 3000.00),
(2664, 87, 62, 14, NULL, 4000.00),
(2665, 87, 63, 15, NULL, 5000.00),
(2666, 87, 64, 16, NULL, 10000.00),
(2667, 87, 65, 17, NULL, 20000.00),
(2668, 87, 66, 18, NULL, 30000.00),
(2669, 87, 67, 19, NULL, 40000.00),
(2670, 87, 68, 20, NULL, 50000.00),
(2671, 87, 68, 21, NULL, 11111.00),
(2672, 87, 68, 22, NULL, 22222.00),
(2673, 87, 69, 23, NULL, 33333.00),
(2674, 87, 70, 24, NULL, 44444.00),
(2675, 87, 71, 25, NULL, 55555.00),
(2676, 87, 72, 26, NULL, 66666.00),
(2677, 87, 73, 27, NULL, 77777.00),
(2678, 87, 27, 28, NULL, 88888.00),
(2679, 87, 74, 29, NULL, 1200000.00),
(2680, 87, 29, 30, NULL, 123456792.00),
(2681, 87, 30, 31, NULL, 111.00),
(2682, 87, 31, 32, NULL, 22.00),
(2683, 87, 32, 33, NULL, 3.00),
(2684, 87, 33, 34, NULL, 4.00),
(2685, 87, 34, 35, NULL, 5.00),
(2686, 87, 35, 36, NULL, 6.00),
(2687, 87, 36, 37, NULL, 7.00),
(2688, 87, 37, 38, NULL, 8.00),
(2689, 87, 38, 39, NULL, 9.00),
(2690, 87, 75, 40, NULL, 9.00),
(2691, 87, 40, 41, NULL, 132.00),
(2692, 87, 76, 42, NULL, 500.00),
(2693, 87, 76, 43, NULL, 600.00),
(2694, 87, 43, 44, NULL, 6700.00),
(2695, 87, 44, 45, NULL, 87000.00),
(2696, 87, 76, 46, NULL, 7800.00),
(2697, 87, 46, 47, NULL, 56000000.00),
(2698, 87, 47, 48, NULL, 56000.00),
(2699, 87, 48, 49, NULL, 6700.00),
(2700, 87, 49, 50, NULL, 9800.00),
(2701, 87, 77, 51, NULL, 3000.00),
(2702, 87, 77, 52, NULL, 5605600.00),
(2703, 87, 52, 53, NULL, 45000.00),
(2704, 87, 53, 54, NULL, 8000.00),
(2705, 87, 54, 55, NULL, 6000.00),
(2706, 87, 55, 56, NULL, 8000.00),
(2707, 87, 78, 57, NULL, 13000.00),
(2708, 87, 57, 58, NULL, 9000.00),
(2709, 87, 78, 59, NULL, 70000.00),
(2710, 87, 59, 60, NULL, 8888000.00),
(2711, 89, 60, 11, NULL, 1000.00),
(2712, 89, 60, 12, NULL, 2000.00),
(2713, 89, 61, 13, NULL, 3000.00),
(2714, 89, 62, 14, NULL, 4000.00),
(2715, 89, 63, 15, NULL, 5000.00),
(2716, 89, 64, 16, NULL, 10000.00),
(2717, 89, 65, 17, NULL, 20000.00),
(2718, 89, 66, 18, NULL, 30000.00),
(2719, 89, 67, 19, NULL, 40000.00),
(2720, 89, 68, 20, NULL, 50000.00),
(2721, 89, 68, 21, NULL, 11111.00),
(2722, 89, 68, 22, NULL, 22222.00),
(2723, 89, 69, 23, NULL, 33333.00),
(2724, 89, 70, 24, NULL, 44444.00),
(2725, 89, 71, 25, NULL, 55555.00),
(2726, 89, 72, 26, NULL, 66666.00),
(2727, 89, 73, 27, NULL, 77777.00),
(2728, 89, 27, 28, NULL, 88888.00),
(2729, 89, 74, 29, NULL, 1200000.00),
(2730, 89, 29, 30, NULL, 123456792.00),
(2731, 89, 30, 31, NULL, 111.00),
(2732, 89, 31, 32, NULL, 22.00),
(2733, 89, 32, 33, NULL, 3.00),
(2734, 89, 33, 34, NULL, 4.00),
(2735, 89, 34, 35, NULL, 5.00),
(2736, 89, 35, 36, NULL, 6.00),
(2737, 89, 36, 37, NULL, 7.00),
(2738, 89, 37, 38, NULL, 8.00),
(2739, 89, 38, 39, NULL, 9.00),
(2740, 89, 75, 40, NULL, 9.00),
(2741, 89, 40, 41, NULL, 132.00),
(2742, 89, 76, 42, NULL, 500.00),
(2743, 89, 76, 43, NULL, 600.00),
(2744, 89, 43, 44, NULL, 6700.00),
(2745, 89, 44, 45, NULL, 87000.00),
(2746, 89, 76, 46, NULL, 7800.00),
(2747, 89, 46, 47, NULL, 56000000.00),
(2748, 89, 47, 48, NULL, 56000.00),
(2749, 89, 48, 49, NULL, 6700.00),
(2750, 89, 49, 50, NULL, 9800.00),
(2751, 89, 77, 51, NULL, 3000.00),
(2752, 89, 77, 52, NULL, 5605600.00),
(2753, 89, 52, 53, NULL, 45000.00),
(2754, 89, 53, 54, NULL, 8000.00),
(2755, 89, 54, 55, NULL, 6000.00),
(2756, 89, 55, 56, NULL, 8000.00),
(2757, 89, 78, 57, NULL, 13000.00),
(2758, 89, 57, 58, NULL, 9000.00),
(2759, 89, 78, 59, NULL, 70000.00),
(2760, 89, 59, 60, NULL, 8888000.00),
(2761, 90, 60, 11, NULL, 1000.00),
(2762, 90, 60, 12, NULL, 2000.00),
(2763, 90, 61, 13, NULL, 3000.00),
(2764, 90, 62, 14, NULL, 4000.00),
(2765, 90, 63, 15, NULL, 5000.00),
(2766, 90, 64, 16, NULL, 10000.00),
(2767, 90, 65, 17, NULL, 20000.00),
(2768, 90, 66, 18, NULL, 30000.00),
(2769, 90, 67, 19, NULL, 40000.00),
(2770, 90, 68, 20, NULL, 50000.00),
(2771, 90, 68, 21, NULL, 11111.00),
(2772, 90, 68, 22, NULL, 22222.00),
(2773, 90, 69, 23, NULL, 33333.00),
(2774, 90, 70, 24, NULL, 44444.00),
(2775, 90, 71, 25, NULL, 55555.00),
(2776, 90, 72, 26, NULL, 66666.00),
(2777, 90, 73, 27, NULL, 77777.00),
(2778, 90, 27, 28, NULL, 88888.00),
(2779, 90, 74, 29, NULL, 1200000.00),
(2780, 90, 29, 30, NULL, 123456792.00),
(2781, 90, 30, 31, NULL, 111.00),
(2782, 90, 31, 32, NULL, 22.00),
(2783, 90, 32, 33, NULL, 3.00),
(2784, 90, 33, 34, NULL, 4.00),
(2785, 90, 34, 35, NULL, 5.00),
(2786, 90, 35, 36, NULL, 6.00),
(2787, 90, 36, 37, NULL, 7.00),
(2788, 90, 37, 38, NULL, 8.00),
(2789, 90, 38, 39, NULL, 9.00),
(2790, 90, 75, 40, NULL, 9.00),
(2791, 90, 40, 41, NULL, 132.00),
(2792, 90, 76, 42, NULL, 500.00),
(2793, 90, 76, 43, NULL, 600.00),
(2794, 90, 43, 44, NULL, 6700.00),
(2795, 90, 44, 45, NULL, 87000.00),
(2796, 90, 76, 46, NULL, 7800.00),
(2797, 90, 46, 47, NULL, 56000000.00),
(2798, 90, 47, 48, NULL, 56000.00),
(2799, 90, 48, 49, NULL, 6700.00),
(2800, 90, 49, 50, NULL, 9800.00),
(2801, 90, 77, 51, NULL, 3000.00),
(2802, 90, 77, 52, NULL, 5605600.00),
(2803, 90, 52, 53, NULL, 45000.00),
(2804, 90, 53, 54, NULL, 8000.00),
(2805, 90, 54, 55, NULL, 6000.00),
(2806, 90, 55, 56, NULL, 8000.00),
(2807, 90, 78, 57, NULL, 13000.00),
(2808, 90, 57, 58, NULL, 9000.00),
(2809, 90, 78, 59, NULL, 70000.00),
(2810, 90, 59, 60, NULL, 8888000.00),
(2811, 91, 60, 11, NULL, 1000.00),
(2812, 91, 60, 12, NULL, 2000.00),
(2813, 91, 61, 13, NULL, 3000.00),
(2814, 91, 62, 14, NULL, 4000.00),
(2815, 91, 63, 15, NULL, 5000.00),
(2816, 91, 64, 16, NULL, 10000.00),
(2817, 91, 65, 17, NULL, 20000.00),
(2818, 91, 66, 18, NULL, 30000.00),
(2819, 91, 67, 19, NULL, 40000.00),
(2820, 91, 68, 20, NULL, 50000.00),
(2821, 91, 68, 21, NULL, 11111.00),
(2822, 91, 68, 22, NULL, 22222.00),
(2823, 91, 69, 23, NULL, 33333.00),
(2824, 91, 70, 24, NULL, 44444.00),
(2825, 91, 71, 25, NULL, 55555.00),
(2826, 91, 72, 26, NULL, 66666.00),
(2827, 91, 73, 27, NULL, 77777.00),
(2828, 91, 27, 28, NULL, 88888.00),
(2829, 91, 74, 29, NULL, 1200000.00),
(2830, 91, 29, 30, NULL, 123456792.00),
(2831, 91, 30, 31, NULL, 111.00),
(2832, 91, 31, 32, NULL, 22.00),
(2833, 91, 32, 33, NULL, 3.00),
(2834, 91, 33, 34, NULL, 4.00),
(2835, 91, 34, 35, NULL, 5.00),
(2836, 91, 35, 36, NULL, 6.00),
(2837, 91, 36, 37, NULL, 7.00),
(2838, 91, 37, 38, NULL, 8.00),
(2839, 91, 38, 39, NULL, 9.00),
(2840, 91, 75, 40, NULL, 9.00),
(2841, 91, 40, 41, NULL, 132.00),
(2842, 91, 76, 42, NULL, 500.00),
(2843, 91, 76, 43, NULL, 600.00),
(2844, 91, 43, 44, NULL, 6700.00),
(2845, 91, 44, 45, NULL, 87000.00),
(2846, 91, 76, 46, NULL, 7800.00),
(2847, 91, 46, 47, NULL, 56000000.00),
(2848, 91, 47, 48, NULL, 56000.00),
(2849, 91, 48, 49, NULL, 6700.00),
(2850, 91, 49, 50, NULL, 9800.00),
(2851, 91, 77, 51, NULL, 3000.00),
(2852, 91, 77, 52, NULL, 5605600.00),
(2853, 91, 52, 53, NULL, 45000.00),
(2854, 91, 53, 54, NULL, 8000.00),
(2855, 91, 54, 55, NULL, 6000.00),
(2856, 91, 55, 56, NULL, 8000.00),
(2857, 91, 78, 57, NULL, 13000.00),
(2858, 91, 57, 58, NULL, 9000.00),
(2859, 91, 78, 59, NULL, 70000.00),
(2860, 91, 59, 60, NULL, 8888000.00),
(2861, 92, 60, 11, NULL, 1000.00),
(2862, 92, 60, 12, NULL, 2000.00),
(2863, 92, 61, 13, NULL, 3000.00),
(2864, 92, 62, 14, NULL, 4000.00),
(2865, 92, 63, 15, NULL, 5000.00),
(2866, 92, 64, 16, NULL, 10000.00),
(2867, 92, 65, 17, NULL, 20000.00),
(2868, 92, 66, 18, NULL, 30000.00),
(2869, 92, 67, 19, NULL, 40000.00),
(2870, 92, 68, 20, NULL, 50000.00),
(2871, 92, 68, 21, NULL, 11111.00),
(2872, 92, 68, 22, NULL, 22222.00),
(2873, 92, 69, 23, NULL, 33333.00),
(2874, 92, 70, 24, NULL, 44444.00),
(2875, 92, 71, 25, NULL, 55555.00),
(2876, 92, 72, 26, NULL, 66666.00),
(2877, 92, 73, 27, NULL, 77777.00),
(2878, 92, 27, 28, NULL, 88888.00),
(2879, 92, 74, 29, NULL, 1200000.00),
(2880, 92, 29, 30, NULL, 123456792.00),
(2881, 92, 30, 31, NULL, 111.00),
(2882, 92, 31, 32, NULL, 22.00),
(2883, 92, 32, 33, NULL, 3.00),
(2884, 92, 33, 34, NULL, 4.00),
(2885, 92, 34, 35, NULL, 5.00),
(2886, 92, 35, 36, NULL, 6.00),
(2887, 92, 36, 37, NULL, 7.00),
(2888, 92, 37, 38, NULL, 8.00),
(2889, 92, 38, 39, NULL, 9.00),
(2890, 92, 75, 40, NULL, 9.00),
(2891, 92, 40, 41, NULL, 132.00),
(2892, 92, 76, 42, NULL, 500.00),
(2893, 92, 76, 43, NULL, 600.00),
(2894, 92, 43, 44, NULL, 6700.00),
(2895, 92, 44, 45, NULL, 87000.00),
(2896, 92, 76, 46, NULL, 7800.00),
(2897, 92, 46, 47, NULL, 56000000.00),
(2898, 92, 47, 48, NULL, 56000.00),
(2899, 92, 48, 49, NULL, 6700.00),
(2900, 92, 49, 50, NULL, 9800.00),
(2901, 92, 77, 51, NULL, 3000.00),
(2902, 92, 77, 52, NULL, 5605600.00),
(2903, 92, 52, 53, NULL, 45000.00),
(2904, 92, 53, 54, NULL, 8000.00),
(2905, 92, 54, 55, NULL, 6000.00),
(2906, 92, 55, 56, NULL, 8000.00),
(2907, 92, 78, 57, NULL, 13000.00),
(2908, 92, 57, 58, NULL, 9000.00),
(2909, 92, 78, 59, NULL, 70000.00),
(2910, 92, 59, 60, NULL, 8888000.00),
(2911, 93, 60, 11, NULL, 1000.00),
(2912, 93, 60, 12, NULL, 2000.00),
(2913, 93, 61, 13, NULL, 3000.00),
(2914, 93, 62, 14, NULL, 4000.00),
(2915, 93, 63, 15, NULL, 5000.00),
(2916, 93, 64, 16, NULL, 10000.00),
(2917, 93, 65, 17, NULL, 20000.00),
(2918, 93, 66, 18, NULL, 30000.00),
(2919, 93, 67, 19, NULL, 40000.00),
(2920, 93, 68, 20, NULL, 50000.00),
(2921, 93, 68, 21, NULL, 11111.00),
(2922, 93, 68, 22, NULL, 22222.00),
(2923, 93, 69, 23, NULL, 33333.00),
(2924, 93, 70, 24, NULL, 44444.00),
(2925, 93, 71, 25, NULL, 55555.00),
(2926, 93, 72, 26, NULL, 66666.00),
(2927, 93, 73, 27, NULL, 77777.00),
(2928, 93, 27, 28, NULL, 88888.00),
(2929, 93, 74, 29, NULL, 1200000.00),
(2930, 93, 29, 30, NULL, 123456792.00),
(2931, 93, 30, 31, NULL, 111.00),
(2932, 93, 31, 32, NULL, 22.00),
(2933, 93, 32, 33, NULL, 3.00),
(2934, 93, 33, 34, NULL, 4.00),
(2935, 93, 34, 35, NULL, 5.00),
(2936, 93, 35, 36, NULL, 6.00),
(2937, 93, 36, 37, NULL, 7.00),
(2938, 93, 37, 38, NULL, 8.00),
(2939, 93, 38, 39, NULL, 9.00),
(2940, 93, 75, 40, NULL, 9.00),
(2941, 93, 40, 41, NULL, 132.00),
(2942, 93, 76, 42, NULL, 500.00),
(2943, 93, 76, 43, NULL, 600.00),
(2944, 93, 43, 44, NULL, 6700.00),
(2945, 93, 44, 45, NULL, 87000.00),
(2946, 93, 76, 46, NULL, 7800.00),
(2947, 93, 46, 47, NULL, 56000000.00),
(2948, 93, 47, 48, NULL, 56000.00),
(2949, 93, 48, 49, NULL, 6700.00),
(2950, 93, 49, 50, NULL, 9800.00),
(2951, 93, 77, 51, NULL, 3000.00),
(2952, 93, 77, 52, NULL, 5605600.00),
(2953, 93, 52, 53, NULL, 45000.00),
(2954, 93, 53, 54, NULL, 8000.00),
(2955, 93, 54, 55, NULL, 6000.00),
(2956, 93, 55, 56, NULL, 8000.00),
(2957, 93, 78, 57, NULL, 13000.00),
(2958, 93, 57, 58, NULL, 9000.00),
(2959, 93, 78, 59, NULL, 70000.00),
(2960, 93, 59, 60, NULL, 8888000.00),
(2961, 94, 60, 11, NULL, 1000.00),
(2962, 94, 60, 12, NULL, 2000.00),
(2963, 94, 61, 13, NULL, 3000.00),
(2964, 94, 62, 14, NULL, 4000.00),
(2965, 94, 63, 15, NULL, 5000.00),
(2966, 94, 64, 16, NULL, 10000.00),
(2967, 94, 65, 17, NULL, 20000.00),
(2968, 94, 66, 18, NULL, 30000.00),
(2969, 94, 67, 19, NULL, 40000.00),
(2970, 94, 68, 20, NULL, 50000.00),
(2971, 94, 68, 21, NULL, 11111.00),
(2972, 94, 68, 22, NULL, 22222.00),
(2973, 94, 69, 23, NULL, 33333.00),
(2974, 94, 70, 24, NULL, 44444.00),
(2975, 94, 71, 25, NULL, 55555.00),
(2976, 94, 72, 26, NULL, 66666.00),
(2977, 94, 73, 27, NULL, 77777.00),
(2978, 94, 27, 28, NULL, 88888.00),
(2979, 94, 74, 29, NULL, 1200000.00),
(2980, 94, 29, 30, NULL, 123456792.00),
(2981, 94, 30, 31, NULL, 111.00),
(2982, 94, 31, 32, NULL, 22.00),
(2983, 94, 32, 33, NULL, 3.00),
(2984, 94, 33, 34, NULL, 4.00),
(2985, 94, 34, 35, NULL, 5.00),
(2986, 94, 35, 36, NULL, 6.00),
(2987, 94, 36, 37, NULL, 7.00),
(2988, 94, 37, 38, NULL, 8.00),
(2989, 94, 38, 39, NULL, 9.00),
(2990, 94, 75, 40, NULL, 9.00),
(2991, 94, 40, 41, NULL, 132.00),
(2992, 94, 76, 42, NULL, 500.00),
(2993, 94, 76, 43, NULL, 600.00),
(2994, 94, 43, 44, NULL, 6700.00),
(2995, 94, 44, 45, NULL, 87000.00),
(2996, 94, 76, 46, NULL, 7800.00),
(2997, 94, 46, 47, NULL, 56000000.00),
(2998, 94, 47, 48, NULL, 56000.00),
(2999, 94, 48, 49, NULL, 6700.00),
(3000, 94, 49, 50, NULL, 9800.00),
(3001, 94, 77, 51, NULL, 3000.00),
(3002, 94, 77, 52, NULL, 5605600.00),
(3003, 94, 52, 53, NULL, 45000.00),
(3004, 94, 53, 54, NULL, 8000.00),
(3005, 94, 54, 55, NULL, 6000.00),
(3006, 94, 55, 56, NULL, 8000.00),
(3007, 94, 78, 57, NULL, 13000.00),
(3008, 94, 57, 58, NULL, 9000.00),
(3009, 94, 78, 59, NULL, 70000.00),
(3010, 94, 59, 60, NULL, 8888000.00),
(3011, 95, 60, 11, NULL, 1000.00),
(3012, 95, 60, 12, NULL, 2000.00),
(3013, 95, 61, 13, NULL, 3000.00),
(3014, 95, 62, 14, NULL, 4000.00),
(3015, 95, 63, 15, NULL, 5000.00),
(3016, 95, 64, 16, NULL, 10000.00),
(3017, 95, 65, 17, NULL, 20000.00),
(3018, 95, 66, 18, NULL, 30000.00),
(3019, 95, 67, 19, NULL, 40000.00),
(3020, 95, 68, 20, NULL, 50000.00),
(3021, 95, 68, 21, NULL, 11111.00),
(3022, 95, 68, 22, NULL, 22222.00),
(3023, 95, 69, 23, NULL, 33333.00),
(3024, 95, 70, 24, NULL, 44444.00),
(3025, 95, 71, 25, NULL, 55555.00),
(3026, 95, 72, 26, NULL, 66666.00),
(3027, 95, 73, 27, NULL, 77777.00),
(3028, 95, 27, 28, NULL, 88888.00),
(3029, 95, 74, 29, NULL, 1200000.00),
(3030, 95, 29, 30, NULL, 123456792.00),
(3031, 95, 30, 31, NULL, 111.00),
(3032, 95, 31, 32, NULL, 22.00),
(3033, 95, 32, 33, NULL, 3.00),
(3034, 95, 33, 34, NULL, 4.00),
(3035, 95, 34, 35, NULL, 5.00),
(3036, 95, 35, 36, NULL, 6.00),
(3037, 95, 36, 37, NULL, 7.00),
(3038, 95, 37, 38, NULL, 8.00),
(3039, 95, 38, 39, NULL, 9.00),
(3040, 95, 75, 40, NULL, 9.00),
(3041, 95, 40, 41, NULL, 132.00),
(3042, 95, 76, 42, NULL, 500.00),
(3043, 95, 76, 43, NULL, 600.00),
(3044, 95, 43, 44, NULL, 6700.00),
(3045, 95, 44, 45, NULL, 87000.00),
(3046, 95, 76, 46, NULL, 7800.00),
(3047, 95, 46, 47, NULL, 56000000.00),
(3048, 95, 47, 48, NULL, 56000.00),
(3049, 95, 48, 49, NULL, 6700.00),
(3050, 95, 49, 50, NULL, 9800.00),
(3051, 95, 77, 51, NULL, 3000.00),
(3052, 95, 77, 52, NULL, 5605600.00),
(3053, 95, 52, 53, NULL, 45000.00),
(3054, 95, 53, 54, NULL, 8000.00),
(3055, 95, 54, 55, NULL, 6000.00),
(3056, 95, 55, 56, NULL, 8000.00),
(3057, 95, 78, 57, NULL, 13000.00),
(3058, 95, 57, 58, NULL, 9000.00),
(3059, 95, 78, 59, NULL, 70000.00),
(3060, 95, 59, 60, NULL, 8888000.00),
(3061, 96, 60, 11, NULL, 1000.00),
(3062, 96, 60, 12, NULL, 2000.00),
(3063, 96, 61, 13, NULL, 3000.00),
(3064, 96, 62, 14, NULL, 4000.00),
(3065, 96, 63, 15, NULL, 5000.00),
(3066, 96, 64, 16, NULL, 10000.00),
(3067, 96, 65, 17, NULL, 20000.00),
(3068, 96, 66, 18, NULL, 30000.00),
(3069, 96, 67, 19, NULL, 40000.00),
(3070, 96, 68, 20, NULL, 50000.00),
(3071, 96, 68, 21, NULL, 11111.00),
(3072, 96, 68, 22, NULL, 22222.00),
(3073, 96, 69, 23, NULL, 33333.00),
(3074, 96, 70, 24, NULL, 44444.00),
(3075, 96, 71, 25, NULL, 55555.00),
(3076, 96, 72, 26, NULL, 66666.00),
(3077, 96, 73, 27, NULL, 77777.00),
(3078, 96, 27, 28, NULL, 88888.00),
(3079, 96, 74, 29, NULL, 1200000.00),
(3080, 96, 29, 30, NULL, 123456792.00),
(3081, 96, 30, 31, NULL, 111.00),
(3082, 96, 31, 32, NULL, 22.00),
(3083, 96, 32, 33, NULL, 3.00),
(3084, 96, 33, 34, NULL, 4.00),
(3085, 96, 34, 35, NULL, 5.00),
(3086, 96, 35, 36, NULL, 6.00),
(3087, 96, 36, 37, NULL, 7.00),
(3088, 96, 37, 38, NULL, 8.00),
(3089, 96, 38, 39, NULL, 9.00),
(3090, 96, 75, 40, NULL, 9.00),
(3091, 96, 40, 41, NULL, 132.00),
(3092, 96, 76, 42, NULL, 500.00),
(3093, 96, 76, 43, NULL, 600.00),
(3094, 96, 43, 44, NULL, 6700.00),
(3095, 96, 44, 45, NULL, 87000.00),
(3096, 96, 76, 46, NULL, 7800.00),
(3097, 96, 46, 47, NULL, 56000000.00),
(3098, 96, 47, 48, NULL, 56000.00),
(3099, 96, 48, 49, NULL, 6700.00),
(3100, 96, 49, 50, NULL, 9800.00),
(3101, 96, 77, 51, NULL, 3000.00),
(3102, 96, 77, 52, NULL, 5605600.00),
(3103, 96, 52, 53, NULL, 45000.00),
(3104, 96, 53, 54, NULL, 8000.00),
(3105, 96, 54, 55, NULL, 6000.00),
(3106, 96, 55, 56, NULL, 8000.00),
(3107, 96, 78, 57, NULL, 13000.00),
(3108, 96, 57, 58, NULL, 9000.00),
(3109, 96, 78, 59, NULL, 70000.00),
(3110, 96, 59, 60, NULL, 8888000.00),
(3111, 97, 60, 11, NULL, 1000.00),
(3112, 97, 60, 12, NULL, 2000.00),
(3113, 97, 61, 13, NULL, 3000.00),
(3114, 97, 62, 14, NULL, 4000.00),
(3115, 97, 63, 15, NULL, 5000.00),
(3116, 97, 64, 16, NULL, 10000.00),
(3117, 97, 65, 17, NULL, 20000.00),
(3118, 97, 66, 18, NULL, 30000.00),
(3119, 97, 67, 19, NULL, 40000.00),
(3120, 97, 68, 20, NULL, 50000.00),
(3121, 97, 68, 21, NULL, 11111.00),
(3122, 97, 68, 22, NULL, 22222.00),
(3123, 97, 69, 23, NULL, 33333.00),
(3124, 97, 70, 24, NULL, 44444.00),
(3125, 97, 71, 25, NULL, 55555.00),
(3126, 97, 72, 26, NULL, 66666.00),
(3127, 97, 73, 27, NULL, 77777.00),
(3128, 97, 27, 28, NULL, 88888.00),
(3129, 97, 74, 29, NULL, 1200000.00),
(3130, 97, 29, 30, NULL, 123456792.00),
(3131, 97, 30, 31, NULL, 111.00),
(3132, 97, 31, 32, NULL, 22.00),
(3133, 97, 32, 33, NULL, 3.00),
(3134, 97, 33, 34, NULL, 4.00),
(3135, 97, 34, 35, NULL, 5.00),
(3136, 97, 35, 36, NULL, 6.00),
(3137, 97, 36, 37, NULL, 7.00),
(3138, 97, 37, 38, NULL, 8.00),
(3139, 97, 38, 39, NULL, 9.00),
(3140, 97, 75, 40, NULL, 9.00),
(3141, 97, 40, 41, NULL, 132.00),
(3142, 97, 76, 42, NULL, 500.00),
(3143, 97, 76, 43, NULL, 600.00),
(3144, 97, 43, 44, NULL, 6700.00),
(3145, 97, 44, 45, NULL, 87000.00),
(3146, 97, 76, 46, NULL, 7800.00),
(3147, 97, 46, 47, NULL, 56000000.00),
(3148, 97, 47, 48, NULL, 56000.00),
(3149, 97, 48, 49, NULL, 6700.00),
(3150, 97, 49, 50, NULL, 9800.00),
(3151, 97, 77, 51, NULL, 3000.00),
(3152, 97, 77, 52, NULL, 5605600.00),
(3153, 97, 52, 53, NULL, 45000.00),
(3154, 97, 53, 54, NULL, 8000.00),
(3155, 97, 54, 55, NULL, 6000.00),
(3156, 97, 55, 56, NULL, 8000.00),
(3157, 97, 78, 57, NULL, 13000.00),
(3158, 97, 57, 58, NULL, 9000.00),
(3159, 97, 78, 59, NULL, 70000.00),
(3160, 97, 59, 60, NULL, 8888000.00),
(3161, 99, 60, 11, NULL, 1000.00),
(3162, 99, 60, 12, NULL, 2000.00),
(3163, 99, 61, 13, NULL, 3000.00),
(3164, 99, 62, 14, NULL, 4000.00),
(3165, 99, 63, 15, NULL, 5000.00),
(3166, 99, 64, 16, NULL, 10000.00),
(3167, 99, 65, 17, NULL, 20000.00),
(3168, 99, 66, 18, NULL, 30000.00),
(3169, 99, 67, 19, NULL, 40000.00),
(3170, 99, 68, 20, NULL, 50000.00),
(3171, 99, 68, 21, NULL, 11111.00),
(3172, 99, 68, 22, NULL, 22222.00),
(3173, 99, 69, 23, NULL, 33333.00),
(3174, 99, 70, 24, NULL, 44444.00),
(3175, 99, 71, 25, NULL, 55555.00),
(3176, 99, 72, 26, NULL, 66666.00),
(3177, 99, 73, 27, NULL, 77777.00),
(3178, 99, 27, 28, NULL, 88888.00),
(3179, 99, 74, 29, NULL, 1200000.00),
(3180, 99, 29, 30, NULL, 123456792.00),
(3181, 99, 30, 31, NULL, 111.00),
(3182, 99, 31, 32, NULL, 22.00),
(3183, 99, 32, 33, NULL, 3.00),
(3184, 99, 33, 34, NULL, 4.00),
(3185, 99, 34, 35, NULL, 5.00),
(3186, 99, 35, 36, NULL, 6.00),
(3187, 99, 36, 37, NULL, 7.00),
(3188, 99, 37, 38, NULL, 8.00),
(3189, 99, 38, 39, NULL, 9.00),
(3190, 99, 75, 40, NULL, 9.00),
(3191, 99, 40, 41, NULL, 132.00),
(3192, 99, 76, 42, NULL, 500.00),
(3193, 99, 76, 43, NULL, 600.00),
(3194, 99, 43, 44, NULL, 6700.00),
(3195, 99, 44, 45, NULL, 87000.00),
(3196, 99, 76, 46, NULL, 7800.00),
(3197, 99, 46, 47, NULL, 56000000.00),
(3198, 99, 47, 48, NULL, 56000.00),
(3199, 99, 48, 49, NULL, 6700.00),
(3200, 99, 49, 50, NULL, 9800.00),
(3201, 99, 77, 51, NULL, 3000.00),
(3202, 99, 77, 52, NULL, 5605600.00),
(3203, 99, 52, 53, NULL, 45000.00),
(3204, 99, 53, 54, NULL, 8000.00),
(3205, 99, 54, 55, NULL, 6000.00),
(3206, 99, 55, 56, NULL, 8000.00),
(3207, 99, 78, 57, NULL, 13000.00),
(3208, 99, 57, 58, NULL, 9000.00),
(3209, 99, 78, 59, NULL, 70000.00),
(3210, 99, 59, 60, NULL, 8888000.00),
(3211, 101, 60, 11, NULL, 1000.00),
(3212, 101, 60, 12, NULL, 2000.00),
(3213, 101, 61, 13, NULL, 3000.00),
(3214, 101, 62, 14, NULL, 4000.00),
(3215, 101, 63, 15, NULL, 5000.00),
(3216, 101, 64, 16, NULL, 10000.00),
(3217, 101, 65, 17, NULL, 20000.00),
(3218, 101, 66, 18, NULL, 30000.00),
(3219, 101, 67, 19, NULL, 40000.00),
(3220, 101, 68, 20, NULL, 50000.00),
(3221, 101, 68, 21, NULL, 11111.00),
(3222, 101, 68, 22, NULL, 22222.00),
(3223, 101, 69, 23, NULL, 33333.00),
(3224, 101, 70, 24, NULL, 44444.00),
(3225, 101, 71, 25, NULL, 55555.00),
(3226, 101, 72, 26, NULL, 66666.00),
(3227, 101, 73, 27, NULL, 77777.00),
(3228, 101, 27, 28, NULL, 88888.00),
(3229, 101, 74, 29, NULL, 1200000.00),
(3230, 101, 29, 30, NULL, 123456792.00),
(3231, 101, 30, 31, NULL, 111.00),
(3232, 101, 31, 32, NULL, 22.00),
(3233, 101, 32, 33, NULL, 3.00),
(3234, 101, 33, 34, NULL, 4.00),
(3235, 101, 34, 35, NULL, 5.00),
(3236, 101, 35, 36, NULL, 6.00),
(3237, 101, 36, 37, NULL, 7.00),
(3238, 101, 37, 38, NULL, 8.00),
(3239, 101, 38, 39, NULL, 9.00),
(3240, 101, 75, 40, NULL, 9.00),
(3241, 101, 40, 41, NULL, 132.00),
(3242, 101, 76, 42, NULL, 500.00),
(3243, 101, 76, 43, NULL, 600.00),
(3244, 101, 43, 44, NULL, 6700.00),
(3245, 101, 44, 45, NULL, 87000.00),
(3246, 101, 76, 46, NULL, 7800.00),
(3247, 101, 46, 47, NULL, 56000000.00),
(3248, 101, 47, 48, NULL, 56000.00),
(3249, 101, 48, 49, NULL, 6700.00),
(3250, 101, 49, 50, NULL, 9800.00),
(3251, 101, 77, 51, NULL, 3000.00),
(3252, 101, 77, 52, NULL, 5605600.00),
(3253, 101, 52, 53, NULL, 45000.00),
(3254, 101, 53, 54, NULL, 8000.00),
(3255, 101, 54, 55, NULL, 6000.00),
(3256, 101, 55, 56, NULL, 8000.00),
(3257, 101, 78, 57, NULL, 13000.00),
(3258, 101, 57, 58, NULL, 9000.00),
(3259, 101, 78, 59, NULL, 70000.00),
(3260, 101, 59, 60, NULL, 8888000.00),
(3261, 102, 60, 11, NULL, 1000.00),
(3262, 102, 60, 12, NULL, 2000.00),
(3263, 102, 61, 13, NULL, 3000.00),
(3264, 102, 62, 14, NULL, 4000.00),
(3265, 102, 63, 15, NULL, 5000.00),
(3266, 102, 64, 16, NULL, 10000.00),
(3267, 102, 65, 17, NULL, 20000.00),
(3268, 102, 66, 18, NULL, 30000.00),
(3269, 102, 67, 19, NULL, 40000.00),
(3270, 102, 68, 20, NULL, 50000.00),
(3271, 102, 68, 21, NULL, 11111.00),
(3272, 102, 68, 22, NULL, 22222.00),
(3273, 102, 69, 23, NULL, 33333.00),
(3274, 102, 70, 24, NULL, 44444.00),
(3275, 102, 71, 25, NULL, 55555.00),
(3276, 102, 72, 26, NULL, 66666.00),
(3277, 102, 73, 27, NULL, 77777.00),
(3278, 102, 27, 28, NULL, 88888.00),
(3279, 102, 74, 29, NULL, 1200000.00),
(3280, 102, 29, 30, NULL, 123456792.00),
(3281, 102, 30, 31, NULL, 111.00),
(3282, 102, 31, 32, NULL, 22.00),
(3283, 102, 32, 33, NULL, 3.00),
(3284, 102, 33, 34, NULL, 4.00),
(3285, 102, 34, 35, NULL, 5.00),
(3286, 102, 35, 36, NULL, 6.00),
(3287, 102, 36, 37, NULL, 7.00),
(3288, 102, 37, 38, NULL, 8.00),
(3289, 102, 38, 39, NULL, 9.00),
(3290, 102, 75, 40, NULL, 9.00),
(3291, 102, 40, 41, NULL, 132.00),
(3292, 102, 76, 42, NULL, 500.00),
(3293, 102, 76, 43, NULL, 600.00),
(3294, 102, 43, 44, NULL, 6700.00),
(3295, 102, 44, 45, NULL, 87000.00),
(3296, 102, 76, 46, NULL, 7800.00),
(3297, 102, 46, 47, NULL, 56000000.00),
(3298, 102, 47, 48, NULL, 56000.00),
(3299, 102, 48, 49, NULL, 6700.00),
(3300, 102, 49, 50, NULL, 9800.00),
(3301, 102, 77, 51, NULL, 3000.00),
(3302, 102, 77, 52, NULL, 5605600.00),
(3303, 102, 52, 53, NULL, 45000.00),
(3304, 102, 53, 54, NULL, 8000.00),
(3305, 102, 54, 55, NULL, 6000.00),
(3306, 102, 55, 56, NULL, 8000.00),
(3307, 102, 78, 57, NULL, 13000.00),
(3308, 102, 57, 58, NULL, 9000.00),
(3309, 102, 78, 59, NULL, 70000.00),
(3310, 102, 59, 60, NULL, 8888000.00);

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(11) NOT NULL,
  `model` varchar(25) DEFAULT NULL,
  `field` varchar(25) DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `doc_type` varchar(100) DEFAULT NULL,
  `size` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=319 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`id`, `model`, `field`, `foreign_key`, `caption`, `name`, `type`, `doc_type`, `size`) VALUES
(292, 'Tender', 'TenderDoc', 81, '', 'images-3.jpg', 'image/jpeg', NULL, 11194),
(293, 'Request', 'RequestDoc', 2, '', 'images-2.jpg', 'image/jpeg', 'VAT / PAN', 8287),
(294, 'Tender', 'TenderDoc', 83, '', 'images-2.jpg', 'image/jpeg', NULL, 8287),
(295, 'Request', 'RequestDoc', 3, '', 'images-3.jpg', 'image/jpeg', 'License', 11194),
(296, 'Request', 'RequestDoc', 4, '', 'usa-region.jpg', 'image/jpeg', 'License', 46782),
(297, 'Request', 'RequestDoc', 4, '', 'usamap1.png', 'image/png', 'Tax Registration', 42098),
(298, 'Request', 'RequestDoc', 3, 'Doc 1', '1256.ppt', 'application/vnd.ms-powerpoint', 'Bidding Document', 912384),
(299, 'Request', 'RequestDoc', 3, 'Doc 2', '1256.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'Bidding Document', 53466),
(300, 'Request', 'RequestDoc', 4, 'Sahil', 'himalaya-sunrise.jpg', 'image/jpeg', 'Bidding Document', 2352331),
(301, 'Tender', 'TenderDoc', 84, '', 'sample-1.jpg', 'image/jpeg', NULL, 31372),
(302, 'Request', 'RequestDoc', 6, '', '1256.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'Tax Clearance', 53466),
(303, 'Request', 'RequestDoc', 6, '', '1256.ppt', 'application/vnd.ms-powerpoint', 'VAT / PAN', 912384),
(304, 'Request', 'RequestDoc', 5, '', '1256.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'VAT / PAN', 12980),
(305, 'Request', 'RequestDoc', 5, '', '1256.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'Tax Clearance', 53466),
(306, 'Request', 'RequestDoc', 5, 'Doc 1', 'agreementletter.pdf', 'application/pdf', 'Bidding Document', 100600),
(307, 'Request', 'RequestDoc', 5, 'Doc 2', 'craftyhand.png', 'image/png', 'Bidding Document', 1002841),
(308, 'Request', 'RequestDoc', 6, 'Test 1', 'download-1.jpg', 'image/jpeg', 'Bidding Document', 16922),
(309, 'Request', 'RequestDoc', 6, 'test 2', 'oops.png', 'image/png', 'Bidding Document', 146956),
(310, 'Tender', 'TenderDoc', 87, '', 'download-1.jpg', 'image/jpeg', NULL, 16922),
(311, 'Request', 'RequestDoc', 13, 'doc 1', '1256.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'Bidding Document', 53466),
(312, 'Request', 'RequestDoc', 13, 'Doc 2', '1256.ppt', 'application/vnd.ms-powerpoint', 'Bidding Document', 912384),
(313, 'Request', 'RequestDoc', 14, 'Test 1', '1256.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Bidding Document', 12980),
(314, 'Tender', 'TenderDoc', 97, '', '1256.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, 53466),
(315, 'Tender', 'TenderDoc', 99, '', '1256.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, 53466),
(316, 'Request', 'RequestDoc', 29, '', '1256.ppt', 'application/vnd.ms-powerpoint', 'Tax Registration', 912384),
(317, 'Request', 'RequestDoc', 28, '', '1256.pdf', 'application/pdf', 'Tax Registration', 278262),
(318, 'Request', 'RequestDoc', 30, 'Test 1', 'download-2.jpg', 'image/jpeg', 'Bidding Document', 6720);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `business_id` int(11) DEFAULT NULL,
  `name` varchar(139) DEFAULT NULL,
  `password` varchar(40) NOT NULL,
  `username` varchar(139) DEFAULT NULL,
  `business_approval_pending` int(11) NOT NULL DEFAULT '0',
  `url` varchar(139) DEFAULT NULL,
  `gender` smallint(1) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `login_ip` varchar(25) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `date_added` datetime DEFAULT NULL,
  `signup_ip` varchar(25) DEFAULT NULL,
  `pass_session` varchar(40) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `business_id`, `name`, `password`, `username`, `business_approval_pending`, `url`, `gender`, `date_of_birth`, `last_login`, `login_ip`, `role_id`, `status_id`, `date_added`, `signup_ip`, `pass_session`) VALUES
(1, NULL, 'HT Admin', '1d4c478b4c3d1b77e42ac22c8715bd047c8b2753', 'htadmin', 0, 'htadmin', 2, '1970-08-20', '2015-03-25 16:43:49', '110.44.118.6', 1, 6, '2013-08-20 16:13:20', '110.34.4.243', NULL),
(100, NULL, 'Staff Testing', '3744d1f938f09c9f8d93a19f3d2a4d0ac65dd6b3', 'Staff Testing', 0, 'staff-testing', 2, '1970-01-01', NULL, NULL, 4, 6, '2014-03-24 09:10:18', '202.51.76.235', NULL),
(12, 22, 'Deurali-Janta Pharmaceuticals Pvt Ltd', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Prava Dhungana', 0, 'prava-dhungana', NULL, '1989-06-23', '2013-10-23 12:31:36', '202.166.198.114', 3, 6, '2013-10-21 17:19:35', '202.79.37.170', NULL),
(21, 23, 'ABC SUPPLIER', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'abcsupplier', 0, 'abcsupplier', NULL, NULL, NULL, NULL, 3, 6, '2013-10-30 16:36:25', '117.121.231.210', NULL),
(9, NULL, 'Binu Maharjan', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Binu', 0, 'binu', 2, '1990-10-01', '2014-02-06 13:40:07', '110.44.117.101', 2, 6, '2013-10-08 15:14:48', '117.121.231.210', NULL),
(10, NULL, 'sushil kumar shrestha', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'sushil', 0, 'sushil', 1, '1979-06-29', '2013-12-08 16:13:36', '117.121.231.210', 2, 6, '2013-10-20 17:03:31', '65.49.14.163', NULL),
(13, 1, 'sushil shrestha', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'sushil1', 0, 'sushil1', 1, '1979-06-29', '2013-12-17 15:48:03', '117.121.231.210', 3, 6, '2013-10-22 10:59:30', '117.121.231.210', NULL),
(14, NULL, 'BABURAM ADHIKARI', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'BABURAM', 0, 'baburam', 1, '1976-06-23', '2013-12-20 19:07:27', '117.121.231.210', 1, 6, '2013-10-22 11:43:55', '36.253.220.78', NULL),
(15, NULL, 'Manik Ratna Tuladhar', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'manik', 0, 'manik', 1, NULL, '2014-05-06 10:59:29', '202.51.76.235', 1, 6, '2013-10-22 11:57:11', '36.253.220.78', NULL),
(95, 30, 'Te', '3744d1f938f09c9f8d93a19f3d2a4d0ac65dd6b3', 'Te', 1, 'te-1', 2, '2014-02-17', '2014-02-18 12:23:07', '110.44.113.253', 3, 6, '2014-02-18 12:02:47', '110.44.113.253', NULL),
(23, 6, 'Resha Nyachhyon', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'resha', 0, 'resha', 2, '1970-01-01', '2013-11-01 11:26:01', '117.121.231.210', 3, 6, '2013-10-30 17:09:17', '117.121.231.210', NULL),
(24, 1, 'test supp', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'supp', 0, 'supp-1', 2, '1990-10-31', '2013-11-01 11:13:29', '117.121.231.210', 3, 6, '2013-10-31 09:30:56', '117.121.231.210', NULL),
(26, 2, 'abc enterprises', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'abc', 0, 'abc-1', 2, '1970-01-01', '2014-05-06 10:52:58', '202.51.76.235', 3, 6, '2013-10-31 17:27:37', '117.121.231.210', 'b5ebe379505f882c74cc5e1808113024rnZa1xY9'),
(27, NULL, 'Dipak khatri', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Dipak khatri', 0, 'dipak-khatri', 1, '1981-01-10', '2013-11-01 13:51:24', '117.121.231.210', 4, 6, '2013-11-01 09:17:24', '117.121.231.210', NULL),
(28, 6, 'abc medicine distributors', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'a gautam', 0, 'a-gautam', 1, '1997-11-03', NULL, NULL, 3, 6, '2013-11-01 09:20:34', '117.121.231.210', NULL),
(94, 32, 'testing ', '3744d1f938f09c9f8d93a19f3d2a4d0ac65dd6b3', 'testing', 0, 'testing-1', 2, '2014-02-17', '2014-02-18 11:41:07', '110.44.113.253', 3, 6, '2014-02-18 11:40:08', '110.44.113.253', NULL),
(48, 17, 'New Test Email', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'newtestemail', 0, 'newtestemail', NULL, NULL, '2014-01-22 13:37:39', '110.44.115.74', 3, 6, '2013-11-28 12:50:16', '110.44.115.157', NULL),
(52, 1, 'Sajwal Tamrakar', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Sajwal', 0, 'sajwal-1', 1, '1989-09-05', '2014-03-04 12:45:28', '110.44.113.253', 3, 6, '2013-11-28 13:35:21', '110.44.115.157', NULL),
(58, 6, 'Saakshi Agrawal', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Saakshi', 0, 'saakshi-1', 2, '1990-12-18', '2014-07-15 15:17:06', '202.51.76.235', 3, 6, '2013-12-02 12:28:01', '110.44.115.4', NULL),
(57, 4, 'Bismeeta', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Bismeeta', 0, 'bismeeta', 2, '1970-01-01', '2014-01-31 13:04:25', '110.44.115.197', 3, 6, '2013-11-29 12:47:49', '110.44.117.56', NULL),
(66, 23, 'Shilpa', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Shilpa', 0, 'shilpa', 2, '1991-02-06', '2014-01-22 11:01:45', '110.44.115.141', 3, 6, '2014-01-20 11:38:56', '110.44.115.141', NULL),
(65, 14, 'Mohit', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Mohit', 0, 'mohit', 1, '1970-01-01', '2014-01-16 13:38:56', '110.44.115.141', 3, 6, '2014-01-16 13:25:54', '110.44.115.141', NULL),
(70, 15, 'ran', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'ran12', 0, 'ran12', 1, '2014-01-06', NULL, NULL, 3, 6, '2014-01-21 09:53:15', '110.44.117.25', NULL),
(73, 28, 'Vaibhaw Poddar', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'bob', 0, 'bob', 1, '1989-06-14', '2014-04-25 10:54:59', '202.51.76.235', 3, 6, '2014-01-28 19:15:20', '110.44.115.167', NULL),
(74, 7, 'Vaibhaw Poddar', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'himaltech', 0, 'himaltech', 1, '1970-01-01', '2014-02-18 18:47:15', '110.44.113.253', 3, 6, '2014-01-30 07:52:47', '110.44.115.167', NULL),
(75, 28, 'Bijay Rajbhandari', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'bijay', 0, 'bijay', 1, '2013-08-27', NULL, NULL, 3, 6, '2014-01-30 09:41:23', '110.44.117.32', NULL),
(76, 3, 'Arpita Singh', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Arpita', 0, 'arpita', 2, '2014-01-14', '2014-07-15 15:08:07', '202.51.76.235', 3, 6, '2014-01-30 10:30:56', '110.44.117.32', NULL),
(77, 2, 'HT', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Sahil', 0, 'sahil', 1, '1992-07-17', '2014-05-22 11:36:24', '202.51.76.235', 3, 6, '2014-01-30 16:00:08', '110.44.117.32', NULL),
(78, 1, '', '351b76d478001ff6ca08c05ef453376b9a932bd4', 'Tester', 0, 'tester', 1, '2014-01-31', '2014-01-31 12:46:34', '110.44.115.197', 3, 6, '2014-01-31 12:45:31', '110.44.115.197', NULL),
(93, 31, 'Test', '3744d1f938f09c9f8d93a19f3d2a4d0ac65dd6b3', 'Test', 0, 'test-1', 2, '2014-02-17', '2014-02-18 11:28:10', '110.44.113.253', 3, 6, '2014-02-18 11:19:38', '110.44.113.253', NULL),
(80, 7, 'Andrew Mogford', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'andrew', 0, 'andrew', 1, '1970-01-01', NULL, NULL, 3, 6, '2014-01-31 14:05:19', '110.44.115.197', NULL),
(81, 30, 'Sandhya', '3744d1f938f09c9f8d93a19f3d2a4d0ac65dd6b3', 'Sandhya', 0, 'sandhya', 2, '1995-02-07', '2014-02-05 11:08:18', '110.44.115.218', 3, 6, '2014-02-05 10:58:14', '110.44.115.218', NULL),
(88, NULL, 'Bins', 'cd3b8768b642db500b135b5a55458624f970fdec', 'Binod', 0, 'binod', 1, '2014-02-05', NULL, NULL, 3, 6, '2014-02-07 15:19:20', '110.44.117.79', NULL),
(84, NULL, 'ankita', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'ankita123', 0, 'ankita123', 2, '2014-02-05', NULL, NULL, 3, 6, '2014-02-05 15:01:26', '110.44.117.84', NULL),
(96, 33, 'TES', '3744d1f938f09c9f8d93a19f3d2a4d0ac65dd6b3', 'TES', 0, 'tes-1', 2, '1970-01-01', '2014-02-18 12:34:20', '110.44.113.253', 3, 6, '2014-02-18 12:29:02', '110.44.113.253', NULL),
(89, NULL, 'Bins', '86e9fbb144694a146daeed8c0c08f6a810e6d72c', 'binod1', 0, 'binod1', 1, '2014-02-07', NULL, NULL, 3, 6, '2014-02-07 15:23:09', '110.44.117.79', NULL),
(90, NULL, 'Sakshi Agrwal', '3744d1f938f09c9f8d93a19f3d2a4d0ac65dd6b3', 'ching', 0, 'ching', 1, '1970-01-01', NULL, NULL, 3, 6, '2014-02-10 14:34:29', '110.44.115.83', NULL),
(97, 2, 'saag-chee', '86e9fbb144694a146daeed8c0c08f6a810e6d72c', '01Tester', 0, '01tester', 2, '2014-02-13', NULL, NULL, 3, 6, '2014-02-18 12:51:09', '110.44.113.253', NULL),
(98, 34, 'China', '3744d1f938f09c9f8d93a19f3d2a4d0ac65dd6b3', 'China', 0, 'china', NULL, '1970-01-01', NULL, NULL, 3, 6, '2014-02-18 13:04:34', '110.44.113.253', NULL),
(99, 34, 'Sa', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'Sa', 0, 'sa-1', 2, '1970-01-01', NULL, NULL, 3, 6, '2014-02-18 13:12:43', '110.44.113.253', NULL),
(101, NULL, 'Admin Testing', '3744d1f938f09c9f8d93a19f3d2a4d0ac65dd6b3', 'Admin Testing', 0, 'admin-testing', 2, '1970-01-01', '2014-05-05 11:53:48', '110.44.117.45', 2, 6, '2014-03-24 09:11:20', '202.51.76.235', NULL),
(102, NULL, 'Sahil', '02ecbbc82d005d1b272795bbf8b7b7446bc5bcf8', 'Dahal', 0, 'dahal', 1, '2013-10-16', NULL, NULL, 3, 6, '2014-05-05 10:53:05', '110.44.117.45', NULL),
(103, 3, 'testing business', '9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8', 'business', 0, 'business-2', 2, '2014-06-29', NULL, NULL, 3, 6, '2014-07-15 15:10:00', '202.51.76.235', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `url` varchar(25) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `name`, `url`) VALUES
(1, 'Super Admin', 'admin'),
(2, 'Admin', 'staff'),
(3, 'Client', 'client'),
(4, 'Staff', 'staff-1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acos`
--
ALTER TABLE `acos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `location_map_id` (`city`),
  ADD KEY `table_id` (`table_id`);

--
-- Indexes for table `aros`
--
ALTER TABLE `aros`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros_acos`
--
ALTER TABLE `aros_acos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ARO_ACO_KEY` (`aro_id`,`aco_id`);

--
-- Indexes for table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_approves`
--
ALTER TABLE `t_approves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_approve_levels_requests`
--
ALTER TABLE `t_approve_levels_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_approve_level_tenders`
--
ALTER TABLE `t_approve_level_tenders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_bids`
--
ALTER TABLE `t_bids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_currency_tenders`
--
ALTER TABLE `t_currency_tenders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_manufactures`
--
ALTER TABLE `t_manufactures`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_products`
--
ALTER TABLE `t_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_requests`
--
ALTER TABLE `t_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_req_docs`
--
ALTER TABLE `t_req_docs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_req_doc_tenders`
--
ALTER TABLE `t_req_doc_tenders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_selections`
--
ALTER TABLE `t_selections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_tenders`
--
ALTER TABLE `t_tenders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_tender_manufacture_products`
--
ALTER TABLE `t_tender_manufacture_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `table_id` (`foreign_key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acos`
--
ALTER TABLE `acos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=934;
--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=164;
--
-- AUTO_INCREMENT for table `aros`
--
ALTER TABLE `aros`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=122;
--
-- AUTO_INCREMENT for table `aros_acos`
--
ALTER TABLE `aros_acos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=143;
--
-- AUTO_INCREMENT for table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=712;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `t_approves`
--
ALTER TABLE `t_approves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `t_approve_levels_requests`
--
ALTER TABLE `t_approve_levels_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `t_approve_level_tenders`
--
ALTER TABLE `t_approve_level_tenders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=251;
--
-- AUTO_INCREMENT for table `t_bids`
--
ALTER TABLE `t_bids`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `t_currency_tenders`
--
ALTER TABLE `t_currency_tenders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `t_manufactures`
--
ALTER TABLE `t_manufactures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT for table `t_products`
--
ALTER TABLE `t_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT for table `t_requests`
--
ALTER TABLE `t_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `t_req_docs`
--
ALTER TABLE `t_req_docs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `t_req_doc_tenders`
--
ALTER TABLE `t_req_doc_tenders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT for table `t_selections`
--
ALTER TABLE `t_selections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `t_tenders`
--
ALTER TABLE `t_tenders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=103;
--
-- AUTO_INCREMENT for table `t_tender_manufacture_products`
--
ALTER TABLE `t_tender_manufacture_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3311;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=319;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
