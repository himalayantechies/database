-- MySQL dump 10.13  Distrib 5.5.42, for Linux (x86_64)
--
-- Host: localhost    Database: oopsnepa_generaldoc
-- ------------------------------------------------------
-- Server version	5.5.42-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gdoc_acs`
--

DROP TABLE IF EXISTS `gdoc_acs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_acs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access` longtext,
  `name` varchar(255) NOT NULL,
  `description` text,
  `visibility` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_acs`
--

LOCK TABLES `gdoc_acs` WRITE;
/*!40000 ALTER TABLE `gdoc_acs` DISABLE KEYS */;
INSERT INTO `gdoc_acs` (`id`, `access`, `name`, `description`, `visibility`) VALUES (1,'[ { \"url\": { \"controller\": \"departments\", \"action\": \"index\" } } ]','Department View',NULL,NULL),(2,'[ { \"url\": { \"controller\": \"departments\", \"action\": \"add\" }}, { \"url\": { \"controller\": \"departments\", \"action\": \"save\" }, \"extra\": [ [ { \"url\": { \"pass\" : \"0\" } }, \"EMPTY\", { } ] ] },{ \"url\": { \"controller\": \"departments\", \"action\": \"save\" }, \"extra\": [ [ { \"url\": { \"pass\" : \"0\" } }, \"NOT EMPTY\", { } ] ] } ,{ \"url\": { \"controller\": \"departments\", \"action\": \"treeUpdate\" } }, { \"url\": { \"controller\": \"departments\", \"action\": \"locTree\" } } ]','Department Add',NULL,NULL),(3,'[{\"url\":{\"controller\":\"departments\",\"action\":\"edit\"},\"extra\":[[{\"auth\":\"role_id\"},\"==\",{\"value\":\"1\"}]]},{\"url\":{\"controller\":\"departments\",\"action\":\"move\"},\"extra\":[[{\"auth\":\"role_id\"},\"==\",{\"value\":\"1\"}]]} ,{ \"url\": { \"controller\": \"departments\", \"action\": \"save\" }, \"extra\": [ [ { \"url\": { \"pass\" : \"0\" } }, \"NOT EMPTY\", { } ], [ { \"url\": { \"pass\" : \"0\" } }, \"IN\", { \"session\": \"Auth.department_ids\" } ] ] }, { \"url\": { \"controller\": \"departments\", \"action\": \"treeUpdate\" } }, { \"url\": { \"controller\": \"departments\", \"action\": \"locTree\" } } ]','Department Update',NULL,NULL),(4,'[ { \"url\": { \"controller\": \"departments\", \"action\": \"delete\" }, \"extra\": [[{\"auth\":\"role_id\"},\"==\",{\"value\":\"1\"}]]},{ \"url\": { \"controller\": \"departments\", \"action\": \"assign_department\" }, \"extra\": [ [ { \"url\": { \"pass\" : \"0\" } }, \"NOT EMPTY\", { } ] ] } ,{ \"url\": { \"controller\": \"departments\", \"action\": \"treeUpdate\" } }, { \"url\": { \"controller\": \"departments\", \"action\": \"locTree\" } },{ \"url\": { \"controller\": \"users\", \"action\": \"revoke_department\" }, \"extra\": [ [ { \"url\": { \"pass\" : \"0\" } }, \"==\" , { \"auth\":\"id\"}] ,[{ \"url\": { \"pass\" : \"1\" } }, \"IN\", { \"session\": \"Auth.department_ids\" } ] ] }, { \"url\": { \"controller\": \"departments\", \"action\": \"unassign_departments\" }, \"extra\": [ [ { \"url\": { \"pass\" : \"0\" } }, \"==\" , { \"auth\":\"id\"}] ,[{ \"url\": { \"pass\" : \"1\" } }, \"IN\", { \"session\": \"Auth.department_ids\" } ] ] } ]','Department Delete',NULL,NULL),(5,'[ { \"url\": { \"controller\": \"users\", \"action\": \"login\" }, \"extra\": [ [ { \"auth\": \"id\" }, \"EMPTY\", { } ] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"logout\" }, \"extra\": [ [ { \"auth\": \"id\" }, \"NOT EMPTY\", { } ] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"profile\" }, \"extra\": [ [ { \"auth\": \"id\" }, \"NOT EMPTY\", { } ], [ { \"url\": { \"pass\": 0 } }, \"EMPTY\", { } ] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"password\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"EMPTY\", {} ], [{\"url\": {\"data\":\"User.id\"}}, \"EMPTY\", {}]] }, { \"url\": { \"controller\": \"users\", \"action\": \"password\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"EMPTY\", {} ], [ { \"url\": { \"data\":\"User.id\"} }, \"==\", { \"auth\": \"id\" } ] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"password\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", {} ], [ { \"url\": { \"pass\":0} }, \"==\", { \"auth\": \"id\" } ] ] }, { \"url\": { \"controller\": \"pages\", \"action\": \"display\" } }, { \"url\": { \"controller\": \"departments\", \"action\": \"department_list\" } }  ]','User Access',NULL,NULL),(6,'[ { \"url\": { \"controller\": \"users\", \"action\": \"registration\" }, \"extra\": [ [ { \"auth\": \"id\" }, \"NOT EMPTY\", [ ] ], [ { \"url\": {\"pass\":0} }, \"EMPTY\", [ ] ] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"registration\" }, \"extra\": [ [ { \"auth\": \"id\" }, \"NOT EMPTY\", [ ] ], [ { \"auth\": \"role_id\" }, \"==\", {\"value\": 1} ], [ { \"url\": {\"pass\":0} }, \"NOT EMPTY\", [ ] ] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"registration\" }, \"extra\": [ [ { \"auth\": \"id\" }, \"NOT EMPTY\", [ ] ], [ { \"auth\": \"role_id\" }, \"!=\", {\"value\": 1} ], [ { \"url\": {\"pass\":0}}, \"NOT EMPTY\", [] ], [ { \"url\": {\"pass\":0}}, \"NOT IN\", {\"model\":\"User\", \"field\":\"id\", \"conditions\":{\"User.role_id\":1}} ] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"index\" } }, { \"url\": { \"controller\": \"users\", \"action\": \"profile\" }, \"extra\": [ [ { \"auth\": \"id\" }, \"NOT EMPTY\", { } ], [ { \"url\": { \"pass\": 0 } }, \"NOT EMPTY\", { } ] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"get_department_users\" }},{ \"url\": { \"controller\": \"users\", \"action\": \"upload\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", { } ] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"delete\" }, \"extra\": [ [ {\"auth\": \"role_id\"}, \"!=\", {\"value\":1}], [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ], [ {\"url\": {\"pass\":0}}, \"!=\", {\"auth\": \"id\"}], [ { \"url\": { \"pass\":1} }, \"NOT EMPTY\", [ ] ], [ { \"url\": { \"pass\":1} }, \"==\", { \"auth\": \"branch_id\" } ], [{\"url\": {\"pass\":0}}, \"NOT IN\", {\"model\": \"User\", \"field\": \"id\", \"conditions\": {\"User.role_id\": 1}}] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"delete\" }, \"extra\": [ [{\"auth\": \"role_id\"}, \"==\", {\"value\":1}], [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ], [ {\"url\": {\"pass\":0}}, \"!=\", {\"auth\": \"id\"}] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"password_policy\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ] ] },{ \"url\": { \"controller\": \"users\", \"action\": \"save_password_policy\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ] ] } ,{ \"url\": { \"controller\": \"users\", \"action\": \"assign_document\" } }, { \"url\": { \"controller\": \"users\", \"action\": \"department_settings\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ], [ {\"auth\" : \"role_id\" }, \"!=\", {\"value\":1}] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"user_roles\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ], [ { \"url\": { \"pass\":1} }, \"NOT EMPTY\", [ ] ] ] }, { \"url\": { \"controller\": \"users\", \"action\": \"user_permission\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ], [ { \"url\": { \"pass\":1} }, \"NOT EMPTY\", [ ] ] ] } ,{ \"url\": { \"controller\": \"users\", \"action\": \"delete\" }, \"extra\": [ [{\"url\": {\"pass\":0}}, \"NOT IN\", {\"model\": \"User\", \"field\": \"id\", \"conditions\": {\"User.role_id\": 1}}] ,[ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ], [ {\"url\": {\"pass\":0}}, \"!=\", {\"auth\": \"id\"}]] },{ \"url\": { \"controller\": \"users\", \"action\": \"user_status\" }},{ \"url\": { \"controller\": \"menus\", \"action\": \"index\" }, \"extra\": [ [ { \"auth\": \"role_id\" }, \"==\", {\"value\":1} ] ] },{ \"url\": { \"controller\": \"menus\", \"action\": \"add\" }, \"extra\": [ [ { \"auth\": \"role_id\" }, \"==\", {\"value\":1} ] ] },{ \"url\": { \"controller\": \"menus\", \"action\": \"edit\" }, \"extra\": [ [ { \"auth\": \"role_id\" }, \"==\", {\"value\":1} ] ] },{ \"url\": { \"controller\": \"menus\", \"action\": \"save\" }, \"extra\": [ [ { \"auth\": \"role_id\" }, \"==\", {\"value\":1} ] ] }]','User Manage',NULL,NULL),(7,'[ { \"url\": { \"controller\": \"branches\", \"action\": \"index\" } }, { \"url\": { \"controller\": \"branches\", \"action\": \"view\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ] ] }, { \"url\": { \"controller\": \"branches\", \"action\": \"edit\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ] ] }, { \"url\": { \"controller\": \"branches\", \"action\": \"editDetails\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ] ] }, { \"url\": { \"controller\": \"branches\", \"action\": \"assign_branch\" }, \"extra\": [ [ { \"url\": { \"pass\" : \"0\" } }, \"NOT EMPTY\", { } ] ] } ,{ \"url\": { \"controller\": \"branches\", \"action\": \"add\" } , \"extra\": [ [ { \"url\": { \"pass\":0} }, \"EMPTY\", [ ] ]] }, { \"url\": { \"controller\": \"branches\", \"action\": \"save\" } }, { \"url\": { \"controller\": \"branches\", \"action\": \"delete\" }, \"extra\": [ [ { \"url\": { \"pass\":0} }, \"NOT EMPTY\", [ ] ] ] } ]','Branch Manage',NULL,NULL),(8,'[{\"url\":{\"controller\":\"documents\",\"action\":\"add\"},\"extra\":[[{\"url\":{\"named\":\"dept\"}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"ownership_transfer\"},\"extra\":[[{\"url\":{\"pass\":\"0\"}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"getChildTags\"}},{\"url\":{\"controller\":\"location_maps\",\"action\":\"getChildTags\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"edit\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]],[{\"url\":{\"named\":\"dept\"}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"upload\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]],[{\"url\":{\"named\":\"dept\"}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"deleteUpload\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]],[{\"url\":{\"named\":\"dept\"}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"delete\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]],[{\"url\":{\"named\":\"dept\"}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"ajax_trash\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]],[{\"url\":{\"named\":\"dept\"}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"delete_image\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"publish\"},\"extra\":[[{\"url\":{\"pass\":0}}, \"IN\", { \"session\": \"Auth.document_ids\" } ]]},{\"url\":{\"controller\":\"documents\",\"action\":\"getAttributes\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"getAttributeValue\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"inbox\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"inbox_view\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"trash\"}} ,{\"url\":{\"controller\":\"documents\",\"action\":\"trash_status\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"recover\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"rejection\"},\"extra\":[[{\"url\":{\"pass\":0}}, \"IN\", { \"session\": \"Auth.security_rule_ids\" },{\"url\":{\"pass\":1}}, \"IN\", {\"session\": \"Auth.document_ids\"}]]}]','Document Manage',NULL,1),(9,'[{\"url\":{\"controller\":\"documents\",\"action\":\"index\"},\"extra\":[[{\"url\":{\"named\":\"dept\"}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"privateDocument\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"view\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]],[{\"url\":{\"named\":\"dept\"}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"preview\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]],[{\"url\":{\"named\":\"dept\"}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"advance_search\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"simple_search\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"ajax_send_documents\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"send_documents\"}}]','Document View',NULL,1),(10,'[{\"url\":{\"controller\":\"settings\",\"action\":\"index\"},\"extra\":[[{\"auth\":\"role_id\"},\"==\",{\"value\":\"1\"}]]},{\"url\":{\"controller\":\"settings\",\"action\":\"edit\"},\"extra\":[[{\"auth\":\"role_id\"},\"==\",{\"value\":\"1\"}]]},{\"url\":{\"controller\":\"settings\",\"action\":\"save\"},\"extra\":[[{\"auth\":\"role_id\"},\"==\",{\"value\":\"1\"}]]}, {\"url\":{\"controller\":\"attributes\",\"action\":\"index\"}},{\"url\":{\"controller\":\"attributes\",\"action\":\"add\"}},{\"url\":{\"controller\":\"attributes\",\"action\":\"edit\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"attributes\",\"action\":\"save\"},\"extra\":[[{\"url\":{\"data\":[]}},\"EMPTY\",[]]]},{\"url\":{\"controller\":\"attributes\",\"action\":\"save\"},\"extra\":[[{\"url\":{\"data\":\"Attribute.document_type_id\"}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"attributes\",\"action\":\"delete\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"categories\",\"action\":\"index\"}},{\"url\":{\"controller\":\"categories\",\"action\":\"treeUpdate\"}},{\"url\":{\"controller\":\"categories\",\"action\":\"locTree\"}},{\"url\":{\"controller\":\"categories\",\"action\":\"view\"}},{\"url\":{\"controller\":\"categories\",\"action\":\"add\"}},{\"url\":{\"controller\":\"categories\",\"action\":\"save\"}},{\"url\":{\"controller\":\"categories\",\"action\":\"edit\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"categories\",\"action\":\"delete\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"categories\",\"action\":\"move\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"conditions\",\"action\":\"index\"}},{\"url\":{\"controller\":\"conditions\",\"action\":\"add\"}},{\"url\":{\"controller\":\"conditions\",\"action\":\"save\"}},{\"url\":{\"controller\":\"conditions\",\"action\":\"edit\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"conditions\",\"action\":\"delete\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"documents_types\",\"action\":\"index\"}},{\"url\":{\"controller\":\"documents_types\",\"action\":\"add\"}},{\"url\":{\"controller\":\"documents_types\",\"action\":\"save\"}},{\"url\":{\"controller\":\"documents_types\",\"action\":\"edit\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"documents_types\",\"action\":\"delete\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"languages\",\"action\":\"index\"}},{\"url\":{\"controller\":\"languages\",\"action\":\"add\"}},{\"url\":{\"controller\":\"languages\",\"action\":\"save\"}},{\"url\":{\"controller\":\"languages\",\"action\":\"edit\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"languages\",\"action\":\"delete\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"location_types\",\"action\":\"index\"}},{\"url\":{\"controller\":\"location_types\",\"action\":\"add\"}},{\"url\":{\"controller\":\"location_types\",\"action\":\"save\"}},{\"url\":{\"controller\":\"location_types\",\"action\":\"edit\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"location_types\",\"action\":\"delete\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"location_maps\",\"action\":\"index\"}},{\"url\":{\"controller\":\"location_maps\",\"action\":\"treeUpdate\"}},{\"url\":{\"controller\":\"location_maps\",\"action\":\"locTree\"}},{\"url\":{\"controller\":\"location_maps\",\"action\":\"add\"}},{\"url\":{\"controller\":\"location_maps\",\"action\":\"save\"}},{\"url\":{\"controller\":\"location_maps\",\"action\":\"edit\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"location_maps\",\"action\":\"move\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"location_maps\",\"action\":\"delete\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"user_roles\",\"action\":\"index\"}},{\"url\":{\"controller\":\"user_roles\",\"action\":\"view\"},\"extra\":[[{\"url\":{\"pass\":\"0\"}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"user_roles\",\"action\":\"add\"},\"extra\":[[{\"url\":{\"pass\":\"0\"}},\"EMPTY\",[]]]},{\"url\":{\"controller\":\"user_roles\",\"action\":\"edit\"},\"extra\":[[{\"url\":{\"pass\":\"0\"}},\"NOT EMPTY\",[]],[{\"url\":{\"pass\":\"0\"}},\"NOT IN\",{\"model\":\"UserRole\",\"field\":\"id\",\"conditions\":{\"UserRole.inbuilt\":1}}]]},{\"url\":{\"controller\":\"user_roles\",\"action\":\"delete\"},\"extra\":[[{\"url\":{\"pass\":\"0\"}},\"NOT EMPTY\",[]],[{\"url\":{\"pass\":\"0\"}},\"NOT IN\",{\"model\":\"UserRole\",\"field\":\"id\",\"conditions\":{\"UserRole.inbuilt\":1}}]]},{\"url\":{\"controller\":\"statuses\",\"action\":\"index\"}},{\"url\":{\"controller\":\"statuses\",\"action\":\"add\"}},{\"url\":{\"controller\":\"statuses\",\"action\":\"save\"}},{\"url\":{\"controller\":\"statuses\",\"action\":\"edit\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]},{\"url\":{\"controller\":\"statuses\",\"action\":\"delete\"},\"extra\":[[{\"url\":{\"pass\":0}},\"NOT EMPTY\",[]]]}]','Company Setting',NULL,NULL),(11,'[{\"url\":{\"controller\":\"reports\",\"action\":\"archi\"}}]','Document Report',NULL,NULL),(12,'[{\"url\":{\"controller\":\"reports\",\"action\":\"department_report\"}}]','Admin Report',NULL,NULL),(13,'[{ \"url\": { \"controller\": \"security_levels\", \"action\": \"index\" }, \"extra\": [ [ { \"auth\": \"role_id\" }, \"==\", {\"value\": 1} ]]},{ \"url\": { \"controller\": \"security_rules\", \"action\": \"edit\" }, \"extra\":[ { \"url\": {\"pass\":0} }, \"EMPTY\", [ ] ] },{ \"url\": { \"controller\": \"security_rules\", \"action\": \"add\" }},{ \"url\": { \"controller\": \"security_rules\", \"action\": \"remove\" }},{ \"url\": { \"controller\": \"users\", \"action\": \"branch_department\" }}]','Security Level',NULL,NULL),(14,'[{\"url\":{\"controller\":\"documents\",\"action\":\"approval_pending\"}},{\"url\":{\"controller\":\"documents\",\"action\":\"approval\"},\"extra\":[[{\"url\":{\"pass\":0}}, \"IN\", { \"session\": \"Auth.security_rule_ids\" },{\"url\":{\"pass\":1}}, \"NOT EMPTY\", {}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"documents_rejection\"},\"extra\":[[{\"url\":{\"pass\":0}}, \"IN\", { \"session\": \"Auth.security_rule_ids\" },{\"url\":{\"pass\":1}}, \"IN\", {\"session\": \"Auth.document_ids\"}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"documents_return\"},\"extra\":[[{\"url\":{\"pass\":0}}, \"IN\", { \"session\": \"Auth.security_rule_ids\" },{\"url\":{\"pass\":1}}, \"IN\", {\"session\": \"Auth.document_ids\"}]]},{\"url\":{\"controller\":\"documents\",\"action\":\"expired_documents\"}}]','Document Approve / Return / Rejection',NULL,NULL);
/*!40000 ALTER TABLE `gdoc_acs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_attributes`
--

DROP TABLE IF EXISTS `gdoc_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_attributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `document_type_id` int(11) NOT NULL,
  `menu` tinyint(4) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_attributes`
--

LOCK TABLES `gdoc_attributes` WRITE;
/*!40000 ALTER TABLE `gdoc_attributes` DISABLE KEYS */;
INSERT INTO `gdoc_attributes` (`id`, `name`, `document_type_id`, `menu`, `created`, `updated`, `created_by`) VALUES (10,'Volume',1,1,'0000-00-00 00:00:00',NULL,NULL),(13,'File',361,1,'0000-00-00 00:00:00','2014-07-03 10:06:02',170),(24,'Pages',365,1,'0000-00-00 00:00:00','2014-07-03 10:06:17',170);
/*!40000 ALTER TABLE `gdoc_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_branches`
--

DROP TABLE IF EXISTS `gdoc_branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `street` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(99) DEFAULT NULL,
  `postal_code` varchar(25) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `url` varchar(195) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=125 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_branches`
--

LOCK TABLES `gdoc_branches` WRITE;
/*!40000 ALTER TABLE `gdoc_branches` DISABLE KEYS */;
INSERT INTO `gdoc_branches` (`id`, `name`, `street`, `city`, `country`, `postal_code`, `phone`, `website`, `url`, `created`, `updated`, `created_by`) VALUES (119,'Kathmandu',NULL,NULL,NULL,NULL,NULL,NULL,'kathmandu','2015-03-23 08:52:46','2015-03-23 08:52:46',204),(121,'Lalitpur',NULL,NULL,NULL,NULL,NULL,NULL,'lalitpur','2015-06-14 09:28:46','2015-06-14 04:28:46',204),(122,'Bhaktapur',NULL,NULL,NULL,NULL,NULL,NULL,'bhaktapur','2015-06-28 15:12:24','2015-06-28 10:12:24',175),(123,'Lamjung',NULL,NULL,NULL,NULL,NULL,NULL,'bhaktapur-1','2015-06-28 15:12:26','2015-07-16 04:43:36',175),(124,'Butwal',NULL,NULL,NULL,NULL,NULL,NULL,'butwal','2015-07-16 09:47:31','2015-07-16 04:47:31',175);
/*!40000 ALTER TABLE `gdoc_branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_categories`
--

DROP TABLE IF EXISTS `gdoc_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(99) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(32) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_categories`
--

LOCK TABLES `gdoc_categories` WRITE;
/*!40000 ALTER TABLE `gdoc_categories` DISABLE KEYS */;
INSERT INTO `gdoc_categories` (`id`, `name`, `description`, `url`, `parent_id`, `rght`, `lft`, `created`, `updated`, `created_by`) VALUES (1,'Report','Study report by Engineering business group ','report',NULL,2,1,'2015-03-23 09:51:57','2015-06-18 04:36:30',204),(2,'Supreme Court decision','Supreme Court decision made at different dates','supreme-court-decision',NULL,4,3,'2015-03-23 09:55:30','2015-03-23 09:55:30',204),(3,'District Court decision','District  Court decision made at different dates','district-court-decision',NULL,6,5,'2015-03-23 09:56:24','2015-03-23 09:56:24',204);
/*!40000 ALTER TABLE `gdoc_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_conditions`
--

DROP TABLE IF EXISTS `gdoc_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_conditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_conditions`
--

LOCK TABLES `gdoc_conditions` WRITE;
/*!40000 ALTER TABLE `gdoc_conditions` DISABLE KEYS */;
INSERT INTO `gdoc_conditions` (`id`, `name`, `created`, `updated`, `created_by`) VALUES (5,'Poor','0000-00-00 00:00:00',NULL,NULL),(6,'Good','0000-00-00 00:00:00',NULL,NULL),(7,'Excellent','2014-07-03 15:40:03','2014-07-03 10:40:03',170);
/*!40000 ALTER TABLE `gdoc_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_department_group_users`
--

DROP TABLE IF EXISTS `gdoc_department_group_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_department_group_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) NOT NULL,
  `user_roles_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `security_level_id` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=139 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_department_group_users`
--

LOCK TABLES `gdoc_department_group_users` WRITE;
/*!40000 ALTER TABLE `gdoc_department_group_users` DISABLE KEYS */;
INSERT INTO `gdoc_department_group_users` (`id`, `department_id`, `user_roles_id`, `user_id`, `security_level_id`) VALUES (82,13,3,159,6),(131,13,2,175,1),(125,13,2,214,1),(129,13,2,204,1),(130,13,2,215,1),(132,35,3,175,1),(133,35,7,159,NULL),(136,37,7,159,NULL),(138,37,3,217,1);
/*!40000 ALTER TABLE `gdoc_department_group_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_departments`
--

DROP TABLE IF EXISTS `gdoc_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(132) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `color` varchar(50) NOT NULL,
  `abbr` varchar(50) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_departments`
--

LOCK TABLES `gdoc_departments` WRITE;
/*!40000 ALTER TABLE `gdoc_departments` DISABLE KEYS */;
INSERT INTO `gdoc_departments` (`id`, `name`, `active`, `color`, `abbr`, `lft`, `rght`, `parent_id`, `created`, `updated`, `created_by`) VALUES (13,'Law',1,'#b05a5a','Law',1,2,NULL,'0000-00-00 00:00:00','2015-03-10 06:02:38',204),(35,'Project Development Department',1,'#0000ff','PDD',3,4,NULL,'2015-03-23 10:21:40','2015-03-27 05:50:10',204),(36,'Test Department',1,'#333300','Test',5,6,NULL,'2015-06-09 13:31:06','2015-06-09 08:31:06',175),(37,'Information Technology',1,'#FFFFFF','ITD',7,8,NULL,'2015-07-16 09:52:04','2015-07-16 04:52:04',175);
/*!40000 ALTER TABLE `gdoc_departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_detail_logs`
--

DROP TABLE IF EXISTS `gdoc_detail_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_detail_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `log_in` datetime NOT NULL,
  `log_out` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=117 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_detail_logs`
--

LOCK TABLES `gdoc_detail_logs` WRITE;
/*!40000 ALTER TABLE `gdoc_detail_logs` DISABLE KEYS */;
INSERT INTO `gdoc_detail_logs` (`id`, `user_id`, `log_in`, `log_out`) VALUES (1,204,'2015-03-17 08:33:33',NULL),(2,204,'2015-03-17 08:33:35','2015-03-17 10:35:38'),(3,204,'2015-03-17 10:56:22','2015-03-17 11:19:14'),(4,204,'2015-03-17 11:06:00',NULL),(5,204,'2015-03-18 04:58:55',NULL),(6,214,'2015-03-18 06:00:37','2015-03-18 06:11:14'),(7,204,'2015-03-18 06:11:38','2015-03-18 06:17:11'),(8,204,'2015-03-18 08:59:30',NULL),(9,204,'2015-03-18 09:49:08','2015-03-18 11:15:44'),(10,204,'2015-03-19 05:09:59',NULL),(11,204,'2015-03-19 08:30:19',NULL),(12,214,'2015-03-19 09:43:20',NULL),(13,204,'2015-03-20 04:48:21','2015-03-20 05:08:34'),(14,204,'2015-03-20 07:34:27','2015-03-20 08:21:48'),(15,204,'2015-03-22 04:39:36',NULL),(16,175,'2015-03-22 05:33:12','2015-03-22 05:40:00'),(17,175,'2015-03-22 05:41:00',NULL),(18,204,'2015-03-22 06:39:25',NULL),(19,214,'2015-03-22 06:39:41',NULL),(20,204,'2015-03-22 10:28:30',NULL),(21,204,'2015-03-23 04:26:26','2015-03-23 06:40:15'),(22,175,'2015-03-23 07:03:21',NULL),(23,175,'2015-03-23 07:04:20',NULL),(24,204,'2015-03-23 07:43:33','2015-03-23 07:44:45'),(25,204,'2015-03-23 07:52:32','2015-03-23 07:54:21'),(26,204,'2015-03-23 07:55:26',NULL),(27,214,'2015-03-23 07:56:50',NULL),(28,204,'2015-03-23 08:23:13','2015-03-23 08:24:17'),(29,204,'2015-03-23 09:11:01','2015-03-23 10:23:38'),(30,175,'2015-03-23 09:39:34',NULL),(31,204,'2015-03-24 04:32:06',NULL),(32,204,'2015-03-24 05:57:43',NULL),(33,175,'2015-03-24 08:38:25','2015-03-24 10:31:48'),(34,204,'2015-03-24 09:01:34',NULL),(35,214,'2015-03-24 10:32:14',NULL),(36,204,'2015-03-25 04:29:15','2015-03-25 05:05:32'),(37,204,'2015-03-25 05:35:23',NULL),(38,204,'2015-03-26 04:56:14',NULL),(39,204,'2015-03-26 04:56:27',NULL),(40,204,'2015-03-26 04:56:44','2015-03-26 07:09:54'),(41,204,'2015-03-26 07:10:15','2015-03-26 07:11:05'),(42,204,'2015-03-26 07:11:46','2015-03-26 07:13:12'),(43,159,'2015-03-26 07:13:39','2015-03-26 07:16:09'),(44,204,'2015-03-26 07:16:18','2015-03-26 09:29:58'),(45,204,'2015-03-26 09:30:17','2015-03-26 09:31:03'),(46,175,'2015-03-26 09:31:28','2015-03-26 09:36:47'),(47,204,'2015-03-26 09:36:55',NULL),(48,204,'2015-03-27 04:56:54','2015-03-27 05:52:23'),(49,214,'2015-03-27 05:52:43',NULL),(50,214,'2015-03-27 05:52:44',NULL),(51,204,'2015-03-29 04:23:30',NULL),(52,175,'2015-03-29 08:40:23','2015-03-29 08:44:05'),(53,204,'2015-03-30 07:07:14',NULL),(54,175,'2015-03-30 07:43:18',NULL),(55,204,'2015-04-03 06:12:50',NULL),(56,204,'2015-04-08 08:46:25','2015-04-08 09:03:04'),(57,204,'2015-04-09 07:20:27',NULL),(58,175,'2015-05-25 05:53:46',NULL),(59,175,'2015-05-31 04:49:11',NULL),(60,175,'2015-05-31 04:49:57',NULL),(61,175,'2015-05-31 04:51:29',NULL),(62,175,'2015-05-31 04:54:39',NULL),(63,204,'2015-05-31 05:19:54','2015-05-31 06:44:04'),(64,175,'2015-05-31 05:24:07',NULL),(65,175,'2015-06-02 07:30:31',NULL),(66,175,'2015-06-02 07:30:54',NULL),(67,175,'2015-06-02 07:41:57',NULL),(68,175,'2015-06-08 10:28:13',NULL),(69,175,'2015-06-08 10:28:56',NULL),(70,175,'2015-06-08 10:54:55',NULL),(71,175,'2015-06-09 08:30:04',NULL),(72,175,'2015-06-09 09:33:41','2015-06-09 09:48:46'),(73,175,'2015-06-09 09:49:25','2015-06-09 09:54:47'),(74,175,'2015-06-09 10:16:41',NULL),(75,175,'2015-06-10 04:44:17',NULL),(76,175,'2015-06-10 04:52:57',NULL),(77,204,'2015-06-10 05:11:51',NULL),(78,175,'2015-06-12 05:37:55',NULL),(79,175,'2015-06-12 09:49:31',NULL),(80,175,'2015-06-14 04:27:15','2015-06-14 04:28:11'),(81,204,'2015-06-14 04:28:20',NULL),(82,175,'2015-06-15 06:03:10',NULL),(83,175,'2015-06-18 04:18:00','2015-06-18 04:35:54'),(84,204,'2015-06-18 04:36:12',NULL),(85,175,'2015-06-19 09:01:07',NULL),(86,175,'2015-06-20 15:06:24','2015-06-20 15:07:56'),(87,175,'2015-06-20 15:08:55','2015-06-20 15:09:50'),(88,175,'2015-06-21 10:29:26',NULL),(89,175,'2015-06-22 10:29:41',NULL),(90,175,'2015-06-22 10:45:31',NULL),(91,175,'2015-06-23 05:20:29',NULL),(92,175,'2015-06-24 10:39:26',NULL),(93,175,'2015-06-25 05:28:48',NULL),(94,175,'2015-06-25 05:48:32',NULL),(95,175,'2015-06-26 06:29:38',NULL),(96,175,'2015-06-26 06:35:41','2015-06-26 06:35:58'),(97,216,'2015-06-26 06:40:11',NULL),(98,175,'2015-06-26 06:46:30','2015-06-26 06:46:48'),(99,216,'2015-06-26 06:46:56',NULL),(100,175,'2015-06-28 09:58:18','2015-06-28 09:59:11'),(101,159,'2015-06-28 09:59:38','2015-06-28 10:10:14'),(102,175,'2015-06-28 10:10:47','2015-06-28 10:16:21'),(103,175,'2015-06-28 13:05:12','2015-06-28 13:49:02'),(104,216,'2015-06-29 05:23:05','2015-06-29 05:24:43'),(105,175,'2015-06-29 05:25:30',NULL),(106,175,'2015-06-29 10:04:04',NULL),(107,175,'2015-07-01 05:52:34',NULL),(108,175,'2015-07-02 05:26:25',NULL),(109,216,'2015-07-02 05:26:34',NULL),(110,175,'2015-07-12 15:46:40',NULL),(111,216,'2015-07-14 05:40:22',NULL),(112,175,'2015-07-16 04:37:36',NULL),(113,217,'2015-07-16 06:14:40',NULL),(114,159,'2015-07-21 17:00:36','2015-07-21 17:04:05'),(115,159,'2015-08-02 05:35:04','2015-08-02 05:38:17'),(116,216,'2015-08-02 05:37:38',NULL);
/*!40000 ALTER TABLE `gdoc_detail_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_documents`
--

DROP TABLE IF EXISTS `gdoc_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(256) DEFAULT NULL,
  `other_title` varchar(245) DEFAULT NULL,
  `disposal_date` date DEFAULT NULL,
  `private` tinyint(4) NOT NULL DEFAULT '0',
  `send_for_approval` int(11) NOT NULL DEFAULT '0',
  `approve` int(11) NOT NULL DEFAULT '0',
  `name` varchar(300) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `description` text,
  `date_added` date DEFAULT NULL,
  `language_id` int(11) DEFAULT NULL,
  `condition_id` int(11) DEFAULT NULL,
  `retention_type_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `documents_type_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `location_map_id` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `security_level_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `trash_status` tinyint(4) NOT NULL,
  `trash_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_documents`
--

LOCK TABLES `gdoc_documents` WRITE;
/*!40000 ALTER TABLE `gdoc_documents` DISABLE KEYS */;
INSERT INTO `gdoc_documents` (`id`, `identifier`, `other_title`, `disposal_date`, `private`, `send_for_approval`, `approve`, `name`, `date`, `description`, `date_added`, `language_id`, `condition_id`, `retention_type_id`, `branch_id`, `user_id`, `documents_type_id`, `department_id`, `status_id`, `location_map_id`, `owner_id`, `security_level_id`, `created`, `updated`, `trash_status`, `trash_date`) VALUES (1,'SCJ-2065-W0-190','Supreme court Judgement',NULL,1,1,1,'Gokaran Prasad Sharma',NULL,'Not Required','2015-03-18',4,6,NULL,89,214,376,13,3,NULL,214,1,'2015-03-18 11:04:00','2015-03-18 06:04:00',0,'0000-00-00 00:00:00'),(2,'SCJ-2055-Rit No.3405','Utpression',NULL,0,1,0,'Kirtichand Thakur',NULL,'Not required','2015-03-18',4,5,NULL,89,214,376,13,3,NULL,214,1,'2015-03-18 11:08:55','2015-06-02 08:49:33',0,'0000-00-00 00:00:00'),(3,'SCJ-2065-W0-0207','Utpression Parmadesh Sahit',NULL,0,1,0,'Gokaran Prasad Sharma',NULL,'Not Required','2015-03-18',4,6,NULL,89,214,376,13,3,NULL,214,1,'2015-03-18 11:11:04','2015-06-02 09:03:34',0,'0000-00-00 00:00:00'),(4,'Law_002','Decision',NULL,1,1,1,'Supreme Decision 2071',NULL,'','2015-03-19',4,5,NULL,89,214,377,13,3,NULL,214,1,'2015-03-19 14:50:33','2015-03-24 04:33:19',1,'2015-03-24 04:33:19'),(21,'IND4554','','2019-11-21',0,1,0,'Identity card',NULL,'','2015-07-16',4,6,NULL,119,217,376,37,6,6,217,0,'2015-07-16 12:19:08','2015-07-16 07:22:09',0,'2015-07-16 00:00:00'),(20,'1234','','2015-06-18',0,1,0,'Test',NULL,'This is a test document','2015-06-12',9,6,NULL,119,175,376,35,21,6,175,2,'2015-06-12 14:55:35','2015-06-12 09:57:38',0,'2015-06-12 00:00:00'),(10,'SCJ-2065-wo-0190a','',NULL,1,1,1,'Gokarna prasad sharma',NULL,'SCJ ','2015-03-24',4,6,NULL,89,204,376,13,3,NULL,204,1,'2015-03-24 09:16:25','2015-03-24 09:17:32',0,'0000-00-00 00:00:00'),(12,'scj-2069-wo-1169','',NULL,1,0,1,'Shyam Sundar Agrawal',NULL,'SCJ','2015-03-24',4,5,NULL,89,204,376,13,3,1,204,1,'2015-03-24 10:52:02','2015-03-24 10:52:02',0,'2015-03-24 00:00:00'),(13,'SCJ-2071-wo-0408','',NULL,1,0,1,'Ram Yekbal Yadav',NULL,'SCJ','2015-03-24',4,6,NULL,89,204,376,13,3,1,204,1,'2015-03-24 10:58:37','2015-03-24 10:58:37',0,'2015-03-24 00:00:00'),(14,'scj-2064-wo-0826','',NULL,0,1,0,'bal krishna koirala',NULL,'awakash umer nagarikta','2015-03-26',4,6,NULL,89,204,376,13,3,1,204,1,'2015-03-26 05:19:22','2015-06-02 08:54:10',0,'2015-03-26 00:00:00'),(15,'dainik bhrman bhatta biniyamawali','',NULL,0,1,0,'BNYM',NULL,'Braman bhatta','2015-03-27',4,6,NULL,89,204,376,13,3,1,204,1,'2015-03-27 05:33:53','2015-06-26 07:00:09',0,'2015-03-27 00:00:00'),(19,'Pro_002','Core i5',NULL,0,1,0,'Desktop',NULL,'','2015-05-31',4,5,NULL,119,175,377,13,3,1,175,1,'2015-05-31 06:28:27','2015-05-31 06:51:09',0,'2015-05-31 00:00:00'),(17,'scj-2067-wo-829','',NULL,1,0,1,'kamal',NULL,'badhuwa biniyam nagarikta','2015-03-27',4,6,NULL,89,214,376,13,3,1,214,1,'2015-03-27 08:12:09','2015-03-27 08:12:09',0,'2015-03-27 00:00:00');
/*!40000 ALTER TABLE `gdoc_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_documents_approvals`
--

DROP TABLE IF EXISTS `gdoc_documents_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_documents_approvals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `security_rule_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_documents_approvals`
--

LOCK TABLES `gdoc_documents_approvals` WRITE;
/*!40000 ALTER TABLE `gdoc_documents_approvals` DISABLE KEYS */;
INSERT INTO `gdoc_documents_approvals` (`id`, `security_rule_id`, `document_id`) VALUES (1,1,5),(2,1,6),(3,1,7),(4,1,8),(5,1,9),(7,1,11),(8,1,12),(9,1,13),(12,1,16),(13,1,17),(14,1,18);
/*!40000 ALTER TABLE `gdoc_documents_approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_documents_attributes`
--

DROP TABLE IF EXISTS `gdoc_documents_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_documents_attributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_documents_attributes`
--

LOCK TABLES `gdoc_documents_attributes` WRITE;
/*!40000 ALTER TABLE `gdoc_documents_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `gdoc_documents_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_documents_categories`
--

DROP TABLE IF EXISTS `gdoc_documents_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_documents_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_documents_categories`
--

LOCK TABLES `gdoc_documents_categories` WRITE;
/*!40000 ALTER TABLE `gdoc_documents_categories` DISABLE KEYS */;
INSERT INTO `gdoc_documents_categories` (`id`, `document_id`, `category_id`) VALUES (11,21,3),(2,10,2),(10,20,3),(4,12,2),(5,13,3),(6,14,2),(8,17,2);
/*!40000 ALTER TABLE `gdoc_documents_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_documents_types`
--

DROP TABLE IF EXISTS `gdoc_documents_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_documents_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=378 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_documents_types`
--

LOCK TABLES `gdoc_documents_types` WRITE;
/*!40000 ALTER TABLE `gdoc_documents_types` DISABLE KEYS */;
INSERT INTO `gdoc_documents_types` (`id`, `name`, `active`, `created`, `updated`, `created_by`) VALUES (376,'PDF',1,'2015-03-17 13:56:08','2015-03-17 08:56:08',204),(377,'JPEG',1,'2015-03-17 16:01:25','2015-03-17 11:02:46',204);
/*!40000 ALTER TABLE `gdoc_documents_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_languages`
--

DROP TABLE IF EXISTS `gdoc_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `code` varchar(32) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_languages`
--

LOCK TABLES `gdoc_languages` WRITE;
/*!40000 ALTER TABLE `gdoc_languages` DISABLE KEYS */;
INSERT INTO `gdoc_languages` (`id`, `name`, `code`, `created`, `updated`, `created_by`) VALUES (4,'Nepali','NP','0000-00-00 00:00:00',NULL,NULL),(9,'English','ENG','0000-00-00 00:00:00',NULL,NULL);
/*!40000 ALTER TABLE `gdoc_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_location_maps`
--

DROP TABLE IF EXISTS `gdoc_location_maps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_location_maps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location_type_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_location_maps`
--

LOCK TABLES `gdoc_location_maps` WRITE;
/*!40000 ALTER TABLE `gdoc_location_maps` DISABLE KEYS */;
INSERT INTO `gdoc_location_maps` (`id`, `name`, `description`, `location_type_id`, `parent_id`, `lft`, `rght`, `created`, `updated`, `created_by`) VALUES (1,'Kathmandu','Region',15,NULL,1,12,'2015-03-23 08:58:41','2015-03-23 08:58:41',204),(2,'Durbarmarg','',17,1,2,3,'2015-03-23 08:59:19','2015-03-23 08:59:19',204),(3,'Chabahil','',17,1,4,5,'2015-03-23 08:59:47','2015-03-23 08:59:47',204),(4,'Baneshwor','',17,1,6,11,'2015-03-23 09:01:10','2015-03-23 09:01:10',204),(6,'Dharan','Region',15,NULL,13,14,'2015-03-23 09:03:09','2015-03-23 09:03:09',204),(7,'Store 1','Store',17,4,7,10,'2015-06-28 15:13:39','2015-06-28 10:13:39',175),(8,'Rack','',1,7,8,9,'2015-06-28 15:13:56','2015-06-28 10:14:58',175);
/*!40000 ALTER TABLE `gdoc_location_maps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_location_types`
--

DROP TABLE IF EXISTS `gdoc_location_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_location_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(24) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_location_types`
--

LOCK TABLES `gdoc_location_types` WRITE;
/*!40000 ALTER TABLE `gdoc_location_types` DISABLE KEYS */;
INSERT INTO `gdoc_location_types` (`id`, `name`, `created`, `updated`, `created_by`) VALUES (1,'Cabinate','0000-00-00 00:00:00',NULL,NULL),(4,'Box. No.','0000-00-00 00:00:00','2014-06-17 06:15:59',175),(5,'File Carrier','0000-00-00 00:00:00',NULL,NULL),(13,'Floor','0000-00-00 00:00:00',NULL,NULL),(17,'Building','0000-00-00 00:00:00',NULL,NULL),(37,'Postal Box No.','0000-00-00 00:00:00',NULL,NULL),(15,'Region','2014-07-01 09:22:33',NULL,NULL);
/*!40000 ALTER TABLE `gdoc_location_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_menus`
--

DROP TABLE IF EXISTS `gdoc_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `value` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_menus`
--

LOCK TABLES `gdoc_menus` WRITE;
/*!40000 ALTER TABLE `gdoc_menus` DISABLE KEYS */;
INSERT INTO `gdoc_menus` (`id`, `field`, `name`, `value`) VALUES (1,'sidebar_actions','Sidebar Actions',1),(2,'sidebar_catalogue','Sidebar Catalogue',1),(3,'sidebar_search','Sidebar Search',1),(4,'sidebar_report','Sidebar Report',1),(5,'sidebar_management','Sidebar Management',1),(6,'sidebar_settings','Sidebar Settings',1),(7,'security_field','Security Field',0),(8,'send_for_approval_field','Approval Field',0),(9,'document_list','Document List Dashboard And Index',1),(10,'email_notification','Email Notification',1),(11,'ownership_transfer','Ownership Transfer in Document',1),(12,'document_edit','Document Edit (mainly for approval process)',1);
/*!40000 ALTER TABLE `gdoc_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_perm`
--

DROP TABLE IF EXISTS `gdoc_perm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_perm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` varchar(255) NOT NULL,
  `level_id` int(11) NOT NULL,
  `access_id` int(11) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `allow` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4911 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_perm`
--

LOCK TABLES `gdoc_perm` WRITE;
/*!40000 ALTER TABLE `gdoc_perm` DISABLE KEYS */;
INSERT INTO `gdoc_perm` (`id`, `level`, `level_id`, `access_id`, `department_id`, `allow`) VALUES (4170,'Role',7,9,NULL,1),(4171,'Role',7,11,NULL,1),(4602,'User',204,13,NULL,1),(4827,'User',216,11,NULL,1),(4818,'Role',2,11,NULL,1),(4817,'Role',2,9,NULL,1),(4816,'Role',2,8,NULL,1),(4815,'Role',2,6,NULL,1),(4857,'User',175,6,NULL,1),(2690,'Role',1,13,NULL,1),(4901,'User',217,9,37,1),(4887,'User',214,3,NULL,1),(4223,'Role',3,7,NULL,1),(4224,'Role',3,8,NULL,1),(4225,'Role',3,9,NULL,1),(4226,'Role',3,11,NULL,1),(4859,'User',175,4,NULL,1),(4168,'Role',7,5,NULL,1),(4222,'Role',3,5,NULL,1),(1398,'Role',1,12,NULL,1),(1397,'Role',1,11,NULL,1),(1396,'Role',1,10,NULL,1),(1395,'Role',1,9,NULL,1),(1394,'Role',1,8,NULL,1),(1393,'Role',1,7,NULL,1),(1392,'Role',1,6,NULL,1),(1391,'Role',1,5,NULL,1),(1390,'Role',1,4,NULL,1),(1389,'Role',1,3,NULL,1),(1388,'Role',1,2,NULL,1),(1387,'Role',1,1,NULL,1),(4884,'User',214,6,NULL,1),(4885,'User',214,5,NULL,1),(4886,'User',214,4,NULL,1),(4872,'User',217,11,NULL,1),(4169,'Role',7,6,NULL,1),(4897,'User',159,9,37,1),(4894,'User',159,9,35,1),(4856,'User',175,7,NULL,1),(4861,'User',175,2,NULL,1),(4860,'User',175,3,NULL,1),(3111,'Role',1,14,NULL,1),(4900,'User',217,8,37,1),(4883,'User',214,8,NULL,1),(4871,'User',159,9,13,1),(4870,'User',159,6,NULL,1),(4869,'User',159,5,NULL,1),(4617,'User',204,9,10,1),(4616,'User',204,8,10,1),(4661,'User',215,8,13,1),(4834,'User',215,8,NULL,1),(4615,'User',204,14,NULL,1),(4614,'User',204,1,NULL,1),(4613,'User',204,2,NULL,1),(4612,'User',204,3,NULL,1),(4611,'User',204,4,NULL,1),(4610,'User',204,5,NULL,1),(4609,'User',204,6,NULL,1),(4608,'User',204,7,NULL,1),(4607,'User',204,8,NULL,1),(4606,'User',204,9,NULL,1),(4605,'User',204,10,NULL,1),(4604,'User',204,11,NULL,1),(4603,'User',204,12,NULL,1),(4662,'User',215,9,13,1),(4858,'User',175,5,NULL,1),(4891,'User',214,9,13,1),(4890,'User',214,8,13,1),(4650,'User',204,8,13,1),(4651,'User',204,9,13,1),(4829,'User',215,2,NULL,1),(4830,'User',215,3,NULL,1),(4831,'User',215,4,NULL,1),(4832,'User',215,5,NULL,1),(4833,'User',215,6,NULL,1),(4820,'User',216,2,NULL,1),(4821,'User',216,3,NULL,1),(4822,'User',216,4,NULL,1),(4823,'User',216,5,NULL,1),(4824,'User',216,6,NULL,1),(4862,'User',175,1,NULL,1),(4855,'User',175,8,NULL,1),(4854,'User',175,9,NULL,1),(4853,'User',175,10,NULL,1),(4852,'User',175,11,NULL,1),(4851,'User',175,12,NULL,1),(4850,'User',175,13,NULL,1),(4825,'User',216,8,NULL,1),(4826,'User',216,9,NULL,1),(4814,'Role',2,5,NULL,1),(4813,'Role',2,4,NULL,1),(4812,'Role',2,3,NULL,1),(4811,'Role',2,2,NULL,1),(4810,'Role',2,1,NULL,1),(4819,'User',216,1,NULL,1),(4828,'User',215,1,NULL,1),(4888,'User',214,2,NULL,1),(4889,'User',214,1,NULL,1),(4835,'User',215,9,NULL,1),(4836,'User',215,11,NULL,1),(4868,'User',159,11,NULL,1),(4867,'User',159,9,NULL,1),(4882,'User',214,9,NULL,1),(4881,'User',214,11,NULL,1),(4863,'User',175,14,NULL,1),(4864,'User',175,8,13,1),(4865,'User',175,9,13,1),(4866,'User',175,9,35,1),(4873,'User',217,9,NULL,1),(4874,'User',217,8,NULL,1),(4875,'User',217,6,NULL,1),(4876,'User',217,5,NULL,1),(4877,'User',217,4,NULL,1),(4878,'User',217,3,NULL,1),(4879,'User',217,2,NULL,1),(4880,'User',217,1,NULL,1),(4902,'User',218,11,NULL,1),(4903,'User',218,9,NULL,1),(4904,'User',218,8,NULL,1),(4905,'User',218,6,NULL,1),(4906,'User',218,5,NULL,1),(4907,'User',218,4,NULL,1),(4908,'User',218,3,NULL,1),(4909,'User',218,2,NULL,1),(4910,'User',218,1,NULL,1);
/*!40000 ALTER TABLE `gdoc_perm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_security_levels`
--

DROP TABLE IF EXISTS `gdoc_security_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_security_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_security_levels`
--

LOCK TABLES `gdoc_security_levels` WRITE;
/*!40000 ALTER TABLE `gdoc_security_levels` DISABLE KEYS */;
INSERT INTO `gdoc_security_levels` (`id`, `level`, `created`, `modified`, `updated`) VALUES (1,1,'2014-06-02 00:00:00','2014-06-02 00:00:00','2014-06-02 00:00:00'),(2,2,'2014-06-02 00:00:00','2014-06-02 00:00:00','2014-06-02 00:00:00'),(3,3,'2014-06-02 00:00:00','2014-06-02 00:00:00','2014-06-02 00:00:00'),(7,5,'2014-06-02 00:00:00','2014-06-02 00:00:00','2014-06-02 00:00:00'),(6,4,'2014-06-02 00:00:00','2014-06-02 00:00:00','2014-06-02 00:00:00'),(8,6,'2014-06-02 00:00:00','2014-06-02 00:00:00','2014-06-02 00:00:00'),(9,7,'2014-06-02 00:00:00','2014-06-02 00:00:00','2014-06-02 00:00:00'),(10,8,'2014-06-02 00:00:00','2014-06-02 00:00:00','2014-06-02 00:00:00'),(11,9,'2014-06-02 00:00:00','2014-06-02 00:00:00','2014-06-02 00:00:00'),(12,10,'2014-06-02 00:00:00','2014-06-02 00:00:00','2014-06-02 00:00:00');
/*!40000 ALTER TABLE `gdoc_security_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_security_rules`
--

DROP TABLE IF EXISTS `gdoc_security_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_security_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `security_level_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `branch_id` (`branch_id`),
  KEY `department_id` (`department_id`),
  KEY `security_level_id` (`security_level_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_security_rules`
--

LOCK TABLES `gdoc_security_rules` WRITE;
/*!40000 ALTER TABLE `gdoc_security_rules` DISABLE KEYS */;
INSERT INTO `gdoc_security_rules` (`id`, `user_id`, `branch_id`, `department_id`, `security_level_id`, `created`, `updated`, `created_by`) VALUES (22,159,116,3,3,'2015-03-13 11:30:08','2015-03-13 06:30:08',175),(21,204,89,10,1,'2015-01-08 15:53:26','2015-01-08 09:53:26',175),(18,204,89,13,2,'2014-12-11 09:50:41','2014-12-11 03:50:41',175);
/*!40000 ALTER TABLE `gdoc_security_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_settings`
--

DROP TABLE IF EXISTS `gdoc_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_settings`
--

LOCK TABLES `gdoc_settings` WRITE;
/*!40000 ALTER TABLE `gdoc_settings` DISABLE KEYS */;
INSERT INTO `gdoc_settings` (`id`, `field`, `value`, `created`, `updated`, `created_by`) VALUES (1,'Company Name','Nepal Electricity Authority','0000-00-00 00:00:00','2015-03-17 08:37:17',204),(2,'Watermark','NEA','0000-00-00 00:00:00','2015-03-17 08:36:51',204);
/*!40000 ALTER TABLE `gdoc_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_statuses`
--

DROP TABLE IF EXISTS `gdoc_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `model` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_statuses`
--

LOCK TABLES `gdoc_statuses` WRITE;
/*!40000 ALTER TABLE `gdoc_statuses` DISABLE KEYS */;
INSERT INTO `gdoc_statuses` (`id`, `name`, `model`) VALUES (1,'Active','User'),(3,'Available','Document'),(4,'Lost','Document'),(5,'Borrowed','Document'),(6,'Reference','Document'),(11,'Reserved','Document'),(9,'Expired','User'),(10,'Blocked','User'),(12,'Lend','Document'),(13,'Cancelled','Document'),(14,'Pending','Document'),(15,'Disposed','Address'),(21,'Disposed','Document'),(22,'Inactive','User');
/*!40000 ALTER TABLE `gdoc_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_uploads`
--

DROP TABLE IF EXISTS `gdoc_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(25) DEFAULT NULL,
  `field` varchar(25) DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `caption` tinyint(1) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_key` (`foreign_key`)
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_uploads`
--

LOCK TABLES `gdoc_uploads` WRITE;
/*!40000 ALTER TABLE `gdoc_uploads` DISABLE KEYS */;
INSERT INTO `gdoc_uploads` (`id`, `model`, `field`, `foreign_key`, `caption`, `name`, `type`, `size`, `created`, `updated`, `created_by`) VALUES (4,'Document','Attachment',1,0,'scj-2065-w0-190.pdf','application/pdf',423966,'2015-03-18 11:04:00','2015-03-18 06:04:00',NULL),(12,'Document','Attachment',3,0,'scj-2065-w0-0207.pdf','application/pdf',485408,'2015-03-18 11:11:04','2015-03-18 06:11:04',NULL),(16,'Document','Attachment',4,0,'law_002.jpg','image/jpeg',242344,'2015-03-19 14:50:34','2015-03-19 09:50:34',NULL),(39,'Document','Attachment',10,0,'scj-2065-wo-0190a.pdf','application/pdf',331805,'2015-03-24 09:17:32','2015-03-24 09:17:32',NULL),(46,'Document','Attachment',12,0,'scj-2069-wo-1169.pdf','application/pdf',1521086,'2015-03-24 10:52:03','2015-03-24 10:52:03',NULL),(50,'Document','Attachment',13,0,'scj-2071-wo-0408.pdf','application/pdf',1839295,'2015-03-24 10:58:38','2015-03-24 10:58:38',NULL),(54,'Document','Attachment',14,0,'scj-2064-wo-0826.pdf','application/pdf',322999,'2015-03-26 05:19:23','2015-03-26 05:19:23',NULL),(58,'Document','Attachment',15,0,'dainik-bhrman-bhatta-biniyamawali.pdf','application/pdf',564979,'2015-03-27 05:33:54','2015-03-27 05:33:54',NULL),(76,'Document','Attachment',19,0,'pro_002-1.png','image/png',716883,'2015-05-31 06:37:17','2015-05-31 06:37:17',NULL),(75,'Document','Attachment',19,0,'pro_002.png','image/png',716883,'2015-05-31 06:32:41','2015-05-31 06:32:41',NULL),(66,'Document','Attachment',17,0,'scj-2067-wo-829-1.pdf','application/pdf',219165,'2015-03-27 08:12:10','2015-03-27 08:12:10',NULL),(74,'Document','Attachment',19,0,'pro_002.jpg','image/jpeg',9174,'2015-05-31 06:28:28','2015-05-31 06:28:28',NULL),(73,NULL,NULL,19,NULL,NULL,NULL,NULL,'2015-05-31 06:28:27',NULL,NULL),(71,NULL,NULL,19,NULL,NULL,NULL,NULL,'2015-05-31 06:28:27','2015-05-31 06:28:27',NULL),(72,NULL,NULL,19,NULL,NULL,NULL,NULL,'2015-05-31 06:28:27',NULL,NULL),(77,'Document','Attachment',2,0,'scj-2055-rit-no-3405.png','image/png',716883,'2015-06-02 13:33:47','2015-06-02 08:33:47',NULL),(78,'Document','Attachment',2,0,'scj-2055-rit-no-3405-1.png','image/png',716883,'2015-06-02 13:49:04','2015-06-02 08:49:04',NULL),(90,'Document','Attachment',20,0,'1234.jpg','image/jpeg',561276,'2015-06-12 14:57:36','2015-06-12 09:57:36',NULL),(89,'Document','Attachment',20,0,'1234.pdf','application/pdf',7945,'2015-06-12 14:55:35','2015-06-12 09:55:35',NULL),(87,NULL,NULL,20,NULL,NULL,NULL,NULL,'2015-06-12 09:55:35',NULL,NULL),(88,NULL,NULL,20,NULL,NULL,NULL,NULL,'2015-06-12 09:55:35',NULL,NULL),(85,'User','Avatar',175,1,'saakshi-agrawal.jpg','image/jpeg',879394,'2015-06-12 13:43:38','2015-06-12 08:43:38',NULL),(86,'Document','CaptionImage',20,1,'test.jpg','image/jpeg',620888,'2015-06-12 14:55:35','2015-06-12 09:55:35',NULL),(92,'Document','Attachment',15,0,'dainik-bhrman-bhatta-biniyamawali.jpg','image/jpeg',620888,'2015-06-26 12:00:07','2015-06-26 07:00:07',NULL),(93,'User','Avatar',214,1,'manoj-1.jpg','image/jpeg',5733,'2015-07-16 09:59:21','2015-07-16 04:59:21',NULL),(94,NULL,NULL,21,NULL,NULL,NULL,NULL,'2015-07-16 12:19:08','2015-07-16 07:19:08',NULL),(95,NULL,NULL,21,NULL,NULL,NULL,NULL,'2015-07-16 07:19:08',NULL,NULL),(96,NULL,NULL,21,NULL,NULL,NULL,NULL,'2015-07-16 07:19:08',NULL,NULL),(97,'Document','Attachment',21,0,'ind4554.pdf','application/pdf',1033569,'2015-07-16 12:19:09','2015-07-16 07:19:09',NULL),(98,'Document','Attachment',21,0,'ind4554-1.pdf','application/pdf',610258,'2015-07-16 12:22:09','2015-07-16 07:22:09',NULL);
/*!40000 ALTER TABLE `gdoc_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_user_activity_details`
--

DROP TABLE IF EXISTS `gdoc_user_activity_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_user_activity_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  `option` varchar(500) NOT NULL,
  `activity_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `document_id` (`document_id`)
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_user_activity_details`
--

LOCK TABLES `gdoc_user_activity_details` WRITE;
/*!40000 ALTER TABLE `gdoc_user_activity_details` DISABLE KEYS */;
INSERT INTO `gdoc_user_activity_details` (`id`, `user_id`, `document_id`, `option`, `activity_date`) VALUES (1,214,1,'add','2015-03-18 06:04:00'),(2,214,2,'add','2015-03-18 06:08:55'),(3,214,3,'add','2015-03-18 06:11:04'),(4,214,4,'add','2015-03-19 09:50:33'),(5,175,5,'add','2015-03-23 07:08:14'),(6,214,6,'add','2015-03-23 08:01:40'),(7,214,7,'add','2015-03-23 08:05:06'),(8,214,6,'edit','2015-03-23 08:51:08'),(9,214,5,'edit','2015-03-23 08:51:14'),(10,214,7,'edit','2015-03-23 08:51:19'),(11,175,8,'add','2015-03-23 09:43:53'),(12,204,8,'edit','2015-03-23 10:00:11'),(13,204,4,'edit','2015-03-24 04:33:19'),(14,204,2,'edit','2015-03-24 04:47:09'),(15,204,9,'add','2015-03-24 09:11:05'),(16,204,9,'edit','2015-03-24 09:12:35'),(17,204,10,'add','2015-03-24 09:16:25'),(18,204,10,'edit','2015-03-24 09:17:32'),(19,214,11,'add','2015-03-24 10:33:56'),(20,204,11,'edit','2015-03-24 10:36:23'),(21,204,12,'add','2015-03-24 10:52:03'),(22,204,13,'add','2015-03-24 10:58:37'),(23,204,14,'add','2015-03-26 05:19:22'),(24,204,15,'add','2015-03-27 05:33:53'),(25,214,16,'add','2015-03-27 08:11:46'),(26,214,17,'add','2015-03-27 08:12:09'),(27,214,18,'add','2015-03-27 08:13:17'),(28,175,19,'add','2015-05-31 06:28:27'),(29,175,19,'edit','2015-05-31 06:32:44'),(30,175,19,'edit','2015-05-31 06:37:20'),(31,175,19,'edit','2015-05-31 06:43:30'),(32,175,19,'edit','2015-05-31 06:43:34'),(33,175,19,'edit','2015-05-31 06:43:36'),(34,175,19,'edit','2015-05-31 06:43:39'),(35,175,19,'edit','2015-05-31 06:43:41'),(36,175,19,'edit','2015-05-31 06:43:46'),(37,175,19,'edit','2015-05-31 06:43:51'),(38,175,19,'edit','2015-05-31 06:43:53'),(39,175,19,'edit','2015-05-31 06:43:56'),(40,175,19,'edit','2015-05-31 06:43:58'),(41,175,19,'edit','2015-05-31 06:44:01'),(42,175,19,'edit','2015-05-31 06:44:04'),(43,175,19,'edit','2015-05-31 06:44:08'),(44,175,19,'edit','2015-05-31 06:44:11'),(45,175,19,'edit','2015-05-31 06:44:14'),(46,175,19,'edit','2015-05-31 06:44:17'),(47,175,19,'edit','2015-05-31 06:44:19'),(48,175,19,'edit','2015-05-31 06:44:22'),(49,175,19,'edit','2015-05-31 06:44:26'),(50,175,19,'edit','2015-05-31 06:44:28'),(51,175,19,'edit','2015-05-31 06:50:15'),(52,175,19,'edit','2015-05-31 06:50:19'),(53,175,19,'edit','2015-05-31 06:50:22'),(54,175,19,'edit','2015-05-31 06:50:25'),(55,175,19,'edit','2015-05-31 06:50:28'),(56,175,19,'edit','2015-05-31 06:50:31'),(57,175,19,'edit','2015-05-31 06:50:33'),(58,175,19,'edit','2015-05-31 06:50:36'),(59,175,19,'edit','2015-05-31 06:50:38'),(60,175,19,'edit','2015-05-31 06:50:40'),(61,175,19,'edit','2015-05-31 06:50:43'),(62,175,19,'edit','2015-05-31 06:50:46'),(63,175,19,'edit','2015-05-31 06:50:48'),(64,175,19,'edit','2015-05-31 06:50:53'),(65,175,19,'edit','2015-05-31 06:50:56'),(66,175,19,'edit','2015-05-31 06:50:58'),(67,175,19,'edit','2015-05-31 06:51:01'),(68,175,19,'edit','2015-05-31 06:51:03'),(69,175,19,'edit','2015-05-31 06:51:06'),(70,175,19,'edit','2015-05-31 06:51:09'),(71,175,2,'edit','2015-06-02 08:33:49'),(72,175,2,'edit','2015-06-02 08:49:07'),(73,175,2,'edit','2015-06-02 08:49:33'),(74,175,14,'edit','2015-06-02 08:50:00'),(75,175,14,'edit','2015-06-02 08:51:14'),(76,175,14,'edit','2015-06-02 08:52:20'),(77,175,14,'edit','2015-06-02 08:53:02'),(78,175,14,'edit','2015-06-02 08:54:10'),(79,175,3,'edit','2015-06-02 09:03:34'),(80,175,20,'add','2015-06-12 09:55:35'),(81,175,20,'edit','2015-06-12 09:57:38'),(82,175,15,'edit','2015-06-26 07:00:09'),(83,217,21,'add','2015-07-16 07:19:08'),(84,217,21,'edit','2015-07-16 07:19:26'),(85,217,21,'edit','2015-07-16 07:22:09');
/*!40000 ALTER TABLE `gdoc_user_activity_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_user_roles`
--

DROP TABLE IF EXISTS `gdoc_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_user_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `inbuilt` tinyint(1) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_user_roles`
--

LOCK TABLES `gdoc_user_roles` WRITE;
/*!40000 ALTER TABLE `gdoc_user_roles` DISABLE KEYS */;
INSERT INTO `gdoc_user_roles` (`id`, `name`, `inbuilt`, `created`, `updated`, `created_by`) VALUES (1,'System Administrator',1,'0000-00-00 00:00:00',NULL,NULL),(2,'Administrator',0,'0000-00-00 00:00:00','2015-06-26 08:55:58',175),(3,'Staff',0,'0000-00-00 00:00:00','2015-01-12 07:32:17',175),(7,'Viewer',0,'0000-00-00 00:00:00','2015-01-08 09:35:54',204);
/*!40000 ALTER TABLE `gdoc_user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdoc_users`
--

DROP TABLE IF EXISTS `gdoc_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdoc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identity_no` varchar(32) DEFAULT NULL,
  `username` varchar(99) DEFAULT NULL,
  `password` varchar(99) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `url` varchar(32) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `street` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(99) NOT NULL,
  `postal_code` varchar(25) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `notes` text,
  `designation` varchar(250) NOT NULL,
  `date_registered` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `signup_ip` varchar(15) DEFAULT NULL,
  `secure_password` tinyint(1) NOT NULL,
  `strong_password` tinyint(1) NOT NULL,
  `login_attempts` int(11) NOT NULL,
  `expire_password` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`),
  KEY `role_id` (`role_id`),
  KEY `branch_id` (`branch_id`)
) ENGINE=MyISAM AUTO_INCREMENT=219 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdoc_users`
--

LOCK TABLES `gdoc_users` WRITE;
/*!40000 ALTER TABLE `gdoc_users` DISABLE KEYS */;
INSERT INTO `gdoc_users` (`id`, `identity_no`, `username`, `password`, `name`, `url`, `gender`, `date_of_birth`, `street`, `city`, `country`, `postal_code`, `phone`, `email`, `website`, `notes`, `designation`, `date_registered`, `expiry_date`, `status_id`, `role_id`, `branch_id`, `signup_ip`, `secure_password`, `strong_password`, `login_attempts`, `expire_password`, `created`, `updated`, `created_by`) VALUES (175,'GENTECH','superadmin@generaldoc.com','f03cceb20d9e4bc1c22e82a772e6e931e9084da7','Super Admin','saakshi-agrawal','2','1991-02-25','','','Nepal','','98765478','','',NULL,'','2014-04-30','2016-08-31',1,1,119,'202.63.242.180',0,0,10,0,'0000-00-00 00:00:00','2015-07-16 04:41:04',175),(159,'USR150','saruita@hotmail.com','466162e374482ee89f18cc4614186b6b590dee5b','Sarita Shakya','sarita-shakya','2',NULL,'','Kathmandu','Nepal','','+977','','',NULL,'Manager','2014-04-22','2017-04-30',1,7,119,'110.44.117.87',0,0,2,0,'0000-00-00 00:00:00','2015-08-02 05:35:04',175),(204,'NBB0004','sanjay@generaldoc.com','466162e374482ee89f18cc4614186b6b590dee5b','Sanjay','ratna-tara-baidhya','1',NULL,'Kamaladi','Kathmandu','Nepal','','+977','','',NULL,'IT Chief','2014-12-04','2015-09-30',22,1,89,'202.70.79.61',1,1,4,0,'2014-12-08 09:56:35','2015-06-18 04:36:12',204),(214,'NEA_001','manoj@generaldoc.com','8d9185a1ec96014d0aa6f71a5deeb182be40d629','Manoj','manoj-1','1',NULL,'','','Nepal','','+977','','',NULL,'System','2015-03-12','2015-04-30',1,2,122,'110.44.117.87',0,0,0,0,'2015-03-12 12:07:14','2015-07-16 04:59:21',175),(215,'NEA_003','dhurba@generaldoc.com','8d9185a1ec96014d0aa6f71a5deeb182be40d629','Dhurba Raj Bhatta','dhurba-raj-bhatta','1',NULL,'','Kathmandu','Nepal','','+977','','',NULL,'Law','2015-03-15','2015-04-30',22,2,89,'202.70.79.61',0,0,0,0,'2015-03-15 14:46:07','2015-03-15 09:46:07',204),(216,'NEA1500','admin@generaldoc.com','466162e374482ee89f18cc4614186b6b590dee5b','Administrator','administrator','1','2014-08-04','','','Nepal','','01-5551007','','',NULL,'','2015-03-01','2019-12-31',1,2,NULL,'110.44.117.16',0,0,0,0,'2015-03-22 05:36:17','2015-08-02 05:37:38',175),(217,'IND5423','surajnepal@generaldoc.com','f03cceb20d9e4bc1c22e82a772e6e931e9084da7','Surja Nepal','surja-nepal','1','1989-02-14','Sanepa','Lalitpur','Nepal','00000','9851061548','','',NULL,'','2015-07-16','2019-07-17',1,2,119,'110.44.117.87',0,0,0,0,'2015-07-16 09:55:17','2015-07-16 06:14:40',175),(218,'BS_001','beema@generaldoc.com','3e1742dffce53f5877b71380e67a40240deef9bf','Beema','beema','1',NULL,'','Kathmandu','Nepal','','+977','','',NULL,'Admin','2015-08-02','2015-09-30',1,2,119,'27.34.65.232',0,0,0,0,'2015-08-02 10:41:17','2015-08-02 05:41:17',216);
/*!40000 ALTER TABLE `gdoc_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'oopsnepa_generaldoc'
--

--
-- Dumping routines for database 'oopsnepa_generaldoc'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-08-03  2:51:40
