-- MySQL dump 10.13  Distrib 5.5.42, for Linux (x86_64)
--
-- Host: localhost    Database: trishuli_bidding
-- ------------------------------------------------------
-- Server version	5.5.42-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acos`
--

DROP TABLE IF EXISTS `acos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=934 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acos`
--

LOCK TABLES `acos` WRITE;
/*!40000 ALTER TABLE `acos` DISABLE KEYS */;
INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES (1,NULL,'APP',NULL,'Controller',1,1866),(39,1,'Plugin',NULL,'FileUpload',76,85),(41,1,'Plugin',NULL,'PhpExcel',86,87),(42,1,'Plugin',NULL,'SuperAdmin',88,145),(495,494,'Action',NULL,'admin_add',1013,1014),(494,1,'Controller',NULL,'ApproveLevels',1012,1025),(493,469,'Action',NULL,'routeCache',1009,1010),(492,469,'Action',NULL,'return_navigations',1007,1008),(491,469,'Action',NULL,'return_main_nav',1005,1006),(490,469,'Action',NULL,'get_plugin_sub_nav',1003,1004),(489,469,'Action',NULL,'get_plugin_main_nav',1001,1002),(488,469,'Action',NULL,'getAddress',999,1000),(487,469,'Action',NULL,'daysOfWeek',997,998),(486,469,'Action',NULL,'createZip',995,996),(485,469,'Action',NULL,'beforeRender',993,994),(484,469,'Action',NULL,'beforeFilter',991,992),(483,469,'Action',NULL,'beforeFacebookSave',989,990),(482,469,'Action',NULL,'beforeFacebookLogin',987,988),(481,469,'Action',NULL,'appendTags',985,986),(480,469,'Action',NULL,'afterFacebookLogin',983,984),(479,469,'Action',NULL,'_uploadBehavior',981,982),(478,469,'Action',NULL,'_relatedUpload',979,980),(477,469,'Action',NULL,'_pictureCrop',977,978),(476,469,'Action',NULL,'_get_facebook_cookie',975,976),(475,469,'Action',NULL,'_getDifference',973,974),(474,469,'Action',NULL,'_getAddress',971,972),(473,469,'Action',NULL,'_deleteUpload',969,970),(472,469,'Action',NULL,'_array_sort',967,968),(471,469,'Action',NULL,'__loadPlugin',965,966),(470,469,'Action',NULL,'__loadConfig',963,964),(469,1,'Controller',NULL,'App',962,1011),(862,578,'Action',NULL,'delete',1205,1206),(876,1,'Controller',NULL,'Currencies',1826,1839),(868,756,'Action',NULL,'delete',1599,1600),(867,727,'Action',NULL,'delete',1509,1510),(866,692,'Action',NULL,'delete',1447,1448),(865,647,'Action',NULL,'delete',1349,1350),(864,619,'Action',NULL,'delete',1307,1308),(863,601,'Action',NULL,'delete',1273,1274),(496,494,'Action',NULL,'admin_delete',1015,1016),(497,494,'Action',NULL,'admin_edit',1017,1018),(498,494,'Action',NULL,'admin_index',1019,1020),(499,494,'Action',NULL,'admin_save',1021,1022),(500,494,'Action',NULL,'beforeFilter',1023,1024),(501,1,'Controller',NULL,'Articles',1026,1035),(502,501,'Action',NULL,'add',1027,1028),(503,501,'Action',NULL,'article',1029,1030),(504,501,'Action',NULL,'beforeFilter',1031,1032),(505,501,'Action',NULL,'index',1033,1034),(506,1,'Controller',NULL,'Attributes',1036,1049),(507,506,'Action',NULL,'admin_add',1037,1038),(508,506,'Action',NULL,'admin_delete',1039,1040),(509,506,'Action',NULL,'admin_edit',1041,1042),(510,506,'Action',NULL,'admin_index',1043,1044),(511,506,'Action',NULL,'admin_save',1045,1046),(512,506,'Action',NULL,'beforeFilter',1047,1048),(513,1,'Controller',NULL,'Bids',1050,1073),(514,513,'Action',NULL,'admin_bid_compare',1051,1052),(515,513,'Action',NULL,'admin_compare',1053,1054),(516,513,'Action',NULL,'admin_view',1055,1056),(517,513,'Action',NULL,'beforeFilter',1057,1058),(518,513,'Action',NULL,'edit',1059,1060),(519,513,'Action',NULL,'tender_bids',1061,1062),(520,513,'Action',NULL,'view',1063,1064),(521,1,'Controller',NULL,'Businesses',1074,1157),(522,521,'Action',NULL,'_businessInfo',1075,1076),(523,521,'Action',NULL,'_clicked',1077,1078),(524,521,'Action',NULL,'_email_confirm',1079,1080),(525,521,'Action',NULL,'_selectBoxes',1081,1082),(526,521,'Action',NULL,'admin_delete',1083,1084),(527,521,'Action',NULL,'admin_export',1085,1086),(528,521,'Action',NULL,'admin_getList',1087,1088),(529,521,'Action',NULL,'admin_index',1089,1090),(530,521,'Action',NULL,'autoComplete',1091,1092),(531,521,'Action',NULL,'autoCompleteFill',1093,1094),(532,521,'Action',NULL,'beforeFilter',1095,1096),(533,521,'Action',NULL,'business',1097,1098),(534,521,'Action',NULL,'business_related',1099,1100),(535,521,'Action',NULL,'claim',1101,1102),(536,521,'Action',NULL,'claimStatus',1103,1104),(537,521,'Action',NULL,'compare',1105,1106),(538,521,'Action',NULL,'confirm',1107,1108),(539,521,'Action',NULL,'email2fren',1109,1110),(540,521,'Action',NULL,'featuredBusiness',1111,1112),(541,521,'Action',NULL,'fillAddress',1113,1114),(542,521,'Action',NULL,'getAddress',1115,1116),(543,521,'Action',NULL,'getAddressList',1117,1118),(544,521,'Action',NULL,'getBusinessList',1119,1120),(545,521,'Action',NULL,'getChildTags',1121,1122),(546,521,'Action',NULL,'getGeocode',1123,1124),(547,521,'Action',NULL,'gpos_edit',1125,1126),(548,521,'Action',NULL,'gpos_view',1127,1128),(549,521,'Action',NULL,'guidelines',1129,1130),(550,521,'Action',NULL,'homeCategoryBusinessMap',1131,1132),(551,521,'Action',NULL,'homeCategoryBusinesses',1133,1134),(552,521,'Action',NULL,'imageCaption',1135,1136),(553,521,'Action',NULL,'imageDelete',1137,1138),(554,521,'Action',NULL,'index',1139,1140),(555,521,'Action',NULL,'jasonEncode',1141,1142),(556,521,'Action',NULL,'listUpdate',1143,1144),(557,521,'Action',NULL,'membership',1145,1146),(558,521,'Action',NULL,'removeDegree',1147,1148),(559,521,'Action',NULL,'save',1149,1150),(560,521,'Action',NULL,'statusUpdate',1151,1152),(561,521,'Action',NULL,'upload',1153,1154),(562,1,'Controller',NULL,'Categories',1158,1189),(563,562,'Action',NULL,'_clicked',1159,1160),(564,562,'Action',NULL,'admin_add',1161,1162),(565,562,'Action',NULL,'admin_delete',1163,1164),(566,562,'Action',NULL,'admin_edit',1165,1166),(567,562,'Action',NULL,'admin_index',1167,1168),(568,562,'Action',NULL,'admin_locTree',1169,1170),(569,562,'Action',NULL,'admin_move',1171,1172),(570,562,'Action',NULL,'admin_save',1173,1174),(571,562,'Action',NULL,'admin_treeUpdate',1175,1176),(572,562,'Action',NULL,'beforeFilter',1177,1178),(573,562,'Action',NULL,'category_select',1179,1180),(574,562,'Action',NULL,'display_categories',1181,1182),(575,562,'Action',NULL,'index',1183,1184),(576,562,'Action',NULL,'jasonEncode',1185,1186),(577,562,'Action',NULL,'test',1187,1188),(578,1,'Controller',NULL,'Classifieds',1190,1207),(579,578,'Action',NULL,'add',1191,1192),(580,578,'Action',NULL,'beforeFilter',1193,1194),(581,578,'Action',NULL,'contactperson',1195,1196),(582,578,'Action',NULL,'edit',1197,1198),(583,578,'Action',NULL,'email',1199,1200),(584,578,'Action',NULL,'index',1201,1202),(585,578,'Action',NULL,'view',1203,1204),(586,1,'Controller',NULL,'Emails',1208,1231),(587,586,'Action',NULL,'__previewEmail',1209,1210),(588,586,'Action',NULL,'admin_add',1211,1212),(589,586,'Action',NULL,'admin_attach',1213,1214),(590,586,'Action',NULL,'admin_delete',1215,1216),(591,586,'Action',NULL,'admin_edit',1217,1218),(592,586,'Action',NULL,'admin_email',1219,1220),(593,586,'Action',NULL,'admin_index',1221,1222),(594,586,'Action',NULL,'admin_preview',1223,1224),(595,586,'Action',NULL,'admin_save',1225,1226),(596,586,'Action',NULL,'beforeFilter',1227,1228),(597,586,'Action',NULL,'emailAttach',1229,1230),(598,1,'Controller',NULL,'Emergencies',1232,1237),(599,598,'Action',NULL,'beforeFilter',1233,1234),(600,598,'Action',NULL,'index',1235,1236),(601,1,'Controller',NULL,'Events',1238,1275),(602,601,'Action',NULL,'_clicked',1239,1240),(603,601,'Action',NULL,'add',1241,1242),(604,601,'Action',NULL,'admin_delete',1243,1244),(605,601,'Action',NULL,'admin_index',1245,1246),(606,601,'Action',NULL,'admin_view',1247,1248),(607,601,'Action',NULL,'beforeFilter',1249,1250),(608,601,'Action',NULL,'display_events',1251,1252),(609,601,'Action',NULL,'edit',1253,1254),(610,601,'Action',NULL,'email2fren',1255,1256),(611,601,'Action',NULL,'event',1257,1258),(612,601,'Action',NULL,'getBusinessAddress',1259,1260),(613,601,'Action',NULL,'imageCaption',1261,1262),(614,601,'Action',NULL,'imageDelete',1263,1264),(615,601,'Action',NULL,'index',1265,1266),(616,601,'Action',NULL,'jasonEncode',1267,1268),(617,601,'Action',NULL,'upload',1269,1270),(618,601,'Action',NULL,'view',1271,1272),(619,1,'Controller',NULL,'Expressions',1276,1309),(620,619,'Action',NULL,'_email_comments',1277,1278),(621,619,'Action',NULL,'_email_confirm',1279,1280),(622,619,'Action',NULL,'addComments',1281,1282),(623,619,'Action',NULL,'beforeFilter',1283,1284),(624,619,'Action',NULL,'deleteImage',1285,1286),(625,619,'Action',NULL,'deleteTag',1287,1288),(626,619,'Action',NULL,'express',1289,1290),(627,619,'Action',NULL,'expressedby',1291,1292),(628,619,'Action',NULL,'expression',1293,1294),(629,619,'Action',NULL,'getTags',1295,1296),(630,619,'Action',NULL,'homePageExpression',1297,1298),(631,619,'Action',NULL,'index',1299,1300),(632,619,'Action',NULL,'index1',1301,1302),(633,619,'Action',NULL,'likeDislike',1303,1304),(634,619,'Action',NULL,'tag',1305,1306),(635,1,'Controller',NULL,'Faqs',1310,1327),(636,635,'Action',NULL,'admin_add',1311,1312),(637,635,'Action',NULL,'admin_delete',1313,1314),(638,635,'Action',NULL,'admin_edit',1315,1316),(639,635,'Action',NULL,'admin_index',1317,1318),(640,635,'Action',NULL,'admin_save',1319,1320),(641,635,'Action',NULL,'beforeFilter',1321,1322),(642,635,'Action',NULL,'faq',1323,1324),(643,635,'Action',NULL,'faqCategory',1325,1326),(644,1,'Controller',NULL,'Fb',1328,1333),(645,644,'Action',NULL,'beforeFilter',1329,1330),(646,644,'Action',NULL,'index',1331,1332),(647,1,'Controller',NULL,'Ideas',1334,1351),(648,647,'Action',NULL,'add',1335,1336),(649,647,'Action',NULL,'addComments',1337,1338),(650,647,'Action',NULL,'beforeFilter',1339,1340),(651,647,'Action',NULL,'edit',1341,1342),(652,647,'Action',NULL,'index',1343,1344),(653,647,'Action',NULL,'likeDislike',1345,1346),(654,647,'Action',NULL,'postlist',1347,1348),(655,1,'Controller',NULL,'Invitations',1352,1361),(656,655,'Action',NULL,'admin_add',1353,1354),(657,655,'Action',NULL,'admin_cancel',1355,1356),(658,655,'Action',NULL,'admin_index',1357,1358),(659,655,'Action',NULL,'beforeFilter',1359,1360),(660,1,'Controller',NULL,'Keywords',1362,1375),(661,660,'Action',NULL,'admin_add',1363,1364),(662,660,'Action',NULL,'admin_delete',1365,1366),(663,660,'Action',NULL,'admin_edit',1367,1368),(664,660,'Action',NULL,'admin_index',1369,1370),(665,660,'Action',NULL,'admin_save',1371,1372),(666,660,'Action',NULL,'beforeFilter',1373,1374),(667,1,'Controller',NULL,'LocationMaps',1376,1403),(668,667,'Action',NULL,'addComments',1377,1378),(669,667,'Action',NULL,'admin_add',1379,1380),(670,667,'Action',NULL,'admin_delete',1381,1382),(671,667,'Action',NULL,'admin_edit',1383,1384),(672,667,'Action',NULL,'admin_index',1385,1386),(673,667,'Action',NULL,'admin_locTree',1387,1388),(674,667,'Action',NULL,'admin_move',1389,1390),(675,667,'Action',NULL,'admin_save',1391,1392),(676,667,'Action',NULL,'admin_treeUpdate',1393,1394),(677,667,'Action',NULL,'beforeFilter',1395,1396),(678,667,'Action',NULL,'edit',1397,1398),(679,667,'Action',NULL,'index',1399,1400),(680,667,'Action',NULL,'likeDislike',1401,1402),(681,1,'Controller',NULL,'Manufactures',1404,1409),(682,681,'Action',NULL,'beforeFilter',1405,1406),(683,681,'Action',NULL,'upload_excel_sheet',1407,1408),(684,1,'Controller',NULL,'Maps',1410,1417),(685,684,'Action',NULL,'beforeFilter',1411,1412),(686,684,'Action',NULL,'getRecord',1413,1414),(687,684,'Action',NULL,'index',1415,1416),(688,1,'Controller',NULL,'Markers',1418,1425),(689,688,'Action',NULL,'beforeFilter',1419,1420),(690,688,'Action',NULL,'index',1421,1422),(691,688,'Action',NULL,'parseToXML',1423,1424),(692,1,'Controller',NULL,'Nolights',1426,1449),(693,692,'Action',NULL,'add',1427,1428),(694,692,'Action',NULL,'beforeFilter',1429,1430),(695,692,'Action',NULL,'edit',1431,1432),(696,692,'Action',NULL,'effectiveDate',1433,1434),(697,692,'Action',NULL,'getGroupSchedules',1435,1436),(698,692,'Action',NULL,'index',1437,1438),(699,692,'Action',NULL,'jsonEncode',1439,1440),(700,692,'Action',NULL,'nolightCache',1441,1442),(701,692,'Action',NULL,'publish',1443,1444),(702,692,'Action',NULL,'save',1445,1446),(703,1,'Controller',NULL,'Pages',1450,1483),(704,703,'Action',NULL,'beforeFilter',1451,1452),(705,703,'Action',NULL,'createAddresses',1453,1454),(706,703,'Action',NULL,'createBusinesses',1455,1456),(707,703,'Action',NULL,'createMapaddress',1457,1458),(708,703,'Action',NULL,'createRouteCache',1459,1460),(709,703,'Action',NULL,'createTags',1461,1462),(710,703,'Action',NULL,'cron_database',1463,1464),(711,703,'Action',NULL,'display',1465,1466),(712,703,'Action',NULL,'facebook',1467,1468),(713,703,'Action',NULL,'flight_monitor',1469,1470),(714,703,'Action',NULL,'getNews',1471,1472),(715,703,'Action',NULL,'imageUpdate',1473,1474),(716,703,'Action',NULL,'manual_cronJob',1475,1476),(717,703,'Action',NULL,'map',1477,1478),(718,703,'Action',NULL,'sql',1479,1480),(719,703,'Action',NULL,'survey',1481,1482),(720,1,'Controller',NULL,'PluginViews',1484,1497),(721,720,'Action',NULL,'admin_add',1485,1486),(722,720,'Action',NULL,'admin_delete',1487,1488),(723,720,'Action',NULL,'admin_edit',1489,1490),(724,720,'Action',NULL,'admin_index',1491,1492),(725,720,'Action',NULL,'admin_save',1493,1494),(726,720,'Action',NULL,'beforeFilter',1495,1496),(727,1,'Controller',NULL,'Posts',1498,1511),(728,727,'Action',NULL,'add',1499,1500),(729,727,'Action',NULL,'addComments',1501,1502),(730,727,'Action',NULL,'beforeFilter',1503,1504),(731,727,'Action',NULL,'edit',1505,1506),(732,727,'Action',NULL,'index',1507,1508),(733,1,'Controller',NULL,'PublicTransports',1512,1527),(734,733,'Action',NULL,'beforeFilter',1513,1514),(735,733,'Action',NULL,'gen',1515,1516),(736,733,'Action',NULL,'generateUniqueHexColors',1517,1518),(737,733,'Action',NULL,'getLocation',1519,1520),(738,733,'Action',NULL,'index',1521,1522),(739,733,'Action',NULL,'test_recursive',1523,1524),(740,733,'Action',NULL,'view',1525,1526),(741,1,'Controller',NULL,'ReqDocs',1528,1543),(742,741,'Action',NULL,'admin_add',1529,1530),(743,741,'Action',NULL,'admin_delete',1531,1532),(744,741,'Action',NULL,'admin_edit',1533,1534),(745,741,'Action',NULL,'admin_index',1535,1536),(746,741,'Action',NULL,'admin_save',1537,1538),(747,741,'Action',NULL,'admin_view',1539,1540),(748,741,'Action',NULL,'beforeFilter',1541,1542),(749,1,'Controller',NULL,'Requests',1544,1583),(750,749,'Action',NULL,'admin_view',1545,1546),(751,749,'Action',NULL,'approve',1547,1548),(752,749,'Action',NULL,'beforeFilter',1549,1550),(753,749,'Action',NULL,'bid_request',1551,1552),(754,749,'Action',NULL,'save_document',1553,1554),(755,749,'Action',NULL,'view',1555,1556),(756,1,'Controller',NULL,'Reviews',1584,1601),(757,756,'Action',NULL,'admin_delete',1585,1586),(758,756,'Action',NULL,'admin_index',1587,1588),(759,756,'Action',NULL,'beforeFilter',1589,1590),(760,756,'Action',NULL,'index',1591,1592),(761,756,'Action',NULL,'prevComment',1593,1594),(762,756,'Action',NULL,'review',1595,1596),(763,756,'Action',NULL,'usefulCount',1597,1598),(764,1,'Controller',NULL,'SearchHistories',1602,1609),(765,764,'Action',NULL,'admin_delete',1603,1604),(766,764,'Action',NULL,'admin_index',1605,1606),(767,764,'Action',NULL,'beforeFilter',1607,1608),(768,1,'Controller',NULL,'Searches',1610,1643),(769,768,'Action',NULL,'_address',1611,1612),(770,768,'Action',NULL,'_addressValue',1613,1614),(771,768,'Action',NULL,'_category',1615,1616),(772,768,'Action',NULL,'_getAddressList',1617,1618),(773,768,'Action',NULL,'_getCategory',1619,1620),(774,768,'Action',NULL,'_getCategoryList',1621,1622),(775,768,'Action',NULL,'_getTag',1623,1624),(776,768,'Action',NULL,'_initializeSearchHistory',1625,1626),(777,768,'Action',NULL,'_page',1627,1628),(778,768,'Action',NULL,'_partial',1629,1630),(779,768,'Action',NULL,'_searchByBusiness',1631,1632),(780,768,'Action',NULL,'_searchByEvent',1633,1634),(781,768,'Action',NULL,'_searchByExpression',1635,1636),(782,768,'Action',NULL,'_searchTerms',1637,1638),(783,768,'Action',NULL,'beforeFilter',1639,1640),(784,768,'Action',NULL,'search',1641,1642),(785,1,'Controller',NULL,'Selections',1644,1661),(786,785,'Action',NULL,'admin_add',1645,1646),(787,785,'Action',NULL,'admin_approve',1647,1648),(788,785,'Action',NULL,'admin_edit',1649,1650),(789,785,'Action',NULL,'admin_index',1651,1652),(790,785,'Action',NULL,'admin_select_bid',1653,1654),(791,785,'Action',NULL,'beforeFilter',1655,1656),(792,1,'Controller',NULL,'SiteConfigurations',1662,1677),(793,792,'Action',NULL,'admin_add',1663,1664),(794,792,'Action',NULL,'admin_delete',1665,1666),(795,792,'Action',NULL,'admin_edit',1667,1668),(796,792,'Action',NULL,'admin_index',1669,1670),(797,792,'Action',NULL,'admin_save',1671,1672),(798,792,'Action',NULL,'admin_setting',1673,1674),(799,792,'Action',NULL,'beforeFilter',1675,1676),(800,1,'Controller',NULL,'Statuses',1678,1691),(801,800,'Action',NULL,'admin_add',1679,1680),(802,800,'Action',NULL,'admin_delete',1681,1682),(803,800,'Action',NULL,'admin_edit',1683,1684),(804,800,'Action',NULL,'admin_index',1685,1686),(805,800,'Action',NULL,'admin_save',1687,1688),(806,800,'Action',NULL,'beforeFilter',1689,1690),(807,1,'Controller',NULL,'Tenders',1692,1759),(808,807,'Action',NULL,'admin_add',1693,1694),(809,807,'Action',NULL,'admin_edit',1695,1696),(810,807,'Action',NULL,'admin_index',1697,1698),(811,807,'Action',NULL,'admin_view',1699,1700),(812,807,'Action',NULL,'beforeFilter',1701,1702),(813,807,'Action',NULL,'bid',1703,1704),(814,807,'Action',NULL,'deleteUpload',1705,1706),(815,807,'Action',NULL,'download',1707,1708),(816,807,'Action',NULL,'index',1709,1710),(817,807,'Action',NULL,'save_TenderDoc',1711,1712),(818,807,'Action',NULL,'upload_excel_sheet',1713,1714),(819,807,'Action',NULL,'view',1715,1716),(820,1,'Controller',NULL,'Uploads',1760,1765),(821,820,'Action',NULL,'beforeFilter',1761,1762),(822,820,'Action',NULL,'deleteUpload',1763,1764),(823,1,'Controller',NULL,'UserRoles',1766,1779),(824,823,'Action',NULL,'admin_add',1767,1768),(825,823,'Action',NULL,'admin_delete',1769,1770),(826,823,'Action',NULL,'admin_edit',1771,1772),(827,823,'Action',NULL,'admin_index',1773,1774),(828,823,'Action',NULL,'admin_save',1775,1776),(829,823,'Action',NULL,'beforeFilter',1777,1778),(830,1,'Controller',NULL,'Users',1780,1825),(831,830,'Action',NULL,'_email',1781,1782),(832,830,'Action',NULL,'_profileEvent',1783,1784),(833,830,'Action',NULL,'admin_delete',1785,1786),(834,830,'Action',NULL,'admin_edit',1787,1788),(835,830,'Action',NULL,'admin_index',1789,1790),(836,830,'Action',NULL,'beforeFilter',1791,1792),(837,830,'Action',NULL,'changePass',1793,1794),(838,830,'Action',NULL,'close',1795,1796),(839,830,'Action',NULL,'deleteUpload',1797,1798),(840,830,'Action',NULL,'login',1799,1800),(841,830,'Action',NULL,'logout',1801,1802),(842,830,'Action',NULL,'members',1803,1804),(843,830,'Action',NULL,'profile',1805,1806),(844,830,'Action',NULL,'registration',1807,1808),(845,830,'Action',NULL,'resetpassword',1809,1810),(846,830,'Action',NULL,'update',1811,1812),(847,830,'Action',NULL,'upload',1813,1814),(848,830,'Action',NULL,'weather',1815,1816),(849,39,'Controller',NULL,'FileUploadApp',83,84),(850,42,'Controller',NULL,'ControlPanels',121,138),(851,850,'Action',NULL,'acoSync',122,123),(852,850,'Action',NULL,'beforeFilter',124,125),(853,850,'Action',NULL,'cleanPermission',126,127),(854,850,'Action',NULL,'getControllerLists',128,129),(855,850,'Action',NULL,'getPermissions',130,131),(856,850,'Action',NULL,'getUserLists',132,133),(857,850,'Action',NULL,'index',134,135),(858,850,'Action',NULL,'security',136,137),(859,42,'Controller',NULL,'SuperAdminApp',139,144),(860,859,'Action',NULL,'beforeFilter',140,141),(861,859,'Action',NULL,'beforeRender',142,143),(870,749,'Action',NULL,'download',1557,1558),(871,513,'Action',NULL,'admin_min_bid_report',1065,1066),(872,749,'Action',NULL,'admin_invite_to_bid',1559,1560),(873,749,'Action',NULL,'missing_files',1561,1562),(874,749,'Action',NULL,'view_control',1563,1564),(875,807,'Action',NULL,'admin_delete',1719,1720),(877,876,'Action',NULL,'admin_add',1827,1828),(878,876,'Action',NULL,'admin_delete',1829,1830),(879,876,'Action',NULL,'admin_edit',1831,1832),(880,876,'Action',NULL,'admin_index',1833,1834),(881,876,'Action',NULL,'admin_save',1835,1836),(882,876,'Action',NULL,'beforeFilter',1837,1838),(883,807,'Action',NULL,'admin_add_currency',1721,1722),(884,807,'Action',NULL,'admin_currency_index',1723,1724),(885,807,'Action',NULL,'admin_edit_currency',1725,1726),(886,807,'Action',NULL,'admin_save_currency',1727,1728),(887,807,'Action',NULL,'download_guideline',1729,1730),(888,807,'Action',NULL,'get_rate',1731,1732),(889,749,'Action',NULL,'staff_approve',1565,1566),(890,749,'Action',NULL,'bid_view_password',1567,1568),(891,749,'Action',NULL,'deleteUpload',1569,1570),(892,749,'Action',NULL,'verify_password',1571,1572),(893,749,'Action',NULL,'verify_password_element',1573,1574),(894,830,'Action',NULL,'verify_password',1817,1818),(895,830,'Action',NULL,'verify_password_element',1819,1820),(896,1,'Controller',NULL,'PluginUploads',1840,1847),(897,896,'Action',NULL,'admin_index',1841,1842),(898,896,'Action',NULL,'admin_plugin_upload',1843,1844),(899,896,'Action',NULL,'beforeFilter',1845,1846),(900,807,'Action',NULL,'admin_delete_currency',1733,1734),(901,807,'Action',NULL,'default_quotation_download',1735,1736),(902,1,'Controller',NULL,'Settings',1848,1865),(903,830,'Action',NULL,'add_member',1821,1822),(904,830,'Action',NULL,'changePass1',1823,1824),(905,807,'Action',NULL,'admin_add_attr',1737,1738),(906,807,'Action',NULL,'admin_bid_open_approval',1739,1740),(907,807,'Action',NULL,'admin_delete_attr',1741,1742),(908,807,'Action',NULL,'admin_edit_attr',1743,1744),(909,807,'Action',NULL,'admin_publish',1745,1746),(910,807,'Action',NULL,'admin_save_attr',1747,1748),(911,807,'Action',NULL,'manufactureList',1749,1750),(912,807,'Action',NULL,'movedown',1751,1752),(913,807,'Action',NULL,'moveup',1753,1754),(914,807,'Action',NULL,'setting',1755,1756),(915,807,'Action',NULL,'update_status',1757,1758),(916,785,'Action',NULL,'admin_selected',1657,1658),(917,785,'Action',NULL,'download_selection',1659,1660),(918,749,'Action',NULL,'admin_invite',1575,1576),(919,749,'Action',NULL,'approveLevel',1577,1578),(920,749,'Action',NULL,'reject',1579,1580),(921,749,'Action',NULL,'simple_upload_bid_doc',1581,1582),(922,521,'Action',NULL,'member_approve',1155,1156),(923,513,'Action',NULL,'admin_bid_document',1067,1068),(924,513,'Action',NULL,'bid_document',1069,1070),(925,513,'Action',NULL,'product',1071,1072),(926,902,'Action',NULL,'admin_add',1849,1850),(927,902,'Action',NULL,'admin_companysetting',1851,1852),(928,902,'Action',NULL,'admin_delete',1853,1854),(929,902,'Action',NULL,'admin_edit',1855,1856),(930,902,'Action',NULL,'admin_index',1857,1858),(931,902,'Action',NULL,'admin_save',1859,1860),(932,902,'Action',NULL,'admin_view',1861,1862),(933,902,'Action',NULL,'beforeFilter',1863,1864);
/*!40000 ALTER TABLE `acos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_id` int(11) NOT NULL,
  `table` varchar(15) NOT NULL,
  `street` varchar(80) DEFAULT NULL,
  `direction` varchar(225) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `phone_number` varchar(24) DEFAULT NULL,
  `email` varchar(99) DEFAULT NULL,
  `website` varchar(99) DEFAULT NULL,
  `geocode_lt` varchar(10) DEFAULT NULL,
  `geocode_lg` varchar(10) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `location_map_id` (`city`),
  KEY `table_id` (`table_id`)
) ENGINE=MyISAM AUTO_INCREMENT=194 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` (`id`, `table_id`, `table`, `street`, `direction`, `city`, `district`, `country`, `phone_number`, `email`, `website`, `geocode_lt`, `geocode_lg`, `status_id`) VALUES (12,1,'User','Anam Nagar','','Kathamdu','Bagmati','Nepal','+9775551007','support@himalayantechies.com','http://www.himalayantechies.com','','',1),(100,58,'User','Anam Nagar','','Kathmandu','','Nepal','014248109','sagrawal@himalayantechies.com','http://www.himalayantechies.com','','',1),(186,119,'User','Jawalakhel',NULL,'Kathmandu','Lalitpur','Nepal','01-5000480','mail@himalhydro.com.np','www.himalhydro.com.np',NULL,NULL,1),(190,46,'Business','Steel Tower,Jawalakhel',NULL,'kathmandu','Lalitpur','Nepal','01-5000480','mail@himalhydro.com.np','www.himalhydro.com.np',NULL,NULL,1),(157,100,'User','',NULL,'','','','','sagrawal@himalayantechies.com','',NULL,NULL,1),(35,14,'User','','','Kathmandu','','','9851078392','support@himalayantechies.com','','','',1),(36,15,'User','','','','','','','support@himalayantechies.com','','','',1),(49,27,'User','kathamandu','','770',NULL,NULL,'9841589962,9801202509',NULL,'','','',1),(65,8,'Business','','','482',NULL,NULL,'','','','','',1),(66,9,'Business','','','482',NULL,NULL,'','','','','',1),(67,10,'Business','','','482',NULL,NULL,'','','','','',1),(68,11,'Business','','','482',NULL,NULL,'','','','','',1),(69,12,'Business','','','482',NULL,NULL,'','','','','',1),(110,60,'User','',NULL,'','','','','pisces_sakshi@hotmail.com','',NULL,NULL,1),(92,21,'Business','','','482',NULL,NULL,'','','','','',1),(184,118,'User','Thapathali',NULL,'kathamndu','Kathmandu','Nepal','01-4257815`','bgc042@yahoo.com','',NULL,NULL,1),(191,122,'User','Bishalnagar -5 , kathamandu Nepal',NULL,'kathamandu','kathamandu','Nepal','9814583000','naveenshahi342@gmail.com','',NULL,NULL,1),(188,121,'User','BSR Industrial Road',NULL,'Shahibabad','Ghaziabad','India','0091-9818285539','m_t_exht_inds@rediffmail.com','',NULL,NULL,1),(104,27,'Business','',NULL,'Kathmandu','','Nepal','5551007','excel-traders@himalayantechies.com','http://www.himalayantechies.com',NULL,NULL,1),(109,60,'User','Tahachal',NULL,'Kathmandu','Bagmati','Nepal','9801045390','arpita_92@hotmail.com','http://oopscareer.com',NULL,NULL,1),(111,61,'User','',NULL,'','','','','','',NULL,NULL,1),(112,62,'User','',NULL,'','','','','','',NULL,NULL,1),(113,63,'User','',NULL,'','','','','','',NULL,NULL,1),(114,64,'User','',NULL,'','','','',NULL,'',NULL,NULL,1),(193,123,'User','okbye11d1',NULL,'raababt','','Morocco','06969622','rofilitrixelhaxor@hotmail.com','rofilitrix-ma.com',NULL,NULL,1),(189,45,'Business','kathamandu',NULL,'kathmandu','kathmandu','Nepal','9841931788','hoobstank.k@gmail.com','',NULL,NULL,1),(141,88,'User','Sanepa',NULL,'Kathmandu','Bagmati','Nepal','9843108751','support@himalayantechies.com','',NULL,NULL,1),(137,84,'User','',NULL,'','','','','arpita_92@hotmail.com','',NULL,NULL,1),(142,89,'User','Sankhamul',NULL,'Kathmandu','Bagmati','Nepal','','support@himalayantechies.com','',NULL,NULL,1),(143,90,'User','',NULL,'','','','','sagrawal@himalayantehies.com','',NULL,NULL,1),(159,102,'User','',NULL,'','','Nepal','','tjcl2068@gmail.com','',NULL,NULL,1),(160,103,'User','sitapaila',NULL,'kathmandu','kathmandu','Nepal','9851197789','hoobstank.k@gmail.com','',NULL,NULL,1),(162,35,'Business','1',NULL,'2','3','Nepal','1235','hoobstank.k@gmail.com','',NULL,NULL,1),(163,105,'User','',NULL,'','','','','dbarman@systra.com','',NULL,NULL,1),(192,47,'Business','BSR Industrial Area',NULL,'Ghaziabad','Shahibabad','India','0091-9818285539','m_t_exht_inds@rediffmail.com','',NULL,NULL,1),(166,107,'User','kathmandu',NULL,'kathmandu','kathmandu','Nepal','9851001773','d.pandey55@yahoo.com','',NULL,NULL,1),(187,120,'User','kathmandu',NULL,'kathmandu','kathmandu','Nepal','9841931788','hoobstank.k@gmail.com','',NULL,NULL,1),(168,109,'User','banasthali',NULL,'kathmandu','kathmandu','Nepal','9851001773','d.pandey55@yahoo.com','',NULL,NULL,1),(169,37,'Business','kathamandu',NULL,'kathmandu','kathmandu','Nepal','9851001773','d.pandey55@yahoo.com','',NULL,NULL,1),(171,111,'User','chakupat',NULL,'lalitpur','lalitpur','nepal','9841689683','bishowkumar@yahoo.com','',NULL,NULL,1),(172,38,'Business','',NULL,'lalitpur','lalitpur','nepal','9841689683','bishowkumar@yahoo.com','',NULL,NULL,1),(173,112,'User','Kathmandu',NULL,'Kathmandu','Kathmandu','Nepal','9841068755','tensab_linus419@yahoo.com','',NULL,NULL,1),(174,39,'Business','Kathmandu',NULL,'Kathmandu','Kathmandu','Nepal','9841068755','tensab_linus419@yahoo.com','',NULL,NULL,1),(175,113,'User','ltpur',NULL,'ltpur','ltpur','nepal','98544445433','tensab.linus419@gmail.com','',NULL,NULL,1),(176,40,'Business','lalitpur',NULL,'lalitpur','lalitpur','Nepal','9841068755','tensab.linus419@gmail.com','',NULL,NULL,1),(177,114,'User','Sanobharyang',NULL,'kathmandu','bagmati','nepal','9851085678','damo@ntc.net.np','',NULL,NULL,1),(178,41,'Business','Located at Sanobharyang',NULL,'kathmandu','bagmati','nepal','9851085678','damo@ntc.net.np','',NULL,NULL,1),(179,115,'User','kathmandu',NULL,'kathmandu','kathmandu','Nepal','9851197789','hoobstank.k@gmail.com','',NULL,NULL,1),(180,42,'Business','sitapaila',NULL,'Kathmandu','kathmandu','Nepal','9851197789','opusengineers@gmail.com','',NULL,NULL,1),(182,117,'User','Swayambhu',NULL,'Ktm','Ktm','Nepal','4271882','sns@nea.org.np','',NULL,NULL,1),(185,44,'Business','tHAPATHALI',NULL,'kathamndu','Kathmandu','Nepal','01-4257815','bgc042@yahoo.com','',NULL,NULL,1);
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aros`
--

DROP TABLE IF EXISTS `aros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aros` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=140 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aros`
--

LOCK TABLES `aros` WRITE;
/*!40000 ALTER TABLE `aros` DISABLE KEYS */;
INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES (1,NULL,'UserRole',1,'admin',1,6),(2,NULL,'UserRole',2,'staff',7,14),(3,NULL,'UserRole',3,'client',15,64),(4,1,'User',1,'htadmin',2,3),(13,2,'User',3,'staff',8,9),(14,3,'User',4,'supplier2',16,17),(15,3,'User',5,'supplier3',18,19),(16,2,'User',2,'staff-1',10,11),(138,3,'User',122,'navin-kumar-shahi',60,61),(74,3,'User',58,'saakshi-1',20,21),(134,3,'User',118,'bajradiwa',50,51),(25,NULL,'UserRole',4,'staff-1',65,68),(29,2,'User',14,'baburam',12,13),(30,3,'User',15,'tuldhar-manik',58,59),(139,3,'User',123,'haxor',62,63),(76,3,'User',60,'test-1',22,23),(77,3,'User',61,'testt',24,25),(78,25,'User',62,'grande-test',66,67),(79,3,'User',63,'grande',26,27),(80,3,'User',64,'fred',28,29),(137,3,'User',121,'multitech',56,57),(118,1,'User',102,'tjvcl',4,5),(119,3,'User',103,'kalyan',30,31),(121,3,'User',105,'debpriya1984',32,33),(123,3,'User',107,'deepak',34,35),(125,3,'User',109,'d-pandey',36,37),(127,3,'User',111,'bishowkumar',38,39),(128,3,'User',112,'sunil',40,41),(129,3,'User',113,'buki',42,43),(130,3,'User',114,'damo4890-gmail-com',44,45),(131,3,'User',115,'opus',46,47),(135,3,'User',119,'hh',52,53),(133,3,'User',117,'snl',48,49),(136,3,'User',120,'check-ebid',54,55);
/*!40000 ALTER TABLE `aros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aros_acos`
--

DROP TABLE IF EXISTS `aros_acos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aros_acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) NOT NULL DEFAULT '0',
  `_read` varchar(2) NOT NULL DEFAULT '0',
  `_update` varchar(2) NOT NULL DEFAULT '0',
  `_delete` varchar(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ARO_ACO_KEY` (`aro_id`,`aco_id`)
) ENGINE=MyISAM AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aros_acos`
--

LOCK TABLES `aros_acos` WRITE;
/*!40000 ALTER TABLE `aros_acos` DISABLE KEYS */;
INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES (1,1,1,'1','1','1','1'),(50,3,545,'1','1','1','1'),(49,3,544,'1','1','1','1'),(45,3,561,'1','1','1','1'),(35,1,554,'1','1','1','1'),(36,1,842,'1','1','1','1'),(37,3,520,'1','1','1','1'),(46,3,541,'1','1','1','1'),(48,3,543,'1','1','1','1'),(47,3,542,'1','1','1','1'),(34,1,533,'1','1','1','1'),(38,3,519,'1','1','1','1'),(39,3,518,'1','1','1','1'),(40,3,533,'1','1','1','1'),(41,3,531,'1','1','1','1'),(42,3,530,'1','1','1','1'),(43,3,534,'1','1','1','1'),(44,3,559,'1','1','1','1'),(51,3,546,'1','1','1','1'),(52,3,557,'1','1','1','1'),(53,3,554,'1','1','1','1'),(54,3,555,'1','1','1','1'),(55,3,754,'1','1','1','1'),(56,3,753,'1','1','1','1'),(57,3,755,'1','1','1','1'),(58,3,813,'1','1','1','1'),(59,3,819,'1','1','1','1'),(60,3,847,'1','1','1','1'),(61,3,846,'1','1','1','1'),(62,3,845,'1','1','1','1'),(63,3,844,'1','1','1','1'),(64,3,843,'1','1','1','1'),(65,3,842,'1','1','1','1'),(66,3,841,'1','1','1','1'),(67,3,840,'1','1','1','1'),(68,3,848,'1','1','1','1'),(69,3,839,'1','1','1','1'),(70,3,838,'1','1','1','1'),(71,3,837,'1','1','1','1'),(72,1,755,'-1','-1','-1','-1'),(73,3,815,'1','1','1','1'),(74,2,1,'1','1','1','1'),(75,2,533,'-1','-1','-1','-1'),(76,2,554,'-1','-1','-1','-1'),(77,2,557,'-1','-1','-1','-1'),(78,2,753,'-1','-1','-1','-1'),(79,2,755,'-1','-1','-1','-1'),(80,2,754,'-1','-1','-1','-1'),(81,2,813,'-1','-1','-1','-1'),(82,2,42,'-1','-1','-1','-1'),(83,2,842,'-1','-1','-1','-1'),(84,3,1,'1','1','1','1'),(85,1,823,'1','1','1','1'),(86,2,823,'-1','-1','-1','-1'),(87,2,833,'-1','-1','-1','-1'),(88,2,834,'-1','-1','-1','-1'),(89,2,835,'-1','-1','-1','-1'),(90,2,529,'-1','-1','-1','-1'),(92,25,1,'-1','-1','-1','-1'),(93,25,42,'-1','-1','-1','-1'),(94,25,554,'-1','-1','-1','-1'),(95,25,533,'-1','-1','-1','-1'),(96,25,567,'-1','-1','-1','-1'),(97,25,557,'-1','-1','-1','-1'),(98,25,529,'-1','-1','-1','-1'),(99,25,811,'1','1','1','1'),(100,25,810,'1','1','1','1'),(101,25,816,'1','1','1','1'),(102,25,840,'1','1','1','1'),(103,25,841,'1','1','1','1'),(104,25,843,'1','1','1','1'),(105,25,846,'1','1','1','1'),(106,25,847,'1','1','1','1'),(107,25,837,'1','1','1','1'),(108,25,831,'1','1','1','1'),(109,25,750,'1','1','1','1'),(110,25,889,'1','1','1','1'),(111,3,891,'1','1','1','1'),(112,3,888,'1','1','1','1'),(113,3,874,'1','1','1','1'),(114,25,516,'1','1','1','1'),(115,25,870,'1','1','1','1'),(116,2,711,'1','1','1','1'),(117,3,711,'1','1','1','1'),(118,25,711,'1','1','1','1'),(119,3,870,'1','1','1','1'),(120,3,830,'-1','-1','-1','-1'),(121,3,818,'1','1','1','1'),(122,3,915,'1','1','1','1'),(123,3,817,'1','1','1','1'),(124,3,911,'1','1','1','1'),(125,3,816,'1','1','1','1'),(126,3,814,'1','1','1','1'),(127,3,901,'1','1','1','1'),(128,3,807,'-1','-1','-1','-1'),(129,1,807,'1','1','1','1'),(130,1,785,'1','1','1','1'),(131,3,785,'-1','-1','-1','-1'),(132,3,749,'-1','-1','-1','-1'),(133,3,873,'1','1','1','1'),(134,3,921,'1','1','1','1'),(135,1,749,'1','1','1','1'),(136,3,922,'1','1','1','1'),(137,3,556,'1','1','1','1'),(138,3,521,'-1','-1','-1','-1'),(139,3,537,'1','1','1','1'),(140,3,924,'1','1','1','1'),(141,3,925,'1','1','1','1'),(142,3,513,'-1','-1','-1','-1'),(143,3,811,'1','1','1','1'),(144,3,914,'1','1','1','1');
/*!40000 ALTER TABLE `aros_acos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `businesses`
--

DROP TABLE IF EXISTS `businesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `businesses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pan_no` varchar(11) DEFAULT NULL,
  `name` varchar(199) DEFAULT NULL,
  `description` text,
  `url` varchar(199) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `date_added` date DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `businesses`
--

LOCK TABLES `businesses` WRITE;
/*!40000 ALTER TABLE `businesses` DISABLE KEYS */;
INSERT INTO `businesses` (`id`, `pan_no`, `name`, `description`, `url`, `user_id`, `owner_id`, `status_id`, `date_added`, `category_id`) VALUES (47,'432234123','Multitech','EPC Contracting','multitech-1',121,121,1,'2014-07-16',715),(45,'951159','check ebid','checking bid','check-ebid-1',120,120,1,'2014-07-15',715),(46,'300041406','Himal Hydro and General Construction Ltd','Himal Hydro Tender submission','himal-hydro-and-general-construction-ltd',119,119,1,'2014-07-15',715),(21,'456','Himalayan Techies','','himalayan-techies',53,15,1,'2013-11-28',2),(44,'300062492','BAJRA GURU-DIWA JV','','bajra-guru-diwa-jv',118,118,1,'2014-05-28',715),(35,'2','1','2','1',103,103,1,'2014-04-17',712),(37,'789456123','deepak pandey','check','deepak-pandey',109,109,1,'2014-04-20',712),(38,'689683','Bishowkumar','','bishowkumar-1',111,111,1,'2014-04-25',712),(39,'068755','Sunil Traders','','s-traders',112,112,1,'2014-04-25',712),(40,'984106877','buki traders','','buki-traders',113,113,1,'2014-04-25',712),(41,'99999999','Bagmati Enterprises','Construction company and Trading house','bagmati-enterprises',114,114,1,'2014-04-25',712),(42,'601186125','Opus Engineering consultant','Opus Engineering Consultant Provides all engineering related services.','opus-engineering-consultant',115,115,1,'2014-04-25',714);
/*!40000 ALTER TABLE `businesses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(20) DEFAULT NULL,
  `name` varchar(124) NOT NULL,
  `url` varchar(124) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=716 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `model`, `name`, `url`, `description`, `parent_id`, `lft`, `rght`) VALUES (712,NULL,'Suppliers','suppliers',NULL,NULL,1,2),(713,NULL,'Reseller','reseller',NULL,NULL,3,4),(714,NULL,'Consultancy','consultancy',NULL,NULL,5,6),(715,NULL,'Contractor','contractor',NULL,NULL,7,8);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`id`, `name`, `value`) VALUES (2,'Currency','0'),(3,'Document','0'),(4,'Invitation','0'),(5,'Manufacturer','0'),(6,'Approve Levels','0'),(7,'company_name','Trishuli Jalvidhyut E-Bidding System'),(8,'administrator_email','ebiddng@trishulijalvidhyut.com.np');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statuses`
--

DROP TABLE IF EXISTS `statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `model` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statuses`
--

LOCK TABLES `statuses` WRITE;
/*!40000 ALTER TABLE `statuses` DISABLE KEYS */;
INSERT INTO `statuses` (`id`, `name`, `model`) VALUES (1,'Active','Business'),(2,'Closed','Business'),(53,'Open for bidding','Tender'),(5,'Deleted','Business'),(6,'Active','User'),(7,'Deleted','User'),(8,'Pending Validation','Business'),(9,'Inactive','User'),(55,'Comparative Analysis','Tender'),(12,'Active','Review'),(13,'Active','Event'),(14,'Active','Address'),(15,'Pending Validation','Address'),(17,'Password Reset','User'),(40,'Canceled','Invitation'),(39,'Bid','Invitation'),(38,'Visited','Invitation'),(37,'Not Visited','Invitation'),(36,'Rejected','Bid'),(35,'Pending','Bid'),(34,'Selected','Bid'),(33,'Active','Tender'),(32,'Closed','Tender'),(31,'Open','Tender'),(54,'Closed for bidding','Tender'),(41,'Canceled','Bid'),(42,'Selected','Selection'),(43,'Waiting','Selection'),(44,'Rejected','Selection'),(45,'Open','TenderType'),(46,'Close','TenderType'),(47,'Not Approved','Request'),(48,'Approved','Request'),(49,'Rejected','Request'),(50,'Enabled','PluginView'),(51,'Disabled','PluginView'),(52,'Inactive','Tender'),(56,'Simple Upload','Tender'),(57,'Bid Analysis','Tender');
/*!40000 ALTER TABLE `statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_approve_level_tenders`
--

DROP TABLE IF EXISTS `t_approve_level_tenders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_approve_level_tenders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foreign_key` int(11) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `tender_id` int(10) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_approve_level_tenders`
--

LOCK TABLES `t_approve_level_tenders` WRITE;
/*!40000 ALTER TABLE `t_approve_level_tenders` DISABLE KEYS */;
INSERT INTO `t_approve_level_tenders` (`id`, `foreign_key`, `model`, `type`, `tender_id`, `parent_id`, `lft`, `rght`) VALUES (1,NULL,'Parent','Request',1,NULL,1,2),(2,NULL,'Parent','Selection',1,NULL,3,4),(3,NULL,'Parent','Request',2,NULL,5,6),(4,NULL,'Parent','Selection',2,NULL,7,8);
/*!40000 ALTER TABLE `t_approve_level_tenders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_approve_levels_requests`
--

DROP TABLE IF EXISTS `t_approve_levels_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_approve_levels_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `approve_level_id` int(2) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `request_id` int(10) DEFAULT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reject` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_approve_levels_requests`
--

LOCK TABLES `t_approve_levels_requests` WRITE;
/*!40000 ALTER TABLE `t_approve_levels_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_approve_levels_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_approves`
--

DROP TABLE IF EXISTS `t_approves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_approves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foreign_key` int(11) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `approve_level_id` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `manufacture_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_approves`
--

LOCK TABLES `t_approves` WRITE;
/*!40000 ALTER TABLE `t_approves` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_approves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_bids`
--

DROP TABLE IF EXISTS `t_bids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_bids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tender_manufacture_products_id` int(11) DEFAULT NULL,
  `request_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `rate_num` double DEFAULT NULL,
  `pack_size_box` varchar(255) DEFAULT NULL,
  `rate_word` varchar(255) DEFAULT NULL,
  `bonus` varchar(100) DEFAULT NULL,
  `max_ret_price` double DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `discount_type` varchar(20) DEFAULT NULL,
  `pcn_margin` float DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `remarks` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_bids`
--

LOCK TABLES `t_bids` WRITE;
/*!40000 ALTER TABLE `t_bids` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_bids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_currency_tenders`
--

DROP TABLE IF EXISTS `t_currency_tenders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_currency_tenders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tender_id` int(11) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `ex_rate` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_currency_tenders`
--

LOCK TABLES `t_currency_tenders` WRITE;
/*!40000 ALTER TABLE `t_currency_tenders` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_currency_tenders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_manufactures`
--

DROP TABLE IF EXISTS `t_manufactures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_manufactures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_manufactures`
--

LOCK TABLES `t_manufactures` WRITE;
/*!40000 ALTER TABLE `t_manufactures` DISABLE KEYS */;
INSERT INTO `t_manufactures` (`id`, `name`) VALUES (1,'Ranbaxy'),(2,'Sinovac Biotech Co Ltd'),(3,'Lanzhou Institute of Biological Products'),(4,'Akums Drugs and Pharmaceuticals Ltd'),(5,'Alive Pharmaceuticals Pvt. Ltd.'),(6,'Amie Pharmaceuticals Pvt. Ltd.'),(7,'Apex Pharmaceuticals Pvt. Ltd.'),(8,'Chemidrug Industries Pvt. Ltd.'),(9,'Concept Pharmaceuticals (Nepal) Pvt. Ltd.'),(10,'CTL Pharmceuticals Pvt. Ltd. '),(11,'Elder Universal Pharmaceutical (Nepal) Pvt. Ltd.'),(12,'Magnus Pharma Pvt. Ltd.'),(13,'Manoj Pharmaceutical Works'),(14,'Nepal Aushadhi Limited'),(15,'Manufacturer 18'),(16,'Panas Pharmaceuticals Pvt. Ltd.'),(17,'Manufacturer 20'),(18,'Manufacturer 21'),(19,'Manufacturer 22'),(20,'Manufacturer 23'),(21,'Manufacturer 24'),(22,'Manufacturer 25'),(23,'Company 1'),(24,'Company 2'),(25,'Company 3'),(26,'Company 4'),(27,'Ohm Pharma Lab Pvt. Ltd.'),(28,'Company 6'),(29,'Siddhartha Pharmaceuticals Pvt. Ltd.'),(30,'Company 9'),(31,'Company 10'),(32,'Company 12'),(33,'Company 13'),(34,'Company 14'),(35,'Company 15'),(36,'Vijayadeep Laboratories Ltd.'),(37,'Company 18'),(38,'Company 19'),(39,'Company 20'),(40,'Company 21'),(41,'Unique Pharmaceuticals Pvt. Ltd.'),(42,'Company 23'),(43,'Company 25');
/*!40000 ALTER TABLE `t_manufactures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_products`
--

DROP TABLE IF EXISTS `t_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(200) DEFAULT NULL,
  `g_name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_products`
--

LOCK TABLES `t_products` WRITE;
/*!40000 ALTER TABLE `t_products` DISABLE KEYS */;
INSERT INTO `t_products` (`id`, `b_name`, `g_name`) VALUES (1,'Brand Name 1','Generic Name 1'),(2,'Brand Name 2','Generic Name 2'),(3,'Brand Name 3','Generic Name 3'),(4,'Brand Name 4','Generic Name 4'),(5,'Brand Name 5','Generic Name 5'),(6,'Brand Name 6','Generic Name 6'),(7,'Brand Name 7','Generic Name 7'),(8,'Brand Name 8','Generic Name 8'),(9,'Brand Name 9','Generic Name 9'),(10,'Brand Name 10','Generic Name 10'),(11,'Brand Name 11','Generic Name 11'),(12,'Brand Name 12','Generic Name 12'),(13,'Brand Name 13','Generic Name 13'),(14,'Brand Name 14','Generic Name 14'),(15,'Brand Name 15','Generic Name 15'),(16,'Brand Name 16','Generic Name 16'),(17,'Brand Name 17','Generic Name 17'),(18,'Brand Name 18','Generic Name 18'),(19,'Brand Name 19','Generic Name 19'),(20,'Brand Name 20','Generic Name 20'),(21,'Brand Name 21','Generic Name 21'),(22,'Brand Name 22','Generic Name 22'),(23,'Brand Name 23','Generic Name 23'),(24,'Brand Name 24','Generic Name 24'),(25,'Brand Name 25','Generic Name 25'),(26,'Brand Name 26','Generic Name 26'),(27,'Brand Name 27','Generic Name 27'),(28,'Brand Name 28','Generic Name 28'),(29,'Brand Name 29','Generic Name 29'),(30,'Brand Name 30','Generic Name 30'),(31,'Brand Name 31','Generic Name 31'),(32,'Brand Name 32','Generic Name 32'),(33,'Brand Name 33','Generic Name 33'),(34,'Brand Name 34','Generic Name 34'),(35,'Brand Name 35','Generic Name 35'),(36,'Brand Name 36','Generic Name 36'),(37,'Brand Name 37','Generic Name 37'),(38,'Brand Name 38','Generic Name 38'),(39,'Brand Name 39','Generic Name 39'),(40,'Brand Name 40','Generic Name 40'),(41,'Brand Name 41','Generic Name 41'),(42,'Brand Name 42','Generic Name 42'),(43,'Brand Name 43','Generic Name 43'),(44,'Brand Name 44','Generic Name 44'),(45,'Brand Name 45','Generic Name 45'),(46,'Brand Name 46','Generic Name 46'),(47,'Brand Name 47','Generic Name 47'),(48,'Brand Name 48','Generic Name 48'),(49,'Brand Name 49','Generic Name 49'),(50,'Brand Name 50','Generic Name 50');
/*!40000 ALTER TABLE `t_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_req_doc_tenders`
--

DROP TABLE IF EXISTS `t_req_doc_tenders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_req_doc_tenders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `req_doc_id` int(11) DEFAULT NULL,
  `tender_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_req_doc_tenders`
--

LOCK TABLES `t_req_doc_tenders` WRITE;
/*!40000 ALTER TABLE `t_req_doc_tenders` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_req_doc_tenders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_req_docs`
--

DROP TABLE IF EXISTS `t_req_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_req_docs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(25) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_req_docs`
--

LOCK TABLES `t_req_docs` WRITE;
/*!40000 ALTER TABLE `t_req_docs` DISABLE KEYS */;
INSERT INTO `t_req_docs` (`id`, `name`, `type`, `description`) VALUES (9,'PAN Certificate','PAN Certificate','PAN Certificate'),(11,'Engineering Council Certificate','Engineering Council Certi','original scanned copy of Nepal  Engineering council certificate'),(12,'Individual CV','Individual CV','Scanned Copy of Individual CV'),(13,'Balance Sheet','Balance Sheet','Balance sheet ');
/*!40000 ALTER TABLE `t_req_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_requests`
--

DROP TABLE IF EXISTS `t_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tender_id` int(11) DEFAULT NULL,
  `business_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `bid_view` int(1) NOT NULL DEFAULT '0' COMMENT '0 =No, 1 = Yes',
  `overall_discount` float DEFAULT NULL,
  `discount_type` varchar(20) DEFAULT NULL,
  `document_status` int(1) NOT NULL DEFAULT '0' COMMENT '0 => unsufficent, 1 => sufficient',
  `currency` varchar(10) DEFAULT NULL,
  `supplier_status` varchar(255) DEFAULT NULL,
  `bid_view_password` varchar(10) DEFAULT NULL,
  `bid_view_password2` varchar(10) DEFAULT NULL,
  `bid_view_status` int(1) NOT NULL DEFAULT '0',
  `staff_approve` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_requests`
--

LOCK TABLES `t_requests` WRITE;
/*!40000 ALTER TABLE `t_requests` DISABLE KEYS */;
INSERT INTO `t_requests` (`id`, `tender_id`, `business_id`, `created_date`, `updated_date`, `user_id`, `type`, `status_id`, `bid_view`, `overall_discount`, `discount_type`, `document_status`, `currency`, `supplier_status`, `bid_view_password`, `bid_view_password2`, `bid_view_status`, `staff_approve`) VALUES (1,1,44,'2014-05-28 14:02:34','2014-05-28 14:02:34',118,'Request',47,0,NULL,NULL,0,NULL,'Requested',NULL,NULL,0,0),(2,1,37,'2014-06-02 10:13:38','2014-06-02 10:13:38',109,'Request',47,0,NULL,NULL,0,NULL,'Requested',NULL,NULL,0,0),(3,2,46,'2014-07-15 11:39:39','2014-07-16 10:07:52',119,'Request',47,0,NULL,NULL,0,NULL,'Bid Placed',NULL,NULL,1,0),(4,2,47,'2014-07-16 10:57:27','2014-07-16 10:57:27',121,'Request',47,0,NULL,NULL,0,NULL,'Requested',NULL,NULL,0,0);
/*!40000 ALTER TABLE `t_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_selections`
--

DROP TABLE IF EXISTS `t_selections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_selections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tender_id` int(11) DEFAULT NULL,
  `bid_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_selections`
--

LOCK TABLES `t_selections` WRITE;
/*!40000 ALTER TABLE `t_selections` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_selections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_tender_manufacture_products`
--

DROP TABLE IF EXISTS `t_tender_manufacture_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_tender_manufacture_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tender_id` int(11) DEFAULT NULL,
  `manufacture_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `dosage_form_id` int(11) DEFAULT NULL,
  `quantity` float(20,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_tender_manufacture_products`
--

LOCK TABLES `t_tender_manufacture_products` WRITE;
/*!40000 ALTER TABLE `t_tender_manufacture_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_tender_manufacture_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_tenders`
--

DROP TABLE IF EXISTS `t_tenders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_tenders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(60) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `opening_date` datetime DEFAULT NULL,
  `bid_opening_date` datetime DEFAULT NULL,
  `bid_closing_date` datetime DEFAULT NULL,
  `closing_date` datetime DEFAULT NULL,
  `description` text,
  `department_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `tender_publish` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_tenders`
--

LOCK TABLES `t_tenders` WRITE;
/*!40000 ALTER TABLE `t_tenders` DISABLE KEYS */;
INSERT INTO `t_tenders` (`id`, `code`, `type`, `subject`, `opening_date`, `bid_opening_date`, `bid_closing_date`, `closing_date`, `description`, `department_id`, `user_id`, `created_date`, `updated_date`, `status_id`, `tender_publish`) VALUES (1,'2014-05-09_100001','Simple Upload','E-bidding for construction of Camp Facilities','2014-06-03 14:00:34','2014-05-04 10:00:34','2014-06-03 12:00:34','2014-06-03 17:00:34','',NULL,102,'2014-05-09 15:56:28','2014-05-09 15:56:28',32,1),(2,'2014-06-22_100002','Simple Upload','Ebidding for Construction of Test Adit Tunnel','2014-07-16 14:00:48','2014-06-16 10:00:48','2014-07-16 12:00:48','2014-07-16 17:00:48','For further detail, contact Trishuli Jal Vidhyut Company Limited at Sohrakhutte, Kathmandu, Nepal',NULL,102,'2014-06-22 11:48:40','2014-06-22 11:48:40',32,1);
/*!40000 ALTER TABLE `t_tenders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploads`
--

DROP TABLE IF EXISTS `uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(25) DEFAULT NULL,
  `field` varchar(25) DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `doc_type` varchar(100) DEFAULT NULL,
  `size` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `table_id` (`foreign_key`)
) ENGINE=MyISAM AUTO_INCREMENT=467 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploads`
--

LOCK TABLES `uploads` WRITE;
/*!40000 ALTER TABLE `uploads` DISABLE KEYS */;
INSERT INTO `uploads` (`id`, `model`, `field`, `foreign_key`, `caption`, `name`, `type`, `doc_type`, `size`) VALUES (466,'Request','RequestDoc',3,'Cash Receipt ','cash-receipt0001.pdf','application/pdf','Bidding Document',230953),(465,'Request','RequestDoc',3,'Qualification Information','qualification-7.pdf','application/pdf','Bidding Document',51396864),(464,'Request','RequestDoc',3,'Declaration letter ','declaration-9.pdf','application/pdf','Bidding Document',849338),(463,'Request','RequestDoc',3,'BOQ with rate, Amount and Total amount','boq-8-1.pdf','application/pdf','Bidding Document',1452948),(462,'Request','RequestDoc',3,'Power of Attorney','power-of-att-6.pdf','application/pdf','Bidding Document',606012),(461,'Request','RequestDoc',3,'Tax clearance ','tax-5.pdf','application/pdf','Bidding Document',228271),(460,'Request','RequestDoc',3,'VAT / PAN registration','vat-reg-4.pdf','application/pdf','Bidding Document',180674),(459,'Request','RequestDoc',3,'Company Registration','company-registration-3.pdf','application/pdf','Bidding Document',834060),(456,'Request','RequestDoc',3,'Form of Bid 1','bid-form-letter-of-bid.pdf','application/pdf','Bidding Document',1830207),(457,'Request','RequestDoc',3,'Form of Bid 2','bid-form-2.pdf','application/pdf','Bidding Document',28182908),(458,'Request','RequestDoc',3,'Bid Secuirty','bid-security-2.pdf','application/pdf','Bidding Document',2266584);
/*!40000 ALTER TABLE `uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `url` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` (`id`, `name`, `url`) VALUES (1,'Super Admin','admin'),(2,'Admin','staff'),(3,'Client','client'),(4,'Staff','staff-1');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) DEFAULT NULL,
  `name` varchar(139) DEFAULT NULL,
  `password` varchar(40) NOT NULL,
  `username` varchar(139) DEFAULT NULL,
  `business_approval_pending` int(11) NOT NULL DEFAULT '0',
  `url` varchar(139) DEFAULT NULL,
  `gender` smallint(1) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `login_ip` varchar(25) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `date_added` datetime DEFAULT NULL,
  `signup_ip` varchar(25) DEFAULT NULL,
  `pass_session` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `business_id` (`business_id`),
  KEY `role_id` (`role_id`),
  KEY `status_id` (`status_id`)
) ENGINE=MyISAM AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `business_id`, `name`, `password`, `username`, `business_approval_pending`, `url`, `gender`, `date_of_birth`, `last_login`, `login_ip`, `role_id`, `status_id`, `date_added`, `signup_ip`, `pass_session`) VALUES (1,NULL,'Himalayan Techies','1d4c478b4c3d1b77e42ac22c8715bd047c8b2753','htsadmin',0,'htsadmin',2,'1970-08-20','2014-07-16 14:22:49','202.51.76.235',1,6,'2013-08-20 16:13:20','110.34.4.243',NULL),(123,NULL,'Rofilitrix','b72f2fc31546cf250b62883c3eb436ef4fadd413','Haxor',0,'haxor',1,'2015-02-24',NULL,NULL,3,6,'2015-02-04 07:32:01','41.249.137.203',NULL),(122,NULL,'Bharat construction','53207088734c587be8c3cba1136fced6550aafd4','Navin kumar shahi',0,'navin-kumar-shahi',1,'1975-07-12','2014-07-15 19:13:02','202.166.221.40',3,6,'2014-07-15 19:09:22','202.166.221.40',NULL),(119,46,'Himal Hydro and General Construction Ltd','a34d5f0b4bb4d7fae6246caa13aecd133997f3b3','HH',0,'hh',1,'1970-01-01','2014-07-16 11:59:10','182.93.83.30',3,6,'2014-07-15 09:35:23','182.93.83.30',NULL),(14,NULL,'Himalayan Techies','1d4c478b4c3d1b77e42ac22c8715bd047c8b2753','htadmin',0,'htadmin',1,'1976-06-23','2013-12-20 19:07:27','117.121.231.210',2,6,'2013-10-22 11:43:55','36.253.220.78',NULL),(15,21,'Himalayan Techies','1d4c478b4c3d1b77e42ac22c8715bd047c8b2753','htclient',0,'htclient',1,'1970-01-01','2014-07-15 11:12:20','202.51.76.235',3,6,'2013-10-22 11:57:11','36.253.220.78',NULL),(58,21,'Saakshi Agrawal','9faf801fbb3d0c11e4c54fdd80344a46dc0b59a8','Saakshi',0,'saakshi-1',2,'1990-12-18','2014-07-15 11:22:32','202.51.76.235',3,6,'2013-12-02 12:28:01','110.44.115.4',NULL),(121,47,'Akhil','afcd7debe1881131fc46a831ef169b79b447e560','Multitech',0,'multitech',1,'2000-07-01','2014-07-16 10:13:08','113.199.131.239',3,6,'2014-07-15 10:48:33','113.199.149.98',NULL),(102,NULL,'Trishuli Jal','2dab168b3ea3e2c98b8e0913eebc6faae3d1478a','tjvcl',0,'tjvcl',1,'2013-12-02','2015-01-26 10:21:07','120.89.116.189',1,6,'2014-04-10 13:53:34','110.44.117.94',NULL),(109,37,'deepak pandey','6c51b9b30bf0983f50e2ce974ec67e4ae2abe462','d.pandey',0,'d-pandey',1,'1960-04-15','2014-06-02 10:16:03','113.199.178.222',3,6,'2014-04-20 10:47:19','113.199.166.117',NULL),(103,35,'kalyan khanal','167f0c8dd1af9a6c366735c45c0b93677147135a','kalyan',0,'kalyan',1,'1990-04-01','2014-05-04 14:33:26','113.199.130.245',3,6,'2014-04-17 15:39:05','113.199.153.72',NULL),(105,NULL,'DEBASIS BARMAN','029e9f64263f59f4f0fbcfcffc9f9022b5ed2d1a','debpriya1984',0,'debpriya1984',1,'1970-01-01','2014-04-28 11:36:14','14.141.48.10',3,6,'2014-04-17 17:42:01','14.141.48.10',NULL),(107,35,'deepak','6c51b9b30bf0983f50e2ce974ec67e4ae2abe462','deepak',1,'deepak',1,'2014-04-16','2014-07-15 10:09:43','120.89.113.3',3,6,'2014-04-18 11:19:17','113.199.174.78',NULL),(111,38,'Bishow Kumar Shrestha','bea2ad85d057a0ef8f6d1893b278df1eeb83d387','bishowkumar',0,'bishowkumar',1,'1985-02-21','2014-05-08 10:27:51','113.199.147.73',3,6,'2014-04-25 11:04:52','113.199.150.17',NULL),(112,39,'Sunil','1af512fef77b5fda19dadeea7fd8f2ab67b0b25b','sunil',0,'sunil',1,'1986-12-25','2014-04-27 12:41:15','113.199.132.31',3,6,'2014-04-25 11:28:51','113.199.177.129',NULL),(113,40,'kailash','67020e5ec9a10046ea2b602cba756347e09e97a4','buki',0,'buki',1,'1990-04-25','2014-04-25 12:02:54','113.199.177.129',3,6,'2014-04-25 11:43:14','113.199.177.129',NULL),(114,41,'Damodar Bhakta Shrestha','53e023861c626e8d5eebfac665152b8b8f7343e1','damo4890@gmail.com',0,'damo4890-gmail-com',1,'1961-07-16','2014-04-25 11:57:10','113.199.177.129',3,6,'2014-04-25 11:49:57','113.199.177.129',NULL),(115,42,'Kalyan Khanal','167f0c8dd1af9a6c366735c45c0b93677147135a','Opus ',0,'opus',1,'1989-04-01','2014-05-07 14:52:08','113.199.146.182',3,6,'2014-04-25 12:52:19','113.199.177.129',NULL),(120,45,'check ebid','3068c50bccf9d9f68d4d37f5b6681e1b4c427021','check ebid',0,'check-ebid',1,'1990-01-01',NULL,NULL,3,6,'2014-07-15 10:12:06','120.89.113.3',NULL),(117,43,'SS','7383bea647746c25b7e0e2e11779306d254d2d2c','snl',0,'snl',1,'1990-04-01','2014-07-15 17:02:11','120.89.113.3',3,6,'2014-04-30 10:55:13','113.199.139.149',NULL),(118,44,'BAJRA GURU-DIWA JV','d78e73554ea889c8093e9410d1a9d6b8fe8381d7','BAJRADIWA',0,'bajradiwa',NULL,'1970-01-01','2014-05-28 14:01:22','113.199.146.62',3,6,'2014-05-28 13:58:21','113.199.146.62',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'trishuli_bidding'
--

--
-- Dumping routines for database 'trishuli_bidding'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-03-21  9:47:04
