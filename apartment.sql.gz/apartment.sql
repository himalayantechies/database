-- phpMyAdmin SQL Dump
-- version 4.5.0-dev
-- http://www.phpmyadmin.net
--
-- Host: himalayantechies-db-server.cepyls6xdgwo.us-west-2.rds.amazonaws.com
-- Generation Time: Jun 21, 2015 at 04:50 AM
-- Server version: 5.6.19-log
-- PHP Version: 5.4.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `apartment`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=973 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `apartments`
--

CREATE TABLE IF NOT EXISTS `apartments` (
  `id` int(11) NOT NULL,
  `tower_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `apartment_type_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `apartments`
--

INSERT INTO `apartments` (`id`, `tower_id`, `name`, `apartment_type_id`, `created`, `modified`, `updated`) VALUES
(2, 1, '101', 2, '2014-07-01 10:36:53', 1405314512, '2014-07-14 05:08:32'),
(3, 1, '102', 1, '2014-07-02 11:47:03', 1404979054, '2014-07-10 07:57:34'),
(4, 1, '103', 2, '2014-07-02 12:22:36', 1404897384, '2014-07-09 09:16:24'),
(5, 1, '104', 1, '2014-07-02 12:23:29', 1404897395, '2014-07-09 09:16:35'),
(6, 1, '111', 2, '2014-07-02 12:23:51', 1404897407, '2014-07-09 09:16:47'),
(7, 1, '112', 1, '2014-07-02 12:24:49', 1404897419, '2014-07-09 09:16:59'),
(8, 1, '113', 2, '2014-07-02 12:25:25', 1404897431, '2014-07-09 09:17:11'),
(9, 1, '114', 2, '2014-07-02 12:25:42', 1404897443, '2014-07-09 09:17:23'),
(10, 2, '201', 1, '2014-07-08 07:59:06', 1404897373, '2014-07-09 09:16:13'),
(11, 2, '202', 1, '2014-07-28 05:32:38', 1407140781, '2014-08-04 08:26:21'),
(12, 3, '301', 2, '2014-08-04 08:26:02', 1407140762, '2014-08-04 08:26:02');

-- --------------------------------------------------------

--
-- Table structure for table `apartments_users`
--

CREATE TABLE IF NOT EXISTS `apartments_users` (
  `id` int(11) NOT NULL,
  `apartment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `apartment_types`
--

CREATE TABLE IF NOT EXISTS `apartment_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `covered_area` double DEFAULT NULL,
  `total_area` double DEFAULT NULL,
  `measurement_id` int(11) DEFAULT NULL,
  `no_of_bedrooms` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `apartment_types`
--

INSERT INTO `apartment_types` (`id`, `name`, `covered_area`, `total_area`, `measurement_id`, `no_of_bedrooms`, `created`, `modified`, `updated`) VALUES
(1, 'Apartment B', 2099, 2150, 1, 4, '2014-07-09 09:14:50', 1405314977, '2014-07-14 05:16:17'),
(2, 'Apartment A', 1599, 1800, 1, 3, '2014-07-09 09:15:14', 1405314947, '2014-07-14 05:15:47');

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=1232 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) NOT NULL,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) NOT NULL DEFAULT '0',
  `_read` varchar(2) NOT NULL DEFAULT '0',
  `_update` varchar(2) NOT NULL DEFAULT '0',
  `_delete` varchar(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=316 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE IF NOT EXISTS `attachments` (
  `id` int(11) NOT NULL,
  `issue_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `mime` varchar(255) DEFAULT NULL,
  `directory` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `attachments`
--

INSERT INTO `attachments` (`id`, `issue_id`, `name`, `filename`, `size`, `mime`, `directory`, `user_id`, `created`, `modified`, `updated`) VALUES
(1, 1, 'e-quotation-format-1.xlsx', 'E Quotation - Format.xlsx', 19515, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'files/issue/issue1', NULL, '2014-07-11 08:39:30', 1405067970, '2014-07-11 08:39:30'),
(2, 1, '1256.xlsx', '1256.xlsx', 12980, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'files/issue/issue1', NULL, '2014-07-11 09:01:14', 1405069274, '2014-07-11 09:01:14'),
(3, 4, 'download-1.jpg', 'download (1).jpg', 16922, 'image/jpeg', 'files/issue/issue4', 1, '2014-07-21 05:29:11', 1405920551, '2014-07-21 05:29:11'),
(4, 5, 'download-1.jpg', 'download (1).jpg', 16922, 'image/jpeg', 'files/issue/issue5', 1, '2014-07-21 05:29:22', 1405920562, '2014-07-21 05:29:22'),
(5, 6, 'download-1.jpg', 'download (1).jpg', 16922, 'image/jpeg', 'files/issue/issue6', 1, '2014-07-21 05:29:51', 1405920591, '2014-07-21 05:29:51'),
(6, 7, '1256.pdf', '1256.pdf', 278262, 'application/pdf', 'files/issue/issue7', 1, '2014-07-28 05:38:00', 1406525880, '2014-07-28 05:38:00'),
(7, 7, 'images.jpg', 'images.jpg', 7448, 'image/jpeg', 'files/issue/issue7', 1, '2014-07-28 05:38:32', 1406525912, '2014-07-28 05:38:32');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL,
  `commented_id` int(11) NOT NULL,
  `comment_type` varchar(255) DEFAULT NULL,
  `comments` text,
  `user_id` int(11) DEFAULT NULL,
  `commented_date` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `commented_id`, `comment_type`, `comments`, `user_id`, `commented_date`, `created`, `modified`, `updated`) VALUES
(1, 0, 'A', 'This is testing', 2, '2014-07-28 00:00:00', '2014-07-22 07:57:51', 1406015900, '2014-07-22 07:58:20');

-- --------------------------------------------------------

--
-- Table structure for table `committees`
--

CREATE TABLE IF NOT EXISTS `committees` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `facility_id` int(11) DEFAULT NULL,
  `active` int(1) DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `description` text,
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `committees`
--

INSERT INTO `committees` (`id`, `name`, `facility_id`, `active`, `start_date`, `end_date`, `description`, `created`, `modified`, `updated`) VALUES
(1, 'Residence Welfare Association', 1, 1, '2014-06-30 06:36:00', '2014-06-30 06:36:00', '', '2014-06-30 06:37:15', 1406526076, '2014-07-28 05:41:16'),
(2, 'Grounds Keeping Committee', NULL, 0, '2014-07-01 00:00:00', '2014-10-31 00:00:00', 'Committee to look after the grounds.', '2014-07-16 09:35:14', 1405503314, '2014-07-16 09:35:14');

-- --------------------------------------------------------

--
-- Table structure for table `committees_users`
--

CREATE TABLE IF NOT EXISTS `committees_users` (
  `id` int(11) NOT NULL,
  `committee_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `committees_users`
--

INSERT INTO `committees_users` (`id`, `committee_id`, `user_id`, `designation`, `created`, `modified`, `updated`) VALUES
(1, 1, 2, 'Committee Incharge', '2014-07-02 07:37:11', 1405310066, '2014-07-14 03:54:26'),
(2, 1, 4, 'Reporter', '2014-07-08 07:37:36', 1404805056, '2014-07-08 07:37:36');

-- --------------------------------------------------------

--
-- Table structure for table `contractors`
--

CREATE TABLE IF NOT EXISTS `contractors` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `primary_phone` varchar(255) NOT NULL,
  `secondary_phone` varchar(255) NOT NULL,
  `primary_mobile` varchar(255) NOT NULL,
  `secondary_mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `primary_contact` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `primary_email` varchar(255) NOT NULL,
  `primary_contact_mobile` varchar(255) NOT NULL,
  `alternate_contact` varchar(255) NOT NULL,
  `alternate_mobile` varchar(255) NOT NULL,
  `alternate_email` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contractors`
--

INSERT INTO `contractors` (`id`, `name`, `address`, `primary_phone`, `secondary_phone`, `primary_mobile`, `secondary_mobile`, `email`, `primary_contact`, `designation`, `primary_email`, `primary_contact_mobile`, `alternate_contact`, `alternate_mobile`, `alternate_email`, `created`, `modified`, `updated`) VALUES
(1, 'Water Purifier', 'Sanepa', '9985410123', '', '', '', 'info@himalayantechies.com', '', '', '', '', '', '', '', '2014-06-09 09:44:03', 1402307043, '2014-06-09 09:44:03');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `name`, `start_date`, `end_date`, `description`, `created`, `modified`, `updated`) VALUES
(2, 'Birthday Party', '2014-07-14 00:00:00', '2014-08-09 00:00:00', '', '2014-07-22 07:53:25', 1406015605, '2014-07-22 07:53:25');

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE IF NOT EXISTS `facilities` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `contractor_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`id`, `name`, `location`, `contractor_id`, `created`, `modified`, `updated`) VALUES
(1, 'RO Water Purification', 'Basement', 1, '2014-06-30 06:31:44', 1404109904, '2014-06-30 06:31:44'),
(2, 'Silver Squash Room', 'Tower 9 Basement', 1, '2014-07-17 05:05:38', 1405573538, '2014-07-17 05:05:38'),
(3, 'Silver Swimming Pool', 'Behind Tower 5', 0, '2014-07-17 05:07:47', 1406114231, '2014-07-23 11:17:11'),
(4, 'Badminton Court', 'Central Park', 1, '2014-07-17 05:10:18', 1405573818, '2014-07-17 05:10:18'),
(5, 'Tennish Court', 'Central Park', 1, '2014-07-17 05:10:44', 1405573844, '2014-07-17 05:10:44'),
(6, 'Party Hall', 'Ground floor', 1, '2014-07-21 05:25:45', 1405920370, '2014-07-21 05:26:10');

-- --------------------------------------------------------

--
-- Table structure for table `issues`
--

CREATE TABLE IF NOT EXISTS `issues` (
  `id` int(11) NOT NULL,
  `tracker_id` int(11) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `desciption` longtext,
  `status_id` int(11) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `estimated_time` varchar(100) DEFAULT NULL,
  `estimated_cost` double DEFAULT NULL,
  `final_cost` double DEFAULT NULL,
  `committee_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `related_task` varchar(255) DEFAULT NULL,
  `done_ratio` int(11) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `issues`
--

INSERT INTO `issues` (`id`, `tracker_id`, `subject`, `desciption`, `status_id`, `priority`, `start_date`, `end_date`, `estimated_time`, `estimated_cost`, `final_cost`, `committee_id`, `user_id`, `author_id`, `related_task`, `done_ratio`, `created`, `modified`, `updated`) VALUES
(1, 2, 'Fix the plumbing in tower 2', 'Fix the plumbing in tower 2 floor 1. The water is flooding the whole place', 1, 'High', '2014-07-15 00:00:00', '2014-07-24 00:00:00', '5', 1500, 5000, NULL, 3, NULL, '', 0, '2014-07-08 10:34:35', 1405501977, '2014-07-16 09:12:57'),
(2, 2, 'Leaking Pipe', 'New Description.', 2, 'High', '2014-06-29 00:00:00', '2014-08-09 00:00:00', '', NULL, NULL, 1, NULL, NULL, '', 0, '2014-07-09 08:04:54', 1405507420, '2014-07-16 10:43:40'),
(3, 1, 'Shot Circuit', '', 1, 'Normal', '2014-07-13 00:00:00', '2014-08-09 00:00:00', '20:00:00', 345, 500, NULL, 2, NULL, '', 0, '2014-07-14 09:33:33', 1405330413, '2014-07-14 09:33:33'),
(4, 2, 'Leaking pipes', '', 1, 'High', '2014-06-30 00:00:00', '2014-07-23 00:00:00', '2', 29, 20, 1, 1, 1, '1', 60, '2014-07-21 05:29:11', 1405920551, '2014-07-21 05:29:11'),
(5, 2, 'Leaking pipes', '', 1, 'High', '2014-06-30 00:00:00', '2014-07-23 00:00:00', '2', 29, 20, 1, 1, 1, '1', 60, '2014-07-21 05:29:20', 1405920560, '2014-07-21 05:29:20'),
(6, 2, 'Leaking pipes', '', 1, 'High', '2014-06-30 00:00:00', '2014-07-23 00:00:00', '2', 29, 20, 1, NULL, 1, '1', 60, '2014-07-21 05:29:51', 1405920591, '2014-07-21 05:29:51'),
(7, 1, 'Electricity', '', 1, 'Urgent', '2014-06-29 00:00:00', '2014-07-14 00:00:00', '8', 800, 1000, 1, 2, 1, '1', 50, '2014-07-28 05:37:26', 1406525912, '2014-07-28 05:38:32');

-- --------------------------------------------------------

--
-- Table structure for table `issue_relations`
--

CREATE TABLE IF NOT EXISTS `issue_relations` (
  `id` int(11) NOT NULL,
  `issue_from_id` int(11) NOT NULL,
  `issue_to_id` int(11) NOT NULL,
  `relation_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `delay` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `issue_relations`
--

INSERT INTO `issue_relations` (`id`, `issue_from_id`, `issue_to_id`, `relation_type`, `delay`) VALUES
(1, 1, 4, 'relates', NULL),
(2, 1, 5, 'relates', NULL),
(3, 1, 6, 'relates', NULL),
(4, 1, 7, 'relates', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `issue_statuses`
--

CREATE TABLE IF NOT EXISTS `issue_statuses` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `issue_statuses`
--

INSERT INTO `issue_statuses` (`id`, `name`, `is_closed`, `is_default`, `position`) VALUES
(1, 'New', 0, 1, 1),
(2, 'Assigned', 0, 0, 2),
(3, 'Resolved', 0, 0, 3),
(4, 'Feedback', 0, 0, 4),
(5, 'Closed', 1, 0, 5),
(6, 'Rejected', 1, 0, 6);

-- --------------------------------------------------------

--
-- Table structure for table `journals`
--

CREATE TABLE IF NOT EXISTS `journals` (
  `id` int(11) NOT NULL,
  `journalized_id` int(11) NOT NULL DEFAULT '0',
  `journalized_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8_unicode_ci,
  `created_on` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `journals`
--

INSERT INTO `journals` (`id`, `journalized_id`, `journalized_type`, `user_id`, `notes`, `created_on`) VALUES
(1, 7, 'issue', 1, '', '2014-07-28 05:38:00'),
(2, 7, 'issue', 1, '', '2014-07-28 05:38:32');

-- --------------------------------------------------------

--
-- Table structure for table `journal_details`
--

CREATE TABLE IF NOT EXISTS `journal_details` (
  `id` int(11) NOT NULL,
  `journal_id` int(11) NOT NULL DEFAULT '0',
  `property` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `prop_key` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `journal_details`
--

INSERT INTO `journal_details` (`id`, `journal_id`, `property`, `prop_key`, `old_value`, `value`) VALUES
(1, 1, 'attachment', 'attach_id', NULL, '1256.pdf'),
(2, 2, 'attachment', 'attach_id', NULL, 'images.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance_charges`
--

CREATE TABLE IF NOT EXISTS `maintenance_charges` (
  `id` int(11) NOT NULL,
  `apartment_type_id` int(11) NOT NULL,
  `maintenance_charge` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `measurement_id` int(11) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `maintenance_charges`
--

INSERT INTO `maintenance_charges` (`id`, `apartment_type_id`, `maintenance_charge`, `measurement_id`, `start_date`, `end_date`, `created`, `modified`, `updated`) VALUES
(1, 1, '2000', 1, '2014-07-06 00:00:00', '2014-08-09 00:00:00', '2014-07-10 07:54:30', 1404978870, '2014-07-10 07:54:30');

-- --------------------------------------------------------

--
-- Table structure for table `measurements`
--

CREATE TABLE IF NOT EXISTS `measurements` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `measurements`
--

INSERT INTO `measurements` (`id`, `name`, `created`, `modified`, `updated`) VALUES
(1, 'Sq. Ft.', '2014-07-09 09:14:08', 1405313780, '2014-07-14 04:56:20'),
(2, 'Sq. Meter', '2014-07-09 09:14:19', 1405313795, '2014-07-14 04:56:35');

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE IF NOT EXISTS `notices` (
  `id` int(11) NOT NULL,
  `notice_type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notices`
--

INSERT INTO `notices` (`id`, `notice_type`, `title`, `message`, `start_date`, `end_date`, `created`, `modified`, `updated`) VALUES
(1, '1', 'test', '', '2014-07-29 00:00:00', '2014-08-09 00:00:00', '2014-07-28 05:33:58', 1406525648, '2014-07-28 05:34:08');

-- --------------------------------------------------------

--
-- Table structure for table `parkings`
--

CREATE TABLE IF NOT EXISTS `parkings` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `apartment_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `parkings`
--

INSERT INTO `parkings` (`id`, `name`, `apartment_id`, `created`, `modified`, `updated`) VALUES
(1, 'Parking 1', 1, '2014-07-01 10:30:06', 1404210606, '2014-07-01 10:30:06'),
(2, 'Parking 1', 1, '2014-07-01 10:35:06', 1404210906, '2014-07-01 10:35:06'),
(3, '', 2, '2014-07-02 07:38:01', 1404286681, '2014-07-02 07:38:01'),
(4, '1254ht', 2, '2014-07-03 08:41:05', 1404376865, '2014-07-03 08:41:05'),
(5, '897ht', 2, '2014-07-11 06:58:35', 1405061915, '2014-07-11 06:58:35');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `permissions` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `permissions`, `created`, `modified`, `updated`) VALUES
(1, 'Administrator', '', '2014-06-23 05:24:45', 1403501085, '2014-06-23 05:24:45'),
(2, 'Owner', '', '2014-06-23 05:25:14', 1403501114, '2014-06-23 05:25:14'),
(3, 'Rentor', '', '2014-06-23 05:25:32', 1403501132, '2014-06-23 05:25:32');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rate` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `rate`, `description`, `created`, `modified`, `updated`) VALUES
(2, 'Car Wash', '50 per car wash', '50 per car wash', '2014-07-07 04:29:19', 1404804755, '2014-07-08 07:32:35'),
(4, 'Ironing', '.50 per cloth', '', '2014-07-08 07:33:03', 1404804783, '2014-07-08 07:33:03');

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE IF NOT EXISTS `statuses` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `name`, `created`, `modified`, `updated`) VALUES
(1, 'Active', '2014-07-29 05:33:22', 1406612002, '2014-07-29 05:33:22');

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subscription_type` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `user_id`, `category_id`, `subscription_type`, `created`, `modified`, `updated`) VALUES
(1, 2, 0, '123', '2014-07-22 07:42:20', 1406014991, '2014-07-22 07:43:11');

-- --------------------------------------------------------

--
-- Table structure for table `time_logs`
--

CREATE TABLE IF NOT EXISTS `time_logs` (
  `id` int(11) NOT NULL,
  `issue_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `spend_time` varchar(100) DEFAULT NULL,
  `applicable_cost` double NOT NULL,
  `comments` longtext NOT NULL,
  `logged_on` datetime NOT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `time_logs`
--

INSERT INTO `time_logs` (`id`, `issue_id`, `user_id`, `spend_time`, `applicable_cost`, `comments`, `logged_on`, `created`, `modified`, `updated`) VALUES
(1, 1, 1, '2014-08-07 00:00:00', 500, 'testing', '2014-07-22 00:00:00', '2014-07-22 07:35:47', 1406014547, '2014-07-22 07:35:47');

-- --------------------------------------------------------

--
-- Table structure for table `towers`
--

CREATE TABLE IF NOT EXISTS `towers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `towers`
--

INSERT INTO `towers` (`id`, `name`, `created`, `modified`, `updated`) VALUES
(1, 'Tower 01', '2014-06-09 09:59:58', 1402307998, '2014-06-09 09:59:58'),
(2, 'Tower 02', '2014-06-09 10:00:17', 1402308017, '2014-06-09 10:00:17'),
(3, 'Tower 03', '2014-07-02 12:17:59', 1404303479, '2014-07-02 12:17:59'),
(4, 'Tower 04', '2014-07-02 12:18:13', 1404303493, '2014-07-02 12:18:13'),
(5, 'Tower 05', '2014-07-02 12:18:58', 1404303538, '2014-07-02 12:18:58'),
(6, 'Tower 06', '2014-07-02 12:19:03', 1404303543, '2014-07-02 12:19:03'),
(7, 'Tower 07', '2014-07-02 12:19:08', 1404303548, '2014-07-02 12:19:08');

-- --------------------------------------------------------

--
-- Table structure for table `trackers`
--

CREATE TABLE IF NOT EXISTS `trackers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trackers`
--

INSERT INTO `trackers` (`id`, `name`, `created`, `modified`, `updated`) VALUES
(1, 'Electricity', '2014-06-23 04:58:17', 1405318077, '2014-07-14 06:07:57'),
(2, 'Plumbing', '2014-06-23 04:58:53', 1405318092, '2014-07-14 06:08:12'),
(3, 'Open Space', '2014-06-23 04:59:07', 1405318187, '2014-07-14 06:09:47'),
(4, 'Parking', '2014-06-23 04:59:19', 1405318207, '2014-07-14 06:10:07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `status_id` int(11) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `registered_on` datetime DEFAULT NULL,
  `primary_mobile` varchar(255) DEFAULT NULL,
  `alternate_mobile` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `url`, `status_id`, `username`, `email`, `last_login`, `registered_on`, `primary_mobile`, `alternate_mobile`, `address`, `created`, `modified`, `updated`) VALUES
(1, 'Arpita Singh', '515a00680c332d799df14a76a1f3f8f4f53c3fb7', 'arpita', NULL, 'htadmin', 'asingh@himalayantechies.com', '2015-04-17 06:19:09', '2014-05-27 06:54:00', '9841112113', '9867123123', 'fdfdsv', '2014-05-27 06:56:11', 1429251549, '2015-04-17 06:19:09'),
(2, 'Sakshi Agrawal', '8333e02966267861d1766023511d0a149a116f8e', '', NULL, 'sakshi', 'sagrawal@himalayantechies.com', '2014-06-20 07:14:31', '2014-06-09 10:01:00', '', '', '', '2014-06-09 10:02:23', 1406525744, '2014-07-28 05:35:44'),
(3, 'Vaibhaw Poddar', '123456', 'vaibhaw-poddar', NULL, '', 'bob@himalayantechies.com', NULL, '2014-06-23 05:01:42', '9851061345', '9999916615', '', '2014-06-23 05:01:42', 1404304290, '2014-07-02 12:31:30'),
(4, 'Sajwal Tamrakar', '2b507be7361406c4006389803a517b56c941fb1d', 'stamrakar', NULL, 'stamrakar', 'stamrakar@himalayantechies.com', NULL, '2014-06-30 06:17:24', '5551007', '5551007', '', '2014-06-30 06:17:24', 1404304174, '2014-07-02 12:29:34'),
(5, 'Rashik Maharjan', '2b507be7361406c4006389803a517b56c941fb1d', 'rashik', NULL, 'rashik', 'rmaharjan@himalayantechies.com', NULL, '2014-07-02 12:14:57', '', '', '', '2014-07-02 12:14:57', 1404303297, '2014-07-02 12:14:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acos`
--
ALTER TABLE `acos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apartments`
--
ALTER TABLE `apartments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apartments_users`
--
ALTER TABLE `apartments_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apartment_types`
--
ALTER TABLE `apartment_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros`
--
ALTER TABLE `aros`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros_acos`
--
ALTER TABLE `aros_acos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ARO_ACO_KEY` (`aro_id`,`aco_id`);

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `committees`
--
ALTER TABLE `committees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `committees_users`
--
ALTER TABLE `committees_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contractors`
--
ALTER TABLE `contractors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issues`
--
ALTER TABLE `issues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issue_relations`
--
ALTER TABLE `issue_relations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issue_statuses`
--
ALTER TABLE `issue_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `journals`
--
ALTER TABLE `journals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `journals_journalized_id` (`journalized_id`,`journalized_type`);

--
-- Indexes for table `journal_details`
--
ALTER TABLE `journal_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `journal_details_journal_id` (`journal_id`);

--
-- Indexes for table `maintenance_charges`
--
ALTER TABLE `maintenance_charges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `measurements`
--
ALTER TABLE `measurements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notices`
--
ALTER TABLE `notices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parkings`
--
ALTER TABLE `parkings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `time_logs`
--
ALTER TABLE `time_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `towers`
--
ALTER TABLE `towers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trackers`
--
ALTER TABLE `trackers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acos`
--
ALTER TABLE `acos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=973;
--
-- AUTO_INCREMENT for table `apartments`
--
ALTER TABLE `apartments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `apartments_users`
--
ALTER TABLE `apartments_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `apartment_types`
--
ALTER TABLE `apartment_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `aros`
--
ALTER TABLE `aros`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1232;
--
-- AUTO_INCREMENT for table `aros_acos`
--
ALTER TABLE `aros_acos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=316;
--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `committees`
--
ALTER TABLE `committees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `committees_users`
--
ALTER TABLE `committees_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `contractors`
--
ALTER TABLE `contractors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `facilities`
--
ALTER TABLE `facilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `issues`
--
ALTER TABLE `issues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `issue_relations`
--
ALTER TABLE `issue_relations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `issue_statuses`
--
ALTER TABLE `issue_statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `journals`
--
ALTER TABLE `journals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `journal_details`
--
ALTER TABLE `journal_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `maintenance_charges`
--
ALTER TABLE `maintenance_charges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `measurements`
--
ALTER TABLE `measurements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `notices`
--
ALTER TABLE `notices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `parkings`
--
ALTER TABLE `parkings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `time_logs`
--
ALTER TABLE `time_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `towers`
--
ALTER TABLE `towers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `trackers`
--
ALTER TABLE `trackers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
