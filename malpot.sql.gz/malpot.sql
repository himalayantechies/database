-- phpMyAdmin SQL Dump
-- version 4.5.0-dev
-- http://www.phpmyadmin.net
--
-- Host: himalayantechies-db-server.cepyls6xdgwo.us-west-2.rds.amazonaws.com
-- Generation Time: Jun 22, 2015 at 03:21 AM
-- Server version: 5.6.19-log
-- PHP Version: 5.4.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `malpot`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) unsigned NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT '',
  `foreign_key` int(10) unsigned DEFAULT NULL,
  `alias` varchar(255) DEFAULT '',
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `acos`
--

INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, NULL, NULL, 'controllers', 1, 186),
(2, 1, NULL, NULL, 'Documents', 2, 19),
(3, 2, NULL, NULL, 'deleteUpload', 3, 4),
(4, 2, NULL, NULL, 'create_zip', 5, 6),
(5, 2, NULL, NULL, 'recovery', 7, 8),
(6, 2, NULL, NULL, 'list_zipfiles', 9, 10),
(7, 2, NULL, NULL, 'delete_zipifles', 11, 12),
(8, 2, NULL, NULL, 'setLanguage', 13, 14),
(9, 2, NULL, NULL, 'langConvert', 15, 16),
(10, 2, NULL, NULL, 'revertToEng', 17, 18),
(11, 1, NULL, NULL, 'Groups', 20, 33),
(12, 11, NULL, NULL, 'add', 21, 22),
(13, 11, NULL, NULL, 'index', 23, 24),
(14, 11, NULL, NULL, 'delete', 25, 26),
(15, 11, NULL, NULL, 'setLanguage', 27, 28),
(16, 11, NULL, NULL, 'langConvert', 29, 30),
(17, 11, NULL, NULL, 'revertToEng', 31, 32),
(18, 1, NULL, NULL, 'Mishils', 34, 121),
(19, 18, NULL, NULL, 'gen_info', 35, 36),
(20, 18, NULL, NULL, 'land_info', 37, 38),
(21, 18, NULL, NULL, 'building_info', 39, 40),
(22, 18, NULL, NULL, 'verification', 41, 42),
(23, 18, NULL, NULL, 'designer', 43, 44),
(24, 18, NULL, NULL, 'add_designer', 45, 46),
(25, 18, NULL, NULL, 'getDesignerList', 47, 48),
(26, 18, NULL, NULL, 'addOwner', 49, 50),
(27, 18, NULL, NULL, 'addApplicant', 51, 52),
(28, 18, NULL, NULL, 'addVerificationUpload', 53, 54),
(29, 18, NULL, NULL, 'addDesignerUpload', 55, 56),
(30, 18, NULL, NULL, 'landArea', 57, 58),
(31, 18, NULL, NULL, 'floorArea', 59, 60),
(32, 18, NULL, NULL, 'deleteFloorInfo', 61, 62),
(33, 18, NULL, NULL, 'deleteTaxDeposit', 63, 64),
(34, 18, NULL, NULL, 'deleteLandInfo', 65, 66),
(35, 18, NULL, NULL, 'deleteVerification', 67, 68),
(36, 18, NULL, NULL, 'upload', 69, 70),
(37, 18, NULL, NULL, 'ownerDelete', 71, 72),
(38, 18, NULL, NULL, 'document_list', 73, 74),
(39, 18, NULL, NULL, 'tax', 75, 76),
(40, 18, NULL, NULL, 'taxDocument', 77, 78),
(41, 18, NULL, NULL, 'mishils', 79, 80),
(42, 18, NULL, NULL, 'building_infos', 81, 82),
(43, 18, NULL, NULL, 'land_infos', 83, 84),
(44, 18, NULL, NULL, 'landArea_details', 85, 86),
(45, 18, NULL, NULL, 'floorArea_details', 87, 88),
(46, 18, NULL, NULL, 'tax_details', 89, 90),
(47, 18, NULL, NULL, 'verification_details', 91, 92),
(48, 18, NULL, NULL, 'designer_details', 93, 94),
(49, 18, NULL, NULL, 'landOwner_details', 95, 96),
(50, 18, NULL, NULL, 'buildingOwner_details', 97, 98),
(51, 18, NULL, NULL, 'landOwner_groups', 99, 100),
(52, 18, NULL, NULL, 'buildingOwner_groups', 101, 102),
(53, 18, NULL, NULL, 'change_status', 103, 104),
(54, 18, NULL, NULL, 'change_Ownerstatus', 105, 106),
(55, 18, NULL, NULL, 'mishilNoByBuildingId', 107, 108),
(56, 18, NULL, NULL, 'mishilNoByLandId', 109, 110),
(57, 18, NULL, NULL, 'setLanguage', 111, 112),
(58, 18, NULL, NULL, 'langConvert', 113, 114),
(59, 18, NULL, NULL, 'revertToEng', 115, 116),
(60, 1, NULL, NULL, 'MonthNepalis', 122, 137),
(61, 60, NULL, NULL, 'index', 123, 124),
(62, 60, NULL, NULL, 'edit', 125, 126),
(63, 60, NULL, NULL, 'save', 127, 128),
(64, 60, NULL, NULL, 'delete', 129, 130),
(65, 60, NULL, NULL, 'setLanguage', 131, 132),
(66, 60, NULL, NULL, 'langConvert', 133, 134),
(67, 60, NULL, NULL, 'revertToEng', 135, 136),
(68, 1, NULL, NULL, 'Pages', 138, 147),
(69, 68, NULL, NULL, 'display', 139, 140),
(70, 68, NULL, NULL, 'setLanguage', 141, 142),
(71, 68, NULL, NULL, 'langConvert', 143, 144),
(72, 68, NULL, NULL, 'revertToEng', 145, 146),
(73, 1, NULL, NULL, 'Searches', 148, 157),
(74, 73, NULL, NULL, 'search', 149, 150),
(75, 73, NULL, NULL, 'setLanguage', 151, 152),
(76, 73, NULL, NULL, 'langConvert', 153, 154),
(77, 73, NULL, NULL, 'revertToEng', 155, 156),
(78, 1, NULL, NULL, 'Users', 158, 181),
(79, 78, NULL, NULL, 'login', 159, 160),
(80, 78, NULL, NULL, 'logout', 161, 162),
(81, 78, NULL, NULL, 'index', 163, 164),
(82, 78, NULL, NULL, 'register', 165, 166),
(83, 78, NULL, NULL, 'view', 167, 168),
(84, 78, NULL, NULL, 'usernameById', 169, 170),
(85, 78, NULL, NULL, 'change_password', 171, 172),
(86, 78, NULL, NULL, 'initDB', 173, 174),
(87, 78, NULL, NULL, 'setLanguage', 175, 176),
(88, 78, NULL, NULL, 'langConvert', 177, 178),
(89, 78, NULL, NULL, 'revertToEng', 179, 180),
(90, 1, NULL, NULL, 'AclExtras', 182, 183),
(91, 1, NULL, NULL, 'FileUpload', 184, 185),
(92, 18, NULL, NULL, 'designers_list', 117, 118),
(93, 18, NULL, NULL, 'mishils_list', 119, 120);

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) unsigned NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT '',
  `foreign_key` int(10) unsigned DEFAULT NULL,
  `alias` varchar(255) DEFAULT '',
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aros`
--

INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, 'Group', 1, 'admin', 1, 18),
(2, NULL, 'Group', 2, 'managers', 19, 24),
(3, NULL, 'Group', 3, 'users', 25, 30),
(4, 1, 'User', 1, 'admin', 2, 3),
(5, 2, 'User', 2, 'manager1', 20, 21),
(6, 3, 'User', 3, 'user1', 26, 27),
(7, 1, 'User', 4, 'rwer', 4, 5),
(8, 1, 'User', 5, 'loginuser', 6, 7),
(9, 1, 'User', 6, 'loginuser1', 8, 9),
(10, 1, 'User', 7, 'loginuser2', 10, 11),
(11, 1, 'User', 8, 'loginuser3', 12, 13),
(12, 1, 'User', 9, 'ram', 14, 15),
(13, 2, 'User', 10, 'laxmanm', 22, 23),
(14, 3, 'User', 11, 'laxmanu', 28, 29),
(15, 1, 'User', 9, 'ram', 16, 17);

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) unsigned NOT NULL,
  `aro_id` int(10) unsigned NOT NULL,
  `aco_id` int(10) unsigned NOT NULL,
  `_create` char(2) NOT NULL DEFAULT '0',
  `_read` char(2) NOT NULL DEFAULT '0',
  `_update` char(2) NOT NULL DEFAULT '0',
  `_delete` char(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aros_acos`
--

INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES
(1, 1, 1, '1', '1', '1', '1'),
(2, 2, 1, '-1', '-1', '-1', '-1'),
(3, 2, 44, '-1', '-1', '-1', '-1'),
(4, 2, 6, '-1', '-1', '-1', '-1'),
(5, 2, 15, '1', '1', '1', '1'),
(6, 2, 54, '1', '1', '1', '1'),
(7, 2, 2, '1', '1', '1', '1'),
(8, 2, 58, '1', '1', '1', '1'),
(9, 3, 1, '-1', '-1', '-1', '-1'),
(10, 3, 58, '1', '1', '1', '1'),
(11, 1, 74, '1', '1', '1', '1'),
(12, 2, 74, '-1', '-1', '-1', '-1'),
(13, 2, 118, '-1', '-1', '-1', '-1'),
(14, 2, 79, '-1', '-1', '-1', '-1'),
(15, 2, 88, '1', '1', '1', '1'),
(16, 2, 130, '1', '1', '1', '1'),
(17, 2, 75, '1', '1', '1', '1'),
(18, 2, 134, '1', '1', '1', '1'),
(19, 2, 178, '1', '1', '1', '1'),
(20, 3, 74, '-1', '-1', '-1', '-1'),
(21, 3, 134, '1', '1', '1', '1'),
(22, 3, 178, '1', '1', '1', '1'),
(23, 2, 53, '-1', '-1', '-1', '-1'),
(24, 2, 18, '1', '1', '1', '1'),
(25, 2, 68, '1', '1', '1', '1'),
(26, 2, 73, '1', '1', '1', '1'),
(27, 2, 85, '1', '1', '1', '1'),
(28, 3, 73, '1', '1', '1', '1'),
(29, 3, 85, '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `buildings`
--

CREATE TABLE IF NOT EXISTS `buildings` (
  `id` int(11) NOT NULL,
  `mishil_id` int(11) DEFAULT NULL,
  `purpose_id` int(11) DEFAULT NULL,
  `construction_type_id` int(11) DEFAULT NULL,
  `building_type_id` int(11) DEFAULT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `buildings`
--

INSERT INTO `buildings` (`id`, `mishil_id`, `purpose_id`, `construction_type_id`, `building_type_id`, `zone_id`, `user_id`, `time`, `status`, `parent_id`, `lft`, `rght`, `url`) VALUES
(1, 1, NULL, NULL, NULL, NULL, 1, '2012-12-04 04:06:16', 1, NULL, 1, 2, 'building1'),
(2, 3, NULL, NULL, NULL, NULL, 1, '2012-12-04 04:22:39', 0, NULL, 3, 6, 'building3'),
(4, 3, 1, 3, 12, 14, 1, '2012-12-05 12:14:29', 1, 2, 4, 5, 'building3-1');

-- --------------------------------------------------------

--
-- Table structure for table `buildings_designers`
--

CREATE TABLE IF NOT EXISTS `buildings_designers` (
  `id` int(11) NOT NULL,
  `building_id` int(11) DEFAULT NULL,
  `designer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `building_details`
--

CREATE TABLE IF NOT EXISTS `building_details` (
  `id` int(11) NOT NULL,
  `building_id` int(11) DEFAULT NULL,
  `building_param_id` int(11) DEFAULT NULL,
  `value` varchar(45) DEFAULT NULL,
  `rate` varchar(45) DEFAULT NULL,
  `by_law` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `building_details`
--

INSERT INTO `building_details` (`id`, `building_id`, `building_param_id`, `value`, `rate`, `by_law`) VALUES
(1, 4, 1, NULL, '45', '534'),
(2, 4, 2, NULL, '454', '6435'),
(3, 4, 3, NULL, '', ''),
(4, 4, 4, NULL, '', ''),
(5, 4, 5, NULL, '', ''),
(6, 4, 6, NULL, '', ''),
(7, 4, 7, NULL, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `building_params`
--

CREATE TABLE IF NOT EXISTS `building_params` (
  `id` int(11) NOT NULL,
  `parameter` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `measurement_unit` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `building_params`
--

INSERT INTO `building_params` (`id`, `parameter`, `status`, `measurement_unit`) VALUES
(1, 'Ground Coverage', NULL, 'Sq. Ft.'),
(2, 'Total Height', NULL, 'Ft.'),
(3, 'Total Floor Area', NULL, 'Sq. Ft'),
(4, 'R.O.W/ Setback', NULL, 'm'),
(5, 'Hight Tension Line', NULL, 'm'),
(6, 'River Bank', NULL, 'm'),
(7, 'No. of Storey/ Light Plane', NULL, 'Nos');

-- --------------------------------------------------------

--
-- Table structure for table `designers`
--

CREATE TABLE IF NOT EXISTS `designers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `registration_no` varchar(45) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `contact_no` varchar(45) DEFAULT NULL,
  `class` varchar(45) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE IF NOT EXISTS `documents` (
  `id` int(11) NOT NULL,
  `document_type_id` int(11) DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `file_name` varchar(100) DEFAULT NULL,
  `model` varchar(45) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `floor_areas`
--

CREATE TABLE IF NOT EXISTS `floor_areas` (
  `id` int(11) NOT NULL,
  `building_id` int(11) DEFAULT NULL,
  `floor_construction_type_id` int(11) DEFAULT NULL,
  `floor_id` int(11) DEFAULT NULL,
  `other_building` int(11) DEFAULT NULL,
  `existing_storey` float DEFAULT NULL,
  `storey_added` float DEFAULT NULL,
  `far_non_countable` float DEFAULT NULL,
  `far_countable` float DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `time` datetime DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `floor_areas`
--

INSERT INTO `floor_areas` (`id`, `building_id`, `floor_construction_type_id`, `floor_id`, `other_building`, `existing_storey`, `storey_added`, `far_non_countable`, `far_countable`, `user_id`, `status`, `time`, `parent_id`, `lft`, `rght`, `url`) VALUES
(1, 2, 16, 9, NULL, NULL, NULL, 45, 34, 1, 0, '2012-12-04 04:24:34', NULL, 1, 6, 'floor2'),
(2, 2, 16, 10, NULL, NULL, NULL, 23, 43, 1, 0, '2012-12-05 12:15:07', NULL, 7, 12, 'floor2-1'),
(3, 1, 17, 9, 45, 34, 34, NULL, NULL, 1, 0, '2012-12-05 12:16:01', NULL, 13, 16, 'floor1'),
(4, 1, 17, 9, 45, 34, 34, NULL, NULL, 1, 1, '2012-12-05 12:53:16', 3, 14, 15, 'floor1-1'),
(5, 2, 16, 9, NULL, NULL, NULL, 45, 36, 1, 0, '2012-12-09 09:26:08', 1, 2, 3, 'floor2-2'),
(6, 2, 16, 10, NULL, NULL, NULL, 23, 35, 1, 0, '2012-12-09 09:28:54', 2, 8, 9, 'floor2-3'),
(7, 2, 16, 9, NULL, NULL, NULL, 45, 34, 1, 1, '2012-12-09 09:34:06', 1, 4, 5, 'floor2-4'),
(8, 2, 16, 10, NULL, NULL, NULL, 26, 35, 1, 1, '2012-12-09 11:04:57', 2, 10, 11, 'floor2-5');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL,
  `group` varchar(40) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `group`) VALUES
(1, 'admin'),
(2, 'managers'),
(3, 'users');

-- --------------------------------------------------------

--
-- Table structure for table `lands`
--

CREATE TABLE IF NOT EXISTS `lands` (
  `id` int(11) NOT NULL,
  `mishil_id` int(11) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `current_ward_id` int(11) DEFAULT NULL,
  `sabik_ward_id` int(11) DEFAULT NULL,
  `plot_no` varchar(100) DEFAULT NULL,
  `ropani` int(11) DEFAULT '0',
  `aana` int(11) DEFAULT '0',
  `paisa` int(11) DEFAULT '0',
  `daam` int(11) DEFAULT '0',
  `remarks` text,
  `user_id` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lands`
--

INSERT INTO `lands` (`id`, `mishil_id`, `address`, `current_ward_id`, `sabik_ward_id`, `plot_no`, `ropani`, `aana`, `paisa`, `daam`, `remarks`, `user_id`, `time`, `status`, `parent_id`, `lft`, `rght`, `url`) VALUES
(1, 1, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, 1, '2012-12-04 04:06:16', 1, NULL, 1, 2, 'plot'),
(2, 3, NULL, NULL, NULL, NULL, 0, 0, 0, 0, NULL, 1, '2012-12-04 04:22:39', 0, NULL, 3, 6, 'plot-1'),
(3, 3, '453', 5, 16, '435', 0, 4, 1, 0, 'ert', 1, '2012-12-04 04:24:24', 1, 2, 4, 5, 'plot435');

-- --------------------------------------------------------

--
-- Table structure for table `land_areas`
--

CREATE TABLE IF NOT EXISTS `land_areas` (
  `id` int(11) NOT NULL,
  `land_id` int(11) DEFAULT NULL,
  `shape_id` int(11) DEFAULT NULL,
  `side_a` float DEFAULT NULL,
  `side_b` float DEFAULT NULL,
  `side_c` float DEFAULT NULL,
  `measurement_unit_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `time` datetime DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `land_areas`
--

INSERT INTO `land_areas` (`id`, `land_id`, `shape_id`, `side_a`, `side_b`, `side_c`, `measurement_unit_id`, `user_id`, `status`, `time`, `parent_id`, `lft`, `rght`, `url`) VALUES
(1, 2, 22, 34, 43, 34, 18, 1, 0, '2012-12-04 04:24:12', NULL, 1, 40, 'landarea2'),
(2, 2, 22, 34, 43, 36, 18, 1, 0, '2012-12-09 09:25:15', 1, 2, 3, 'landarea2-1'),
(3, 2, 22, 34, 43, 45, 18, 1, 0, '2012-12-09 09:40:01', 1, 4, 5, 'landarea2-2'),
(4, 2, 22, 34, 56, 45, 18, 1, 0, '2012-12-09 09:44:37', 1, 6, 7, 'landarea2-3'),
(5, 2, 22, 34, 54, 45, 18, 1, 0, '2012-12-09 10:05:55', 1, 8, 9, 'landarea2-4'),
(6, 2, 22, 34, 57, 45, 18, 1, 0, '2012-12-09 10:06:31', 1, 10, 11, 'landarea2-5'),
(7, 2, 22, 34, 53, 45, 18, 1, 0, '2012-12-09 10:10:05', 1, 12, 13, 'landarea2-6'),
(8, 2, 22, 34, 56, 45, 18, 1, 0, '2012-12-09 10:10:45', 1, 14, 15, 'landarea2-7'),
(9, 2, 22, 34, 52, 45, 18, 1, 0, '2012-12-09 10:19:01', 1, 16, 17, 'landarea2-8'),
(10, 2, 22, 34, 56, 45, 18, 1, 0, '2012-12-09 10:22:03', 1, 18, 19, 'landarea2-9'),
(11, 2, 22, 34, 53, 45, 18, 1, 0, '2012-12-09 10:23:49', 1, 20, 21, 'landarea2-10'),
(12, 2, 22, 34, 56, 45, 18, 1, 0, '2012-12-09 10:25:06', 1, 22, 23, 'landarea2-11'),
(13, 2, 22, 34, 52, 45, 18, 1, 0, '2012-12-09 10:27:14', 1, 24, 25, 'landarea2-12'),
(14, 2, 22, 34, 56, 45, 18, 1, 0, '2012-12-09 10:29:10', 1, 26, 27, 'landarea2-13'),
(15, 2, 22, 34, 52, 45, 18, 1, 0, '2012-12-09 10:37:25', 1, 28, 29, 'landarea2-14'),
(16, 2, 22, 34, 56, 45, 18, 1, 0, '2012-12-09 10:47:42', 1, 30, 31, 'landarea2-15'),
(17, 2, 22, 34, 52, 45, 18, 1, 0, '2012-12-09 10:48:11', 1, 32, 33, 'landarea2-16'),
(18, 2, 22, 34, 56, 45, 18, 1, 0, '2012-12-09 10:50:36', 1, 34, 35, 'landarea2-17'),
(19, 2, 22, 34, 52, 45, 18, 1, 0, '2012-12-09 10:51:28', 1, 36, 37, 'landarea2-18'),
(20, 2, 22, 34, 56, 45, 18, 1, 1, '2012-12-09 11:04:26', 1, 38, 39, 'landarea2-19');

-- --------------------------------------------------------

--
-- Table structure for table `mishils`
--

CREATE TABLE IF NOT EXISTS `mishils` (
  `id` int(11) NOT NULL,
  `registration_no` varchar(45) DEFAULT NULL,
  `mishil_no` varchar(45) DEFAULT NULL,
  `naksha_registration_date` date DEFAULT NULL,
  `naksha_pass_date` date DEFAULT NULL,
  `sarjamin_date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mishils`
--

INSERT INTO `mishils` (`id`, `registration_no`, `mishil_no`, `naksha_registration_date`, `naksha_pass_date`, `sarjamin_date`, `user_id`, `time`, `status`, `parent_id`, `lft`, `rght`, `url`) VALUES
(1, '436', '456', '2017-08-28', '2016-09-14', NULL, 1, '2012-12-04 04:06:16', 0, NULL, 1, 4, 'mishil456'),
(2, '436', '456', '2017-08-28', '2016-09-14', NULL, 1, '2012-12-04 04:22:09', 1, 1, 2, 3, 'mishil456-1'),
(3, '546', '56', '2016-12-31', NULL, NULL, 1, '2012-12-04 04:22:39', 1, NULL, 5, 6, 'mishil56');

-- --------------------------------------------------------

--
-- Table structure for table `month_nepalis`
--

CREATE TABLE IF NOT EXISTS `month_nepalis` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `month_nepalis`
--

INSERT INTO `month_nepalis` (`id`, `name`) VALUES
(3, 'बैशाख');

-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

CREATE TABLE IF NOT EXISTS `owners` (
  `id` int(11) NOT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `middle_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `owner_type_id` varchar(45) DEFAULT NULL,
  `unique_id` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `time` datetime DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`id`, `first_name`, `middle_name`, `last_name`, `owner_type_id`, `unique_id`, `user_id`, `status`, `time`, `parent_id`, `lft`, `rght`) VALUES
(1, 'Land', NULL, 'Owner', '4', '657', 1, 0, '2012-12-04 04:06:16', NULL, 1, 2),
(2, 'Building', NULL, 'Owner', '4', '45', 1, 0, '2012-12-04 04:06:16', NULL, 3, 4),
(3, 'Land', NULL, 'Owner', '4', '657', 1, 1, '2012-12-04 04:22:09', NULL, 5, 6),
(4, 'Building', NULL, 'Owner', '4', '45', 1, 1, '2012-12-04 04:22:09', NULL, 7, 8),
(5, 'Land', NULL, 'Owner', '4', '67', 1, 1, '2012-12-04 04:22:39', NULL, 9, 10),
(6, 'Building', NULL, 'Owner', '4', '567', 1, 1, '2012-12-04 04:22:39', NULL, 11, 12);

-- --------------------------------------------------------

--
-- Table structure for table `owners_properties`
--

CREATE TABLE IF NOT EXISTS `owners_properties` (
  `id` int(11) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `property_type` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `owners_properties`
--

INSERT INTO `owners_properties` (`id`, `owner_id`, `property_id`, `property_type`) VALUES
(1, 1, 1, 'Land'),
(2, 2, 1, 'Building'),
(3, 3, 1, 'Land'),
(4, 4, 1, 'Building'),
(5, 5, 2, 'Land'),
(6, 6, 2, 'Building');

-- --------------------------------------------------------

--
-- Table structure for table `tax_deposits`
--

CREATE TABLE IF NOT EXISTS `tax_deposits` (
  `id` int(11) NOT NULL,
  `building_id` int(11) DEFAULT NULL,
  `particulars` varchar(40) DEFAULT NULL,
  `rate` float DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `receipt_no` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tax_deposits`
--

INSERT INTO `tax_deposits` (`id`, `building_id`, `particulars`, `rate`, `amount`, `receipt_no`, `status`, `lft`, `rght`, `parent_id`, `time`, `user_id`, `url`) VALUES
(1, 2, 'vat', 13, 34435, 355, 0, 1, 8, NULL, '2012-12-04 04:25:32', 1, 'vat'),
(2, 2, 'vat', 13, 3443, 355, 0, 2, 3, 1, '2012-12-09 09:26:40', 1, 'vat-1'),
(3, 2, 'vat', 13, 344, 355, 0, 4, 5, 1, '2012-12-09 09:27:23', 1, 'vat-2'),
(4, 2, 'vat', 13, 344, 321, 1, 6, 7, 1, '2012-12-09 09:38:03', 1, 'vat-3');

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE IF NOT EXISTS `types` (
  `id` int(11) NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `model` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `type`, `model`) VALUES
(1, 'अवासिय', 'Purpose'),
(2, 'Commercial', 'Purpose'),
(3, 'Row', 'ConstructionType'),
(4, 'Individual', 'OwnerType'),
(5, 'Institutional', 'Purpose'),
(6, 'Corporate', 'OwnerType'),
(7, 'INGO', 'OwnerType'),
(8, 'Semi-attached', 'ConstructionType'),
(9, 'पहिलेा तल्ला', 'Floor'),
(10, 'देाश्रेा तल्ला', 'Floor'),
(11, 'Attacheed', 'ConstructionType'),
(12, 'New', 'BuildingType'),
(13, 'Floor ext', 'BuildingType'),
(14, 'Planned Residential', 'Zone'),
(15, 'Commercial', 'Zone'),
(16, 'नयाँ निर्माण', 'FloorConstructionType'),
(17, 'Existing', 'FloorConstructionType'),
(18, 'फिट', 'MeasurementUnit'),
(19, 'मिटर', 'MeasurementUnit'),
(20, 'Building Permit', 'VerificationType'),
(21, 'भूकम्पिय सुरक्षा', 'VerificationType'),
(22, 'त्रिभुज', 'Shape'),
(23, 'वर्गाकार', 'Shape'),
(24, 'Dtype1', 'DesignerDocument'),
(25, 'Dtype2', 'DesignerDocument'),
(26, 'Vtype1', 'VerificationDocument'),
(27, 'Vtype2', 'VerificationDocument'),
(28, 'Ltype1', 'LandDocument'),
(29, 'Ltype2', 'LandDocument'),
(30, 'Btype1', 'BuildingDocument'),
(31, 'Btype2', 'DocumentType'),
(32, 'Btype2', 'DocumentType'),
(33, 'Btype2', 'BuildingDocument'),
(34, 'आयताकार', 'Shape'),
(35, 'taxtype1', 'TaxDepositDocument'),
(36, 'taxtype2', 'TaxDepositDocument');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `group_id`) VALUES
(1, 'ht', 'd1a44cacaaa0db1e1280beefef7b34abda3e2bfd', 1),
(2, 'manager1', 'a4a1625e591b861f5213792dfd069c918752ed07', 2),
(3, 'user1', '7b64df4364677e4fb6ce223bcb4e39ce152a4b81', 3),
(4, 'rwer', 'f1c46b236bc1d8cb48666966006b9851062cfc61', 1),
(5, 'loginuser', 'fd8fdaabddfe280bd50ba59998a2fa2745df7b90', 1),
(6, 'loginuser1', '43f685786e58219de8853f5448b99fe5f40e0cb7', 1),
(7, 'loginuser2', '087cfbd1ce5f2d7b9b2f763b6149b63bdf51aa06', 1),
(8, 'loginuser3', '166fd652d839567b453a9044fe89b6810f428724', 1),
(9, 'ram', 'a22ca52c2cb458301c2835eaec1a167c8ed516a2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `verifications`
--

CREATE TABLE IF NOT EXISTS `verifications` (
  `id` int(11) NOT NULL,
  `mishil_id` int(11) DEFAULT NULL,
  `verification_type_id` int(11) DEFAULT NULL,
  `by` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `remarks` text,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `time` datetime DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `verifications`
--

INSERT INTO `verifications` (`id`, `mishil_id`, `verification_type_id`, `by`, `date`, `remarks`, `user_id`, `status`, `time`, `parent_id`, `lft`, `rght`, `url`) VALUES
(1, 3, 20, 'user', '2003-03-13', 'dfg', NULL, 0, '2012-12-07 05:04:01', NULL, 1, 6, 'vrf3'),
(2, 3, 20, 'user', '2003-03-13', 'dfg', 1, 0, '2012-12-07 05:04:09', NULL, 7, 8, 'vrf3-1'),
(3, 3, 20, 'user1', '2003-03-13', 'dfg', NULL, 0, '2012-12-09 11:06:05', 1, 2, 3, 'vrf3-2'),
(4, 3, 20, 'user', '2003-03-13', 'dfg', NULL, 1, '2012-12-09 11:06:18', 1, 4, 5, 'vrf3-3');

-- --------------------------------------------------------

--
-- Table structure for table `wards`
--

CREATE TABLE IF NOT EXISTS `wards` (
  `id` int(11) NOT NULL,
  `ward_no` varchar(45) DEFAULT NULL,
  `ward_type` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wards`
--

INSERT INTO `wards` (`id`, `ward_no`, `ward_type`) VALUES
(1, '१', 'Current'),
(2, '२', 'Current'),
(3, '३', 'Current'),
(4, '४', 'Current'),
(5, '५', 'Current'),
(6, '६', 'Current'),
(7, '७', 'Current'),
(8, '८', 'Current'),
(9, '९', 'Current'),
(10, '१०', 'Current'),
(11, '१', 'Sabik'),
(12, '२', 'Sabik'),
(13, '३', 'Sabik'),
(14, '४', 'Sabik'),
(15, '५', 'Sabik'),
(16, '६', 'Sabik'),
(17, '७', 'Sabik'),
(18, '८', 'Sabik'),
(19, '९', 'Sabik'),
(20, '१०', 'Sabik');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acos`
--
ALTER TABLE `acos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros`
--
ALTER TABLE `aros`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros_acos`
--
ALTER TABLE `aros_acos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buildings`
--
ALTER TABLE `buildings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buildings_designers`
--
ALTER TABLE `buildings_designers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `building_details`
--
ALTER TABLE `building_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `building_params`
--
ALTER TABLE `building_params`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `designers`
--
ALTER TABLE `designers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `floor_areas`
--
ALTER TABLE `floor_areas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lands`
--
ALTER TABLE `lands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `land_areas`
--
ALTER TABLE `land_areas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mishils`
--
ALTER TABLE `mishils`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `month_nepalis`
--
ALTER TABLE `month_nepalis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `owners`
--
ALTER TABLE `owners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `owners_properties`
--
ALTER TABLE `owners_properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tax_deposits`
--
ALTER TABLE `tax_deposits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `verifications`
--
ALTER TABLE `verifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wards`
--
ALTER TABLE `wards`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acos`
--
ALTER TABLE `acos`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT for table `aros`
--
ALTER TABLE `aros`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `aros_acos`
--
ALTER TABLE `aros_acos`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `buildings`
--
ALTER TABLE `buildings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `buildings_designers`
--
ALTER TABLE `buildings_designers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `building_details`
--
ALTER TABLE `building_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `building_params`
--
ALTER TABLE `building_params`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `designers`
--
ALTER TABLE `designers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `floor_areas`
--
ALTER TABLE `floor_areas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `lands`
--
ALTER TABLE `lands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `land_areas`
--
ALTER TABLE `land_areas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `mishils`
--
ALTER TABLE `mishils`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `month_nepalis`
--
ALTER TABLE `month_nepalis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `owners`
--
ALTER TABLE `owners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `owners_properties`
--
ALTER TABLE `owners_properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tax_deposits`
--
ALTER TABLE `tax_deposits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `verifications`
--
ALTER TABLE `verifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `wards`
--
ALTER TABLE `wards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
