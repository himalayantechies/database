-- phpMyAdmin SQL Dump
-- version 4.5.0-dev
-- http://www.phpmyadmin.net
--
-- Host: himalayantechies-db-server.cepyls6xdgwo.us-west-2.rds.amazonaws.com
-- Generation Time: Jun 21, 2015 at 03:10 AM
-- Server version: 5.6.19-log
-- PHP Version: 5.4.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `skilledamericans`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=423 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `acos`
--

INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(308, NULL, NULL, NULL, 'controllers', 1, 206),
(309, 308, 'Addresses', NULL, 'Addresses', 2, 13),
(310, 308, 'Categories', NULL, 'Categories', 14, 43),
(409, 308, 'Skills', NULL, 'Skills', 194, 205),
(415, 310, 'Categories', NULL, 'category_select', 41, 42),
(313, 308, 'LocationMaps', NULL, 'LocationMaps', 44, 65),
(314, 308, 'Pages', NULL, 'Pages', 66, 73),
(315, 308, 'ControlPanels', NULL, 'ControlPanels', 74, 85),
(316, 308, 'Searches', NULL, 'Searches', 86, 93),
(317, 308, 'UserRoles', NULL, 'UserRoles', 94, 105),
(318, 308, 'Users', NULL, 'Users', 106, 155),
(319, 318, 'Users', NULL, 'profile', 107, 108),
(320, 318, 'Users', NULL, 'admin_index', 109, 110),
(321, 309, 'Addresses', NULL, 'view', 3, 4),
(322, 309, 'Addresses', NULL, 'index', 5, 6),
(323, 309, 'Addresses', NULL, 'add', 7, 8),
(324, 309, 'Addresses', NULL, 'delete', 9, 10),
(325, 309, 'Addresses', NULL, 'edit', 11, 12),
(326, 318, 'Users', NULL, 'admin_save', 111, 112),
(327, 318, 'Users', NULL, 'admin_edit', 113, 114),
(328, 318, 'Users', NULL, 'admin_approve', 115, 116),
(329, 318, 'Users', NULL, 'delete', 117, 118),
(330, 318, 'Users', NULL, 'admin_delete', 119, 120),
(331, 318, 'Users', NULL, 'deleteAro', 121, 122),
(332, 318, 'Users', NULL, 'editprofile', 123, 124),
(333, 318, 'Users', NULL, 'gallery', 125, 126),
(334, 318, 'Users', NULL, 'info', 127, 128),
(336, 318, 'Users', NULL, 'passwordchange', 129, 130),
(337, 318, 'Users', NULL, 'profilechange', 131, 132),
(338, 318, 'Users', NULL, 'skills', 133, 134),
(339, 318, 'Users', NULL, 'upload', 135, 136),
(340, 313, 'LocationMaps', NULL, 'admin_add', 45, 46),
(341, 313, 'LocationMaps', NULL, 'admin_delete', 47, 48),
(342, 313, 'LocationMaps', NULL, 'admin_edit', 49, 50),
(343, 313, 'LocationMaps', NULL, 'admin_index', 51, 52),
(344, 313, 'LocationMaps', NULL, 'admin_locTree', 53, 54),
(345, 313, 'LocationMaps', NULL, 'admin_move', 55, 56),
(346, 313, 'LocationMaps', NULL, 'admin_save', 57, 58),
(347, 313, 'LocationMaps', NULL, 'admin_treeUpdate', 59, 60),
(348, 317, 'UserRoles', NULL, 'admin_add', 95, 96),
(349, 317, 'UserRoles', NULL, 'admin_delete', 97, 98),
(350, 317, 'UserRoles', NULL, 'admin_edit', 99, 100),
(351, 317, 'UserRoles', NULL, 'admin_index', 101, 102),
(352, 317, 'UserRoles', NULL, 'admin_save', 103, 104),
(353, 315, 'ControlPanels', NULL, 'admin_getControllerLists', 75, 76),
(354, 315, 'ControlPanels', NULL, 'admin_getControllerMethods', 77, 78),
(355, 315, 'ControlPanels', NULL, 'admin_getControllerPermissions', 79, 80),
(356, 315, 'ControlPanels', NULL, 'admin_index', 81, 82),
(357, 315, 'ControlPanels', NULL, 'admin_security', 83, 84),
(358, 308, 'Contacts', NULL, 'Contacts', 156, 163),
(359, 308, 'Keywords', NULL, 'Keywords', 164, 175),
(360, 308, 'Paypals', NULL, 'Paypals', 176, 181),
(361, 308, 'Statuses', NULL, 'Statuses', 182, 193),
(362, 360, 'Paypals', NULL, 'expresscheckout', 177, 178),
(363, 360, 'Paypals', NULL, 'confirm', 179, 180),
(364, 316, 'Searches', NULL, 'beforeFilter', 87, 88),
(365, 316, 'Searches', NULL, 'category', 89, 90),
(366, 316, 'Searches', NULL, 'display', 91, 92),
(367, 318, 'Users', NULL, 'domainCheck', 137, 138),
(368, 318, 'Users', NULL, 'login', 139, 140),
(413, 318, 'Users', NULL, 'logout', 145, 146),
(370, 318, 'Users', NULL, 'resetpassword', 141, 142),
(371, 318, 'Users', NULL, 'signup', 143, 144),
(372, 361, 'Statuses', NULL, 'admin_add', 183, 184),
(373, 361, 'Statuses', NULL, 'admin_delete', 185, 186),
(374, 361, 'Statuses', NULL, 'admin_edit', 187, 188),
(375, 361, 'Statuses', NULL, 'admin_index', 189, 190),
(376, 361, 'Statuses', NULL, 'admin_save', 191, 192),
(410, 409, 'Skills', NULL, 'add', 195, 196),
(411, 409, 'Skills', NULL, 'delete', 197, 198),
(380, 314, 'Pages', NULL, 'display_link', 67, 68),
(381, 314, 'Pages', NULL, 'display', 69, 70),
(382, 314, 'Pages', NULL, 'page', 71, 72),
(383, 313, 'LocationMaps', NULL, 'autocomplete', 61, 62),
(384, 313, 'LocationMaps', NULL, 'index', 63, 64),
(385, 359, 'Keywords', NULL, 'admin_add', 165, 166),
(386, 359, 'Keywords', NULL, 'admin_delete', 167, 168),
(387, 359, 'Keywords', NULL, 'admin_edit', 169, 170),
(388, 359, 'Keywords', NULL, 'admin_index', 171, 172),
(389, 359, 'Keywords', NULL, 'admin_save', 173, 174),
(390, 358, 'Contacts', NULL, 'admin_delete', 157, 158),
(391, 358, 'Contacts', NULL, 'admin_index', 159, 160),
(393, 358, 'Contacts', NULL, 'index', 161, 162),
(394, 310, 'Categories', NULL, 'admin_add', 15, 16),
(395, 310, 'Categories', NULL, 'admin_delete', 17, 18),
(396, 310, 'Categories', NULL, 'admin_edit', 19, 20),
(397, 310, 'Categories', NULL, 'admin_index', 21, 22),
(398, 310, 'Categories', NULL, 'admin_locTree', 23, 24),
(399, 310, 'Categories', NULL, 'admin_move', 25, 26),
(400, 310, 'Categories', NULL, 'admin_save', 27, 28),
(401, 310, 'Categories', NULL, 'admin_treeUpdate', 29, 30),
(414, 318, 'Users', NULL, 'paypal', 147, 148),
(403, 310, 'Categories', NULL, 'display_categories', 31, 32),
(404, 310, 'Categories', NULL, 'getCategoryList', 33, 34),
(405, 310, 'Categories', NULL, 'getChildTags', 35, 36),
(406, 310, 'Categories', NULL, 'index', 37, 38),
(407, 310, 'Categories', NULL, 'jasonEncode', 39, 40),
(412, 409, 'Skills', NULL, 'getlist', 199, 200),
(418, 318, 'Users', NULL, 'view', 149, 150),
(419, 318, 'Users', NULL, 'getskilllist', 151, 152),
(420, 318, 'Users', NULL, 'hideshow', 153, 154),
(421, 409, 'Skills', NULL, 'edit', 201, 202),
(422, 409, 'Skills', NULL, 'skill', 203, 204);

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
  `id` int(11) NOT NULL,
  `street_1` varchar(50) DEFAULT NULL,
  `street_2` varchar(50) DEFAULT NULL,
  `zipcode` varchar(9) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state_id` varchar(100) DEFAULT NULL,
  `phone_no_1` varchar(19) DEFAULT NULL,
  `phone_no_2` varchar(19) DEFAULT NULL,
  `fax_no` varchar(19) DEFAULT NULL,
  `url` varchar(50) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `hideshow_id` int(11) NOT NULL DEFAULT '4'
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `street_1`, `street_2`, `zipcode`, `city`, `state_id`, `phone_no_1`, `phone_no_2`, `fax_no`, `url`, `user_id`, `hideshow_id`) VALUES
(7, 'North End', '', '21742', 'Hagerstown', 'MD', '2408675309', '', '', '', 8, 4),
(8, '295 Monterey Blvd, #1', '', '94131', 'San Francisco', 'CA', '+14155084503', '', '', '', 9, 4),
(32, '320 Duncan Street', NULL, '94131', 'San Francisco', 'CA', '4155034509', NULL, '', '', 33, 4),
(33, 'A', NULL, '123', 'L', 'AL', '999', NULL, '12345', '', 34, 4),
(26, '119 Crespi Drive', NULL, '94132', 'San Francisco', 'CA', '+14155084503', NULL, '', '', 27, 4),
(53, '5405 5th Avenue', NULL, '15123', 'Pittsburgh', 'PA', '4155042365', NULL, '', '', 54, 1),
(51, '1856 englewood dr.', NULL, '91945', 'Lemon Grove', 'CA', '(619) 534-2235', NULL, '', '', 52, 4),
(54, 'North End', NULL, '21742', 'Hagerstown', 'MD', '2404693226', NULL, '', '', 55, 1),
(55, 'matt matt', NULL, '21740', 'matt', 'MD', '3018675309', NULL, '', '', 56, 4);

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aros`
--

INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, 'UserRole', 5, 'administrator', 1, 8),
(2, NULL, 'UserRole', 6, 'profile', 9, 22),
(16, 2, 'User', 8, 'matthew-labozzetta', 18, 19),
(17, 1, 'User', 9, 'vaibhaw-poddar', 2, 3),
(25, NULL, NULL, NULL, '''premium''', 27, 28),
(23, NULL, NULL, NULL, '''premium''', 23, 24),
(24, NULL, NULL, NULL, '''''', 25, 26),
(26, NULL, 'UserRole', 7, 'premium', 29, 30),
(67, 2, 'User', 52, 'rochallenicole', 14, 15),
(69, 2, 'User', 54, 'khumbaya', 16, 17),
(42, 2, 'User', 27, 'vaibhaw-1', 10, 11),
(49, 1, 'User', 34, 'sujan', 4, 5),
(48, 2, 'User', 33, 'info', 12, 13),
(70, 1, 'User', 55, 'skilledamerican', 6, 7),
(71, 2, 'User', 56, 'mattmatt', 20, 21);

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) NOT NULL,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) NOT NULL DEFAULT '0',
  `_read` varchar(2) NOT NULL DEFAULT '0',
  `_update` varchar(2) NOT NULL DEFAULT '0',
  `_delete` varchar(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=268 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aros_acos`
--

INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES
(114, 1, 308, '1', '1', '1', '1'),
(115, 1, 309, '1', '1', '1', '1'),
(116, 1, 310, '1', '1', '1', '1'),
(126, 1, 409, '1', '1', '1', '1'),
(133, 1, 371, '-1', '-1', '-1', '-1'),
(119, 1, 313, '1', '1', '1', '1'),
(120, 1, 314, '1', '1', '1', '1'),
(121, 1, 315, '1', '1', '1', '1'),
(122, 1, 316, '1', '1', '1', '1'),
(123, 1, 317, '1', '1', '1', '1'),
(124, 1, 318, '1', '1', '1', '1'),
(125, 2, 308, '-1', '-1', '-1', '-1'),
(127, 1, 361, '1', '1', '1', '1'),
(128, 1, 358, '1', '1', '1', '1'),
(129, 1, 359, '1', '1', '1', '1'),
(130, 1, 360, '1', '1', '1', '1'),
(131, 1, 363, '-1', '-1', '-1', '-1'),
(132, 1, 362, '-1', '-1', '-1', '-1'),
(135, 1, 368, '-1', '-1', '-1', '-1'),
(136, 2, 323, '1', '1', '1', '1'),
(137, 2, 324, '1', '1', '1', '1'),
(138, 2, 325, '1', '1', '1', '1'),
(139, 2, 322, '-1', '-1', '-1', '-1'),
(140, 2, 321, '-1', '-1', '-1', '-1'),
(141, 2, 394, '-1', '-1', '-1', '-1'),
(142, 2, 395, '-1', '-1', '-1', '-1'),
(143, 2, 396, '-1', '-1', '-1', '-1'),
(144, 2, 397, '-1', '-1', '-1', '-1'),
(145, 2, 398, '-1', '-1', '-1', '-1'),
(146, 2, 399, '-1', '-1', '-1', '-1'),
(147, 2, 400, '-1', '-1', '-1', '-1'),
(148, 2, 401, '-1', '-1', '-1', '-1'),
(149, 2, 415, '-1', '-1', '-1', '-1'),
(150, 2, 403, '1', '1', '1', '1'),
(151, 2, 404, '1', '1', '1', '1'),
(152, 2, 405, '1', '1', '1', '1'),
(153, 2, 406, '1', '1', '1', '1'),
(154, 2, 407, '1', '1', '1', '1'),
(155, 2, 339, '1', '1', '1', '1'),
(156, 2, 338, '1', '1', '1', '1'),
(157, 2, 371, '-1', '-1', '-1', '-1'),
(158, 2, 370, '1', '1', '1', '1'),
(159, 2, 337, '1', '1', '1', '1'),
(160, 2, 319, '1', '1', '1', '1'),
(161, 2, 336, '1', '1', '1', '1'),
(162, 2, 413, '1', '1', '1', '1'),
(163, 2, 368, '-1', '-1', '-1', '-1'),
(164, 2, 334, '1', '1', '1', '1'),
(165, 2, 333, '1', '1', '1', '1'),
(166, 2, 332, '1', '1', '1', '1'),
(167, 2, 367, '1', '1', '1', '1'),
(168, 2, 329, '1', '1', '1', '1'),
(169, 2, 326, '-1', '-1', '-1', '-1'),
(170, 2, 320, '-1', '-1', '-1', '-1'),
(171, 2, 327, '-1', '-1', '-1', '-1'),
(172, 2, 330, '-1', '-1', '-1', '-1'),
(173, 2, 328, '-1', '-1', '-1', '-1'),
(174, 2, 317, '-1', '-1', '-1', '-1'),
(175, 2, 361, '-1', '-1', '-1', '-1'),
(176, 2, 410, '1', '1', '1', '1'),
(177, 2, 411, '1', '1', '1', '1'),
(178, 2, 412, '1', '1', '1', '1'),
(179, 2, 365, '1', '1', '1', '1'),
(180, 2, 366, '1', '1', '1', '1'),
(181, 2, 363, '1', '1', '1', '1'),
(182, 2, 362, '1', '1', '1', '1'),
(183, 2, 381, '1', '1', '1', '1'),
(184, 2, 380, '1', '1', '1', '1'),
(185, 2, 382, '1', '1', '1', '1'),
(186, 2, 385, '-1', '-1', '-1', '-1'),
(187, 2, 386, '-1', '-1', '-1', '-1'),
(188, 2, 387, '-1', '-1', '-1', '-1'),
(189, 2, 388, '-1', '-1', '-1', '-1'),
(190, 2, 389, '-1', '-1', '-1', '-1'),
(191, 2, 315, '-1', '-1', '-1', '-1'),
(192, 2, 393, '1', '1', '1', '1'),
(193, 2, 391, '-1', '-1', '-1', '-1'),
(194, 2, 390, '-1', '-1', '-1', '-1'),
(195, 26, 323, '1', '1', '1', '1'),
(196, 26, 324, '1', '1', '1', '1'),
(197, 26, 325, '1', '1', '1', '1'),
(198, 26, 394, '-1', '-1', '-1', '-1'),
(199, 26, 396, '-1', '-1', '-1', '-1'),
(200, 26, 395, '-1', '-1', '-1', '-1'),
(201, 26, 397, '-1', '-1', '-1', '-1'),
(202, 26, 398, '-1', '-1', '-1', '-1'),
(203, 26, 399, '-1', '-1', '-1', '-1'),
(204, 26, 400, '-1', '-1', '-1', '-1'),
(205, 26, 401, '-1', '-1', '-1', '-1'),
(206, 26, 415, '-1', '-1', '-1', '-1'),
(207, 26, 403, '1', '1', '1', '1'),
(208, 26, 404, '1', '1', '1', '1'),
(209, 26, 405, '1', '1', '1', '1'),
(210, 26, 406, '1', '1', '1', '1'),
(211, 26, 393, '1', '1', '1', '1'),
(212, 26, 391, '-1', '-1', '-1', '-1'),
(213, 26, 390, '-1', '-1', '-1', '-1'),
(214, 26, 315, '-1', '-1', '-1', '-1'),
(215, 26, 385, '-1', '-1', '-1', '-1'),
(216, 26, 386, '-1', '-1', '-1', '-1'),
(217, 26, 389, '-1', '-1', '-1', '-1'),
(218, 26, 387, '-1', '-1', '-1', '-1'),
(219, 26, 388, '-1', '-1', '-1', '-1'),
(220, 26, 381, '1', '1', '1', '1'),
(221, 26, 380, '1', '1', '1', '1'),
(222, 26, 382, '1', '1', '1', '1'),
(223, 26, 363, '-1', '-1', '-1', '-1'),
(224, 26, 362, '-1', '-1', '-1', '-1'),
(225, 26, 365, '1', '1', '1', '1'),
(226, 26, 366, '1', '1', '1', '1'),
(227, 26, 411, '1', '1', '1', '1'),
(228, 26, 410, '1', '1', '1', '1'),
(229, 26, 412, '1', '1', '1', '1'),
(230, 26, 372, '-1', '-1', '-1', '-1'),
(231, 26, 373, '-1', '-1', '-1', '-1'),
(232, 26, 374, '-1', '-1', '-1', '-1'),
(233, 26, 376, '-1', '-1', '-1', '-1'),
(234, 26, 375, '-1', '-1', '-1', '-1'),
(235, 26, 348, '-1', '-1', '-1', '-1'),
(236, 26, 349, '-1', '-1', '-1', '-1'),
(237, 26, 350, '-1', '-1', '-1', '-1'),
(238, 26, 351, '-1', '-1', '-1', '-1'),
(239, 26, 352, '-1', '-1', '-1', '-1'),
(240, 26, 328, '-1', '-1', '-1', '-1'),
(241, 26, 330, '-1', '-1', '-1', '-1'),
(242, 26, 327, '-1', '-1', '-1', '-1'),
(243, 26, 320, '-1', '-1', '-1', '-1'),
(244, 26, 326, '-1', '-1', '-1', '-1'),
(245, 26, 329, '1', '1', '1', '1'),
(246, 26, 367, '1', '1', '1', '1'),
(247, 26, 332, '1', '1', '1', '1'),
(248, 26, 333, '1', '1', '1', '1'),
(249, 26, 339, '1', '1', '1', '1'),
(250, 26, 338, '1', '1', '1', '1'),
(251, 26, 371, '-1', '-1', '-1', '-1'),
(252, 26, 370, '1', '1', '1', '1'),
(253, 26, 337, '1', '1', '1', '1'),
(254, 26, 319, '1', '1', '1', '1'),
(255, 26, 336, '1', '1', '1', '1'),
(256, 26, 413, '1', '1', '1', '1'),
(257, 26, 368, '-1', '-1', '-1', '-1'),
(258, 26, 334, '1', '1', '1', '1'),
(260, 2, 419, '1', '1', '1', '1'),
(261, 26, 419, '1', '1', '1', '1'),
(262, 2, 420, '1', '1', '1', '1'),
(263, 26, 420, '1', '1', '1', '1'),
(264, 2, 421, '1', '1', '1', '1'),
(265, 26, 421, '1', '1', '1', '1'),
(266, 2, 422, '1', '1', '1', '1'),
(267, 26, 422, '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(124) NOT NULL,
  `url` varchar(124) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `model` varchar(32) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=594 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `url`, `description`, `model`, `parent_id`, `lft`, `rght`) VALUES
(3, 'Contractors', 'arts-entertainment', 'Contractors for hire', '', NULL, 11, 24),
(4, 'Mechanic', 'automotive', 'Mechanics', '', NULL, 25, 30),
(5, 'Beauty', 'beauty-spas', 'Beauty', '', NULL, 31, 38),
(6, 'Tutor', 'education', 'Tutors', '', NULL, 39, 48),
(8, 'Financial Services', 'financial-services', 'Financial Services', NULL, NULL, 49, 60),
(74, 'Food', 'food', 'Food', NULL, NULL, 105, 106),
(11, 'Health & Medical', 'health-medical', 'Health & Medical', NULL, NULL, 61, 62),
(571, 'Child/Adult Care', 'child-adult-care', 'Child/Adult Care', '', NULL, 117, 118),
(18, 'Petcare', 'pets-2', 'Petcare', '', NULL, 63, 76),
(19, 'Professional Services', 'professional-services', 'Professional Services', NULL, NULL, 77, 104),
(1, 'Labor', 'active-life', 'Labor Offered', '', NULL, 1, 10),
(583, 'Automobile', 'automobile', 'Auto', '', 4, 28, 29),
(582, 'Small Engine', 'small-engine', 'Small engine', '', 4, 26, 27),
(581, 'Misc', 'misc-1', 'Miscellaneous', '', 1, 8, 9),
(580, 'Misc', 'misc', 'Miscellaneous', '', 3, 22, 23),
(579, 'Painter', 'painter', 'Painting', '', 3, 20, 21),
(578, 'Electrician', 'electrician', 'Electrician', '', 3, 18, 19),
(572, 'Heavy', 'heavy', 'Heavy lifting', '', 1, 2, 3),
(573, 'Farm', 'farm-1', 'Farm labor', '', 1, 4, 5),
(574, 'Light', 'light', 'Light labor', '', 1, 6, 7),
(575, 'Handyman/Basic Services', 'handyman-basic-services', 'Basic services', '', 3, 12, 13),
(442, 'Hairstyling', 'beauty-services', 'Hairstyling', '', 5, 34, 35),
(110, 'Massage', 'massage', 'Massage', NULL, 5, 32, 33),
(584, 'Misc', 'misc-2', 'Miscellaneous', '', 5, 36, 37),
(585, 'Elementary', 'elementary', 'Elementary', '', 6, 40, 41),
(586, 'Middle/High School', 'middle-high-school', 'Middle/High School', '', 6, 42, 43),
(587, 'Specialty', 'specialty-1', 'Specialty', '', 6, 44, 45),
(588, 'Misc', 'misc-3', 'Miscellaneous', '', 6, 46, 47),
(143, 'Insurance', 'insurance', 'Insurance', '', 8, 50, 51),
(144, 'Investing', 'investing', 'Investing', NULL, 8, 52, 53),
(270, 'Pet Services', 'pet-services', 'Pet Services', NULL, 18, 64, 73),
(592, 'Pet Sitter', 'pet-sitter', 'Pet Sitter', '', 18, 74, 75),
(273, 'Dog Walkers', 'dog-walkers', 'Dog Walkers', NULL, 270, 65, 66),
(274, 'Pet Boarding - Sitting', 'pet-boarding-sitting', 'Pet Sitting', NULL, 270, 67, 68),
(275, 'Pet Groomers', 'pet-groomers', 'Pet Groomers', NULL, 270, 69, 70),
(276, 'Pet Training', 'pet-training', 'Pet Training', NULL, 270, 71, 72),
(277, 'Accountants', 'accountants', 'Accountants', NULL, 19, 78, 79),
(278, 'Architects', 'architects', 'Architects', NULL, 19, 80, 81),
(279, 'Employment Agencies', 'employment-agencies', 'Employment Agencies', NULL, 19, 82, 83),
(280, 'Graphic Design', 'graphic-design', 'Graphic Design', NULL, 19, 84, 85),
(281, 'Internet Service Providers', 'internet-service-providers', 'Internet Service Providers', NULL, 19, 86, 87),
(282, 'Lawyers', 'lawyers', 'Lawyers', NULL, 19, 88, 97),
(283, 'Web Design', 'web-design', 'Web Design', NULL, 19, 98, 99),
(284, 'Bankruptcy', 'bankruptcy', 'Bankruptcy', NULL, 282, 89, 90),
(285, 'Divorce and Family Law', 'divorce-and-family-law', 'Divorce and Family Law', NULL, 282, 91, 92),
(286, 'General Litigation', 'general-litigation', 'General Litigation', NULL, 282, 93, 94),
(287, 'Personal Injury', 'personal-injury', 'Personal Injury', NULL, 282, 95, 96),
(589, 'Book Keeping', 'book-keeping', 'Book Keepers', '', 8, 54, 55),
(590, 'Specialty', 'specialty-2', 'Specialty', '', 8, 56, 57),
(591, 'Misc', 'misc-4', 'Miscellaneous', '', 8, 58, 59),
(519, 'Medical Transcription', 'medical-transcription', 'Medical Transcription', NULL, 19, 100, 101),
(520, 'Advertising & Marketing', 'advertising-marketing', 'Advertising & Marketing', NULL, 19, 102, 103),
(576, 'Plumbers', 'plumbers', 'Plumber', '', 3, 14, 15),
(558, 'Lawncare', 'home-and-garden', 'Lawncare', '', NULL, 109, 110),
(548, 'Religion/Spirituality', 'religion-ans-spirituality', 'Religion/Spirituality', '', NULL, 107, 108),
(561, 'Entertainment', 'entertainment', 'Entertainment', NULL, NULL, 111, 112),
(562, 'Cooking/Serving', 'cooking-food-and-wine', 'Cooking/Serving', '', NULL, 113, 114),
(564, 'Computers/Web', 'computers-and-internet', 'Computers/Web', '', NULL, 115, 116),
(577, 'Carpenter', 'carpenter', 'Carpenter', '', 3, 16, 17);

-- --------------------------------------------------------

--
-- Table structure for table `categories_users`
--

CREATE TABLE IF NOT EXISTS `categories_users` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `skill_id` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories_users`
--

INSERT INTO `categories_users` (`id`, `category_id`, `skill_id`) VALUES
(98, 548, 58),
(16, 283, 4),
(22, 592, 20),
(85, 562, 21),
(23, 564, 3),
(84, 581, 48),
(28, 442, 23),
(29, 442, 24),
(53, 442, 25),
(96, 283, 57);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(55) DEFAULT NULL,
  `email` varchar(79) DEFAULT NULL,
  `subject` varchar(23) DEFAULT NULL,
  `message` text,
  `date_added` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `message`, `date_added`) VALUES
(19, NULL, NULL, 'Negative Reviews about ', 'As you are aware, potential customers that Google your name can see the reviews that are posted publicly. Our company specializes in posting Positive Reviews to Yelp, Google, TripAdvisor, Amazon, Facebook and other major websites. To repair your Reputation and boost your brand, Please reply to email@pandapr.com or call us Toll Free on 888-756-3489. \r\n\r\nhttp://www.pandapr.com \r\n\r\nOur motto is that a happy customer is a repeat customer.', '2014-10-12 01:09:27'),
(17, 'Morty', 'support@superbsocial.net', 'Account issues', 'Hello, my name is Morty Goldman; I just stumbled upon your site - www.skilledamericans.com - I''m sorry to write in such an odd manner, I thought to call you but I didn''t want to take up your time. What I have to say may be of great interest to you. Did you know that an overwhelming majority of businesses, organizations and celebrities buy likes and followers? What, you thought your competitor''s likes and followers are organic and naturally gained? Ha ha. Just recently Gangman Style ( http://www.youtube.com/watch?v=9bZkp7q19f0 ) reached a record 2 billion views. Now imagine the scale of Gangnam Style''s popularity being applied to your business! This is exactly how I deliver results to my clients - and I assure you that you''ll be overwhelmingly pleased with the outcome. \r\n \r\nGive us a call: +1 (877) 410-4002 \r\nor visit us at http://www.SuperbSocial.net', '2014-07-02 13:09:53'),
(18, NULL, NULL, 'Your Facebook Reputatio', 'Facebook is the second most visited website on the internet, and number 1 in terms of hours spent on a website daily by users (surpassing even Google). The social platform also makes it a perfect place to get viral exposure. We offer offer top quality US based (or international) Facebook fans to your fan page.  We also offer high quality Twitter followers. If you don''t have a Facebook or Twitter page, we will create one for you. We have the most experience, professionalism and highest quality targeting in the business... \r\n\r\nhttp://www.pandapr.com \r\n\r\nOur motto is that a happy customer is a repeat customer. Please reply to email@pandapr.com or call us Toll Free on 888-756-3489', '2014-10-11 03:06:41'),
(14, 'Katy', 'k.sweeney@myactv.net', 'Information', 'Hey Matt! Is this site up and running????', '2013-08-21 19:17:45'),
(15, 'barny182@hotmail.com', 'barny182@hotmail.com', 'Report fraud', 'iugzA6 http://www.MHyzKpN7h4ERauvS72jUbdI0HeKxuZom.com', '2013-11-14 04:31:24'),
(16, NULL, NULL, 'Get noticed  ', 'Statistics show that millions of people are now searching online for services or information about companies. Would you like to be the one they choose? We have been helping companies reach their full potential, rise above their competition and finally get an excellent return of investment. Why not give it a try? It’s only 49$/month. \r\nTest our services for FREE on www.ratingsking.com  or benefit the special offer we have this month. \r\n\r\nIf you don’t want to receive any of our offers, please go to www.ratingsking.com/unsubscribe.php and submit your website/s. We will never send you any of our offers to any email assigned to your domains. ', '2014-04-13 15:29:27'),
(20, 'Fredrick Parker', 'fredrickp896@gmail.com', 'Account issues', 'Want more clients and customers? We will help them find you by putting you on the 1st page of Google. Email us back to get a full proposal.', '2015-03-18 04:51:46');

-- --------------------------------------------------------

--
-- Table structure for table `hideshows`
--

CREATE TABLE IF NOT EXISTS `hideshows` (
  `id` int(11) NOT NULL,
  `email` int(11) NOT NULL,
  `phone` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hideshows`
--

INSERT INTO `hideshows` (`id`, `email`, `phone`) VALUES
(1, 0, 0),
(2, 0, 1),
(3, 1, 0),
(4, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `keywords`
--

CREATE TABLE IF NOT EXISTS `keywords` (
  `id` int(11) NOT NULL,
  `keyword` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `keywords`
--

INSERT INTO `keywords` (`id`, `keyword`, `type`) VALUES
(1, 'contacts', 'controller'),
(2, 'users', 'controller'),
(3, 'acos', ''),
(4, 'aros', ''),
(5, 'mattspainting', ''),
(6, 'about', ''),
(7, 'faqs', '');

-- --------------------------------------------------------

--
-- Table structure for table `location_maps`
--

CREATE TABLE IF NOT EXISTS `location_maps` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `url` varchar(150) DEFAULT NULL,
  `geocode_lt` varchar(10) DEFAULT NULL,
  `geocode_lg` varchar(10) DEFAULT NULL,
  `location_type_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=643 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `location_maps`
--

INSERT INTO `location_maps` (`id`, `name`, `description`, `url`, `geocode_lt`, `geocode_lg`, `location_type_id`, `parent_id`, `lft`, `rght`) VALUES
(633, 'Hawaii', 'HI', 'hawaii', NULL, NULL, 2, 621, 24, 25),
(634, 'Idaho', 'ID', 'idaho', NULL, NULL, 2, 621, 26, 27),
(635, 'Indiana', 'IN', 'indiana', NULL, NULL, 2, 621, 28, 29),
(636, 'Illinois', 'IL', 'illinois', NULL, NULL, 2, 621, 30, 31),
(637, 'Iowa', 'IA', 'iowa', NULL, NULL, 2, 621, 32, 33),
(638, 'Kansas', 'KS', 'kansas', NULL, NULL, 2, 621, 34, 35),
(639, 'Kentucky', 'KY', 'kentucky', NULL, NULL, 2, 621, 36, 37),
(640, 'Louisiana', 'LA', 'louisiana', NULL, NULL, 2, 621, 38, 39),
(641, 'Maine', 'ME', 'maine', NULL, NULL, 2, 621, 40, 41),
(642, 'Maryland', 'MD', 'maryland', NULL, NULL, 2, 621, 42, 43),
(621, 'United States of America', 'USA, America', 'united-states-of-america', NULL, NULL, 1, NULL, 1, 44),
(631, 'Florida', 'FL', 'florida', NULL, NULL, 2, 621, 20, 21),
(632, 'Georgia', 'GA', 'georgia', NULL, NULL, 2, 621, 22, 23),
(630, 'Delaware', 'DE', 'delaware', NULL, NULL, 2, 621, 18, 19),
(629, 'Connecticut', 'CT', 'connecticut', NULL, NULL, 2, 621, 16, 17),
(628, 'Colorado', 'CO', 'colorado', NULL, NULL, 2, 621, 14, 15),
(627, 'Arkansas', 'AR', 'arkansas', NULL, NULL, 2, 621, 12, 13),
(626, 'Arizona', 'AZ', 'arizona', NULL, NULL, 2, 621, 10, 11),
(625, 'Alaska', 'AK', 'alaska', NULL, NULL, 2, 621, 8, 9),
(624, 'Alabama', 'AL', 'alabama', NULL, NULL, 2, 621, 6, 7),
(623, 'San Francisco', 'San Francisco', 'san-francisco', NULL, NULL, 3, 622, 3, 4),
(622, 'California', 'California', 'california', NULL, NULL, 2, 621, 2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `location_types`
--

CREATE TABLE IF NOT EXISTS `location_types` (
  `id` int(11) NOT NULL,
  `name` varchar(24) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `location_types`
--

INSERT INTO `location_types` (`id`, `name`) VALUES
(1, 'Country'),
(2, 'State'),
(3, 'City'),
(4, 'Street'),
(5, 'Landmark'),
(6, 'Ward'),
(7, 'Zone'),
(8, 'District');

-- --------------------------------------------------------

--
-- Table structure for table `paypals`
--

CREATE TABLE IF NOT EXISTS `paypals` (
  `id` int(11) NOT NULL,
  `token` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `payer_id` varchar(30) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `transaction_type` varchar(50) DEFAULT NULL,
  `payment_type` varchar(30) NOT NULL,
  `correlation_id` varchar(100) DEFAULT NULL,
  `amt` float(10,2) DEFAULT NULL,
  `order_time` datetime DEFAULT NULL,
  `fee_amt` float(10,2) DEFAULT NULL,
  `tax_amt` float(10,2) DEFAULT NULL,
  `currency_code` varchar(10) DEFAULT NULL,
  `payment_status` varchar(20) DEFAULT NULL,
  `pending_reason` text,
  `reason_code` varchar(20) DEFAULT NULL,
  `protection_eligibility` varchar(20) DEFAULT NULL,
  `settle_amt` float(10,2) DEFAULT NULL,
  `exchange_rate` float(10,2) DEFAULT NULL,
  `ack` varchar(20) DEFAULT NULL,
  `error_code` varchar(20) DEFAULT NULL,
  `version` varchar(20) DEFAULT NULL,
  `build` varchar(20) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `paypals`
--

INSERT INTO `paypals` (`id`, `token`, `user_id`, `payer_id`, `transaction_id`, `transaction_type`, `payment_type`, `correlation_id`, `amt`, `order_time`, `fee_amt`, `tax_amt`, `currency_code`, `payment_status`, `pending_reason`, `reason_code`, `protection_eligibility`, `settle_amt`, `exchange_rate`, `ack`, `error_code`, `version`, `build`) VALUES
(1, 'EC-5DV64543EV504490T', 9, 'CUEV5KFB3PMFE', '6AP52431TU0246349', 'expresscheckout', 'instant', '1281ed443549', 19.95, '2011-09-27 07:07:14', 0.88, 0.00, 'USD', NULL, 'paymentreview', 'None', 'Ineligible', NULL, NULL, 'Success', NULL, '64', '2133933');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE IF NOT EXISTS `skills` (
  `id` int(11) NOT NULL,
  `skill` varchar(255) DEFAULT NULL,
  `certification` text,
  `description` text,
  `specials` text,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `skill`, `certification`, `description`, `specials`, `user_id`) VALUES
(4, 'web', 'php', '', '', 9),
(3, 'website', 'javascript', 'jquery, javascript', '', 9),
(20, 'Pet Sitter', 'None', 'Can sit with pets', 'None', 9),
(21, 'Master chef', '', 'hello world', '', 27),
(57, 'Web Developer', '', 'Knowledge about : PHP - Cakephp(framework), jQuery(framework), HTML, CSS\r\n(Design)Beside that Photoshop Illustrator', '', 34),
(48, 'Labor provided', 'I bench press 300.', 'I provide labor.', 'Ready at a moment''s notice.', 8),
(23, 'sdg', '', 'sdsdf', '', 9),
(25, 'check', '', 'fsdfasd\r\n', '', 9),
(58, 'preacher', 'i have none', 'i provide religious services', 'it is free', 56);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` char(10) NOT NULL,
  `state` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `state`) VALUES
('AK', 'Alaska'),
('AL', 'Alabama'),
('AR', 'Arkansas'),
('AZ', 'Arizona'),
('CA', 'California'),
('CO', 'Colorado'),
('CT', 'Connecticut'),
('DE', 'Delaware'),
('FL', 'Florida'),
('GA', 'Georgia'),
('HI', 'Hawaii'),
('IA', 'Iowa'),
('ID', 'Idaho'),
('IL', 'Illinois'),
('IN', 'Indiana'),
('KS', 'Kansas'),
('KY', 'Kentucky'),
('LA', 'Louisiana'),
('MA', 'Massachusetts'),
('MD', 'Maryland'),
('ME', 'Maine'),
('MI', 'Michigan'),
('MN', 'Minnesota'),
('MO', 'Missouri'),
('MS', 'Mississippi'),
('MT', 'Montana'),
('NC', 'North Carolina'),
('ND', 'North Dakota'),
('NE', 'Nebraska'),
('NH', 'New Hampshire'),
('NJ', 'New Jersey'),
('NM', 'New Mexico'),
('NV', 'Nevada'),
('NY', 'New York'),
('OH', 'Ohio'),
('OK', 'Oklahoma'),
('OR', 'Oregon'),
('PA', 'Pennsylvania'),
('RI', 'Rhode Island'),
('SC', 'South Carolina'),
('SD', 'South Dakota'),
('TX', 'Texas'),
('UT', 'Utah'),
('VA', 'Virginia'),
('VT', 'Vermont'),
('WA', 'Washington'),
('WI', 'Wisconsin'),
('WV', 'West Virginia'),
('WY', 'Wyoming');

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE IF NOT EXISTS `statuses` (
  `id` int(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `name`) VALUES
(1, 'Free'),
(2, 'Pending Validation'),
(3, 'Premium'),
(4, 'In Active'),
(5, 'Deleted');

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(11) NOT NULL,
  `model` varchar(25) DEFAULT NULL,
  `field` varchar(25) DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `caption` tinyint(1) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=1081 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`id`, `model`, `field`, `foreign_key`, `caption`, `name`, `type`, `size`) VALUES
(996, 'User', 'Photo', 9, 1, 'vaibhaw-poddar.jpg', 'image/jpeg', 674525),
(998, 'User', 'Photo', 15, 0, 'sweta-pandey.jpg', 'image/jpeg', 54505),
(999, 'User', 'Photo', 15, 1, 'sweta-pandey-1.jpg', 'image/jpeg', 54505),
(1034, NULL, NULL, NULL, 0, '', '', 0),
(1001, NULL, NULL, NULL, 0, '', '', 0),
(1030, 'User', 'Photo', 32, 1, 'sujan-maharjan-2.jpg', 'image/jpeg', 25383),
(1032, NULL, NULL, NULL, 0, '', '', 0),
(1076, NULL, NULL, NULL, 0, '', '', 0),
(1077, 'User', 'Photo', 8, 1, 'IMG_0321.JPG', 'image/jpeg', 1638199),
(1028, NULL, NULL, NULL, 0, '', '', 0),
(1029, NULL, NULL, NULL, 0, '', '', 0),
(1026, NULL, NULL, NULL, 0, '', '', 0),
(1031, 'User', 'Photo', 33, 1, 'info-himalayantechies.png', 'image/png', 15140),
(1022, 'User', 'Photo', 16, 1, 'on-test-maharjan-15.jpg', 'image/jpeg', 26790),
(1023, 'User', 'Photo', 24, 1, 'suzan-loading.jpg', 'image/jpeg', 25383),
(1024, NULL, NULL, NULL, 0, '', '', 0),
(1025, 'User', 'Photo', 30, 1, 'sujan-maharjan.jpg', 'image/jpeg', 25383),
(1019, NULL, NULL, NULL, 1, '', '', 0),
(1020, 'User', 'Photo', 16, 0, 'on-test-maharjan-13.jpg', 'image/jpeg', 17829),
(1035, NULL, NULL, NULL, 0, '', '', 0),
(1036, NULL, NULL, NULL, 0, '', '', 0),
(1038, NULL, NULL, NULL, 0, '', '', 0),
(1039, NULL, NULL, NULL, 0, '', '', 0),
(1040, NULL, NULL, NULL, 0, '', '', 0),
(1041, NULL, NULL, NULL, 0, '', '', 0),
(1042, NULL, NULL, NULL, 0, '', '', 0),
(1043, NULL, NULL, NULL, 0, '', '', 0),
(1044, NULL, NULL, NULL, 0, '', '', 0),
(1045, NULL, NULL, NULL, 0, '', '', 0),
(1046, NULL, NULL, NULL, 0, '', '', 0),
(1047, NULL, NULL, NULL, 0, '', '', 0),
(1048, NULL, NULL, NULL, 0, '', '', 0),
(1049, NULL, NULL, NULL, 0, '', '', 0),
(1074, NULL, NULL, NULL, 0, '', '', 0),
(1050, NULL, NULL, NULL, 0, '', '', 0),
(1051, 'User', 'Photo', 9, 0, 'bottom_gold.gif', 'image/gif', 12376),
(1052, NULL, NULL, NULL, 0, '', '', 0),
(1053, NULL, NULL, NULL, 0, '', '', 0),
(1054, NULL, NULL, NULL, 0, '', '', 0),
(1055, NULL, NULL, NULL, 0, '', '', 0),
(1056, NULL, NULL, NULL, 0, '', '', 0),
(1057, NULL, NULL, NULL, 0, '', '', 0),
(1058, NULL, NULL, NULL, 0, '', '', 0),
(1059, NULL, NULL, NULL, 0, '', '', 0),
(1060, NULL, NULL, NULL, 0, '', '', 0),
(1061, NULL, NULL, NULL, 0, '', '', 0),
(1062, NULL, NULL, NULL, 0, '', '', 0),
(1063, NULL, NULL, NULL, 0, '', '', 0),
(1064, NULL, NULL, NULL, 0, '', '', 0),
(1065, NULL, NULL, NULL, 0, '', '', 0),
(1066, NULL, NULL, NULL, 0, '', '', 0),
(1067, NULL, NULL, NULL, 0, '', '', 0),
(1068, NULL, NULL, NULL, 0, '', '', 0),
(1069, NULL, NULL, NULL, 0, '', '', 0),
(1070, NULL, NULL, NULL, 0, '', '', 0),
(1071, NULL, NULL, NULL, 0, '', '', 0),
(1078, NULL, NULL, NULL, 0, '', '', 0),
(1080, NULL, NULL, NULL, 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(199) DEFAULT NULL,
  `middle_name` varchar(51) DEFAULT NULL,
  `last_name` varchar(52) DEFAULT NULL,
  `username` varchar(199) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `url` varchar(199) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `status_id` int(30) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `login_ip` varchar(15) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `middle_name`, `last_name`, `username`, `password`, `url`, `role_id`, `status_id`, `priority`, `date_added`, `expiry_date`, `last_login`, `login_ip`) VALUES
(8, 'Matt', '', 'Patrick', 'matthew.labozzetta@gmail.com', 'de2ea26c8b66b2332e76298cc0b7af3c26325c07', 'M-P', 6, 3, NULL, '2011-09-11 06:31:16', NULL, '2012-03-26 09:56:11', '24.89.21.55'),
(9, 'Vaibhaw', '', 'Poddar', 'bob@himalayantechies.com', 'de2ea26c8b66b2332e76298cc0b7af3c26325c07', 'vaibhaw-poddar', 5, 3, NULL, '2011-09-11 08:32:23', '2012-09-27 00:00:00', '2014-06-01 00:41:08', '137.117.209.108'),
(52, 'Rochalle Racine', 'Nicole', 'Racine', 'rochallenicole@gmail.com', 'bf3d07be18208d94f1b463f1e5cf6dc7c5971f27', 'rochallenicole', 6, 3, 2, '2012-03-07 03:05:14', NULL, NULL, '72.197.112.129'),
(27, 'Vaibhaw', '', 'Poddar', 'vaibhawp@yahoo.co.uk', 'b199364cbecddfa22840cdad75487b9ffec5358f', 'vaibhaw-1-1', 6, 3, NULL, '2011-12-16 02:31:15', NULL, '2012-02-02 05:56:01', '124.41.223.173'),
(34, 'sujan', '', 'maharjan', 's3niya@hotmail.com', '2078a19b4f3a2186aa177115ee1977cc1fad8d19', 'weprogramming', 5, 3, 1, '2011-12-18 21:35:55', NULL, '2014-11-13 08:25:58', '49.244.9.200'),
(33, 'Info', '', 'Himalayantechies', 'info@himalayantechies.com', 'de2ea26c8b66b2332e76298cc0b7af3c26325c07', 'info', 6, 1, 2, '2011-12-18 01:07:28', NULL, NULL, '182.93.95.10'),
(56, 'matt', '', 'matt', 'matt85946@yahoo.com', '5209ac4dac0fe10d9f405ac7b34b858f2818c1f8', 'mattmatt', 6, 3, 2, '2012-05-02 12:23:27', NULL, NULL, '24.89.21.55'),
(54, 'Khumbaya', '', 'Team', 'team@khumbaya.com', 'de2ea26c8b66b2332e76298cc0b7af3c26325c07', 'khumbaya', 6, 3, 2, '2012-04-08 00:05:38', NULL, NULL, '182.93.95.10'),
(55, 'Matthew', '', 'Patrick', 'mpatrick@skilledamericans.com', 'de2ea26c8b66b2332e76298cc0b7af3c26325c07', 'skilledamerican', 5, 3, 2, '2012-04-08 00:55:51', NULL, '2012-05-02 12:25:13', '24.89.21.55');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE IF NOT EXISTS `user_details` (
  `id` int(11) NOT NULL,
  `skill` varchar(50) DEFAULT NULL,
  `certification` varchar(50) DEFAULT NULL,
  `description` text,
  `specials` varchar(50) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `url` varchar(25) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `name`, `url`, `priority`) VALUES
(5, 'Administrator', 'administrator', 1),
(6, 'Profile', 'profile', 3),
(7, 'Premium', 'premium', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acos`
--
ALTER TABLE `acos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros`
--
ALTER TABLE `aros`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros_acos`
--
ALTER TABLE `aros_acos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ARO_ACO_KEY` (`aro_id`,`aco_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories_users`
--
ALTER TABLE `categories_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hideshows`
--
ALTER TABLE `hideshows`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `keywords`
--
ALTER TABLE `keywords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location_maps`
--
ALTER TABLE `location_maps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location_types`
--
ALTER TABLE `location_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paypals`
--
ALTER TABLE `paypals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acos`
--
ALTER TABLE `acos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=423;
--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `aros`
--
ALTER TABLE `aros`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=72;
--
-- AUTO_INCREMENT for table `aros_acos`
--
ALTER TABLE `aros_acos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=268;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=594;
--
-- AUTO_INCREMENT for table `categories_users`
--
ALTER TABLE `categories_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=99;
--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `hideshows`
--
ALTER TABLE `hideshows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `keywords`
--
ALTER TABLE `keywords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `location_maps`
--
ALTER TABLE `location_maps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=643;
--
-- AUTO_INCREMENT for table `location_types`
--
ALTER TABLE `location_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `paypals`
--
ALTER TABLE `paypals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1081;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
