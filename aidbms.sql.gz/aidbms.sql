-- phpMyAdmin SQL Dump
-- version 4.5.0-dev
-- http://www.phpmyadmin.net
--
-- Host: himalayantechies-db-server.cepyls6xdgwo.us-west-2.rds.amazonaws.com
-- Generation Time: Jun 21, 2015 at 04:49 AM
-- Server version: 5.6.19-log
-- PHP Version: 5.4.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `aidbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `animals`
--

CREATE TABLE IF NOT EXISTS `animals` (
  `id` int(11) NOT NULL,
  `animal_type_id` varchar(2) NOT NULL,
  `animal_type_name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `animals`
--

INSERT INTO `animals` (`id`, `animal_type_id`, `animal_type_name`, `description`, `created`, `modified_by`, `updated`) VALUES
(1, '23', 'camel', 'Camel desert', '2014-12-03 22:45:07', 2, '2014-12-03 22:45:07'),
(3, '24', 'Chicken', '', '2014-12-04 13:04:57', 2, '2014-12-04 13:04:57'),
(5, '26', 'Cow', '', '2014-12-04 13:05:42', 2, '2014-12-04 13:05:42'),
(6, '27', 'Goat', '', '2014-12-04 13:06:22', 2, '2014-12-04 13:06:22'),
(7, '28', 'Horse', '', '2014-12-04 13:06:42', 2, '2014-12-04 13:06:42'),
(8, '87', 'OX', '', '2015-01-14 12:16:08', 2, '2015-01-14 12:18:05');

-- --------------------------------------------------------

--
-- Table structure for table `animal_registrations`
--

CREATE TABLE IF NOT EXISTS `animal_registrations` (
  `id` int(11) NOT NULL,
  `herd_id` varchar(9) NOT NULL,
  `animal_type` varchar(2) NOT NULL,
  `animal_digit_no` varchar(3) NOT NULL,
  `animal_description` text NOT NULL,
  `other_description` text NOT NULL,
  `animal_photo` varchar(100) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `animal_registrations`
--

INSERT INTO `animal_registrations` (`id`, `herd_id`, `animal_type`, `animal_digit_no`, `animal_description`, `other_description`, `animal_photo`, `created`, `modified_by`, `updated`) VALUES
(1, '123456789', 'ca', '123', 'new age', 'healthy', NULL, '2014-12-17 16:11:04', NULL, '2014-12-17 16:11:04'),
(9, '987654321', '23', '000', 'brown in color', 'healthy', 'animal9.png', '2015-01-06 12:29:05', NULL, '2015-01-06 12:29:10'),
(10, '987654321', '23', '111', 'brown in color2', 'healthy2', 'animal10.png', '2015-01-06 12:29:05', NULL, '2015-01-06 12:29:14'),
(11, '987654321', '23', '12', 'Test', 'Testing', 'animal11.png', '2015-01-12 15:26:09', NULL, '2015-01-12 15:26:16'),
(12, '987654321', '23', '126', 'ok', 'ok', 'animal12.png', '2015-01-14 16:05:23', NULL, '2015-01-14 16:05:27'),
(13, '147258369', '26', '123', 'Testing Code', 'Testing Code', 'animal13.png', '2015-01-14 16:07:51', NULL, '2015-01-14 16:08:11');

-- --------------------------------------------------------

--
-- Table structure for table `artificial_inseminations`
--

CREATE TABLE IF NOT EXISTS `artificial_inseminations` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL COMMENT 'New or Repeat',
  `date` varchar(100) NOT NULL,
  `herd_id` varchar(9) NOT NULL,
  `animal_id` varchar(5) NOT NULL,
  `semen_no` varchar(50) DEFAULT NULL,
  `no_of_repeat` int(11) DEFAULT NULL,
  `cause_of_repeat` text,
  `created` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `artificial_inseminations`
--

INSERT INTO `artificial_inseminations` (`id`, `type`, `date`, `herd_id`, `animal_id`, `semen_no`, `no_of_repeat`, `cause_of_repeat`, `created`, `modified_by`, `updated`) VALUES
(1, 'New', '0000-00-00', '123456789', '23123', '5', NULL, NULL, '2014-12-17 16:29:33', NULL, '2014-12-17 16:29:33'),
(2, 'New', '0000-00-00', '123456789', '23123', '15', NULL, NULL, '2014-12-17 16:29:33', NULL, '2014-12-17 16:29:33'),
(3, 'Repeat', '0000-00-00', '123456789', '23123', '15', 2, '23', '2014-12-17 16:29:33', NULL, '2014-12-17 16:29:33'),
(4, 'New', '0000-00-00', '987654321', '23000', '123', NULL, NULL, '2015-01-06 12:29:06', NULL, '2015-01-06 12:29:06'),
(5, 'New', '0000-00-00', '987654321', '23111', '123', NULL, NULL, '2015-01-06 12:29:06', NULL, '2015-01-06 12:29:06'),
(6, 'New', '0000-00-00', '123456789', '23123', '123', NULL, NULL, '2015-01-06 12:29:06', NULL, '2015-01-06 12:29:06'),
(7, 'New', '0000-00-00', '123456789', '23000', '123', NULL, NULL, '2015-01-06 12:29:06', NULL, '2015-01-06 12:29:06'),
(8, 'Repeat', '0000-00-00', '987654321', '23000', '10', 2, 'dont know', '2015-01-06 12:29:06', NULL, '2015-01-06 12:29:06'),
(9, 'Repeat', '0000-00-00', '987654321', '23123', '10', 2, 'dont know', '2015-01-06 12:29:06', NULL, '2015-01-06 12:29:06'),
(10, 'Repeat', '0000-00-00', '987654321', '23123', '12', 12, 'stdts', '2015-01-06 12:52:18', NULL, '2015-01-06 12:52:18'),
(18, 'New', '2015-01-14', '147258369', '26123', '86556556', NULL, NULL, '2015-01-14 16:56:39', NULL, '2015-01-14 16:56:39'),
(19, 'Repeat', '2015-01-14', '147258369', '26123', '26589', 8658, 'fhfvgykfg', '2015-01-14 16:57:06', NULL, '2015-01-14 16:57:06');

-- --------------------------------------------------------

--
-- Table structure for table `calvings`
--

CREATE TABLE IF NOT EXISTS `calvings` (
  `id` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `herd_id` varchar(9) NOT NULL,
  `animal_id` varchar(5) NOT NULL,
  `date_of_calving` date NOT NULL,
  `sex` varchar(50) NOT NULL,
  `calve_id` int(11) NOT NULL,
  `calf_photo` varchar(100) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `calvings`
--

INSERT INTO `calvings` (`id`, `date`, `herd_id`, `animal_id`, `date_of_calving`, `sex`, `calve_id`, `calf_photo`, `created`, `modified_by`, `updated`) VALUES
(4, '0000-00-00', '123456789', '23123', '0000-00-00', 'Female', 12345, 'calf4.png', '2014-12-17 16:11:04', NULL, '2015-01-05 16:28:48'),
(18, '0000-00-00', '123456789', '23123', '0000-00-00', 'Male', 123456, 'calf18.png', '2014-12-17 16:29:34', NULL, '2015-01-06 12:13:17'),
(19, '0000-00-00', '123456789', '23123', '0000-00-00', 'Female', 123456, NULL, '2015-01-05 16:43:48', NULL, '2015-01-05 16:43:48'),
(20, '--6/1/2015', '987654321', '23000', '0000-00-00', 'Male', 11111, 'calf20.png', '2015-01-06 12:29:07', NULL, '2015-01-06 12:29:17'),
(21, '--6/1/2015', '987654321', '23111', '0000-00-00', 'Female', 22222, 'calf21.png', '2015-01-06 12:29:07', NULL, '2015-01-06 12:29:20'),
(22, '--6/1/2015', '123456789', '23123', '0000-00-00', 'Female', 33333, 'calf22.png', '2015-01-06 12:29:07', NULL, '2015-01-06 12:29:23'),
(23, '--12/1/2015', '987654321', '23126', '0000-00-00', 'Female', 1, 'calf23.png', '2015-01-14 16:05:23', NULL, '2015-01-14 16:57:14');

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE IF NOT EXISTS `devices` (
  `id` int(11) NOT NULL,
  `device_id` varchar(5) NOT NULL,
  `serial_no` varchar(100) NOT NULL,
  `assigned_inseminator` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `device_id`, `serial_no`, `assigned_inseminator`, `created`, `modified_by`, `updated`) VALUES
(6, '1', '123', '1', '2014-12-04 11:47:42', 2, '2014-12-04 11:47:42'),
(7, '12345', '254', '4', '2015-01-09 13:51:18', 2, '2015-01-09 13:51:18'),
(8, '12343', '54215215421', '1', '2015-02-22 15:41:49', 5, '2015-02-22 15:41:49');

-- --------------------------------------------------------

--
-- Table structure for table `diseases`
--

CREATE TABLE IF NOT EXISTS `diseases` (
  `id` int(11) NOT NULL,
  `code` varchar(3) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `diseases`
--

INSERT INTO `diseases` (`id`, `code`, `name`, `description`, `created`, `modified_by`, `updated`) VALUES
(3, '151', 'Salmonella', 'According to the National Centers for Infectious Disease (CDC), "Salmonellosis is a bacterial disease caused by the bacterium Salmonella." Salmonella is one of the most common types of food-borne illnesses nationwide. All types of species, including humans can carry salmonella in their intestinal tract. Because salmonella can live and breed outside of the intestinal tract as well, this disease cannot be eradicated. This disease is spread from animal to animal through contact and consumption of contaminated feces, or contaminated water supply through feces. Food that can be infected are things such as poultry and other meats, raw eggs, and milk. Occasionally vegetables can also be affected by being washed in a contaminated water supply. This disease is spread from humans by improper washing of hands after contact with animal feces.', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(4, '152', 'Campylobacteriosis', 'The CDC states that campylobacteriosis "is a bacterial disease caused by Campylobacter jejuni or Campylobacter coli." Campylobacteriosis, which affects the intestinal tract, is most common in animals farmed for food. This disease is passed from animal to animal by consumption of food or drink contaminated by feces. It can also be spread by direct contact with a contaminated animal. Humans are affected mainly with improper handling of undercooked or raw poultry meat or through direct contact with a sick animal.', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(5, '153', 'Tuberculosis', 'The Centers for Infectious Control define tuberculosis (TB) as "a disease caused by a bacterium called Mycobacterium tuberculosis." TB is mainly carried by domestic animals and farm animals, but can occasionally be found in wild animals. This disease usually attacks the lungs first and can be fatal. This can be transferred from animal to animal through the air and through the consumption of contaminated feces or urine. Humans are most often affected through contact with other humans, and not as much with animals.', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE IF NOT EXISTS `districts` (
  `id` int(11) NOT NULL,
  `code` varchar(2) NOT NULL,
  `name` varchar(80) NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `code`, `name`, `created`, `modified_by`, `updated`) VALUES
(3, '3', 'Ilam', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(13, '5', 'Sankhuwasabha', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(14, '6', 'Tehrathum', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(15, '8', 'Dhankuta', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(16, '7', 'Bhojpur', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(17, '10', 'Morang', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(18, '9', 'Sunsari', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(19, '11', 'Solukhumbu', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(21, '12', 'Khotang', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(22, '13', 'Udaypur', '2014-12-03 22:43:19', 2, '2014-12-04 13:00:24'),
(23, '14', 'Okhaldhunga', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(24, '15', 'Saptari', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(25, '16', 'Siraha', '2014-12-03 22:43:19', 2, '2014-12-04 13:00:27'),
(26, '17', 'Dhanusa', '2014-12-03 22:43:19', 2, '2014-12-04 12:59:08'),
(27, '18', 'Mahottari', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(28, '19', 'Sarlahi', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(29, '4', 'Jhapa', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(30, '20', 'Sindhuli', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(31, '21', 'Ramechhap', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(32, '22', 'Dolkha', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(33, '23', 'Sindhupalchowk', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(34, '24', 'Rasuwa', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(35, '25', 'Dhading', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(36, '26', 'Nuwakot', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(37, '27', 'Kathmandu', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(38, '28', 'Lalitpur', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(39, '29', 'Bhaktapur', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(40, '30', 'Kavrepalanchowk', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(41, '31', 'Makwanpur', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(42, '32', 'Rautahat', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(43, '33', 'Bara', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(44, '34', 'Parsa', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(45, '35', 'Chitwan', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(46, '36', 'Nawalparasi', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(47, '37', 'Rupandehi', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(48, '38', 'Kapilvastu', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(50, '40', 'Palpa', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(51, '41', 'Gulmi', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(52, '42', 'Syangja', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(53, '43', 'Tanahun', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(54, '44', 'Gorkha', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(55, '45', 'Manang', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(56, '46', 'Lamjung', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(57, '47', 'Kaski', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(58, '48', 'Parvat', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(59, '49', 'Baglung', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(60, '50', 'Myagdi', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(61, '51', 'Mustang', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(62, '52', 'Mugu', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(63, '53', 'Dolpa', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(64, '54', 'Humla', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(65, '55', 'Jumla', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(66, '56', 'Kalikot', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(67, '57', 'Rukum', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(68, '58', 'Rolpa', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(69, '59', 'Pyuthan', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(70, '60', 'Dang', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(71, '61', 'Salyan', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(72, '62', 'Banke', '2014-12-03 22:43:19', 2, '2015-01-09 13:47:57'),
(73, '63', 'Bardiya', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(74, '64', 'Surkhet', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(75, '65', 'Jajarkot', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(76, '66', 'Dailekh', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(77, '67', 'Kailali', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(78, '68', 'Doti', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(79, '69', 'Achham', '2014-12-03 22:43:19', 2, '2014-12-04 13:00:29'),
(80, '70', 'Bajura', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(81, '71', 'Bajhang', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(82, '72', 'Darchula', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(83, '73', 'Baitadi', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(84, '74', 'Dadeldhura', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(85, '75', 'Kanchanpur', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(86, '76', 'Che.Si.Ni. Dhankuta', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(87, '77', 'Che.Si.Ni. Bhaktapur', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(88, '78', 'Che.Si.Ni. Kaski', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(89, '79', 'Che.Si.Ni. Surkhet', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(90, '80', 'Che.Si.Ni. Doti', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(91, '81', 'Sa.Ja.Bi.Ke Sano Thimi', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(92, '1', 'Taplejung', '2014-12-03 22:43:19', 0, '2014-12-03 22:43:19'),
(93, '53', 'Biratnagar', '2015-01-09 13:47:02', 2, '2015-01-09 13:47:02');

-- --------------------------------------------------------

--
-- Table structure for table `herd_registrations`
--

CREATE TABLE IF NOT EXISTS `herd_registrations` (
  `id` int(11) NOT NULL,
  `herd_id` varchar(50) NOT NULL,
  `district_id` varchar(2) NOT NULL,
  `vdc_id` varchar(2) NOT NULL,
  `ward_no` varchar(2) NOT NULL,
  `farmer_code` varchar(50) NOT NULL,
  `farmer_name` varchar(100) NOT NULL,
  `farmer_address` varchar(255) NOT NULL,
  `contact_detail` varchar(100) NOT NULL,
  `status_present` varchar(100) NOT NULL,
  `no_of_animal` int(11) NOT NULL,
  `age_group` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `herd_registrations`
--

INSERT INTO `herd_registrations` (`id`, `herd_id`, `district_id`, `vdc_id`, `ward_no`, `farmer_code`, `farmer_name`, `farmer_address`, `contact_detail`, `status_present`, `no_of_animal`, `age_group`, `created`, `modified_by`, `updated`) VALUES
(1, '123456789', '2', '2', '2', '123456', 'Tester', 'India', '9015793575', 'ghijkl', 10, '10-20', '2014-12-16 12:44:56', NULL, '2014-12-16 12:44:56'),
(2, '123456789', '12', '34', '56', '123', 'abc', 'def', '9015793575', 'ready', 10, 'medium', '2014-12-17 16:06:45', NULL, '2014-12-17 16:06:45'),
(3, '123456789', '12', '34', '56', '123', 'abc', 'def', '9015793575', 'ready', 10, 'medium', '2014-12-17 16:11:04', NULL, '2014-12-17 16:11:04'),
(4, '123456789', '12', '34', '56', '123', 'abc', 'def', '9015793575', 'ready', 10, 'medium', '2014-12-17 16:27:28', NULL, '2014-12-17 16:27:28'),
(5, '123456789', '12', '34', '56', '123', 'abc', 'def', '9015793575', 'ready', 10, 'medium', '2014-12-17 16:29:30', NULL, '2014-12-17 16:29:30'),
(6, '123456789', '12', '34', '56', '123', 'abc', 'def', 'gjjhhhgjgjgf', 'chvhvuhgugu', 10, 'hvhhhfhgij', '2014-12-18 17:40:57', NULL, '2014-12-18 17:40:57'),
(7, '123456789', '12', '34', '56', '123', 'abc', 'def', 'gjjhhhgjgjgf', 'chvhvuhgugu', 10, 'hvhhhfhgij', '2014-12-23 13:44:47', NULL, '2014-12-23 13:44:47'),
(8, '123456789', '12', '34', '5', '12345', 'sfhgjdjtdjt', 'dtjtjddtu', 'dtdusutdutdt', 'shhsrdh', 12, 'rsjtduduxut', '2015-01-05 16:43:48', NULL, '2015-01-05 16:43:48'),
(9, '987654321', '12', '34', '', '1234', 'sachin', 'noida', 'abc', 'good', 10, 'medium', '2015-01-06 12:29:05', NULL, '2015-01-06 12:29:05'),
(10, '123456789', '01', '', '', '2365', 'Test', 'Sanepa', '564648', 'active', 12, '2 ', '2015-01-12 14:38:07', NULL, '2015-01-12 14:38:07'),
(11, '987654321', '97', '7', '', '01', 'Ramlal', 'Butwal', '5789697', 'active', 20, '2 to 5 years', '2015-01-12 15:23:29', NULL, '2015-01-12 15:23:29'),
(12, '1324657980', '01', '85', '34', '02', 'dgfgf', 'cgdgf', '46467', 'fvcc', 9863, '23', '2015-01-14 16:05:23', NULL, '2015-01-14 16:05:23'),
(13, '1234567890123', '78', '25', '36', '123654', 'tdgxbx', 'ffdcbvv', '45364', 'yes', 25, '3', '2015-01-14 16:05:23', NULL, '2015-01-14 16:05:23'),
(14, '147258369', '12', '34', '56', '12345', 'saakshi', 'KP', '12345677', 'yes', 12, '12', '2015-01-14 16:05:23', NULL, '2015-01-14 16:05:23'),
(15, '123456780', '12', '31', '5', '123', 'sfhtus', 'dtetstutuytsuts', 'stdysureydysurfutdu', 'stusyrsut', 123, 'ysfysfusfu', '2015-01-14 16:56:59', NULL, '2015-01-14 16:56:59');

-- --------------------------------------------------------

--
-- Table structure for table `inseminators`
--

CREATE TABLE IF NOT EXISTS `inseminators` (
  `id` int(11) NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` varchar(100) NOT NULL,
  `organisation_id` int(11) NOT NULL,
  `area` text NOT NULL,
  `background` text NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inseminators`
--

INSERT INTO `inseminators` (`id`, `code`, `name`, `organisation_id`, `area`, `background`, `created`, `modified_by`, `updated`) VALUES
(1, '1', 'Sakshi Agrawal', 2, 'Ilam Municipality, IIlam', 'HT', '2014-12-03 22:45:07', 2, '2014-12-04 15:57:35'),
(4, '23', 'Arpita Singh', 1, 'Sanepa', 'HT', '2014-12-03 22:45:07', 2, '2014-12-03 22:45:07'),
(5, '23535', 'Bob Poddar', 2, 'Bhaktapur', 'Bhaktapur', '2015-01-09 13:54:53', 2, '2015-01-09 13:55:22'),
(6, '222', 'Shiva ', 2, 'Dhapakhel', 'Inseminator\r\n', '2015-04-24 15:30:40', 6, '2015-04-24 15:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `muncipalities`
--

CREATE TABLE IF NOT EXISTS `muncipalities` (
  `id` int(11) NOT NULL,
  `code` varchar(2) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `muncipalities`
--

INSERT INTO `muncipalities` (`id`, `code`, `name`, `created`, `modified_by`, `updated`) VALUES
(2, '2', 'Tiringe', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(3, '3', 'Thumbedin', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(13, '5', 'Thukimma', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(14, '6', 'Thinglabu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(15, '8', 'Thechambu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(16, '7', 'Tellok', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(17, '10', 'Tapethok', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(18, '9', 'Surumkhim', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(19, '11', 'Sinam', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(21, '12', 'Sikaicha', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(22, '13', 'Sawandin', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(23, '14', 'Sanwa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(24, '15', 'Santhakra', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(25, '16', 'Sanghu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(26, '17', 'Sadewa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(27, '18', 'Sablakhu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(28, '19', 'Phurumbu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(29, '4', 'Phungling', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(30, '20', 'Phulbari', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(31, '21', 'Phawakhola', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(32, '22', 'Phakumba', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(33, '23', 'Pedang', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(34, '24', 'Papung', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(35, '25', 'Olangchung Gola', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(36, '26', 'Nidhuradin', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(37, '27', 'Nangkholyang', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(38, '28', 'Nalbu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(39, '29', 'Mehele', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(40, '30', 'Mamangkhe', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(41, '31', 'Liwang', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(42, '32', 'Linkhim', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(43, '33', 'Lingtep', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(44, '34', 'Limbudin', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(45, '35', 'Lelep', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(46, '36', 'Khokling', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(47, '37', 'Khewang', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(48, '38', 'Khejenim', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(49, '39', 'Khamlung', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(50, '40', 'Kalikhola', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(51, '41', 'Yasok', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(52, '42', 'Hangpang', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(53, '43', 'Hangdewa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(54, '44', 'Ekhabu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(55, '45', 'Dummrise', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(56, '46', 'Dokhu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(57, '47', 'Dhungesanghu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(58, '48', 'Change', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(59, '49', 'Chaksibote', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(60, '50', 'Angkhop', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(61, '51', 'Ambegudin', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(62, '52', 'Aangna', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(63, '53', 'Yanganam', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(64, '54', 'Tharpu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(65, '55', 'Syabrumba', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(66, '56', 'Subhang', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(67, '57', 'Siwa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(68, '58', 'Sidin', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(69, '59', 'Sarang Danda', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(70, '60', 'Ranitar', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(71, '61', 'Rani Gaun', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(72, '62', 'Rabi', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(73, '63', 'Prangbung', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(74, '64', 'Phidim', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(75, '65', 'Phalaincha', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(76, '66', 'Phaktep', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(77, '67', 'Pauwa Sartap', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(78, '68', 'Panchami', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(79, '69', 'Oyam', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(80, '70', 'Olane', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(81, '71', 'Nawamidanda', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(82, '72', 'Nangeen', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(83, '73', 'Nagi', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(84, '74', 'Memeng', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(85, '75', 'Mauwa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(86, '76', 'Mangjabung', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(87, '77', 'Lungrupa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(88, '78', 'Lumphabung', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(89, '79', 'Limba', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(90, '80', 'Kurumba', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(91, '81', 'Hangum', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(92, '82', 'Embung', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(93, '83', 'Ekteen', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(94, '84', 'Durdimba', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(95, '85', 'Chyangthapu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(96, '86', 'Chokmagu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(97, '87', 'Chilingdin', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(98, '88', 'Bharapa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(99, '89', 'Amarpur', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(100, '90', 'Aarubote', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(101, '91', 'Aangsarang', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(102, '92', 'Sumbek', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(103, '93', 'Sulubung', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(104, '94', 'Soyang', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(105, '95', 'Soyak', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(106, '96', 'Siddhithumka', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(107, '97', 'Shree Antu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(108, '98', 'Shantipur', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(109, '99', 'Shanti Danda', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(110, '10', 'Sangrumba', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(111, '10', 'Samalbung', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(112, '10', 'Sakhejung', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(113, '10', 'Sakfara', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(114, '10', 'Pyang', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(115, '10', 'Puwamajhuwa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(116, '10', 'Phuyatappa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(117, '10', 'Phikal Bazar', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(118, '10', 'Phakphok', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(119, '10', 'Pasupati Nagar', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(120, '11', 'Panchakanya', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(121, '11', 'Naya Bazar', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(122, '11', 'Namsaling', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(123, '11', 'Mangalbare', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(124, '11', 'Maipokhari', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(125, '11', 'Maimajhuwa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(126, '11', 'Mahamai', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(127, '11', 'Mabu', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(128, '11', 'Lumde', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(129, '11', 'Laxmipur', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(130, '12', 'Kolbung', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(131, '12', 'Kanyam', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(132, '12', 'Jogmai', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(133, '12', 'Jitpur', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(134, '12', 'Jirmale', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(135, '12', 'Jamuna', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(136, '12', 'Ilam Municipality', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(137, '12', 'Gorkhe', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(138, '12', 'Godak', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(139, '12', 'Gajurmukhi', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(140, '13', 'Erautar', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(141, '13', 'Ektappa', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(142, '13', 'Ebhang', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(143, '13', 'Dhuseni', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(144, '13', 'Danabari', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(145, '13', 'Chulachuli', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(146, '13', 'Chisapani', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(147, '13', 'Chamaita', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(148, '13', 'Barbote', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(149, '13', 'Bajho', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(150, '14', 'Amchok', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(152, '21', '', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07'),
(153, '43', 'Test', '2015-01-09 14:25:13', 2, '2015-01-09 14:25:13');

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE IF NOT EXISTS `organizations` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(50) NOT NULL,
  `contact_detail` text NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`id`, `description`, `type`, `contact_detail`, `created`, `modified_by`, `updated`) VALUES
(2, 'Bhaktapur Animal Shelter ', 'Private', '698707', '2014-12-04 13:08:27', 2, '2014-12-04 13:08:27'),
(3, 'Poultry Farming pvt ltd.', 'Government', '223423423ht', '2015-01-09 13:56:56', 2, '2015-01-09 14:00:30');

-- --------------------------------------------------------

--
-- Table structure for table `repeats`
--

CREATE TABLE IF NOT EXISTS `repeats` (
  `id` int(11) NOT NULL,
  `code` varchar(2) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `repeats`
--

INSERT INTO `repeats` (`id`, `code`, `description`, `created`, `modified_by`, `updated`) VALUES
(2, '12', 'testing', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07');

-- --------------------------------------------------------

--
-- Table structure for table `treatments`
--

CREATE TABLE IF NOT EXISTS `treatments` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `herd_id` varchar(50) NOT NULL,
  `animal_id` varchar(50) NOT NULL,
  `disease_code` varchar(50) DEFAULT NULL,
  `disease_description` text,
  `treatment_code` varchar(50) DEFAULT NULL,
  `treatment_description` text,
  `result` text NOT NULL,
  `need_follow_up` varchar(100) DEFAULT NULL,
  `follow_up_no` varchar(50) DEFAULT NULL,
  `remark` text,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `treatments`
--

INSERT INTO `treatments` (`id`, `type`, `date`, `herd_id`, `animal_id`, `disease_code`, `disease_description`, `treatment_code`, `treatment_description`, `result`, `need_follow_up`, `follow_up_no`, `remark`, `parent_id`, `lft`, `rght`, `created`, `modified_by`, `updated`) VALUES
(1, 'New', '0000-00-00', '123456789', '23123', '12', '12', '12', '12', '12', 'Yes', NULL, '12', NULL, NULL, NULL, '2014-12-17 16:29:34', NULL, '2014-12-17 16:29:34'),
(2, 'New', '0000-00-00', '123456789', '23123', NULL, NULL, NULL, NULL, '12', 'No', '12', '12', NULL, NULL, NULL, '2014-12-17 16:29:34', NULL, '2014-12-17 16:29:34'),
(3, 'New', '0000-00-00', '123456789', '23123', '12', 'hfhfhhfh', '12', 'fhfhhfhf', 'ghhfu', 'Yes', NULL, 'gghvv', NULL, NULL, NULL, '2014-12-18 17:40:57', NULL, '2014-12-18 17:40:57'),
(4, 'FollowUp', '0000-00-00', '123456789', '23123', NULL, NULL, NULL, NULL, 'hvhvujgh', 'No', '12', 'gfgfyhjgug', NULL, NULL, NULL, '2014-12-18 17:40:57', NULL, '2014-12-18 17:40:57'),
(5, 'New', '0000-00-00', '123456789', '23123', '12', 'hfhfhhfh', '12', 'fhfhhfhf', 'ghhfu', 'Yes', NULL, 'gghvv', NULL, NULL, NULL, '2014-12-23 13:44:47', NULL, '2014-12-23 13:44:47'),
(6, 'FollowUp', '0000-00-00', '123456789', '23123', NULL, NULL, NULL, NULL, 'hvhvujgh', 'No', '12', 'gfgfyhjgug', NULL, NULL, NULL, '2014-12-23 13:44:47', NULL, '2014-12-23 13:44:47');

-- --------------------------------------------------------

--
-- Table structure for table `treatment_setups`
--

CREATE TABLE IF NOT EXISTS `treatment_setups` (
  `id` int(11) NOT NULL,
  `code` varchar(3) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `treatment_setups`
--

INSERT INTO `treatment_setups` (`id`, `code`, `name`, `description`, `created`, `modified_by`, `updated`) VALUES
(1, '123', 'Injection', 'This is a test injection', '2014-12-03 22:45:07', 0, '2014-12-03 22:45:07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(5) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `access_right` varchar(50) NOT NULL,
  `access_feature` varchar(50) NOT NULL,
  `validity_period` datetime NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `username`, `password`, `access_right`, `access_feature`, `validity_period`, `created`, `updated`) VALUES
(2, '1', 'htadmin', 'htadmin', '1', '1', '0000-00-00 00:00:00', '2014-12-03 22:45:07', '2015-05-01 00:00:00'),
(4, '4', 'sagrawal@himalayantechies.com', 'sagrawal', 'yes', 'yes', '0000-00-00 00:00:00', '2015-01-09 14:16:25', '2015-01-09 14:24:17'),
(5, '45324', 'Shiwanee', '123456', 'yes', 'yes', '2015-03-28 00:00:00', '2015-01-14 12:22:33', '2015-02-14 12:22:33'),
(6, '8451', 'htadmin1', '8bb31a9ceafecf7099542bdc81982b4c8a9510c9', '1', '1', '2016-12-31 00:00:00', '2015-04-24 00:00:00', '2015-04-24 00:00:00'),
(7, '87541', 'aidbms', 'aidbms123456', '1', '1', '2016-12-31 00:00:00', '2016-12-31 00:00:00', '2016-12-31 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `animals`
--
ALTER TABLE `animals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `animal_registrations`
--
ALTER TABLE `animal_registrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `artificial_inseminations`
--
ALTER TABLE `artificial_inseminations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `calvings`
--
ALTER TABLE `calvings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `diseases`
--
ALTER TABLE `diseases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `herd_registrations`
--
ALTER TABLE `herd_registrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inseminators`
--
ALTER TABLE `inseminators`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `muncipalities`
--
ALTER TABLE `muncipalities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repeats`
--
ALTER TABLE `repeats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `treatments`
--
ALTER TABLE `treatments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `treatment_setups`
--
ALTER TABLE `treatment_setups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `animals`
--
ALTER TABLE `animals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `animal_registrations`
--
ALTER TABLE `animal_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `artificial_inseminations`
--
ALTER TABLE `artificial_inseminations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `calvings`
--
ALTER TABLE `calvings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `diseases`
--
ALTER TABLE `diseases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT for table `herd_registrations`
--
ALTER TABLE `herd_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `inseminators`
--
ALTER TABLE `inseminators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `muncipalities`
--
ALTER TABLE `muncipalities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=154;
--
-- AUTO_INCREMENT for table `organizations`
--
ALTER TABLE `organizations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `repeats`
--
ALTER TABLE `repeats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `treatments`
--
ALTER TABLE `treatments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `treatment_setups`
--
ALTER TABLE `treatment_setups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
