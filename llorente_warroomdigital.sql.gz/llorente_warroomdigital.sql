-- MySQL dump 10.13  Distrib 5.5.42, for Linux (x86_64)
--
-- Host: localhost    Database: llorente_warroomdigital
-- ------------------------------------------------------
-- Server version	5.5.42-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acos`
--

DROP TABLE IF EXISTS `acos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acos`
--

LOCK TABLES `acos` WRITE;
/*!40000 ALTER TABLE `acos` DISABLE KEYS */;
INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES (1,NULL,'',NULL,'controllers',1,498),(2,1,'',NULL,'Acl',2,25),(3,2,'',NULL,'AclActions',3,16),(4,3,'',NULL,'admin_index',4,5),(5,3,'',NULL,'admin_add',6,7),(6,3,'',NULL,'admin_edit',8,9),(7,3,'',NULL,'admin_delete',10,11),(8,3,'',NULL,'admin_move',12,13),(9,3,'',NULL,'admin_generate',14,15),(10,2,'',NULL,'AclPermissions',17,24),(11,10,'',NULL,'admin_index',18,19),(12,10,'',NULL,'admin_toggle',20,21),(13,10,'',NULL,'admin_upgrade',22,23),(14,1,'',NULL,'Blocks',26,55),(15,14,'',NULL,'Blocks',27,44),(16,15,'',NULL,'admin_toggle',28,29),(17,15,'',NULL,'admin_index',30,31),(18,15,'',NULL,'admin_add',32,33),(19,15,'',NULL,'admin_edit',34,35),(20,15,'',NULL,'admin_delete',36,37),(21,15,'',NULL,'admin_moveup',38,39),(22,15,'',NULL,'admin_movedown',40,41),(23,15,'',NULL,'admin_process',42,43),(24,14,'',NULL,'Regions',45,54),(25,24,'',NULL,'admin_index',46,47),(26,24,'',NULL,'admin_add',48,49),(27,24,'',NULL,'admin_edit',50,51),(28,24,'',NULL,'admin_delete',52,53),(29,1,'',NULL,'Comments',56,73),(30,29,'',NULL,'Comments',57,72),(31,30,'',NULL,'admin_index',58,59),(32,30,'',NULL,'admin_edit',60,61),(33,30,'',NULL,'admin_delete',62,63),(34,30,'',NULL,'admin_process',64,65),(35,30,'',NULL,'index',66,67),(36,30,'',NULL,'add',68,69),(37,30,'',NULL,'delete',70,71),(38,1,'',NULL,'Contacts',74,97),(50,1,'',NULL,'Croogo',98,99),(51,1,'',NULL,'Extensions',100,147),(52,51,'',NULL,'ExtensionsLocales',101,112),(53,52,'',NULL,'admin_index',102,103),(54,52,'',NULL,'admin_activate',104,105),(55,52,'',NULL,'admin_add',106,107),(56,52,'',NULL,'admin_edit',108,109),(57,52,'',NULL,'admin_delete',110,111),(58,51,'',NULL,'ExtensionsPlugins',113,128),(59,58,'',NULL,'admin_index',114,115),(60,58,'',NULL,'admin_add',116,117),(61,58,'',NULL,'admin_delete',118,119),(62,58,'',NULL,'admin_toggle',120,121),(63,58,'',NULL,'admin_migrate',122,123),(64,51,'',NULL,'ExtensionsThemes',129,142),(65,64,'',NULL,'admin_index',130,131),(66,64,'',NULL,'admin_activate',132,133),(67,64,'',NULL,'admin_add',134,135),(68,64,'',NULL,'admin_editor',136,137),(69,64,'',NULL,'admin_save',138,139),(70,64,'',NULL,'admin_delete',140,141),(71,1,'',NULL,'FileManager',148,183),(72,71,'',NULL,'Attachments',149,160),(73,72,'',NULL,'admin_index',150,151),(74,72,'',NULL,'admin_add',152,153),(75,72,'',NULL,'admin_edit',154,155),(76,72,'',NULL,'admin_delete',156,157),(77,72,'',NULL,'admin_browse',158,159),(78,71,'',NULL,'FileManager',161,182),(79,78,'',NULL,'admin_index',162,163),(80,78,'',NULL,'admin_browse',164,165),(81,78,'',NULL,'admin_editfile',166,167),(82,78,'',NULL,'admin_upload',168,169),(83,78,'',NULL,'admin_delete_file',170,171),(84,78,'',NULL,'admin_delete_directory',172,173),(85,78,'',NULL,'admin_rename',174,175),(86,78,'',NULL,'admin_create_directory',176,177),(87,78,'',NULL,'admin_create_file',178,179),(88,78,'',NULL,'admin_chmod',180,181),(89,1,'',NULL,'Install',184,197),(90,89,'',NULL,'Install',185,196),(91,90,'',NULL,'index',186,187),(92,90,'',NULL,'database',188,189),(93,90,'',NULL,'data',190,191),(94,90,'',NULL,'adminuser',192,193),(95,90,'',NULL,'finish',194,195),(96,1,'',NULL,'Menus',198,231),(97,96,'',NULL,'Links',199,218),(98,97,'',NULL,'admin_toggle',200,201),(99,97,'',NULL,'admin_index',202,203),(100,97,'',NULL,'admin_add',204,205),(101,97,'',NULL,'admin_edit',206,207),(102,97,'',NULL,'admin_delete',208,209),(103,97,'',NULL,'admin_moveup',210,211),(104,97,'',NULL,'admin_movedown',212,213),(105,97,'',NULL,'admin_process',214,215),(106,96,'',NULL,'Menus',219,230),(107,106,'',NULL,'admin_index',220,221),(108,106,'',NULL,'admin_add',222,223),(109,106,'',NULL,'admin_edit',224,225),(110,106,'',NULL,'admin_delete',226,227),(111,1,'',NULL,'Meta',232,239),(112,1,'',NULL,'Migrations',240,241),(113,1,'',NULL,'Nodes',242,281),(114,113,'',NULL,'Nodes',243,280),(115,114,'',NULL,'admin_toggle',244,245),(116,114,'',NULL,'admin_index',246,247),(117,114,'',NULL,'admin_create',248,249),(118,114,'',NULL,'admin_add',250,251),(119,114,'',NULL,'admin_edit',252,253),(120,114,'',NULL,'admin_update_paths',254,255),(121,114,'',NULL,'admin_delete',256,257),(122,114,'',NULL,'admin_delete_meta',258,259),(123,114,'',NULL,'admin_add_meta',260,261),(124,114,'',NULL,'admin_process',262,263),(125,114,'',NULL,'index',264,265),(126,114,'',NULL,'term',266,267),(127,114,'',NULL,'promoted',268,269),(128,114,'',NULL,'search',270,271),(129,114,'',NULL,'view',272,273),(130,1,'',NULL,'Search',282,283),(131,1,'',NULL,'Settings',284,319),(132,131,'',NULL,'Languages',285,300),(133,132,'',NULL,'admin_index',286,287),(134,132,'',NULL,'admin_add',288,289),(135,132,'',NULL,'admin_edit',290,291),(136,132,'',NULL,'admin_delete',292,293),(137,132,'',NULL,'admin_moveup',294,295),(138,132,'',NULL,'admin_movedown',296,297),(139,132,'',NULL,'admin_select',298,299),(140,131,'',NULL,'Settings',301,318),(142,140,'',NULL,'admin_index',302,303),(143,140,'',NULL,'admin_view',304,305),(144,140,'',NULL,'admin_add',306,307),(145,140,'',NULL,'admin_edit',308,309),(146,140,'',NULL,'admin_delete',310,311),(147,140,'',NULL,'admin_prefix',312,313),(148,140,'',NULL,'admin_moveup',314,315),(149,140,'',NULL,'admin_movedown',316,317),(150,1,'',NULL,'Taxonomy',320,359),(151,150,'',NULL,'Terms',321,334),(152,151,'',NULL,'admin_index',322,323),(153,151,'',NULL,'admin_add',324,325),(154,151,'',NULL,'admin_edit',326,327),(155,151,'',NULL,'admin_delete',328,329),(156,151,'',NULL,'admin_moveup',330,331),(157,151,'',NULL,'admin_movedown',332,333),(158,150,'',NULL,'Types',335,344),(159,158,'',NULL,'admin_index',336,337),(160,158,'',NULL,'admin_add',338,339),(161,158,'',NULL,'admin_edit',340,341),(162,158,'',NULL,'admin_delete',342,343),(163,150,'',NULL,'Vocabularies',345,358),(164,163,'',NULL,'admin_index',346,347),(165,163,'',NULL,'admin_add',348,349),(166,163,'',NULL,'admin_edit',350,351),(167,163,'',NULL,'admin_delete',352,353),(168,163,'',NULL,'admin_moveup',354,355),(169,163,'',NULL,'admin_movedown',356,357),(170,1,'',NULL,'Ckeditor',360,361),(171,1,'',NULL,'Users',362,407),(172,171,'',NULL,'Roles',363,372),(173,172,'',NULL,'admin_index',364,365),(174,172,'',NULL,'admin_add',366,367),(175,172,'',NULL,'admin_edit',368,369),(176,172,'',NULL,'admin_delete',370,371),(177,171,'',NULL,'Users',373,406),(178,177,'',NULL,'admin_index',374,375),(179,177,'',NULL,'admin_add',376,377),(180,177,'',NULL,'admin_edit',378,379),(181,177,'',NULL,'admin_reset_password',380,381),(182,177,'',NULL,'admin_delete',382,383),(183,177,'',NULL,'admin_login',384,385),(184,177,'',NULL,'admin_logout',386,387),(185,177,'',NULL,'index',388,389),(186,177,'',NULL,'add',390,391),(187,177,'',NULL,'activate',392,393),(188,177,'',NULL,'edit',394,395),(189,177,'',NULL,'forgot',396,397),(190,177,'',NULL,'reset',398,399),(191,177,'',NULL,'login',400,401),(192,177,'',NULL,'logout',402,403),(193,177,'',NULL,'view',404,405),(194,1,NULL,NULL,'Crises',408,419),(195,194,NULL,NULL,'index',409,410),(196,194,NULL,NULL,'view',411,412),(197,194,NULL,NULL,'add',413,414),(198,194,NULL,NULL,'edit',415,416),(199,194,NULL,NULL,'delete',417,418),(200,51,NULL,NULL,'ExtensionsDashboard',143,146),(201,200,NULL,NULL,'admin_index',144,145),(202,58,NULL,NULL,'admin_moveup',124,125),(203,58,NULL,NULL,'admin_movedown',126,127),(204,97,NULL,NULL,'admin_link_chooser',216,217),(205,106,NULL,NULL,'admin_toggle',228,229),(206,111,NULL,NULL,'Meta',233,238),(207,206,NULL,NULL,'admin_delete_meta',234,235),(208,206,NULL,NULL,'admin_add_meta',236,237),(209,114,NULL,NULL,'admin_hierarchy',274,275),(210,114,NULL,NULL,'admin_moveup',276,277),(211,114,NULL,NULL,'admin_movedown',278,279),(212,NULL,NULL,NULL,'api',499,514),(213,212,NULL,NULL,'v1_0',500,513),(214,213,NULL,NULL,'Nodes',501,506),(215,214,NULL,NULL,'Nodes',502,505),(216,215,NULL,NULL,'lookup',503,504),(217,213,NULL,NULL,'Users',507,512),(218,217,NULL,NULL,'Users',508,511),(219,218,NULL,NULL,'lookup',509,510),(220,1,NULL,NULL,'Wysiwyg',420,421),(221,1,NULL,NULL,'Feeds',422,433),(222,221,NULL,NULL,'index',423,424),(223,221,NULL,NULL,'view',425,426),(224,221,NULL,NULL,'add',427,428),(225,221,NULL,NULL,'edit',429,430),(226,221,NULL,NULL,'delete',431,432),(227,1,NULL,NULL,'PanicRooms',434,445),(228,227,NULL,NULL,'index',435,436),(229,227,NULL,NULL,'view',437,438),(230,227,NULL,NULL,'add',439,440),(231,227,NULL,NULL,'edit',441,442),(232,227,NULL,NULL,'delete',443,444),(233,1,NULL,NULL,'Tasks',446,457),(234,233,NULL,NULL,'index',447,448),(235,233,NULL,NULL,'view',449,450),(236,233,NULL,NULL,'add',451,452),(237,233,NULL,NULL,'edit',453,454),(238,233,NULL,NULL,'delete',455,456),(260,1,NULL,NULL,'Connections',458,471),(261,260,NULL,NULL,'index',459,460),(262,260,NULL,NULL,'view',461,462),(263,260,NULL,NULL,'add',463,464),(264,260,NULL,NULL,'edit',465,466),(265,260,NULL,NULL,'delete',467,468),(266,38,NULL,NULL,'Contacts',75,86),(267,266,NULL,NULL,'admin_index',76,77),(268,266,NULL,NULL,'admin_add',78,79),(269,266,NULL,NULL,'admin_edit',80,81),(270,266,NULL,NULL,'admin_delete',82,83),(271,266,NULL,NULL,'view',84,85),(272,38,NULL,NULL,'Messages',87,96),(273,272,NULL,NULL,'admin_index',88,89),(274,272,NULL,NULL,'admin_edit',90,91),(275,272,NULL,NULL,'admin_delete',92,93),(276,272,NULL,NULL,'admin_process',94,95),(277,1,NULL,NULL,'ConnectionsCrises',472,483),(278,277,NULL,NULL,'index',473,474),(279,277,NULL,NULL,'view',475,476),(280,277,NULL,NULL,'add',477,478),(281,277,NULL,NULL,'edit',479,480),(282,277,NULL,NULL,'delete',481,482),(283,1,NULL,NULL,'Statuses',484,495),(284,283,NULL,NULL,'index',485,486),(285,283,NULL,NULL,'view',487,488),(286,283,NULL,NULL,'add',489,490),(287,283,NULL,NULL,'edit',491,492),(288,283,NULL,NULL,'delete',493,494),(289,260,NULL,NULL,'upload',469,470),(290,1,NULL,NULL,'FileUpload',496,497);
/*!40000 ALTER TABLE `acos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aros`
--

DROP TABLE IF EXISTS `aros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aros` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aros`
--

LOCK TABLES `aros` WRITE;
/*!40000 ALTER TABLE `aros` DISABLE KEYS */;
INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES (1,2,'Role',1,'Role-admin',3,8),(2,3,'Role',2,'Role-registered',2,9),(3,NULL,'Role',3,'Role-public',1,10),(4,1,'User',1,'techies',4,5),(5,1,'User',2,'admin',6,7);
/*!40000 ALTER TABLE `aros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aros_acos`
--

DROP TABLE IF EXISTS `aros_acos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aros_acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_read` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_update` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_delete` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aros_acos`
--

LOCK TABLES `aros_acos` WRITE;
/*!40000 ALTER TABLE `aros_acos` DISABLE KEYS */;
INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES (1,3,35,'1','1','1','1'),(2,3,36,'1','1','1','1'),(3,2,37,'1','1','1','1'),(5,3,125,'1','1','1','1'),(6,3,126,'1','1','1','1'),(7,3,127,'1','1','1','1'),(8,3,128,'1','1','1','1'),(9,3,129,'1','1','1','1'),(10,2,185,'1','1','1','1'),(11,3,186,'1','1','1','1'),(12,3,187,'1','1','1','1'),(13,2,188,'1','1','1','1'),(14,3,189,'1','1','1','1'),(15,3,190,'1','1','1','1'),(16,3,191,'1','1','1','1'),(17,2,192,'1','1','1','1'),(18,2,193,'1','1','1','1'),(19,3,183,'1','1','1','1'),(20,2,195,'-1','-1','-1','-1'),(21,2,196,'-1','-1','-1','-1'),(22,2,197,'-1','-1','-1','-1'),(23,2,198,'-1','-1','-1','-1'),(24,2,199,'-1','-1','-1','-1'),(25,3,195,'-1','-1','-1','-1'),(26,3,196,'-1','-1','-1','-1');
/*!40000 ALTER TABLE `aros_acos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocks` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `region_id` int(20) DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `show_title` tinyint(1) NOT NULL DEFAULT '1',
  `class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `element` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `visibility_roles` text COLLATE utf8_unicode_ci,
  `visibility_paths` text COLLATE utf8_unicode_ci,
  `visibility_php` text COLLATE utf8_unicode_ci,
  `params` text COLLATE utf8_unicode_ci,
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `block_alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks`
--

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
INSERT INTO `blocks` (`id`, `region_id`, `title`, `alias`, `body`, `show_title`, `class`, `status`, `weight`, `element`, `visibility_roles`, `visibility_paths`, `visibility_php`, `params`, `publish_start`, `publish_end`, `updated`, `updated_by`, `created`, `created_by`) VALUES (3,4,'About','about','This is the content of your block. Can be modified in admin panel.',1,'',1,2,'','','','','',NULL,NULL,'2009-12-20 03:07:39',NULL,'2009-07-26 17:13:14',NULL),(5,4,'Meta','meta','[menu:meta]',1,'',1,6,'','','','','',NULL,NULL,'2009-12-22 05:17:39',NULL,'2009-09-12 06:36:22',NULL),(6,4,'Blogroll','blogroll','[menu:blogroll]',1,'',1,4,'','','','','',NULL,NULL,'2009-12-20 03:07:33',NULL,'2009-09-12 23:33:27',NULL),(7,4,'Categories','categories','[vocabulary:categories type=\"blog\"]',1,'',1,3,'','','','','',NULL,NULL,'2009-12-20 03:07:36',NULL,'2009-10-03 16:52:50',NULL),(8,4,'Search','search','',0,'',1,1,'Nodes.search','','','','',NULL,NULL,'2009-12-20 03:07:39',NULL,'2009-12-20 03:07:27',NULL),(9,4,'Recent Posts','recent_posts','[node:recent_posts conditions=\"Node.type:blog\" order=\"Node.id DESC\" limit=\"5\"]',1,'',1,5,'','','','','',NULL,NULL,'2010-04-08 21:09:31',NULL,'2009-12-22 05:17:32',NULL);
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `model` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Node',
  `foreign_key` int(20) NOT NULL,
  `user_id` int(20) NOT NULL DEFAULT '0',
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `notify` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `comment_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'comment',
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_fk` (`model`,`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `connections`
--

DROP TABLE IF EXISTS `connections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(74) NOT NULL,
  `office_phone` varchar(24) DEFAULT NULL,
  `mobile_phone` varchar(24) DEFAULT NULL,
  `job_description` text,
  `email` varchar(74) DEFAULT NULL,
  `notes` text,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connections`
--

LOCK TABLES `connections` WRITE;
/*!40000 ALTER TABLE `connections` DISABLE KEYS */;
INSERT INTO `connections` (`id`, `name`, `office_phone`, `mobile_phone`, `job_description`, `email`, `notes`, `modified`, `created`) VALUES (2,'Patrick Swazy','98541021512','','In addition to launching new hardware, Samsung has updated its Multiroom app, as well. It now supports the Gear S, giving the smartwatch playback, volume and playlist control, and adds a screen that shows the list of available speakers to connect to. Samsung also promises that the revamped app makes it easier to share music across all WiFi connected devices in your home. All three models will be out in the US and Europe by the end of this year and will thankfully be more affordable than the R7, with prices ranging from $199 to $399. ','ram@google.com','dfsdfsdfsdf','2015-09-03 11:48:21','2015-08-26 10:38:27'),(3,'Evan Cooper','9851021326','9854124510','Samsung is releasing three new 360-degree wireless speakers -- the R1, R3 and R5, which it showed off at IFA this year -- as a follow-up to its Portal-esque R7 device. They\'re not quite egg-shaped like their predecessor (and its own predecessors), but they feature the same \"ring-radiator\" technology that helps them fill a room with sound. Plus, they now have a physical user interface on the top panel that allows users to quickly play, pause, adjust the volume and switch music sources.','email@google.com','Samsung is releasing three new 360-degree wireless speakers -- the R1, R3 and R5, which it showed off at IFA this year -- as a follow-up to its Portal-esque R7 device. They\'re not quite egg-shaped like their predecessor (and its own predecessors), but they feature the same \"ring-radiator\" technology that helps them fill a room with sound. Plus, they now have a physical user interface on the top panel that allows users to quickly play, pause, adjust the volume and switch music sources.','2015-08-26 14:02:56','2015-08-26 14:02:56'),(4,'Victoria Woo','9851200000','5412451000','In addition to launching new hardware, Samsung has updated its Multiroom app, as well. It now supports the Gear S, giving the smartwatch playback, volume and playlist control, and adds a screen that shows the list of available speakers to connect to. Samsung also promises that the revamped app makes it easier to share music across all WiFi connected devices in your home. All three models will be out in the US and Europe by the end of this year and will thankfully be more affordable than the R7, with prices ranging from $199 to $399. ','vic@kissaah.com','','2015-08-27 12:26:09','2015-08-27 12:26:09'),(5,'Pankaj Udas','9854102151','5212541252','In addition to launching new hardware, Samsung has updated its Multiroom app, as well. It now supports the Gear S, giving the smartwatch playback, volume and playlist control, and adds a screen that shows the list of available speakers to connect to. Samsung also promises that the revamped app makes it easier to share music across all WiFi connected devices in your home. All three models will be out in the US and Europe by the end of this year and will thankfully be more affordable than the R7, with prices ranging from $199 to $399. ','pankah@google.com','','2015-09-03 11:49:07','2015-08-27 12:26:49'),(6,'Owen Hunt','9512364575','9515151245','Owen Hunt is the Chief of Surgery at Grey Sloan Memorial Hospital. Entering the series, he immediately begins a relationship with Cristina Yang. Suffering from posttraumatic stress disorder, he has struggled with the horrors he experienced whilst serving with the army in Iraq. He invites a former colleague, Teddy Altman, to work alongside him, a decision which causes some friction between himself and Cristina. In the Season 7 premiere, he marries Cristina. After Webber resigns, he is given the position of chief. He and Cristina experience marital problems after his affair with a woman at a bar. They try to resolve it, but it eventually leads to their divorce. They do not end the relationship until season 9, episode 24, when she decides to let him go. In season 10, he starts a relationship with Emma Marling, an attending at Seattle Presbyterian. They break up and he starts to see Cristina again, but that ends when Cristina moves to Zurich.','email@google.com','','2015-08-27 12:28:38','2015-08-27 12:28:38'),(7,'Derek Shepherd','9851021326','5412451000','As Chief of Neurosurgery, Derek Shepherd earns the nickname \"McDreamy\" by the female staff of Seattle Grace. The lead male character, he is known for his complicated lovelife. He initially moves to Seattle from New York City to get away from his adulterous ex-wife Addison Montgomery, whom he discovered was having an affair with his best friend, Mark Sloan. He subsequently begins a long romance with Meredith Grey, which results in their marriage. He has a somewhat antagonistic relationship with Richard Webber, whom he believes isn\'t governing the hospital appropriately. He takes over as the Chief of Surgery after going to the hospital board about Chief Webber\'s drinking problem. He resigns after nearly dying from being shot because he thinks being chief isn\'t his place. He and Meredith adopt an orphan named Zola from Africa in Season 7. After surviving the plane crash in the Season 8 finale, he begins Season 9 recovering from his injured hand. His hand goes numb while he tries to grip one of the instruments before surgery. His son Bailey is born in the Season 9 finale. In season 10 Derek starts to work with the president, using his technology that he and Callie created. He wants to move to DC with his family, but Meredith says shes doesn\'t want to in the season finale. In season 11 episode 21 \"How To Save A Life\", he dies of a head injury after his car was T-Boned by a semi.','ram@google.com','','2015-09-03 11:47:09','2015-08-27 12:29:28'),(8,'Richard Webber','9851021326','9515151245','Authority figure and former Chief of Surgery at Seattle Grace, Richard has had a difficult past, characterized by affairs and alcoholism. His relationship with Meredith Grey is at times volatile because he had an affair with her mother. Richard has struggled with managing the finances of Seattle Grace and has merged the hospital with Mercy West Hospital. The merger has caused him a lot of stress, strained his relationship with Derek Shepherd and ultimately contributes to the collapse of his sobriety. He steps down as Chief of Surgery in Season 8. In the Season 9 premiere, it is Dr. Webber that pulls the plug on Mark Sloan. In the final episode of Season 9, Dr. Webber has been electrocuted and nobody knows that he is down in the basement till in season 10 he and Dr. Heather Brooks are found by Dr. Shane and they were able to save him but he has been hospitalized even though he had a lot of damage he is still alive.','pankah@google.com','','2015-08-27 12:29:51','2015-08-27 12:29:51');
/*!40000 ALTER TABLE `connections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `connections_crises`
--

DROP TABLE IF EXISTS `connections_crises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connections_crises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `connection_id` int(11) NOT NULL,
  `crisis_id` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connections_crises`
--

LOCK TABLES `connections_crises` WRITE;
/*!40000 ALTER TABLE `connections_crises` DISABLE KEYS */;
INSERT INTO `connections_crises` (`id`, `connection_id`, `crisis_id`, `modified`, `created`) VALUES (1,2,4,NULL,NULL),(2,7,7,NULL,NULL);
/*!40000 ALTER TABLE `connections_crises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `address2` text COLLATE utf8_unicode_ci,
  `state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postcode` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `message_status` tinyint(1) NOT NULL DEFAULT '1',
  `message_archive` tinyint(1) NOT NULL DEFAULT '1',
  `message_count` int(11) NOT NULL DEFAULT '0',
  `message_spam_protection` tinyint(1) NOT NULL DEFAULT '0',
  `message_captcha` tinyint(1) NOT NULL DEFAULT '0',
  `message_notify` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` (`id`, `title`, `alias`, `body`, `name`, `position`, `address`, `address2`, `state`, `country`, `postcode`, `phone`, `mobile_phone`, `fax`, `email`, `notes`, `message_status`, `message_archive`, `message_count`, `message_spam_protection`, `message_captcha`, `message_notify`, `status`, `updated`, `updated_by`, `created`, `created_by`) VALUES (1,'Contact','contact','','','','','','','','','',NULL,'','you@your-site.com',NULL,1,0,0,0,0,1,1,'2009-10-07 22:07:49',NULL,'2009-09-16 01:45:17',NULL);
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crises`
--

DROP TABLE IF EXISTS `crises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(54) NOT NULL,
  `category` varchar(54) NOT NULL,
  `severity` varchar(12) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crises`
--

LOCK TABLES `crises` WRITE;
/*!40000 ALTER TABLE `crises` DISABLE KEYS */;
INSERT INTO `crises` (`id`, `name`, `category`, `severity`, `user_id`, `modified`, `created`) VALUES (4,'Add Crises 1','Crisis Category','Severe',2,'2015-08-26 09:19:43','2015-07-09 10:18:00'),(7,'Second Crises','No category','no severity',2,'2015-08-26 09:56:42','2015-08-26 09:56:42');
/*!40000 ALTER TABLE `crises` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboards`
--

DROP TABLE IF EXISTS `dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboards` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `alias` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_id` int(20) NOT NULL DEFAULT '0',
  `column` int(20) NOT NULL DEFAULT '0',
  `weight` int(20) NOT NULL DEFAULT '0',
  `collapsed` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboards`
--

LOCK TABLES `dashboards` WRITE;
/*!40000 ALTER TABLE `dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feeds`
--

DROP TABLE IF EXISTS `feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `panic_room_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feeds`
--

LOCK TABLES `feeds` WRITE;
/*!40000 ALTER TABLE `feeds` DISABLE KEYS */;
INSERT INTO `feeds` (`id`, `post`, `user_id`, `panic_room_id`, `parent_id`, `modified`, `created`) VALUES (1,'Burger King has offered McDonald’s a golden opportunity to come together and make one burger to rule them all — in the name of world peace, of course.',2,1,NULL,'2015-08-26 12:44:46','2015-08-26 09:54:27'),(2,'This is another post for test purposes only. Please check it out.',2,1,NULL,'2015-08-26 12:41:00','2015-08-26 12:41:00'),(3,'In full-page ads running Wednesday in The New York Times and the Chicago Tribune – the hometown paper of the Illinois-based McDonald’s – the fast-food chain is proposing the “McWhopper,” a hybrid of each company’s signature Big Mac and Whopper burgers that will be sold for one day in one pop-up store in one city.',2,1,NULL,'2015-08-26 12:42:16','2015-08-26 12:42:16');
/*!40000 ALTER TABLE `feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `native` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` (`id`, `title`, `native`, `alias`, `status`, `weight`, `updated`, `updated_by`, `created`, `created_by`) VALUES (1,'English','English','eng',1,1,'2009-11-02 21:37:38',NULL,'2009-11-02 20:52:00',NULL);
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `menu_id` int(20) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `visibility_roles` text COLLATE utf8_unicode_ci,
  `params` text COLLATE utf8_unicode_ci,
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
INSERT INTO `links` (`id`, `parent_id`, `menu_id`, `title`, `class`, `description`, `link`, `target`, `rel`, `status`, `lft`, `rght`, `visibility_roles`, `params`, `publish_start`, `publish_end`, `updated`, `updated_by`, `created`, `created_by`) VALUES (5,NULL,4,'About','about','','plugin:nodes/controller:nodes/action:view/type:page/slug:about','','',1,3,4,'','',NULL,NULL,'2009-10-06 23:14:21',NULL,'2009-08-19 12:23:33',NULL),(6,NULL,4,'Contact','contact','','plugin:contacts/controller:contacts/action:view/contact','','',1,5,10,'','',NULL,NULL,'2009-10-06 23:14:45',NULL,'2009-08-19 12:34:56',NULL),(8,20,3,'Guía del usuario','guia-del-usuario','','plugin:nodes/controller:nodes/action:view/type:page/slug:guia-del-usuario','','',1,8,9,'','',NULL,NULL,'2015-07-09 04:28:36',1,'2009-09-06 21:34:57',NULL),(10,NULL,5,'Site Admin','site-admin','','/admin','','',1,1,2,'','',NULL,NULL,'2009-09-12 06:34:09',NULL,'2009-09-12 06:34:09',NULL),(11,NULL,5,'Log out','log-out','','/plugin:users/controller:users/action:logout','','',1,11,12,'[\"1\",\"2\"]','',NULL,NULL,'2009-09-12 06:35:22',NULL,'2009-09-12 06:34:41',NULL),(12,NULL,6,'Croogo','croogo','','http://www.croogo.org','','',1,3,4,'','',NULL,NULL,'2009-09-12 23:31:59',NULL,'2009-09-12 23:31:59',NULL),(14,NULL,6,'CakePHP','cakephp','','http://www.cakephp.org','','',1,1,2,'','',NULL,NULL,'2009-10-07 03:25:25',NULL,'2009-09-12 23:38:43',NULL),(16,NULL,5,'Entries (RSS)','entries-rss','','/promoted.rss','','',1,3,4,'','',NULL,NULL,'2009-10-27 17:46:22',NULL,'2009-10-27 17:46:22',NULL),(17,NULL,5,'Comments (RSS)','comments-rss','','/comments.rss','','',1,5,10,'','',NULL,NULL,'2009-10-27 17:46:54',NULL,'2009-10-27 17:46:54',NULL),(18,NULL,3,'Crisis','crisis','','controller:crises/action:index','','',1,17,18,'','',NULL,NULL,'2015-09-02 14:24:04',2,'2015-07-08 09:47:53',1),(20,NULL,3,'Manual de Crisis','manual-de-crisis','','javascript:;','','',1,7,14,'','',NULL,NULL,'2015-08-26 11:42:05',2,'2015-07-08 13:00:12',1),(21,20,3,'Procedimiento General','procedimiento-general','','plugin:nodes/controller:nodes/action:view/type:page/slug:procedimiento-general','','',1,10,11,'','',NULL,NULL,'2015-07-09 04:32:17',1,'2015-07-09 04:32:17',1),(22,20,3,'Objeto del manual','objeto-del-manual','','plugin:nodes/controller:nodes/action:view/type:page/slug:objeto-del-manual','','',1,12,13,'','',NULL,NULL,'2015-07-09 04:33:21',1,'2015-07-09 04:33:21',1),(23,NULL,3,'Stakeholders','stakeholders','','controller:connections/action:index','','',1,15,16,'','',NULL,NULL,'2015-08-27 07:52:13',2,'2015-07-09 10:45:17',1),(28,NULL,3,'Mensajes','mensajes','','/plugin:contacts/controller:contacts/action:view/contact','','',1,21,22,'','',NULL,NULL,'2015-08-26 09:12:33',2,'2015-07-09 10:49:14',1),(31,NULL,3,'Archivos','archivos','','javascript:;','','',1,19,20,'','',NULL,NULL,'2015-07-09 10:51:35',1,'2015-07-09 10:51:35',1),(32,NULL,3,'Tablero de Mando','tablero-de-mando','','plugin:nodes/controller:nodes/action:promoted','','',1,5,6,'','',NULL,NULL,'2015-09-02 17:10:43',2,'2015-08-26 09:08:03',2);
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `status` int(1) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `link_count` int(11) NOT NULL,
  `params` text COLLATE utf8_unicode_ci,
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menu_alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` (`id`, `title`, `alias`, `class`, `description`, `status`, `weight`, `link_count`, `params`, `publish_start`, `publish_end`, `updated`, `updated_by`, `created`, `created_by`) VALUES (3,'Main Menu','main','','',1,NULL,9,'',NULL,NULL,'2009-08-19 12:21:06',NULL,'2009-07-22 01:49:53',NULL),(4,'Footer','footer','','',1,NULL,2,'',NULL,NULL,'2009-08-19 12:22:42',NULL,'2009-08-19 12:22:42',NULL),(5,'Meta','meta','','',1,NULL,4,'',NULL,NULL,'2009-09-12 06:33:29',NULL,'2009-09-12 06:33:29',NULL),(6,'Blogroll','blogroll','','',1,NULL,2,'',NULL,NULL,'2009-09-12 23:30:24',NULL,'2009-09-12 23:30:24',NULL);
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci,
  `message_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta`
--

DROP TABLE IF EXISTS `meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Node',
  `foreign_key` int(20) DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `weight` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `created_by` int(20) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `updated_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta`
--

LOCK TABLES `meta` WRITE;
/*!40000 ALTER TABLE `meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_taxonomies`
--

DROP TABLE IF EXISTS `model_taxonomies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_taxonomies` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `model` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Node',
  `foreign_key` int(20) NOT NULL DEFAULT '0',
  `taxonomy_id` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_taxonomies`
--

LOCK TABLES `model_taxonomies` WRITE;
/*!40000 ALTER TABLE `model_taxonomies` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_taxonomies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodes`
--

DROP TABLE IF EXISTS `nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodes` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `user_id` int(20) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8_unicode_ci,
  `status` int(1) DEFAULT NULL,
  `mime_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_status` int(1) NOT NULL DEFAULT '1',
  `comment_count` int(11) DEFAULT '0',
  `promote` tinyint(1) NOT NULL DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `terms` text COLLATE utf8_unicode_ci,
  `sticky` tinyint(1) NOT NULL DEFAULT '0',
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `visibility_roles` text COLLATE utf8_unicode_ci,
  `type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'node',
  `publish_start` datetime DEFAULT NULL,
  `publish_end` datetime DEFAULT NULL,
  `updated` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodes`
--

LOCK TABLES `nodes` WRITE;
/*!40000 ALTER TABLE `nodes` DISABLE KEYS */;
INSERT INTO `nodes` (`id`, `parent_id`, `user_id`, `title`, `slug`, `body`, `excerpt`, `status`, `mime_type`, `comment_status`, `comment_count`, `promote`, `path`, `terms`, `sticky`, `lft`, `rght`, `visibility_roles`, `type`, `publish_start`, `publish_end`, `updated`, `updated_by`, `created`, `created_by`) VALUES (2,NULL,1,'Guía del usuario','guia-del-usuario','<div>\r\n<h2><strong>OBLIGACIONES DE LOS USUARIOS DEL MANUAL</strong></h2>\r\n\r\n<ul>\r\n	<li>Conocer en detalle sus contenidos</li>\r\n	<li>Seguir sus indicaciones en todo momento</li>\r\n	<li>Informar a la DG de Comunicaci&oacute;n Corporativa de cambios relacionados con su &aacute;mbito de actuaci&oacute;n que afecten al Manual: nuevas funciones profesionales, cambios normativos, nuevos protocolos internos o externos, datos de contacto internos o externos, etc.</li>\r\n</ul>\r\n\r\n<p>El &eacute;xito en la gesti&oacute;n de situaciones complejas que pueden afectar gravemente a la imagen p&uacute;blica de la compa&ntilde;&iacute;a depende del cumplimiento de los procedimientos y protocolos de este Manual</p>\r\n\r\n<h2><strong>CU&Aacute;NDO SE APLICA EL MANUAL</strong></h2>\r\n\r\n<p>El Manual de Gesti&oacute;n de la Comunicaci&oacute;n en Situaciones de Crisis debe utilizarse tan pronto como tengamos conocimiento de una incidencia o problema, siguiendo estos pasos:</p>\r\n\r\n<ol>\r\n	<li><strong>Valorar</strong>: conocer las caracter&iacute;sticas de la incidencia y determinar posibles factores que pudieran agravarla.</li>\r\n</ol>\r\n\r\n<p><span style=\"color: #ff6600;\"><em>En el punto XX encontrar&aacute; informaci&oacute;n detallada sobre los diferentes riesgos que afectan a su &aacute;rea de actuaci&oacute;n y una tabla que le ayudar&aacute; a hacer una correcta valoraci&oacute;n.</em></span></p>\r\n\r\n<ol start=\"2\">\r\n	<li><strong>Alertar</strong>: informar del hecho a las personas de la organizaci&oacute;n afectadas y/o responsables de la gesti&oacute;n de la incidencia.</li>\r\n</ol>\r\n\r\n<p><span style=\"color: #ff6600;\"><em>En el punto XX figura una tabla que explica a qui&eacute;n deber&aacute; trasladar la informaci&oacute;n en su organizaci&oacute;n.</em></span></p>\r\n\r\n<ol start=\"3\">\r\n	<li><strong>Controlar</strong>: estar pendientes de la evoluci&oacute;n del problema y registrar las novedades.</li>\r\n</ol>\r\n\r\n<p><span style=\"color: #ff6600;\"><em>En el punto XX se recogen las acciones a realizar y los procedimientos de control que debe cumplimentar. </em></span></p>\r\n</div>\r\n','',1,'',0,0,0,'/page/guia-del-usuario','',0,1,2,'','page',NULL,NULL,'2015-07-09 04:27:38',1,'2009-12-25 22:00:00',NULL),(3,NULL,1,'Objeto del manual','objeto-del-manual','<div>\r\n<h2><strong>FUNCI&Oacute;N DEL MANUAL DE CRISIS</strong></h2>\r\n\r\n<p>El Manual de Gesti&oacute;n de la Comunicaci&oacute;n en Situaciones de Crisis de Gas Natural Fenosa incorpora los protocolos de alerta y actuaci&oacute;n en situaciones de crisis adecuados a la organizaci&oacute;n territorial y a la diversificaci&oacute;n del negocio.</p>\r\n\r\n<ul>\r\n	<li>Responde a la exigencia de gesti&oacute;n responsable propia de la compa&ntilde;&iacute;a y compromete a la totalidad de la organizaci&oacute;n.</li>\r\n	<li>Establece las l&iacute;neas estrat&eacute;gicas y los protocolos de actuaci&oacute;n necesarios para dar respuesta a las necesidades de comunicaci&oacute;n en situaciones de crisis potenciales o reales.</li>\r\n	<li>Es complementario del Plan de Emergencia de la compa&ntilde;&iacute;a, que es la gu&iacute;a que fija el procedimiento para la resoluci&oacute;n t&eacute;cnica de los accidentes.</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>PRIORIDADES DE GNF EN UNA CRISIS</strong></h2>\r\n\r\n<p>Nuestras prioridades en la resoluci&oacute;n de una emergencia</p>\r\n\r\n<ol>\r\n	<li>Atenci&oacute;n a las v&iacute;ctimas y sus familiares</li>\r\n	<li>Puesta en seguridad de las instalaciones</li>\r\n	<li>Prevenci&oacute;n de potenciales da&ntilde;os personales</li>\r\n	<li>Gesti&oacute;n de la comunicaci&oacute;n con los diferentes p&uacute;blicos</li>\r\n</ol>\r\n</div>\r\n','',1,NULL,1,0,0,'/page/objeto-del-manual','',0,3,4,'','page',NULL,NULL,'2015-07-09 04:31:01',1,'2015-07-09 04:31:01',1),(4,NULL,1,'Procedimiento General','procedimiento-general','<p><a href=\"http://enacment-test.com/page/objeto-del-manual\">1. Objeto del Manual</a></p>\r\n\r\n<p><a href=\"http://enacment-test.com/page/guia-del-usuario\">2. Gu&iacute;a del Usuario</a></p>\r\n\r\n<p>3. Valoraci&oacute;n de la Incidencia</p>\r\n\r\n<p>4. Activaci&oacute;n de la Alerta</p>\r\n\r\n<p>5. Protocolos de Actuaci&oacute;n</p>\r\n','',1,NULL,1,0,0,'/page/procedimiento-general','',0,5,6,'','page',NULL,NULL,'2015-07-09 04:31:43',1,'2015-07-09 04:31:43',1),(5,NULL,0,'DSC01262','DSC01262.JPG','',NULL,NULL,'image/jpeg',1,0,0,'/uploads/DSC01262.JPG',NULL,0,1,2,NULL,'attachment',NULL,NULL,'2015-08-30 06:51:29',2,'2015-08-30 06:51:29',2);
/*!40000 ALTER TABLE `nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panic_rooms`
--

DROP TABLE IF EXISTS `panic_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `panic_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(54) NOT NULL,
  `description` text,
  `priority` varchar(10) DEFAULT NULL,
  `crisis_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panic_rooms`
--

LOCK TABLES `panic_rooms` WRITE;
/*!40000 ALTER TABLE `panic_rooms` DISABLE KEYS */;
INSERT INTO `panic_rooms` (`id`, `name`, `description`, `priority`, `crisis_id`, `user_id`, `modified`, `created`) VALUES (1,'First Panic Room','Kids to see his dad','151',4,2,'2015-08-26 09:32:07','2015-08-26 09:32:07'),(2,'Second Panic Room','create mode 100755\r\ncreate mode 100755\r\ncreate mode 100755\r\ncreate mode 100755\r\ncreate mode 100755\r\ncreate mode 100755','151',4,2,'2015-08-26 09:39:34','2015-08-26 09:39:34'),(3,'Third panic room','That city, Burger King is proposing, would be Atlanta, a meeting point between both company’s headquarters. The marketing stunt would be held on Sept. 21, with proceeds benefiting the anti-conflict nonprofit Peace One Day.','Severe',4,2,'2015-08-26 12:52:07','2015-08-26 12:50:01');
/*!40000 ALTER TABLE `panic_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regions`
--

DROP TABLE IF EXISTS `regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `block_count` int(11) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `created_by` int(20) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `updated_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `region_alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regions`
--

LOCK TABLES `regions` WRITE;
/*!40000 ALTER TABLE `regions` DISABLE KEYS */;
INSERT INTO `regions` (`id`, `title`, `alias`, `description`, `block_count`, `created`, `created_by`, `updated`, `updated_by`) VALUES (3,'none','none','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(4,'right','right','',6,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(6,'left','left','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(7,'header','header','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(8,'footer','footer','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(9,'region1','region1','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(10,'region2','region2','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(11,'region3','region3','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(12,'region4','region4','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(13,'region5','region5','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(14,'region6','region6','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(15,'region7','region7','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(16,'region8','region8','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(17,'region9','region9','',0,'2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL);
/*!40000 ALTER TABLE `regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `created_by` int(20) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `updated_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `title`, `alias`, `created`, `created_by`, `updated`, `updated_by`) VALUES (1,'Admin','admin','2009-04-05 00:10:34',NULL,'2009-04-05 00:10:34',NULL),(2,'Registered','registered','2009-04-05 00:10:50',NULL,'2009-04-06 05:20:38',NULL),(3,'Public','public','2009-04-05 00:12:38',NULL,'2009-04-07 01:41:45',NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_users`
--

DROP TABLE IF EXISTS `roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `granted_by` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pk_role_users` (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_users`
--

LOCK TABLES `roles_users` WRITE;
/*!40000 ALTER TABLE `roles_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` (`id`, `class`, `type`, `created`) VALUES (1,'InitMigrations','Migrations','2015-07-07 14:37:59'),(2,'ConvertVersionToClassNames','Migrations','2015-07-07 14:37:59'),(3,'IncreaseClassNameLength','Migrations','2015-07-07 14:37:59'),(4,'FirstMigrationSettings','Settings','2015-07-07 14:37:59'),(5,'SettingsTrackableFields','Settings','2015-07-07 14:38:01'),(6,'AddedAssetTimestampSetting','Settings','2015-07-07 14:38:01'),(7,'ExposeSiteThemeAndLocaleAndHomeUrl','Settings','2015-07-07 14:38:01'),(8,'FirstMigrationAcl','Acl','2015-07-07 14:38:02'),(9,'FirstMigrationBlocks','Blocks','2015-07-07 14:38:02'),(10,'BlocksTrackableFields','Blocks','2015-07-07 14:38:04'),(11,'BlocksPublishingFields','Blocks','2015-07-07 14:38:05'),(12,'FirstMigrationComments','Comments','2015-07-07 14:38:05'),(13,'CommentsTrackableFields','Comments','2015-07-07 14:38:06'),(14,'AddCommentsForeignKeys','Comments','2015-07-07 14:38:06'),(15,'FirstMigrationContacts','Contacts','2015-07-07 14:38:07'),(16,'ContactsTrackableFields','Contacts','2015-07-07 14:38:08'),(17,'FirstMigrationMenus','Menus','2015-07-07 14:38:08'),(18,'MenusTrackableFields','Menus','2015-07-07 14:38:10'),(19,'MenusPublishingFields','Menus','2015-07-07 14:38:11'),(20,'FirstMigrationMeta','Meta','2015-07-07 14:38:11'),(21,'MetaTrackableFields','Meta','2015-07-07 14:38:12'),(22,'FirstMigrationNodes','Nodes','2015-07-07 14:38:13'),(23,'NodesTrackableFields','Nodes','2015-07-07 14:38:13'),(24,'NodesPublishingFields','Nodes','2015-07-07 14:38:14'),(25,'FirstMigrationTaxonomy','Taxonomy','2015-07-07 14:38:15'),(26,'TaxonomyTrackableFields','Taxonomy','2015-07-07 14:38:17'),(27,'RenameNodesTaxonomy','Taxonomy','2015-07-07 14:38:17'),(28,'AddModelTaxonomyForeignKey','Taxonomy','2015-07-07 14:38:18'),(29,'AddWysisygEnableField','Taxonomy','2015-07-07 14:38:18'),(30,'FirstMigrationUsers','Users','2015-07-07 14:38:19'),(31,'UsersTrackableFields','Users','2015-07-07 14:38:20'),(32,'UsersEnlargeTimezone','Users','2015-07-07 14:38:20'),(33,'FirstMigrationDashboard','Dashboards','2015-07-07 14:38:20');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `key` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `editable` tinyint(1) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime DEFAULT NULL,
  `created_by` int(20) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `updated_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`id`, `key`, `value`, `title`, `description`, `input_type`, `editable`, `weight`, `params`, `created`, `created_by`, `updated`, `updated_by`) VALUES (6,'Site.title','War Room Digital','','','',1,1,'','2015-07-07 14:38:24',NULL,'2015-08-26 11:12:03',2),(7,'Site.tagline','','','','textarea',1,2,'','2015-07-07 14:38:24',NULL,'2015-08-26 11:12:03',2),(8,'Site.email','info@warroomdigital.co.mx','','','',1,3,'','2015-07-07 14:38:24',NULL,'2015-08-26 11:12:03',2),(9,'Site.status','1','','','checkbox',1,6,'','2015-07-07 14:38:24',NULL,'2015-08-26 11:12:03',2),(12,'Meta.robots','index, follow','','','',1,6,'','2015-07-07 14:38:24',NULL,'2015-07-07 14:38:24',NULL),(13,'Meta.keywords','croogo, Croogo','','','textarea',1,7,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(14,'Meta.description','Croogo - A CakePHP powered Content Management System','','','textarea',1,8,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(15,'Meta.generator','Croogo - Content Management System','','','',0,9,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(16,'Service.akismet_key','your-key','','','',1,11,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(17,'Service.recaptcha_public_key','your-public-key','','','',1,12,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(18,'Service.recaptcha_private_key','your-private-key','','','',1,13,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(19,'Service.akismet_url','http://your-blog.com','','','',1,10,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(20,'Site.theme','Metronic','','','',0,14,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',1),(21,'Site.feed_url','','','','',0,15,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(22,'Reading.nodes_per_page','5','','','',1,16,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(23,'Writing.wysiwyg','1','Enable WYSIWYG editor','','checkbox',1,17,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(24,'Comment.level','1','','levels deep (threaded comments)','',1,18,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(25,'Comment.feed_limit','10','','number of comments to show in feed','',1,19,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(26,'Site.locale','eng','','','text',1,20,'','2015-07-07 14:38:25',NULL,'2015-08-26 11:12:03',2),(27,'Reading.date_time_format','D, M d Y H:i:s','','','',1,21,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(28,'Comment.date_time_format','M d, Y','','','',1,22,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(29,'Site.timezone','UTC','','Provide a valid timezone identifier as specified in https://php.net/manual/en/timezones.php','',1,4,'','2015-07-07 14:38:25',NULL,'2015-08-26 11:12:03',2),(32,'Hook.bootstraps','Settings,Comments,Contacts,Nodes,Meta,Menus,Users,Blocks,Taxonomy,FileManager,Wysiwyg,Ckeditor','','','',0,23,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(33,'Comment.email_notification','1','Enable email notification','','checkbox',1,24,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(34,'Access Control.multiRole','0','Enable Multiple Roles','','checkbox',1,25,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(35,'Access Control.rowLevel','0','Row Level Access Control','','checkbox',1,26,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(36,'Access Control.autoLoginDuration','+1 week','\"Remember Me\" Duration','Eg: +1 day, +1 week. Leave empty to disable.','text',1,27,'','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(37,'Access Control.models','','Models with Row Level Acl','Select models to activate Row Level Access Control on','multiple',1,26,'multiple=checkbox\noptions={\"Nodes.Node\": \"Node\", \"Blocks.Block\": \"Block\", \"Menus.Menu\": \"Menu\", \"Menus.Link\": \"Link\"}','2015-07-07 14:38:25',NULL,'2015-07-07 14:38:25',NULL),(38,'Site.ipWhitelist','127.0.0.1','Whitelisted IP Addresses','Separate multiple IP addresses with comma','text',1,27,'','2015-07-07 14:38:25',NULL,'2015-08-26 11:12:03',2),(39,'Site.asset_timestamp','1','Asset timestamp','Appends a timestamp which is last modified time of the particular file at the end of asset files URLs (CSS, JavaScript, Image). Useful to prevent visitors to visit the site with an outdated version of these files in their browser cache.','radio',1,28,'options={\"0\": \"Disabled\", \"1\": \"Enabled in debug mode only\", \"force\": \"Always enabled\"}','2015-07-07 14:38:25',NULL,'2015-08-26 11:12:03',2),(40,'Site.admin_theme','','Administration Theme','','text',1,29,'','2015-07-07 14:38:25',NULL,'2015-08-26 11:12:03',2),(41,'Site.home_url','controller:crises/action:view','Home Url','Default action for home page in link string format.','text',1,30,'','2015-07-07 14:38:25',NULL,'2015-08-26 11:12:03',2),(42,'Croogo.installed','1','','','',0,31,'','2015-07-07 14:39:34',NULL,'2015-07-07 14:39:34',NULL),(43,'Croogo.version','2.2.2','','','',0,32,'','2015-07-07 14:40:12',1,'2015-07-07 14:40:12',1);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statuses`
--

DROP TABLE IF EXISTS `statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(54) NOT NULL,
  `level` varchar(54) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statuses`
--

LOCK TABLES `statuses` WRITE;
/*!40000 ALTER TABLE `statuses` DISABLE KEYS */;
INSERT INTO `statuses` (`id`, `name`, `level`, `modified`, `created`) VALUES (1,'Assigned','1','2015-08-26 11:31:18','2015-08-26 11:31:18'),(2,'In Progress','1','2015-08-26 13:31:00','2015-08-26 13:30:36');
/*!40000 ALTER TABLE `statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(54) NOT NULL,
  `panic_room_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `status_id` int(11) NOT NULL,
  `priority` varchar(54) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` (`id`, `name`, `panic_room_id`, `user_id`, `start_date`, `due_date`, `status_id`, `priority`, `modified`, `created`) VALUES (1,'My Task 2',1,2,'2015-09-03','2015-09-05',1,'Major','2015-08-26 13:27:15','2015-08-26 11:31:49'),(2,'Create a new folder',1,2,'2015-09-27','2015-09-30',2,'Very important','2015-08-26 13:31:34','2015-08-26 13:00:23');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxonomies`
--

DROP TABLE IF EXISTS `taxonomies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxonomies` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `term_id` int(10) NOT NULL,
  `vocabulary_id` int(10) NOT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxonomies`
--

LOCK TABLES `taxonomies` WRITE;
/*!40000 ALTER TABLE `taxonomies` DISABLE KEYS */;
INSERT INTO `taxonomies` (`id`, `parent_id`, `term_id`, `vocabulary_id`, `lft`, `rght`) VALUES (1,NULL,1,1,1,2),(2,NULL,2,1,3,4),(3,NULL,3,2,1,2);
/*!40000 ALTER TABLE `taxonomies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terms`
--

DROP TABLE IF EXISTS `terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terms` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terms`
--

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
INSERT INTO `terms` (`id`, `title`, `slug`, `description`, `updated`, `updated_by`, `created`, `created_by`) VALUES (1,'Uncategorized','uncategorized','','2009-07-22 03:38:43',NULL,'2009-07-22 03:34:56',NULL),(2,'Announcements','announcements','','2010-05-16 23:57:06',NULL,'2009-07-22 03:45:37',NULL),(3,'mytag','mytag','','2009-08-26 14:42:43',NULL,'2009-08-26 14:42:43',NULL);
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `types`
--

DROP TABLE IF EXISTS `types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `types` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `format_show_author` tinyint(1) NOT NULL DEFAULT '1',
  `format_show_date` tinyint(1) NOT NULL DEFAULT '1',
  `format_use_wysiwyg` tinyint(1) NOT NULL DEFAULT '1',
  `comment_status` int(1) NOT NULL DEFAULT '1',
  `comment_approve` tinyint(1) NOT NULL DEFAULT '1',
  `comment_spam_protection` tinyint(1) NOT NULL DEFAULT '0',
  `comment_captcha` tinyint(1) NOT NULL DEFAULT '0',
  `params` text COLLATE utf8_unicode_ci,
  `plugin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `types`
--

LOCK TABLES `types` WRITE;
/*!40000 ALTER TABLE `types` DISABLE KEYS */;
INSERT INTO `types` (`id`, `title`, `alias`, `description`, `format_show_author`, `format_show_date`, `format_use_wysiwyg`, `comment_status`, `comment_approve`, `comment_spam_protection`, `comment_captcha`, `params`, `plugin`, `updated`, `updated_by`, `created`, `created_by`) VALUES (1,'Page','page','A page is a simple method for creating and displaying information that rarely changes, such as an \"About us\" section of a website. By default, a page entry does not allow visitor comments.',0,0,1,0,1,0,0,'',NULL,'2009-09-09 00:23:24',NULL,'2009-09-02 18:06:27',NULL),(2,'Blog','blog','A blog entry is a single post to an online journal, or blog.',1,1,1,2,1,0,0,'',NULL,'2009-09-15 12:15:43',NULL,'2009-09-02 18:20:44',NULL),(4,'Node','node','Default content type.',1,1,1,2,1,0,0,'',NULL,'2009-10-06 21:53:15',NULL,'2009-09-05 23:51:56',NULL);
/*!40000 ALTER TABLE `types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `types_vocabularies`
--

DROP TABLE IF EXISTS `types_vocabularies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `types_vocabularies` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type_id` int(10) NOT NULL,
  `vocabulary_id` int(10) NOT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `types_vocabularies`
--

LOCK TABLES `types_vocabularies` WRITE;
/*!40000 ALTER TABLE `types_vocabularies` DISABLE KEYS */;
INSERT INTO `types_vocabularies` (`id`, `type_id`, `vocabulary_id`, `weight`) VALUES (24,4,1,NULL),(25,4,2,NULL),(30,2,1,NULL),(31,2,2,NULL);
/*!40000 ALTER TABLE `types_vocabularies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploads`
--

DROP TABLE IF EXISTS `uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreign_key` int(11) DEFAULT NULL,
  `caption` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploads`
--

LOCK TABLES `uploads` WRITE;
/*!40000 ALTER TABLE `uploads` DISABLE KEYS */;
INSERT INTO `uploads` (`id`, `model`, `field`, `foreign_key`, `caption`, `name`, `type`, `size`, `created`, `modified`, `created_by`) VALUES (1,'Connection','Avatar',7,'Derek Shepherd','derek-shepherd.jpg','image/jpeg',16101,'2015-09-03 11:47:09','2015-09-03 11:47:09',NULL),(2,'Connection','Avatar',2,'Patrick Swazy','patrick-swazy.jpg','image/jpeg',13118,'2015-09-03 11:48:21','2015-09-03 11:48:21',NULL),(3,'Connection','Avatar',5,'Pankaj Udas','pankaj-udas.jpg','image/jpeg',8870,'2015-09-03 11:49:07','2015-09-03 11:49:07',NULL);
/*!40000 ALTER TABLE `uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `username` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activation_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `timezone` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `role_id`, `username`, `password`, `name`, `email`, `website`, `activation_key`, `image`, `bio`, `status`, `updated`, `updated_by`, `created`, `timezone`, `created_by`) VALUES (1,1,'techies','f5026d4ec820942a205ff8372646cf8c76c80e6b','techies','bob@himalayantechies.com','','e98c21c3ea75116abb09f0d02097efee',NULL,NULL,1,'2015-07-09 16:00:05',1,'2015-07-07 14:39:34','',NULL),(2,1,'admin','3eb8450257cfa18711dd5cdca66e4a8b94cb90d8','Administrator','info@enamecent.com','','ff6fbecbd172d08b7989c7e50fe5605a',NULL,NULL,1,'2015-07-09 15:59:47',1,'2015-07-09 15:59:24','',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabularies`
--

DROP TABLE IF EXISTS `vocabularies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabularies` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `multiple` tinyint(1) NOT NULL DEFAULT '0',
  `tags` tinyint(1) NOT NULL DEFAULT '0',
  `plugin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `updated_by` int(20) DEFAULT NULL,
  `created` datetime NOT NULL,
  `created_by` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vocabulary_alias` (`alias`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabularies`
--

LOCK TABLES `vocabularies` WRITE;
/*!40000 ALTER TABLE `vocabularies` DISABLE KEYS */;
INSERT INTO `vocabularies` (`id`, `title`, `alias`, `description`, `required`, `multiple`, `tags`, `plugin`, `weight`, `updated`, `updated_by`, `created`, `created_by`) VALUES (1,'Categories','categories','',0,1,0,NULL,1,'2010-05-17 20:03:11',NULL,'2009-07-22 02:16:21',NULL),(2,'Tags','tags','',0,1,0,NULL,2,'2010-05-17 20:03:11',NULL,'2009-07-22 02:16:34',NULL);
/*!40000 ALTER TABLE `vocabularies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'llorente_warroomdigital'
--

--
-- Dumping routines for database 'llorente_warroomdigital'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-09-04  0:38:48
